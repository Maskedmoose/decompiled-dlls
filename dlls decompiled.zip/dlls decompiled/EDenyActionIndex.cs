﻿using System;

// Token: 0x020000E2 RID: 226
public enum EDenyActionIndex
{
	// Token: 0x04000AA4 RID: 2724
	None,
	// Token: 0x04000AA5 RID: 2725
	NotEnoughMoney,
	// Token: 0x04000AA6 RID: 2726
	NotEnoughGem,
	// Token: 0x04000AA7 RID: 2727
	NotEnoughFame,
	// Token: 0x04000AA8 RID: 2728
	NotEnoughBuilder,
	// Token: 0x04000AA9 RID: 2729
	NotEnoughMainCounterLevel,
	// Token: 0x04000AAA RID: 2730
	RestockerOutDelivery,
	// Token: 0x04000AAB RID: 2731
	RestockerUpgrading,
	// Token: 0x04000AAC RID: 2732
	MaxObjectCount,
	// Token: 0x04000AAD RID: 2733
	MaxLevel,
	// Token: 0x04000AAE RID: 2734
	AnotherItemUpgrading,
	// Token: 0x04000AAF RID: 2735
	RequireBuildAllObjectFirst,
	// Token: 0x04000AB0 RID: 2736
	WaitServerCallback
}
