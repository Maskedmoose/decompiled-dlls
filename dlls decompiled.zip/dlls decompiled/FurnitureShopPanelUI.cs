﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000067 RID: 103
public class FurnitureShopPanelUI : UIElementBase
{
	// Token: 0x0600045C RID: 1116 RVA: 0x000260EC File Offset: 0x000242EC
	public void Init(FurnitureShopUIScreen furnitureShopUIScreen, int index)
	{
		this.m_FurnitureShopUIScreen = furnitureShopUIScreen;
		this.m_Index = index;
		FurniturePurchaseData furniturePurchaseData = InventoryBase.GetFurniturePurchaseData(index);
		if (CSingleton<CGameManager>.Instance.m_IsPrologue && index > 5)
		{
			this.m_UIGrp.SetActive(false);
			this.m_PrologueUIGrp.SetActive(true);
		}
		if (this.m_LevelRequirementString == "")
		{
			this.m_LevelRequirementString = this.m_LevelRequirementText.text;
		}
		this.m_LevelRequired = furniturePurchaseData.levelRequirement;
		if (CPlayerData.m_ShopLevel + 1 >= this.m_LevelRequired)
		{
			this.m_LevelRequirementText.gameObject.SetActive(false);
			this.m_CompanyTitle.gameObject.SetActive(true);
			this.m_LockPurchaseBtn.gameObject.SetActive(false);
		}
		else
		{
			this.m_LevelRequirementText.text = LocalizationManager.GetTranslation(this.m_LevelRequirementString, true, 0, true, false, null, null, true).Replace("XXX", this.m_LevelRequired.ToString());
			this.m_LevelRequirementText.gameObject.SetActive(true);
			this.m_CompanyTitle.gameObject.SetActive(false);
			this.m_LockPurchaseBtn.gameObject.SetActive(true);
		}
		this.m_Image.sprite = furniturePurchaseData.icon;
		this.m_NameText.text = furniturePurchaseData.GetName();
		this.m_PriceText.text = GameInstance.GetPriceString(furniturePurchaseData.price, false, true, false, "F2");
	}

	// Token: 0x0600045D RID: 1117 RVA: 0x0002624E File Offset: 0x0002444E
	public override void OnPressButton()
	{
		if (CPlayerData.m_ShopLevel + 1 >= this.m_LevelRequired)
		{
			this.m_FurnitureShopUIScreen.OnPressPanelUIButton(this.m_Index);
		}
	}

	// Token: 0x04000561 RID: 1377
	public Image m_Image;

	// Token: 0x04000562 RID: 1378
	public TextMeshProUGUI m_NameText;

	// Token: 0x04000563 RID: 1379
	public TextMeshProUGUI m_PriceText;

	// Token: 0x04000564 RID: 1380
	public TextMeshProUGUI m_LevelRequirementText;

	// Token: 0x04000565 RID: 1381
	public GameObject m_CompanyTitle;

	// Token: 0x04000566 RID: 1382
	public GameObject m_LockPurchaseBtn;

	// Token: 0x04000567 RID: 1383
	public GameObject m_PrologueUIGrp;

	// Token: 0x04000568 RID: 1384
	private FurnitureShopUIScreen m_FurnitureShopUIScreen;

	// Token: 0x04000569 RID: 1385
	private int m_Index;

	// Token: 0x0400056A RID: 1386
	private int m_LevelRequired;

	// Token: 0x0400056B RID: 1387
	private string m_LevelRequirementString = "";
}
