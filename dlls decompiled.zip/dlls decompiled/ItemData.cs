﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;

// Token: 0x02000031 RID: 49
[Serializable]
public class ItemData
{
	// Token: 0x060002A0 RID: 672 RVA: 0x000197C5 File Offset: 0x000179C5
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true);
	}

	// Token: 0x060002A1 RID: 673 RVA: 0x000197DC File Offset: 0x000179DC
	public float GetItemVolume()
	{
		if (this.isTallItem)
		{
			return this.itemDimension.x * this.itemDimension.y * this.itemDimension.z * 2f;
		}
		return this.itemDimension.x * this.itemDimension.y * this.itemDimension.z;
	}

	// Token: 0x040002FC RID: 764
	public string name;

	// Token: 0x040002FD RID: 765
	public Sprite icon;

	// Token: 0x040002FE RID: 766
	public float iconScale;

	// Token: 0x040002FF RID: 767
	public float baseCost;

	// Token: 0x04000300 RID: 768
	public float marketPriceMinPercent;

	// Token: 0x04000301 RID: 769
	public float marketPriceMaxPercent;

	// Token: 0x04000302 RID: 770
	public EItemType boxFollowItemPrice;

	// Token: 0x04000303 RID: 771
	public bool isNotBoosterPack;

	// Token: 0x04000304 RID: 772
	public bool isTallItem;

	// Token: 0x04000305 RID: 773
	public bool isHideItemUntilUnlocked;

	// Token: 0x04000306 RID: 774
	public float posYOffsetInBox;

	// Token: 0x04000307 RID: 775
	public float scaleOffsetInBox;

	// Token: 0x04000308 RID: 776
	public Vector3 itemDimension;

	// Token: 0x04000309 RID: 777
	public Vector3 colliderPosOffset;

	// Token: 0x0400030A RID: 778
	public Vector3 colliderScale;

	// Token: 0x0400030B RID: 779
	public List<EPriceChangeType> affectedPriceChangeType;
}
