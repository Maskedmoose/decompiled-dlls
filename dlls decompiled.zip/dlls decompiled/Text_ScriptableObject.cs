﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000136 RID: 310
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 6)]
public class Text_ScriptableObject : ScriptableObject
{
	// Token: 0x060008EC RID: 2284 RVA: 0x00041314 File Offset: 0x0003F514
	public string GetRandomName()
	{
		int num = Mathf.Clamp(Random.Range(-4, 4), 1, 3);
		int num2 = Random.Range(0, 100);
		int num3 = Random.Range(0, 100);
		List<string> randomName = this.m_RandomName1;
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		List<string> list3 = new List<string>();
		string text = "";
		string text2 = "";
		if (num >= 1)
		{
			if (Random.Range(0, 2) == 0)
			{
				list = this.m_RandomName2;
			}
			else
			{
				list = this.m_RandomName3;
			}
		}
		if (num >= 2)
		{
			if (Random.Range(0, 2) == 0)
			{
				list2 = this.m_RandomName2;
			}
			else
			{
				list2 = this.m_RandomName3;
			}
		}
		if (num >= 3)
		{
			if (Random.Range(0, 2) == 0)
			{
				list3 = this.m_RandomName2;
			}
			else
			{
				list3 = this.m_RandomName3;
			}
		}
		if (num2 < 15)
		{
			text = Random.Range(0, 10000).ToString();
		}
		if (num3 < 15)
		{
			if (Random.Range(0, 2) == 0)
			{
				int index = Random.Range(0, this.m_RandomName2.Count);
				text2 = this.m_RandomName2[index];
			}
			else
			{
				int index2 = Random.Range(0, this.m_RandomName3.Count);
				text2 = this.m_RandomName3[index2];
			}
		}
		int index3 = Random.Range(0, randomName.Count);
		int index4 = Random.Range(0, list.Count);
		int index5 = Random.Range(0, list2.Count);
		int index6 = Random.Range(0, list3.Count);
		string text3 = text2;
		if (randomName.Count > 0)
		{
			text3 += randomName[index3];
		}
		if (list.Count > 0)
		{
			text3 += list[index4];
		}
		if (list2.Count > 0)
		{
			text3 += list2[index5];
		}
		if (list3.Count > 0)
		{
			text3 += list3[index6];
		}
		if (text != "")
		{
			text3 += text;
		}
		if (!char.IsUpper(text3[0]) && Random.Range(0, 100) < 30)
		{
			text3 = char.ToUpper(text3[0]).ToString() + text3.Substring(1);
		}
		return text3;
	}

	// Token: 0x040010F1 RID: 4337
	public List<string> m_RandomName1;

	// Token: 0x040010F2 RID: 4338
	public List<string> m_RandomName2;

	// Token: 0x040010F3 RID: 4339
	public List<string> m_RandomName3;

	// Token: 0x040010F4 RID: 4340
	public List<string> m_CardExpansionNameList;

	// Token: 0x040010F5 RID: 4341
	public List<Material> m_CurrencyMaterialList;

	// Token: 0x040010F6 RID: 4342
	public List<PriceChangeTypeText> m_PriceChangeTypeTextList;

	// Token: 0x040010F7 RID: 4343
	public List<Sprite> m_GamepadCtrlBtnSpriteList;

	// Token: 0x040010F8 RID: 4344
	public List<Sprite> m_XBoxCtrlBtnSpriteList;

	// Token: 0x040010F9 RID: 4345
	public List<Sprite> m_PSCtrlBtnSpriteList;

	// Token: 0x040010FA RID: 4346
	public Sprite m_KeyboardBtnImage;

	// Token: 0x040010FB RID: 4347
	public Sprite m_LeftMouseClickImage;

	// Token: 0x040010FC RID: 4348
	public Sprite m_RightMouseClickImage;

	// Token: 0x040010FD RID: 4349
	public Sprite m_LeftMouseHoldImage;

	// Token: 0x040010FE RID: 4350
	public Sprite m_RightMouseHoldImage;

	// Token: 0x040010FF RID: 4351
	public Sprite m_MiddleMouseScrollImage;

	// Token: 0x04001100 RID: 4352
	public Sprite m_EnterImage;

	// Token: 0x04001101 RID: 4353
	public Sprite m_SpacebarImage;

	// Token: 0x04001102 RID: 4354
	public Sprite m_TabImage;

	// Token: 0x04001103 RID: 4355
	public Sprite m_ShiftImage;

	// Token: 0x04001104 RID: 4356
	public Sprite m_QuestionMarkImage;
}
