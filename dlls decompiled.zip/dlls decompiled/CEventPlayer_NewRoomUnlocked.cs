﻿using System;

// Token: 0x020000BF RID: 191
public class CEventPlayer_NewRoomUnlocked : CEvent
{
}
