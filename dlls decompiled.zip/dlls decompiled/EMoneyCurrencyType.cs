﻿using System;

// Token: 0x020000E6 RID: 230
public enum EMoneyCurrencyType
{
	// Token: 0x04000B14 RID: 2836
	None = -1,
	// Token: 0x04000B15 RID: 2837
	USD,
	// Token: 0x04000B16 RID: 2838
	Euro,
	// Token: 0x04000B17 RID: 2839
	Yen,
	// Token: 0x04000B18 RID: 2840
	GBP,
	// Token: 0x04000B19 RID: 2841
	CNY
}
