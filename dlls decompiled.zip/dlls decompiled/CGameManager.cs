﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x020000A8 RID: 168
public class CGameManager : CSingleton<CGameManager>
{
	// Token: 0x17000006 RID: 6
	// (get) Token: 0x060006BD RID: 1725 RVA: 0x00037794 File Offset: 0x00035994
	// (set) Token: 0x060006BE RID: 1726 RVA: 0x0003779B File Offset: 0x0003599B
	public static Transform Player
	{
		get
		{
			return CGameManager.m_Player;
		}
		set
		{
			CGameManager.m_Player = value;
		}
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x060006BF RID: 1727 RVA: 0x000377A3 File Offset: 0x000359A3
	// (set) Token: 0x060006C0 RID: 1728 RVA: 0x000377AA File Offset: 0x000359AA
	public static float TotalGameSceneTime
	{
		get
		{
			return CGameManager.m_TotalGameSceneTime;
		}
		set
		{
			CGameManager.m_TotalGameSceneTime = value;
		}
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x060006C1 RID: 1729 RVA: 0x000377B2 File Offset: 0x000359B2
	public static double TimePassed
	{
		get
		{
			return CGameManager.m_TimePassed;
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x060006C2 RID: 1730 RVA: 0x000377B9 File Offset: 0x000359B9
	// (set) Token: 0x060006C3 RID: 1731 RVA: 0x000377C0 File Offset: 0x000359C0
	public static double TotalTimePassed
	{
		get
		{
			return CGameManager.m_TotalTimePassed;
		}
		set
		{
			CGameManager.m_TotalTimePassed = value;
		}
	}

	// Token: 0x060006C4 RID: 1732 RVA: 0x000377C8 File Offset: 0x000359C8
	private void Start()
	{
		this.m_LockItemLabel = true;
		this.Init();
	}

	// Token: 0x060006C5 RID: 1733 RVA: 0x000377D8 File Offset: 0x000359D8
	private void Awake()
	{
		if (CGameManager.m_Instance == null)
		{
			CGameManager.m_Instance = this;
		}
		else if (CGameManager.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
		this.m_GameData = CGameData.instance;
		if (PlayerPrefs.HasKey("ResetGame") && PlayerPrefs.GetInt("ResetGame") == 1)
		{
			CSaveLoad.Delete();
			PlayerPrefs.SetInt("ResetGame", 0);
		}
		this.m_LastPauseDateTime = DateTime.UtcNow;
	}

	// Token: 0x060006C6 RID: 1734 RVA: 0x00037858 File Offset: 0x00035A58
	private void OnLevelFinishedLoading(Scene scene, LoadSceneMode mode)
	{
		LoadingScreen.CloseScreen();
		if (scene.name == "Title")
		{
			this.m_IsGameLevel = false;
			SoundManager.BlendToMusic("BGM_Silence", 1f, true);
			CSingleton<LoadingScreen>.Instance.FinishLoading();
		}
		else
		{
			this.m_IsGameLevel = true;
		}
		InputManager.OnLevelFinishedLoading();
		if (CGameManager.m_InitLoaded || scene.name == "Title")
		{
			return;
		}
		if (PlayerPrefs.HasKey("ResetGame") && PlayerPrefs.GetInt("ResetGame") == 1)
		{
			CSaveLoad.Delete();
			PlayerPrefs.SetInt("ResetGame", 0);
		}
		if (this.m_LoadGameIndex != -1 && this.m_IsGameLevel)
		{
			this.m_LoadGameIndex = -1;
			base.StartCoroutine(this.LoadDelay());
			return;
		}
		if (this.m_IsGameLevel)
		{
			CSingleton<ShelfManager>.Instance.m_FinishLoadingObjectData = true;
			GameInstance.m_SaveFileNotFound = true;
			CPlayerData.CreateDefaultData(false);
			CGameManager.m_InitLoaded = true;
			CEventManager.QueueEvent(new CEventPlayer_GameDataFinishLoaded());
			CSingleton<LoadingScreen>.Instance.FinishLoading();
			GameInstance.m_FinishedSavefileLoading = true;
		}
	}

	// Token: 0x060006C7 RID: 1735 RVA: 0x00037958 File Offset: 0x00035B58
	private void Update()
	{
		bool developerModeEnabled = this.m_DeveloperModeEnabled;
		CGameManager.m_TotalGameSceneTime += Time.deltaTime;
		CGameManager.m_TotalTimePassed += (double)Time.deltaTime;
		CGameManager.m_TutorialManagerTimer += Time.deltaTime;
		CGameManager.m_TutorialSubGrpTimer += Time.deltaTime;
		CGameManager.m_ForceSyncCloudResetTimer += Time.deltaTime;
		this.m_SecondTimer += Time.deltaTime;
		if (this.m_SecondTimer >= 1f)
		{
			this.m_SecondTimer -= 1f;
		}
		this.m_MinuteTimer += Time.deltaTime;
		if (this.m_MinuteTimer >= 60f)
		{
			this.m_MinuteTimer = 0f;
		}
		if (this.m_EnableScreenshotTaking && (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.V)))
		{
			ScreenCapture.CaptureScreenshot(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/Screenshots/" + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") + ".png", this.m_ScreenshotScaling);
		}
		if (CGameManager.m_HasSavedGame)
		{
			CGameManager.m_HasSavedGameTimer += Time.deltaTime;
			if (CGameManager.m_HasSavedGameTimer > 5f)
			{
				CGameManager.m_HasSavedGameTimer = 0f;
				CGameManager.m_HasSavedGame = false;
			}
		}
		if (CGameManager.m_HasSavedBackupGame)
		{
			CGameManager.m_HasSavedBackupGameTimer += Time.deltaTime;
			if (CGameManager.m_HasSavedBackupGameTimer > 5f)
			{
				CGameManager.m_HasSavedBackupGameTimer = 0f;
				CGameManager.m_HasSavedBackupGame = false;
			}
		}
		if (!this.m_CanSaveGame)
		{
			this.m_CanSaveGameTimer += Time.deltaTime;
			if (this.m_CanSaveGameTimer >= 300f)
			{
				this.m_CanSaveGame = true;
				this.m_CanSaveGameTimer = 0f;
			}
		}
	}

	// Token: 0x060006C8 RID: 1736 RVA: 0x00037B03 File Offset: 0x00035D03
	private void FixedUpdate()
	{
	}

	// Token: 0x060006C9 RID: 1737 RVA: 0x00037B05 File Offset: 0x00035D05
	private IEnumerator LoadDelay()
	{
		yield return new WaitForSeconds(0.0001f);
		if (!CGameManager.m_InitLoaded)
		{
			this.LoadData();
		}
		yield return new WaitForSeconds(0.1f);
		CGameManager.m_InitLoaded = true;
		if (PlayerPrefs.HasKey("HasFinishedTutorial"))
		{
			if ((!CPlayerData.m_HasFinishedTutorial || PlayerPrefs.GetInt("HasFinishedTutorial") != 1) && (CPlayerData.m_HasFinishedTutorial || PlayerPrefs.GetInt("HasFinishedTutorial") != 0))
			{
				CPlayerData.m_CanCloudLoad = true;
			}
		}
		else if (CPlayerData.m_HasFinishedTutorial)
		{
			PlayerPrefs.SetInt("HasFinishedTutorial", 1);
		}
		yield break;
	}

	// Token: 0x060006CA RID: 1738 RVA: 0x00037B14 File Offset: 0x00035D14
	private void Init()
	{
		CGameManager.m_TotalGameSceneTime = 0f;
	}

	// Token: 0x060006CB RID: 1739 RVA: 0x00037B20 File Offset: 0x00035D20
	private void LoadData()
	{
		if (CSaveLoad.Load())
		{
			CGameData.instance.PropagateLoadData(CSaveLoad.m_SavedGame);
			return;
		}
		this.LoadBackupData();
	}

	// Token: 0x060006CC RID: 1740 RVA: 0x00037B3F File Offset: 0x00035D3F
	private IEnumerator changeFramerate()
	{
		yield return new WaitForSeconds(1f);
		Application.targetFrameRate = 30;
		Application.runInBackground = false;
		yield break;
	}

	// Token: 0x060006CD RID: 1741 RVA: 0x00037B47 File Offset: 0x00035D47
	private new void OnApplicationQuit()
	{
		CGameManager.m_HasSavedGame = false;
		GameInstance.m_CurrentSceneIndex = 0;
		this.SaveGameData(false, true);
	}

	// Token: 0x060006CE RID: 1742 RVA: 0x00037B5D File Offset: 0x00035D5D
	private void OnApplicationPause(bool pauseStatus)
	{
		if (pauseStatus)
		{
			CGameManager.m_HasSavedGame = false;
			this.SaveGameData(false, true);
			this.m_LastPauseDateTime = DateTime.UtcNow;
			return;
		}
		DateTime.UtcNow - this.m_LastPauseDateTime;
		this.m_LastPauseDateTime = DateTime.UtcNow;
	}

	// Token: 0x060006CF RID: 1743 RVA: 0x00037B98 File Offset: 0x00035D98
	public void ResetLastPauseTime()
	{
		this.m_LastPauseDateTime = DateTime.UtcNow;
	}

	// Token: 0x060006D0 RID: 1744 RVA: 0x00037BA8 File Offset: 0x00035DA8
	public double DateTimeToUnixTimestamp(DateTime dateTime)
	{
		return (dateTime - new DateTime(1970, 1, 1)).TotalSeconds;
	}

	// Token: 0x060006D1 RID: 1745 RVA: 0x00037BD0 File Offset: 0x00035DD0
	public void SaveGameData(bool ignoreCloudSave = false, bool forceSave = false)
	{
		if (!this.m_IsGameLevel)
		{
			Debug.Log("Skip save at title screen");
			return;
		}
		if (CGameManager.m_HasSavedGame && !ignoreCloudSave && !forceSave)
		{
			return;
		}
		if (GameInstance.m_HasLoadingError)
		{
			Debug.Log("Cant save due to loading error");
			return;
		}
		if (CPlayerData.m_InteractableObjectSaveDataList.Count <= 0)
		{
			Debug.Log("Cant save, no shelf data");
			return;
		}
		if (CGameManager.CanChangeScene() && GameInstance.m_FinishedSavefileLoading)
		{
			CPlayerData.m_LastLocalExitTime = DateTime.UtcNow;
			CGameData.instance.SaveGameData(false);
			CGameData.instance.SaveGameData(true);
			PlayerPrefs.SetString("TotalTimePassed", CGameManager.m_TotalTimePassed.ToString());
			if (!ignoreCloudSave)
			{
				bool isSaveDataDirtySyncToCloud = GameInstance.m_IsSaveDataDirtySyncToCloud;
			}
			CGameManager.m_HasSavedGame = true;
			CGameManager.m_HasSavedGameTimer = 0f;
		}
	}

	// Token: 0x060006D2 RID: 1746 RVA: 0x00037C84 File Offset: 0x00035E84
	public void LoadBackupData()
	{
		if (CSaveLoad.LoadBackup())
		{
			Debug.Log("Load backup save data");
			CGameData.instance.PropagateLoadData(CSaveLoad.m_SavedGame);
			return;
		}
		GameInstance.m_HasLoadingError = false;
		GameInstance.m_SaveFileNotFound = true;
		CPlayerData.CreateDefaultData(false);
		CGameManager.m_InitLoaded = true;
		CSingleton<ShelfManager>.Instance.m_FinishLoadingObjectData = true;
		CEventManager.QueueEvent(new CEventPlayer_GameDataFinishLoaded());
		CSingleton<LoadingScreen>.Instance.FinishLoading();
		GameInstance.m_FinishedSavefileLoading = true;
	}

	// Token: 0x060006D3 RID: 1747 RVA: 0x00037CEF File Offset: 0x00035EEF
	public static void OpenCloseGameScreen()
	{
		CSingleton<CGameManager>.Instance.m_LastScreenIndex = GameInstance.m_CurrentSceneIndex;
		GameInstance.m_CurrentSceneIndex = 0;
		CSingleton<CGameManager>.Instance.m_IsOpenCloseGameScreen = true;
		CSingleton<CGameManager>.Instance.SaveGameData(false, false);
	}

	// Token: 0x060006D4 RID: 1748 RVA: 0x00037D1D File Offset: 0x00035F1D
	public static void ExitCloseGameScreen()
	{
		GameInstance.m_CurrentSceneIndex = CSingleton<CGameManager>.Instance.m_LastScreenIndex;
		CSingleton<CGameManager>.Instance.m_IsOpenCloseGameScreen = false;
	}

	// Token: 0x060006D5 RID: 1749 RVA: 0x00037D39 File Offset: 0x00035F39
	public static bool CanChangeScene()
	{
		return CGameManager.m_TotalGameSceneTime > 0.5f;
	}

	// Token: 0x060006D6 RID: 1750 RVA: 0x00037D4A File Offset: 0x00035F4A
	public static void RestartGame()
	{
		GameInstance.m_CurrentSceneIndex = 0;
		CEventManager.QueueEvent(new CEventPlayer_ChangeScene(ELevelName.Start));
	}

	// Token: 0x060006D7 RID: 1751 RVA: 0x00037D5D File Offset: 0x00035F5D
	private void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_ChangeScene>(new CEventManager.EventDelegate<CEventPlayer_ChangeScene>(this.CPlayer_OnChangeScene));
			SceneManager.sceneLoaded += this.OnLevelFinishedLoading;
		}
	}

	// Token: 0x060006D8 RID: 1752 RVA: 0x00037D8F File Offset: 0x00035F8F
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_ChangeScene>(new CEventManager.EventDelegate<CEventPlayer_ChangeScene>(this.CPlayer_OnChangeScene));
			SceneManager.sceneLoaded -= this.OnLevelFinishedLoading;
		}
	}

	// Token: 0x060006D9 RID: 1753 RVA: 0x00037DC1 File Offset: 0x00035FC1
	private void CPlayer_OnChangeScene(CEventPlayer_ChangeScene evt)
	{
	}

	// Token: 0x060006DA RID: 1754 RVA: 0x00037DC3 File Offset: 0x00035FC3
	public void SaveGame(bool forceSave = false)
	{
		if (GameInstance.m_LoadingDifferentAccount)
		{
			return;
		}
		if (forceSave)
		{
			CGameManager.m_HasSavedGame = false;
		}
		if (this.m_CanSaveGame || forceSave)
		{
			base.StartCoroutine(this.DelaySaveGame());
		}
	}

	// Token: 0x060006DB RID: 1755 RVA: 0x00037DED File Offset: 0x00035FED
	public static void SaveGameToCloud()
	{
		if (CSingleton<CGameManager>.Instance.m_ForceNoCloudSaveLoad)
		{
			return;
		}
		CGameData.instance.IsCloudVersionNewerThanLocal();
	}

	// Token: 0x060006DC RID: 1756 RVA: 0x00037E07 File Offset: 0x00036007
	public static int GetSaveLoadSlotSelectedIndex()
	{
		if (CSingleton<CGameManager>.Instance.m_IsManualSaveLoad)
		{
			CSingleton<CGameManager>.Instance.m_IsManualSaveLoad = false;
			return CSingleton<CGameManager>.Instance.m_CurrentSaveLoadSlotSelectedIndex;
		}
		return 0;
	}

	// Token: 0x060006DD RID: 1757 RVA: 0x00037E2C File Offset: 0x0003602C
	public static void LoadGameFromCloud()
	{
		bool forceNoCloudSaveLoad = CSingleton<CGameManager>.Instance.m_ForceNoCloudSaveLoad;
	}

	// Token: 0x060006DE RID: 1758 RVA: 0x00037E39 File Offset: 0x00036039
	private IEnumerator DelaySaveGame()
	{
		yield return new WaitForSecondsRealtime(0.02f);
		this.m_CanSaveGame = false;
		this.SaveGameData(false, false);
		yield break;
	}

	// Token: 0x060006DF RID: 1759 RVA: 0x00037E48 File Offset: 0x00036048
	private IEnumerator DelayLoadScene(string sceneName)
	{
		yield return new WaitForSeconds(1f);
		SceneManager.LoadScene(sceneName);
		yield break;
	}

	// Token: 0x060006E0 RID: 1760 RVA: 0x00037E57 File Offset: 0x00036057
	public void LoadMainLevelAsync(string sceneName, int loadGameIndex = -1)
	{
		Debug.Log(sceneName);
		this.m_LoadGameIndex = loadGameIndex;
		base.StartCoroutine(this.LoadLobbySceneAsync(sceneName));
	}

	// Token: 0x060006E1 RID: 1761 RVA: 0x00037E74 File Offset: 0x00036074
	private IEnumerator DelayLoadLobbyScene(string sceneName)
	{
		if (sceneName == "Title")
		{
			CGameManager.m_InitLoaded = false;
		}
		Debug.Log("DelayLoadLobbyScene");
		LoadingScreen.OpenScreen();
		yield return new WaitForSeconds(2f);
		SceneManager.LoadScene(sceneName);
		yield break;
	}

	// Token: 0x060006E2 RID: 1762 RVA: 0x00037E83 File Offset: 0x00036083
	private IEnumerator LoadLobbySceneAsync(string sceneName)
	{
		if (sceneName == "Title")
		{
			CGameManager.m_InitLoaded = false;
		}
		LoadingScreen.OpenScreen();
		yield return new WaitForSeconds(2f);
		AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName);
		while (!asyncLoad.isDone)
		{
			string str = ((int)(100f * asyncLoad.progress / 0.9f)).ToString() + "%";
			LoadingScreen.SetPercentDone((int)(100f * asyncLoad.progress / 0.9f));
			Debug.Log("percentDone " + str);
			yield return null;
		}
		yield break;
	}

	// Token: 0x040008F2 RID: 2290
	public static CGameManager m_Instance;

	// Token: 0x040008F3 RID: 2291
	public Text_ScriptableObject m_TextSO;

	// Token: 0x040008F4 RID: 2292
	public bool m_IsGameLevel;

	// Token: 0x040008F5 RID: 2293
	public bool m_NoSave;

	// Token: 0x040008F6 RID: 2294
	public bool m_IsPrologue;

	// Token: 0x040008F7 RID: 2295
	public bool m_IsLightweightDev;

	// Token: 0x040008F8 RID: 2296
	public bool m_DeveloperModeEnabled;

	// Token: 0x040008F9 RID: 2297
	public bool m_ForceNoCloudSaveLoad;

	// Token: 0x040008FA RID: 2298
	public bool m_ForceCollectionPackFull;

	// Token: 0x040008FB RID: 2299
	public bool m_EnableScreenshotTaking;

	// Token: 0x040008FC RID: 2300
	public bool m_IsManualSaveLoad;

	// Token: 0x040008FD RID: 2301
	public int m_CurrentSaveLoadSlotSelectedIndex;

	// Token: 0x040008FE RID: 2302
	public int m_ScreenshotScaling = 2;

	// Token: 0x040008FF RID: 2303
	public int m_TimeScale = 1;

	// Token: 0x04000900 RID: 2304
	public int m_LoadGameIndex = -1;

	// Token: 0x04000901 RID: 2305
	public int m_KeyboardTypeIndex;

	// Token: 0x04000902 RID: 2306
	public int m_QualitySettingIndex;

	// Token: 0x04000903 RID: 2307
	public int m_CenterDotColorIndex;

	// Token: 0x04000904 RID: 2308
	public int m_CenterDotSpriteTypeIndex;

	// Token: 0x04000905 RID: 2309
	public EMoneyCurrencyType m_CurrencyType;

	// Token: 0x04000906 RID: 2310
	public float m_MouseSensitivity = 0.5f;

	// Token: 0x04000907 RID: 2311
	public float m_MouseSensitivityLerp = 0.5f;

	// Token: 0x04000908 RID: 2312
	public float m_CameraFOVSlider = 0.5f;

	// Token: 0x04000909 RID: 2313
	public float m_CenterDotSizeSlider = 0.3f;

	// Token: 0x0400090A RID: 2314
	public float m_OpenPackSpeedSlider;

	// Token: 0x0400090B RID: 2315
	public bool m_EnableTooltip = true;

	// Token: 0x0400090C RID: 2316
	public bool m_InvertedMouse;

	// Token: 0x0400090D RID: 2317
	public bool m_CashierLockMovement;

	// Token: 0x0400090E RID: 2318
	public bool m_LockItemLabel;

	// Token: 0x0400090F RID: 2319
	public bool m_CanConfineMouseCursor;

	// Token: 0x04000910 RID: 2320
	public bool m_CenterDotHasOutline;

	// Token: 0x04000911 RID: 2321
	public bool m_OpenPackShowNewCard;

	// Token: 0x04000912 RID: 2322
	public bool m_OpenPacAutoNextCard;

	// Token: 0x04000913 RID: 2323
	public bool m_DisableController;

	// Token: 0x04000914 RID: 2324
	public bool m_IsTurnVSyncOff;

	// Token: 0x04000915 RID: 2325
	public bool m_CanRunDebugString;

	// Token: 0x04000916 RID: 2326
	public bool m_CanRunDebugString2;

	// Token: 0x04000917 RID: 2327
	private static bool m_InitLoaded;

	// Token: 0x04000918 RID: 2328
	private CGameData m_GameData;

	// Token: 0x04000919 RID: 2329
	private static Transform m_Player;

	// Token: 0x0400091A RID: 2330
	private static float m_TotalGameSceneTime;

	// Token: 0x0400091B RID: 2331
	public static float m_TutorialManagerTimer;

	// Token: 0x0400091C RID: 2332
	public static float m_TutorialSubGrpTimer;

	// Token: 0x0400091D RID: 2333
	private static double m_TimePassed;

	// Token: 0x0400091E RID: 2334
	public static double m_LastTimePassed;

	// Token: 0x0400091F RID: 2335
	private static double m_TotalTimePassed;

	// Token: 0x04000920 RID: 2336
	public static float m_ForceSyncCloudResetTimer;

	// Token: 0x04000921 RID: 2337
	public static DateTime m_LoginTime;

	// Token: 0x04000922 RID: 2338
	private static bool m_HasSavedGame;

	// Token: 0x04000923 RID: 2339
	private static float m_HasSavedGameTimer;

	// Token: 0x04000924 RID: 2340
	private static bool m_HasSavedBackupGame;

	// Token: 0x04000925 RID: 2341
	private static float m_HasSavedBackupGameTimer;

	// Token: 0x04000926 RID: 2342
	private bool m_IsOpenCloseGameScreen;

	// Token: 0x04000927 RID: 2343
	private float m_CanSaveGameTimer;

	// Token: 0x04000928 RID: 2344
	private bool m_CanSaveGame;

	// Token: 0x04000929 RID: 2345
	private int m_LastScreenIndex;

	// Token: 0x0400092A RID: 2346
	private DateTime m_LastPauseDateTime;

	// Token: 0x0400092B RID: 2347
	private float m_SecondTimer;

	// Token: 0x0400092C RID: 2348
	private float m_MinuteTimer;

	// Token: 0x0400092D RID: 2349
	private float m_CloudSaveDirtyTimer;
}
