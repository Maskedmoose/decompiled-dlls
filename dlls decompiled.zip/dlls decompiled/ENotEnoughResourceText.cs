﻿using System;

// Token: 0x0200006F RID: 111
public enum ENotEnoughResourceText
{
	// Token: 0x040005E4 RID: 1508
	None = -1,
	// Token: 0x040005E5 RID: 1509
	Money,
	// Token: 0x040005E6 RID: 1510
	AlreadyPurchased,
	// Token: 0x040005E7 RID: 1511
	ShopLevelNotEnough,
	// Token: 0x040005E8 RID: 1512
	CustomerPlayNotEnough,
	// Token: 0x040005E9 RID: 1513
	GenericNoSlot,
	// Token: 0x040005EA RID: 1514
	ShelfNoItem,
	// Token: 0x040005EB RID: 1515
	ShelfNoSlot,
	// Token: 0x040005EC RID: 1516
	ShelfWrongItemType,
	// Token: 0x040005ED RID: 1517
	BoxNoItem,
	// Token: 0x040005EE RID: 1518
	BoxNoSlot,
	// Token: 0x040005EF RID: 1519
	BoxWrongItemType,
	// Token: 0x040005F0 RID: 1520
	HandFull,
	// Token: 0x040005F1 RID: 1521
	NoItemOnHand,
	// Token: 0x040005F2 RID: 1522
	NothingInCart,
	// Token: 0x040005F3 RID: 1523
	WrongCounterChangeAmount,
	// Token: 0x040005F4 RID: 1524
	WrongCounterCardAmount,
	// Token: 0x040005F5 RID: 1525
	CannotMoveCounterCustomerInQueue,
	// Token: 0x040005F6 RID: 1526
	CanOnlyPutItemOnThisShelf,
	// Token: 0x040005F7 RID: 1527
	CanOnlyStoreBoxOnThisShelf,
	// Token: 0x040005F8 RID: 1528
	CannotStoreEmptyBox,
	// Token: 0x040005F9 RID: 1529
	CannotMixDifferentBoxSizes,
	// Token: 0x040005FA RID: 1530
	UnlockPreviousRoomExpansionFirst,
	// Token: 0x040005FB RID: 1531
	CannotOpenShopYet,
	// Token: 0x040005FC RID: 1532
	NeedAtLeastOneCashierCounter,
	// Token: 0x040005FD RID: 1533
	NotEnoughCardForBundle,
	// Token: 0x040005FE RID: 1534
	TooMuchCounterChangeAmount,
	// Token: 0x040005FF RID: 1535
	CartTooManyItem,
	// Token: 0x04000600 RID: 1536
	AutoCleanserNoSlot,
	// Token: 0x04000601 RID: 1537
	AutoCleanserOnlyAllowCleanser,
	// Token: 0x04000602 RID: 1538
	AutoCleanserRefill,
	// Token: 0x04000603 RID: 1539
	CantSellLastCashierCounter,
	// Token: 0x04000604 RID: 1540
	NoSpaceToStartBundle,
	// Token: 0x04000605 RID: 1541
	ShelfDataNotLoadedCorrectly,
	// Token: 0x04000606 RID: 1542
	CanOnlyPutBulkBox
}
