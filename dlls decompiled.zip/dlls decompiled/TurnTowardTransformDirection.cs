﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D3 RID: 467
	public class TurnTowardTransformDirection : MonoBehaviour
	{
		// Token: 0x06000D04 RID: 3332 RVA: 0x00059EDF File Offset: 0x000580DF
		private void Start()
		{
			this.tr = base.transform;
			this.parentTransform = base.transform.parent;
			if (this.targetTransform == null)
			{
				Debug.LogWarning("No target transform has been assigned to this script.", this);
			}
		}

		// Token: 0x06000D05 RID: 3333 RVA: 0x00059F18 File Offset: 0x00058118
		private void LateUpdate()
		{
			if (!this.targetTransform)
			{
				return;
			}
			Vector3 normalized = Vector3.ProjectOnPlane(this.targetTransform.forward, this.parentTransform.up).normalized;
			Vector3 up = this.parentTransform.up;
			this.tr.rotation = Quaternion.LookRotation(normalized, up);
		}

		// Token: 0x040013F3 RID: 5107
		public Transform targetTransform;

		// Token: 0x040013F4 RID: 5108
		private Transform tr;

		// Token: 0x040013F5 RID: 5109
		private Transform parentTransform;
	}
}
