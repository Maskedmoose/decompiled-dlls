﻿using System;

// Token: 0x02000011 RID: 17
public enum ECustomerState
{
	// Token: 0x040000E5 RID: 229
	None = -1,
	// Token: 0x040000E6 RID: 230
	Idle,
	// Token: 0x040000E7 RID: 231
	WantToBuyItem,
	// Token: 0x040000E8 RID: 232
	WalkToShelf,
	// Token: 0x040000E9 RID: 233
	TakingItemFromShelf,
	// Token: 0x040000EA RID: 234
	WantToPay,
	// Token: 0x040000EB RID: 235
	QueuingToPay,
	// Token: 0x040000EC RID: 236
	ReadyToPay,
	// Token: 0x040000ED RID: 237
	ExitingShop,
	// Token: 0x040000EE RID: 238
	ShopNotOpen,
	// Token: 0x040000EF RID: 239
	WantToBuyCard,
	// Token: 0x040000F0 RID: 240
	WalkToCardShelf,
	// Token: 0x040000F1 RID: 241
	TakingItemFromCardShelf,
	// Token: 0x040000F2 RID: 242
	WantToPlayGame,
	// Token: 0x040000F3 RID: 243
	WalkToPlayTable,
	// Token: 0x040000F4 RID: 244
	PlayingAtTable,
	// Token: 0x040000F5 RID: 245
	EndingPlayTableGame,
	// Token: 0x040000F6 RID: 246
	QueueingPlayTable
}
