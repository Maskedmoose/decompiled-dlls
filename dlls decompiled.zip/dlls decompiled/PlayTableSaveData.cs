﻿using System;
using System.Collections.Generic;

// Token: 0x0200004D RID: 77
[Serializable]
public class PlayTableSaveData
{
	// Token: 0x0400044C RID: 1100
	public Vector3Serializer pos;

	// Token: 0x0400044D RID: 1101
	public QuaternionSerializer rot;

	// Token: 0x0400044E RID: 1102
	public bool isBoxed;

	// Token: 0x0400044F RID: 1103
	public Vector3Serializer boxedPackagePos;

	// Token: 0x04000450 RID: 1104
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x04000451 RID: 1105
	public EObjectType objectType;

	// Token: 0x04000452 RID: 1106
	public bool hasStartPlay;

	// Token: 0x04000453 RID: 1107
	public List<bool> isSeatOccupied;

	// Token: 0x04000454 RID: 1108
	public List<bool> isCustomerSmelly;

	// Token: 0x04000455 RID: 1109
	public int currentPlayerCount;

	// Token: 0x04000456 RID: 1110
	public float currentPlayTime;

	// Token: 0x04000457 RID: 1111
	public float currentPlayTimeMax;

	// Token: 0x04000458 RID: 1112
	public List<float> playTableFee;
}
