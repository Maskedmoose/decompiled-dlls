﻿using System;
using UnityEngine;

// Token: 0x02000138 RID: 312
public class ArrowIndicatorUI : MonoBehaviour
{
	// Token: 0x060008F2 RID: 2290 RVA: 0x000415DC File Offset: 0x0003F7DC
	public void SetPosY(float posYOffset)
	{
		Vector3 localPosition = this.m_ArrowTransformGrp.transform.localPosition;
		localPosition.y = posYOffset;
		this.m_ArrowTransformGrp.transform.localPosition = localPosition;
	}

	// Token: 0x060008F3 RID: 2291 RVA: 0x00041613 File Offset: 0x0003F813
	public void SetScale(float scale)
	{
		this.m_ArrowTransformGrp.localScale = Vector3.one * scale;
	}

	// Token: 0x04001106 RID: 4358
	public Transform m_ArrowTransformGrp;
}
