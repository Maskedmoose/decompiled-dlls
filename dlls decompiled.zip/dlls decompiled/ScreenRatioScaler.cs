﻿using System;
using UnityEngine;

// Token: 0x02000108 RID: 264
public class ScreenRatioScaler : MonoBehaviour
{
	// Token: 0x060007B8 RID: 1976 RVA: 0x00039A8F File Offset: 0x00037C8F
	private void Awake()
	{
		this.Init();
	}

	// Token: 0x060007B9 RID: 1977 RVA: 0x00039A97 File Offset: 0x00037C97
	private void Init()
	{
		if (!this.m_HasInit)
		{
			this.m_HasInit = true;
			this.m_OriginalScale = this.m_Transform.localScale.x;
		}
	}

	// Token: 0x060007BA RID: 1978 RVA: 0x00039AC0 File Offset: 0x00037CC0
	private void Start()
	{
		this.Init();
		if (this.m_InitOnStart)
		{
			float num = (float)Screen.width / (float)Screen.height;
			if (num < 1.61f)
			{
				float d = Mathf.Lerp(this.m_MinScale, this.m_MaxScale, num / 1.6f);
				if (this.m_UseMaxScaleOnly)
				{
					d = this.m_MaxScale;
				}
				this.m_Transform.localScale = Vector3.one * d;
			}
		}
	}

	// Token: 0x060007BB RID: 1979 RVA: 0x00039B30 File Offset: 0x00037D30
	private void OnEnable()
	{
		this.Init();
		float num = (float)Screen.width / (float)Screen.height;
		if (num < 1.61f)
		{
			float d = Mathf.Lerp(this.m_MinScale, this.m_MaxScale, num / 1.6f);
			if (this.m_UseMaxScaleOnly)
			{
				d = this.m_MaxScale;
			}
			this.m_Transform.localScale = Vector3.one * d;
			return;
		}
		this.m_Transform.localScale = Vector3.one * this.m_OriginalScale;
	}

	// Token: 0x04000EF1 RID: 3825
	public Transform m_Transform;

	// Token: 0x04000EF2 RID: 3826
	public float m_MinScale = 0.3f;

	// Token: 0x04000EF3 RID: 3827
	public float m_MaxScale = 0.925f;

	// Token: 0x04000EF4 RID: 3828
	public bool m_InitOnStart;

	// Token: 0x04000EF5 RID: 3829
	public bool m_UseMaxScaleOnly = true;

	// Token: 0x04000EF6 RID: 3830
	private bool m_HasInit;

	// Token: 0x04000EF7 RID: 3831
	private float m_OriginalScale = 1f;
}
