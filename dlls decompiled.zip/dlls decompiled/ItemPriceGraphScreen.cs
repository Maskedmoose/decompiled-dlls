﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200006D RID: 109
public class ItemPriceGraphScreen : UIScreenBase
{
	// Token: 0x0600049B RID: 1179 RVA: 0x00027B4C File Offset: 0x00025D4C
	public void ShowItemPriceChart(EItemType itemType)
	{
		this.m_CurrentScaleLineIndex = 0;
		List<float> floatDataList = CPlayerData.m_ItemPricePercentPastChangeList[(int)itemType].floatDataList;
		List<float> list = new List<float>();
		for (int i = 0; i < floatDataList.Count; i++)
		{
			list.Add(CPlayerData.GetItemMarketPriceCustomPercent(itemType, floatDataList[i]));
		}
		this.EvaluatePriceChart(list);
		ItemData itemData = InventoryBase.GetItemData(itemType);
		this.m_ItemImage.sprite = itemData.icon;
		this.m_ItemName.text = itemData.GetName();
		this.m_ItemGrp.SetActive(true);
		this.m_CardGrp.SetActive(false);
		if (itemData.isHideItemUntilUnlocked)
		{
			int restockDataIndex = InventoryBase.GetRestockDataIndex(itemType);
			bool flag = false;
			if (restockDataIndex > 0)
			{
				flag = CPlayerData.GetIsItemLicenseUnlocked(restockDataIndex);
			}
			if (!flag)
			{
				this.m_ItemImage.sprite = InventoryBase.GetQuestionMarkSprite();
				this.m_ItemName.text = "???";
			}
		}
	}

	// Token: 0x0600049C RID: 1180 RVA: 0x00027C28 File Offset: 0x00025E28
	public void ShowCardPriceChart(int cardIndex, ECardExpansionType expansionType, bool isDestiny)
	{
		this.m_CurrentScaleLineIndex = 0;
		List<float> pastCardPricePercentChange = CPlayerData.GetPastCardPricePercentChange(cardIndex, expansionType, isDestiny);
		List<float> list = new List<float>();
		for (int i = 0; i < pastCardPricePercentChange.Count; i++)
		{
			list.Add(CPlayerData.GetCardMarketPriceCustomPercent(cardIndex, expansionType, isDestiny, pastCardPricePercentChange[i]));
		}
		this.EvaluatePriceChart(list);
		CardData cardData = new CardData();
		cardData.monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(cardIndex, expansionType);
		cardData.isFoil = (cardIndex % CPlayerData.GetCardAmountPerMonsterType(expansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(expansionType, false));
		cardData.borderType = (ECardBorderType)(cardIndex % CPlayerData.GetCardAmountPerMonsterType(expansionType, false));
		cardData.isDestiny = isDestiny;
		cardData.expansionType = expansionType;
		this.m_CardName.text = InventoryBase.GetMonsterData(cardData.monsterType).GetName() + " - " + CPlayerData.GetFullCardTypeName(cardData, false);
		this.m_CardUI.SetCardUI(cardData);
		this.m_ItemGrp.SetActive(false);
		this.m_CardGrp.SetActive(true);
	}

	// Token: 0x0600049D RID: 1181 RVA: 0x00027D14 File Offset: 0x00025F14
	private void EvaluatePriceChart(List<float> dataList)
	{
		this.m_GraphDimensionX = this.m_GraphEndXY.transform.position.x - this.m_GraphStartXY.transform.position.x;
		this.m_GraphDimensionY = this.m_GraphEndXY.transform.position.y - this.m_GraphStartXY.transform.position.y;
		this.m_HighestValue = 0f;
		this.m_LowestValue = 10000f;
		for (int i = 0; i < dataList.Count; i++)
		{
			if (dataList[i] > this.m_HighestValue)
			{
				this.m_HighestValue = dataList[i];
			}
			if (dataList[i] < this.m_LowestValue)
			{
				this.m_LowestValue = dataList[i];
			}
		}
		float min = 0.01f;
		if (this.m_HighestValue > 20000f)
		{
			min = 1000f;
		}
		else if (this.m_HighestValue > 18000f)
		{
			min = 900f;
		}
		else if (this.m_HighestValue > 16000f)
		{
			min = 800f;
		}
		else if (this.m_HighestValue > 14000f)
		{
			min = 700f;
		}
		else if (this.m_HighestValue > 12000f)
		{
			min = 600f;
		}
		else if (this.m_HighestValue > 10000f)
		{
			min = 500f;
		}
		else if (this.m_HighestValue > 8000f)
		{
			min = 400f;
		}
		else if (this.m_HighestValue > 6000f)
		{
			min = 300f;
		}
		else if (this.m_HighestValue > 4000f)
		{
			min = 200f;
		}
		else if (this.m_HighestValue > 2000f)
		{
			min = 100f;
		}
		else if (this.m_HighestValue > 1000f)
		{
			min = 50f;
		}
		else if (this.m_HighestValue > 500f)
		{
			min = 25f;
		}
		else if (this.m_HighestValue > 100f)
		{
			min = 5f;
		}
		else if (this.m_HighestValue > 80f)
		{
			min = 4f;
		}
		else if (this.m_HighestValue > 60f)
		{
			min = 3f;
		}
		else if (this.m_HighestValue > 50f)
		{
			min = 2.5f;
		}
		else if (this.m_HighestValue > 40f)
		{
			min = 2f;
		}
		else if (this.m_HighestValue > 30f)
		{
			min = 1.5f;
		}
		else if (this.m_HighestValue > 20f)
		{
			min = 1f;
		}
		else if (this.m_HighestValue > 10f)
		{
			min = 0.5f;
		}
		else if (this.m_HighestValue > 5f)
		{
			min = 0.2f;
		}
		else if (this.m_HighestValue > 2f)
		{
			min = 0.1f;
		}
		else if (this.m_HighestValue > 1f)
		{
			min = 0.05f;
		}
		else if (this.m_HighestValue > 0.5f)
		{
			min = 0.02f;
		}
		this.m_Distribution = Mathf.Clamp((this.m_HighestValue - this.m_LowestValue) / (float)this.m_DistributionCountY, min, 1000f);
		this.m_HighestValue = this.m_LowestValue + this.m_Distribution * (float)this.m_DistributionCountY;
		if (this.m_LowestValue > 0.02f)
		{
			this.m_LowestValue -= this.m_Distribution * 2f;
		}
		this.m_GraphValueList.Clear();
		for (int j = 0; j < this.m_DistributionCountY + 2; j++)
		{
			this.m_GraphValueList.Add(this.m_LowestValue + this.m_Distribution * (float)j);
			this.m_PriceTextList[this.m_PriceTextList.Count - j - 1].text = GameInstance.GetPriceString(this.m_LowestValue + this.m_Distribution * (float)j, false, true, false, "F2");
		}
		this.m_ValuePercentList.Clear();
		for (int k = 0; k < dataList.Count; k++)
		{
			float item = (dataList[k] - this.m_LowestValue) / (this.m_HighestValue - this.m_LowestValue);
			this.m_ValuePercentList.Add(item);
		}
		for (int l = 0; l < this.m_DotSpriteList.Count; l++)
		{
			this.m_DotSpriteList[l].gameObject.SetActive(false);
		}
		float num = this.m_GraphDimensionX / (float)this.m_DistributionCountX;
		Vector3 position = this.m_GraphStartXY.position;
		for (int m = 0; m < dataList.Count; m++)
		{
			position = this.m_GraphStartXY.position;
			position.x += num * (float)m;
			position.y += Mathf.Lerp(0f, this.m_GraphDimensionY, this.m_ValuePercentList[m]);
			this.m_DotSpriteList[m].position = position;
		}
		if (dataList.Count > 0)
		{
			this.m_DotSpriteList[0].gameObject.SetActive(true);
		}
		for (int n = 0; n < this.m_ItemPriceLineGrpList.Count - 1; n++)
		{
			this.m_ItemPriceLineGrpList[n].SetActive(false);
		}
		if (dataList.Count > 1)
		{
			for (int num2 = 0; num2 < dataList.Count - 1; num2++)
			{
				this.m_ItemPriceLineGrpList[num2].transform.position = this.m_DotSpriteList[num2].position;
				this.m_ItemPriceLineGrpList[num2].transform.LookAt(this.m_DotSpriteList[num2 + 1], Vector3.up);
				Vector3 localScale = this.m_ItemPriceLineGrpList[num2].transform.localScale;
				this.m_GraphStartCalculatePos.transform.position = this.m_DotSpriteList[num2 + 1].position;
				this.m_GraphEndCalculatePos.transform.position = this.m_DotSpriteList[num2].position;
				float num3 = Vector2.Distance(this.m_GraphStartCalculatePos.anchoredPosition, this.m_GraphEndCalculatePos.anchoredPosition);
				localScale.z = num3 / this.m_LineGraphDivide * (2f - base.transform.localScale.x);
				this.m_ItemPriceLineGrpList[num2].transform.localScale = localScale;
				float num4 = dataList[num2 + 1] - dataList[num2];
				if (num4 > 0.005f)
				{
					this.m_ItemPriceLineGrpList[num2].SetColor(this.m_PositiveColor);
				}
				else if (num4 < -0.005f)
				{
					this.m_ItemPriceLineGrpList[num2].SetColor(this.m_NegativeColor);
				}
				else
				{
					this.m_ItemPriceLineGrpList[num2].SetColor(this.m_NeutralColor);
				}
				this.m_ItemPriceLineGrpList[num2].SetScaleLerp(0f);
				this.m_ItemPriceLineGrpList[num2].SetActive(true);
			}
		}
		int num5 = CPlayerData.m_CurrentDay + 1;
		Mathf.Clamp(dataList.Count / 2, 1, 15);
		for (int num6 = 0; num6 < this.m_DayTextList.Count; num6++)
		{
			this.m_DayTextList[num6].enabled = false;
		}
		int num7 = 2;
		if (dataList.Count < 3)
		{
			num7 = 1;
		}
		for (int num8 = 0; num8 < dataList.Count; num8++)
		{
			Vector3 position2 = this.m_DayTextList[num8].transform.position;
			position2.x = this.m_DotSpriteList[num8].transform.position.x;
			this.m_DayTextList[num8].transform.position = position2;
			this.m_DayTextList[num8].text = (num5 - (dataList.Count - num8 - 1)).ToString();
			this.m_DayTextList[num8].enabled = (num8 % num7 == 0 || num8 == 0 || num8 == dataList.Count - 1);
		}
	}

	// Token: 0x0600049E RID: 1182 RVA: 0x00028548 File Offset: 0x00026748
	protected override void RunUpdate()
	{
		for (int i = this.m_CurrentScaleLineIndex; i < this.m_ItemPriceLineGrpList.Count; i++)
		{
			if (this.m_ItemPriceLineGrpList[i].m_IsActive)
			{
				if (this.m_ItemPriceLineGrpList[i].m_Lerp < 1f)
				{
					this.m_ItemPriceLineGrpList[i].AddScaleLerp(Time.fixedDeltaTime * this.m_LineGraphLerpSpeed);
					this.m_CurrentScaleLineIndex = i;
					return;
				}
				this.m_DotSpriteList[i + 1].gameObject.SetActive(true);
			}
		}
	}

	// Token: 0x0600049F RID: 1183 RVA: 0x000285DB File Offset: 0x000267DB
	protected override void OnOpenScreen()
	{
		base.OnOpenScreen();
	}

	// Token: 0x060004A0 RID: 1184 RVA: 0x000285E3 File Offset: 0x000267E3
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
	}

	// Token: 0x040005C1 RID: 1473
	public GameObject m_ItemGrp;

	// Token: 0x040005C2 RID: 1474
	public GameObject m_CardGrp;

	// Token: 0x040005C3 RID: 1475
	public Image m_ItemImage;

	// Token: 0x040005C4 RID: 1476
	public TextMeshProUGUI m_ItemName;

	// Token: 0x040005C5 RID: 1477
	public CardUI m_CardUI;

	// Token: 0x040005C6 RID: 1478
	public TextMeshProUGUI m_CardName;

	// Token: 0x040005C7 RID: 1479
	public Transform m_GraphStartXY;

	// Token: 0x040005C8 RID: 1480
	public Transform m_GraphEndXY;

	// Token: 0x040005C9 RID: 1481
	public float m_LineGraphLerpSpeed = 60f;

	// Token: 0x040005CA RID: 1482
	public float m_LineGraphDivide = 8f;

	// Token: 0x040005CB RID: 1483
	public RectTransform m_GraphStartCalculatePos;

	// Token: 0x040005CC RID: 1484
	public RectTransform m_GraphEndCalculatePos;

	// Token: 0x040005CD RID: 1485
	public Color m_PositiveColor;

	// Token: 0x040005CE RID: 1486
	public Color m_NegativeColor;

	// Token: 0x040005CF RID: 1487
	public Color m_NeutralColor;

	// Token: 0x040005D0 RID: 1488
	public List<ItemPriceLineGrp> m_ItemPriceLineGrpList;

	// Token: 0x040005D1 RID: 1489
	public List<Transform> m_DotSpriteList = new List<Transform>();

	// Token: 0x040005D2 RID: 1490
	public List<TextMeshProUGUI> m_PriceTextList;

	// Token: 0x040005D3 RID: 1491
	public List<TextMeshProUGUI> m_DayTextList;

	// Token: 0x040005D4 RID: 1492
	private float m_GraphDimensionX;

	// Token: 0x040005D5 RID: 1493
	private float m_GraphDimensionY;

	// Token: 0x040005D6 RID: 1494
	private int m_DistributionCountX = 30;

	// Token: 0x040005D7 RID: 1495
	private int m_DistributionCountY = 10;

	// Token: 0x040005D8 RID: 1496
	public int m_CurrentScaleLineIndex;

	// Token: 0x040005D9 RID: 1497
	private float m_LowestValue;

	// Token: 0x040005DA RID: 1498
	private float m_HighestValue;

	// Token: 0x040005DB RID: 1499
	private float m_Distribution;

	// Token: 0x040005DC RID: 1500
	private List<float> m_GraphValueList = new List<float>();

	// Token: 0x040005DD RID: 1501
	private List<float> m_ValuePercentList = new List<float>();
}
