﻿using System;

// Token: 0x02000060 RID: 96
public class ConfirmTrashScreen : UIScreenBase
{
	// Token: 0x06000438 RID: 1080 RVA: 0x00024B64 File Offset: 0x00022D64
	protected override void OnOpenScreen()
	{
		SoundManager.GenericMenuOpen(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(true);
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		base.OnOpenScreen();
	}

	// Token: 0x06000439 RID: 1081 RVA: 0x00024B95 File Offset: 0x00022D95
	protected override void OnCloseScreen()
	{
		SoundManager.GenericMenuClose(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(false);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
		base.OnCloseScreen();
	}

	// Token: 0x0600043A RID: 1082 RVA: 0x00024BC6 File Offset: 0x00022DC6
	public void OnPressConfirmBtn()
	{
		CSingleton<InteractionPlayerController>.Instance.ConfirmDiscardBox();
		SoundManager.GenericConfirm(1f, 1f);
		base.CloseScreen();
	}

	// Token: 0x0600043B RID: 1083 RVA: 0x00024BE7 File Offset: 0x00022DE7
	public void OnPressCancelBtn()
	{
		SoundManager.GenericCancel(1f, 1f);
		base.CloseScreen();
	}
}
