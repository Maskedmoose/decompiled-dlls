﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000126 RID: 294
public class SliderUI : MonoBehaviour
{
	// Token: 0x06000899 RID: 2201 RVA: 0x0003F89C File Offset: 0x0003DA9C
	private void Awake()
	{
	}

	// Token: 0x0600089A RID: 2202 RVA: 0x0003F89E File Offset: 0x0003DA9E
	public void OnSliderPress(int index)
	{
		this.EvaluateSlider();
	}

	// Token: 0x0600089B RID: 2203 RVA: 0x0003F8A6 File Offset: 0x0003DAA6
	public void OnSliderDrag(int index)
	{
		this.EvaluateSlider();
	}

	// Token: 0x0600089C RID: 2204 RVA: 0x0003F8AE File Offset: 0x0003DAAE
	public void OnRelease()
	{
		this.m_OnReleaseEvent.Invoke();
	}

	// Token: 0x0600089D RID: 2205 RVA: 0x0003F8BC File Offset: 0x0003DABC
	private void EvaluateSlider()
	{
		float num = this.m_EndPoint.position.x - this.m_StartPoint.position.x;
		float num2 = Input.mousePosition.x;
		num2 = Mathf.Clamp(num2, this.m_StartPoint.position.x, this.m_EndPoint.position.x);
		this.m_Percent = (num2 - this.m_StartPoint.position.x) / num;
		this.m_SliderIcon.position = new Vector3(num2, this.m_SliderIcon.position.y, 0f);
		this.m_SliderEvent.Invoke(this.m_Percent);
		this.EvaluateText();
	}

	// Token: 0x0600089E RID: 2206 RVA: 0x0003F974 File Offset: 0x0003DB74
	private void EvaluateText()
	{
		if (this.m_DecimalAmount <= 0f)
		{
			int num = Mathf.FloorToInt(this.m_Percent * 100f * this.m_PercentMultiplier / 100f);
			this.m_PercentText.text = num.ToString();
			return;
		}
		float num2 = (float)Mathf.FloorToInt(this.m_Percent * Mathf.Pow(10f, this.m_DecimalAmount) * this.m_PercentMultiplier) / Mathf.Pow(10f, this.m_DecimalAmount);
		this.m_PercentText.text = num2.ToString();
	}

	// Token: 0x0600089F RID: 2207 RVA: 0x0003FA08 File Offset: 0x0003DC08
	public void SetSliderPosByPercent(float percent)
	{
		this.m_Percent = percent;
		float num = Mathf.Lerp(this.m_StartPoint.position.x, this.m_EndPoint.position.x, percent);
		num = Mathf.Clamp(num, this.m_StartPoint.position.x, this.m_EndPoint.position.x);
		this.m_SliderIcon.position = new Vector3(num, this.m_SliderIcon.position.y, 0f);
		this.EvaluateText();
	}

	// Token: 0x060008A0 RID: 2208 RVA: 0x0003FA96 File Offset: 0x0003DC96
	private void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.CPlayer_OnStartGame));
			CEventManager.AddListener<CEventPlayer_ChangeScene>(new CEventManager.EventDelegate<CEventPlayer_ChangeScene>(this.OnOpenLoadingScreen));
		}
	}

	// Token: 0x060008A1 RID: 2209 RVA: 0x0003FAC8 File Offset: 0x0003DCC8
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.CPlayer_OnStartGame));
			CEventManager.RemoveListener<CEventPlayer_ChangeScene>(new CEventManager.EventDelegate<CEventPlayer_ChangeScene>(this.OnOpenLoadingScreen));
		}
	}

	// Token: 0x060008A2 RID: 2210 RVA: 0x0003FAFA File Offset: 0x0003DCFA
	private void CPlayer_OnStartGame(CEventPlayer_GameDataFinishLoaded evt)
	{
	}

	// Token: 0x060008A3 RID: 2211 RVA: 0x0003FAFC File Offset: 0x0003DCFC
	private void OnOpenLoadingScreen(CEventPlayer_ChangeScene evt)
	{
	}

	// Token: 0x0400105F RID: 4191
	public TextMeshProUGUI m_PercentText;

	// Token: 0x04001060 RID: 4192
	public float m_PercentMultiplier = 255f;

	// Token: 0x04001061 RID: 4193
	public float m_DecimalAmount;

	// Token: 0x04001062 RID: 4194
	public RectTransform m_SliderIcon;

	// Token: 0x04001063 RID: 4195
	public RectTransform m_StartPoint;

	// Token: 0x04001064 RID: 4196
	public RectTransform m_EndPoint;

	// Token: 0x04001065 RID: 4197
	private float m_Percent;

	// Token: 0x04001066 RID: 4198
	public SliderPercentEvent m_SliderEvent;

	// Token: 0x04001067 RID: 4199
	public UnityEvent m_OnReleaseEvent;
}
