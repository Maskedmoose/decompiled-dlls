﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200014D RID: 333
public class Door : MonoBehaviour
{
	// Token: 0x0600096E RID: 2414 RVA: 0x00044994 File Offset: 0x00042B94
	private void Start()
	{
		this.defaulRot = base.transform.eulerAngles;
		this.openRot = new Vector3(this.defaulRot.x, this.defaulRot.y + this.DoorOpenAngle, this.defaulRot.z);
	}

	// Token: 0x0600096F RID: 2415 RVA: 0x000449E8 File Offset: 0x00042BE8
	private void Update()
	{
		if (this.open)
		{
			base.transform.eulerAngles = Vector3.Slerp(base.transform.eulerAngles, this.openRot, Time.deltaTime * this.smooth);
		}
		else
		{
			base.transform.eulerAngles = Vector3.Slerp(base.transform.eulerAngles, this.defaulRot, Time.deltaTime * this.smooth);
		}
		if (Input.GetKeyDown(KeyCode.E) && this.trig)
		{
			this.open = !this.open;
		}
		if (this.trig)
		{
			if (this.open)
			{
				this.txt.text = "Close E";
				return;
			}
			this.txt.text = "Open E";
		}
	}

	// Token: 0x06000970 RID: 2416 RVA: 0x00044AAC File Offset: 0x00042CAC
	private void OnTriggerEnter(Collider coll)
	{
		if (coll.tag == "Player")
		{
			if (!this.open)
			{
				this.txt.text = "Close E ";
			}
			else
			{
				this.txt.text = "Open E";
			}
			this.trig = true;
		}
	}

	// Token: 0x06000971 RID: 2417 RVA: 0x00044AFC File Offset: 0x00042CFC
	private void OnTriggerExit(Collider coll)
	{
		if (coll.tag == "Player")
		{
			this.txt.text = " ";
			this.trig = false;
		}
	}

	// Token: 0x040011B2 RID: 4530
	private bool trig;

	// Token: 0x040011B3 RID: 4531
	private bool open;

	// Token: 0x040011B4 RID: 4532
	public float smooth = 2f;

	// Token: 0x040011B5 RID: 4533
	public float DoorOpenAngle = 90f;

	// Token: 0x040011B6 RID: 4534
	private Vector3 defaulRot;

	// Token: 0x040011B7 RID: 4535
	private Vector3 openRot;

	// Token: 0x040011B8 RID: 4536
	public Text txt;
}
