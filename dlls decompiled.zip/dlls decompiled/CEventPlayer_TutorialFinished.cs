﻿using System;

// Token: 0x020000AB RID: 171
public class CEventPlayer_TutorialFinished : CEvent
{
	// Token: 0x1700000B RID: 11
	// (get) Token: 0x060006E8 RID: 1768 RVA: 0x00037F17 File Offset: 0x00036117
	// (set) Token: 0x060006E9 RID: 1769 RVA: 0x00037F1F File Offset: 0x0003611F
	public bool m_IsFinished { get; private set; }

	// Token: 0x060006EA RID: 1770 RVA: 0x00037F28 File Offset: 0x00036128
	public CEventPlayer_TutorialFinished(bool isFinished)
	{
		this.m_IsFinished = isFinished;
	}
}
