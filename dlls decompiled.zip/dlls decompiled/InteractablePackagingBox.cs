﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000023 RID: 35
public class InteractablePackagingBox : InteractableObject
{
	// Token: 0x060001AF RID: 431 RVA: 0x00013256 File Offset: 0x00011456
	protected override void Awake()
	{
		base.Awake();
		this.m_OriginalParent = base.transform.parent;
		this.m_OriginalScale = base.transform.localScale;
	}

	// Token: 0x060001B0 RID: 432 RVA: 0x00013280 File Offset: 0x00011480
	public override void OnMouseButtonUp()
	{
		this.StartHoldBox(true, CSingleton<InteractionPlayerController>.Instance.m_HoldItemPos);
	}

	// Token: 0x060001B1 RID: 433 RVA: 0x00013294 File Offset: 0x00011494
	protected override void Update()
	{
		base.Update();
		if (this.m_IsMovingObject)
		{
			base.transform.position = Vector3.Lerp(base.transform.position, this.m_TargetMoveObjectPosition, Time.deltaTime * 7.5f);
			if (this.m_MoveStateValidArea)
			{
				this.m_IsMovingObjectValidState = true;
			}
		}
	}

	// Token: 0x060001B2 RID: 434 RVA: 0x000132F0 File Offset: 0x000114F0
	protected override void LateUpdate()
	{
		base.LateUpdate();
		if (this.m_Shelf_WorldUIGrp)
		{
			this.m_Shelf_WorldUIGrp.transform.position = base.transform.position;
			this.m_Shelf_WorldUIGrp.transform.rotation = base.transform.rotation;
			this.m_Shelf_WorldUIGrp.localScale = this.m_OriginalScale_ShelfWorldUIGrp * base.transform.lossyScale.x;
		}
	}

	// Token: 0x060001B3 RID: 435 RVA: 0x0001336C File Offset: 0x0001156C
	public override void StartMoveObject()
	{
		CSingleton<InteractionPlayerController>.Instance.OnEnterMoveBoxMode(this.m_BoxPhysicsDimension);
		this.OnRaycastEnded();
		this.m_IsMovingObject = true;
		this.m_IsMovingObjectValidState = false;
		this.m_OriginalLayer = base.gameObject.layer;
		base.gameObject.layer = LayerMask.NameToLayer("Ignore Raycast");
		this.m_BoxCollider.enabled = false;
		this.m_Rigidbody.isKinematic = true;
		this.OnStartMoveObject();
		SoundManager.PlayAudio("SFX_WhipSoft", 0.6f, 1f);
		Quaternion rotation = CSingleton<InteractionPlayerController>.Instance.m_CameraController.transform.rotation;
		Vector3 eulerAngles = rotation.eulerAngles;
		eulerAngles.x = 0f;
		rotation.eulerAngles = eulerAngles;
		base.transform.rotation = rotation;
	}

	// Token: 0x060001B4 RID: 436 RVA: 0x00013432 File Offset: 0x00011632
	protected override void OnPlacedMovedObject()
	{
		CSingleton<InteractionPlayerController>.Instance.OnExitMoveObjectMode();
		this.m_IsMovingObject = false;
		base.gameObject.layer = this.m_OriginalLayer;
		this.m_BoxCollider.enabled = true;
		this.m_Rigidbody.isKinematic = false;
	}

	// Token: 0x060001B5 RID: 437 RVA: 0x0001346E File Offset: 0x0001166E
	protected override void PlayPlaceMoveObjectSFX()
	{
		SoundManager.PlayAudio("SFX_Throw", 0.3f, 1f);
	}

	// Token: 0x060001B6 RID: 438 RVA: 0x00013484 File Offset: 0x00011684
	public virtual void StartHoldBox(bool isPlayer, Transform holdItemPos)
	{
		if (this.m_IsBeingHold)
		{
			return;
		}
		if (isPlayer)
		{
			CSingleton<InteractionPlayerController>.Instance.OnEnterHoldBoxMode(this);
			SoundManager.PlayAudio("SFX_WhipSoft", 0.6f, 1f);
		}
		this.OnRaycastEnded();
		this.SetPhysicsEnabled(false);
		base.LerpToTransform(holdItemPos, holdItemPos);
		this.m_MoveStateValidArea.gameObject.SetActive(true);
		this.m_IsBeingHold = true;
	}

	// Token: 0x060001B7 RID: 439 RVA: 0x000134E9 File Offset: 0x000116E9
	public virtual void OnPressOpenBox()
	{
	}

	// Token: 0x060001B8 RID: 440 RVA: 0x000134EB File Offset: 0x000116EB
	public virtual void OnHoldStateLeftMousePress(bool isPlayer, ShelfCompartment targetItemCompartment)
	{
	}

	// Token: 0x060001B9 RID: 441 RVA: 0x000134ED File Offset: 0x000116ED
	public virtual void OnHoldStateRightMousePress(bool isPlayer, ShelfCompartment targetItemCompartment)
	{
	}

	// Token: 0x060001BA RID: 442 RVA: 0x000134EF File Offset: 0x000116EF
	protected virtual void SpawnPriceTag()
	{
		this.m_Shelf_WorldUIGrp = PriceTagUISpawner.SpawnShelfWorldUIGrp(base.transform);
		this.m_OriginalScale_ShelfWorldUIGrp = this.m_Shelf_WorldUIGrp.localScale;
	}

	// Token: 0x060001BB RID: 443 RVA: 0x00013513 File Offset: 0x00011713
	protected virtual void SetPriceTagVisibility(bool isVisible)
	{
	}

	// Token: 0x060001BC RID: 444 RVA: 0x00013515 File Offset: 0x00011715
	protected IEnumerator DelaySetPriceTagVisibility(float delayTime, bool isVisible)
	{
		yield return new WaitForSeconds(delayTime);
		this.SetPriceTagVisibility(isVisible);
		yield break;
	}

	// Token: 0x060001BD RID: 445 RVA: 0x00013534 File Offset: 0x00011734
	public virtual void ThrowBox(bool isPlayer)
	{
		if (isPlayer)
		{
			CSingleton<InteractionPlayerController>.Instance.OnExitHoldBoxMode();
			SoundManager.PlayAudio("SFX_Throw", 0.6f, 1f);
		}
		this.SetPhysicsEnabled(true);
		base.transform.parent = this.m_OriginalParent.transform;
		base.transform.localScale = this.m_OriginalScale;
		this.m_Rigidbody.AddForce(base.transform.forward * 450f);
		this.m_IsBeingHold = false;
	}

	// Token: 0x060001BE RID: 446 RVA: 0x000135B8 File Offset: 0x000117B8
	public virtual void DropBox(bool isPlayer)
	{
		if (isPlayer)
		{
			CSingleton<InteractionPlayerController>.Instance.OnExitHoldBoxMode();
		}
		this.SetPhysicsEnabled(true);
		base.transform.parent = this.m_OriginalParent.transform;
		base.transform.localScale = this.m_OriginalScale;
		this.m_IsBeingHold = false;
	}

	// Token: 0x060001BF RID: 447 RVA: 0x00013607 File Offset: 0x00011807
	public virtual bool IsBoxOpened()
	{
		return false;
	}

	// Token: 0x060001C0 RID: 448 RVA: 0x0001360A File Offset: 0x0001180A
	public void SetPhysicsEnabled(bool isEnable)
	{
		if (isEnable)
		{
			this.m_Collider.enabled = true;
			this.m_Rigidbody.isKinematic = false;
			return;
		}
		this.m_Collider.enabled = false;
		this.m_Rigidbody.isKinematic = true;
	}

	// Token: 0x0400022C RID: 556
	public Collider m_Collider;

	// Token: 0x0400022D RID: 557
	public Rigidbody m_Rigidbody;

	// Token: 0x0400022E RID: 558
	public Animation m_BoxAnim;

	// Token: 0x0400022F RID: 559
	public Vector3 m_BoxPhysicsDimension;

	// Token: 0x04000230 RID: 560
	public Color m_MoveBoxPreviewColor;

	// Token: 0x04000231 RID: 561
	protected Vector3 m_OriginalScale_ShelfWorldUIGrp;
}
