﻿using System;

// Token: 0x020000CC RID: 204
public class CEventPlayer_ForceCloudSave : CEvent
{
}
