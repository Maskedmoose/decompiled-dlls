﻿using System;
using UnityEngine;

// Token: 0x02000037 RID: 55
public class Item : MonoBehaviour
{
	// Token: 0x060002C5 RID: 709 RVA: 0x00019F4C File Offset: 0x0001814C
	public void SetMesh(Mesh mesh, Material material, EItemType itemType, Mesh meshSecondary = null, Material materialSecondary = null)
	{
		this.m_ItemType = itemType;
		this.m_MeshFilter.mesh = mesh;
		if (meshSecondary == null && materialSecondary == null && this.m_Mesh.materials.Length > 1)
		{
			Material[] materials = new Material[]
			{
				material
			};
			this.m_Mesh.materials = materials;
		}
		else if (meshSecondary != null && this.m_Mesh.materials.Length > 1)
		{
			Material[] materials2 = new Material[]
			{
				material
			};
			this.m_Mesh.materials = materials2;
		}
		else
		{
			this.m_Mesh.material = material;
		}
		this.m_MeshFilterSecondary.gameObject.SetActive(false);
		if (meshSecondary != null)
		{
			this.m_MeshFilterSecondary.mesh = meshSecondary;
			this.m_MeshSecondary.material = materialSecondary;
			this.m_MeshFilterSecondary.gameObject.SetActive(true);
		}
		else if (meshSecondary == null && materialSecondary != null)
		{
			Material[] materials3 = new Material[]
			{
				material,
				materialSecondary
			};
			this.m_Mesh.materials = materials3;
		}
		this.m_OutlineMeshFilter.mesh = mesh;
		this.m_Collider.size = InventoryBase.GetItemData(itemType).colliderScale;
		this.m_Collider.center = InventoryBase.GetItemData(itemType).colliderPosOffset;
		this.m_ItemVolume = InventoryBase.GetItemData(itemType).GetItemVolume();
		this.m_InteractableScanItem.enabled = false;
		this.m_ItemContentFill = 1f;
	}

	// Token: 0x060002C6 RID: 710 RVA: 0x0001A0C0 File Offset: 0x000182C0
	public void LerpToTransform(Transform targetTransform, Transform targetParent, bool ignoreUpForce = false)
	{
		this.m_Timer = 0f;
		this.m_UpTimer = 0f;
		this.m_Accelration = 0f;
		base.transform.parent = targetParent;
		this.m_StartPos = base.transform.position;
		this.m_StartRot = base.transform.rotation;
		this.m_StartScale = base.transform.localScale;
		this.m_TargetTransform = targetTransform;
		this.m_IsLerpingToPos = true;
		this.m_IsSmoothLerpingToPos = false;
		this.m_IsIgnoreUpForce = ignoreUpForce;
		this.m_Mesh.enabled = true;
	}

	// Token: 0x060002C7 RID: 711 RVA: 0x0001A158 File Offset: 0x00018358
	public void SmoothLerpToTransform(Transform targetTransform, Transform targetParent, bool ignoreUpForce = false)
	{
		this.m_Timer = 0f;
		this.m_UpTimer = 0f;
		this.m_Accelration = 0f;
		base.transform.parent = targetParent;
		this.m_StartPos = base.transform.position;
		this.m_StartRot = base.transform.rotation;
		this.m_StartScale = base.transform.localScale;
		this.m_TargetTransform = targetTransform;
		this.m_IsLerpingToPos = false;
		this.m_IsSmoothLerpingToPos = true;
		this.m_IsIgnoreUpForce = ignoreUpForce;
		this.m_Mesh.enabled = true;
	}

	// Token: 0x060002C8 RID: 712 RVA: 0x0001A1F0 File Offset: 0x000183F0
	private void Update()
	{
		if (this.m_IsLerpingToPos)
		{
			this.m_UpTimer += Time.deltaTime * this.m_UpLerpSpeed;
			if (this.m_UpTimer > 0.2f)
			{
				this.m_Timer += Time.deltaTime * this.m_LerpSpeed * (1f + this.m_Accelration);
				this.m_Accelration += Time.deltaTime;
			}
			else
			{
				this.m_Timer += Time.deltaTime * this.m_LerpSpeed * 0.1f;
			}
			Vector3 b = Vector3.up * (Mathf.PingPong(Mathf.Clamp(this.m_UpTimer, 0f, 2f), 1f) * this.m_UpLerpHeight);
			if (this.m_IsIgnoreUpForce)
			{
				b = Vector3.zero;
				this.m_UpTimer = 2f;
			}
			base.transform.position = Vector3.Lerp(this.m_StartPos, this.m_TargetTransform.position + b, this.m_Timer) + b;
			base.transform.rotation = Quaternion.Lerp(this.m_StartRot, this.m_TargetTransform.rotation, this.m_Timer);
			base.transform.localScale = Vector3.Lerp(this.m_StartScale, this.m_TargetTransform.localScale, this.m_Timer);
			if (this.m_Timer >= 1f && this.m_UpTimer >= 2f)
			{
				this.m_Timer = 0f;
				this.m_UpTimer = 0f;
				this.m_Accelration = 0f;
				this.m_IsLerpingToPos = false;
				if (this.m_IsHideAfterFinishLerp)
				{
					this.m_IsHideAfterFinishLerp = false;
					base.gameObject.SetActive(false);
					return;
				}
			}
		}
		else if (this.m_IsSmoothLerpingToPos)
		{
			this.m_UpTimer += Time.deltaTime * this.m_UpLerpSpeed * 0.75f;
			Vector3 b2 = Vector3.up * (Mathf.PingPong(Mathf.Clamp(this.m_UpTimer, 0f, 2f), 1f) * this.m_UpLerpHeight);
			if (this.m_UpTimer > 0.2f)
			{
				this.m_Timer += Time.deltaTime * this.m_LerpSpeed * (1f + this.m_Accelration);
				this.m_Accelration += Time.deltaTime;
				base.transform.position = Vector3.Lerp(base.transform.position, this.m_TargetTransform.position + b2, Time.deltaTime * 10f);
				base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.m_TargetTransform.rotation, Time.deltaTime * 10f);
				base.transform.localScale = Vector3.Lerp(base.transform.localScale, this.m_TargetTransform.localScale, Time.deltaTime * 10f);
			}
			else
			{
				this.m_Timer += Time.deltaTime * this.m_LerpSpeed * 0.1f;
				base.transform.position = Vector3.Lerp(base.transform.position, this.m_TargetTransform.position + b2, Time.deltaTime * 2f) + b2;
				base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.m_TargetTransform.rotation, Time.deltaTime * 2f);
				base.transform.localScale = Vector3.Lerp(base.transform.localScale, this.m_TargetTransform.localScale, Time.deltaTime * 2f);
			}
			if (this.m_IsIgnoreUpForce)
			{
				b2 = Vector3.zero;
				this.m_UpTimer = 2f;
			}
		}
	}

	// Token: 0x060002C9 RID: 713 RVA: 0x0001A5D1 File Offset: 0x000187D1
	public void DepleteContent(float amount)
	{
		this.m_ItemContentFill -= amount;
		if (this.m_ItemContentFill <= 0f)
		{
			this.m_ItemContentFill = 0f;
		}
	}

	// Token: 0x060002CA RID: 714 RVA: 0x0001A5F9 File Offset: 0x000187F9
	public float GetContentFill()
	{
		return this.m_ItemContentFill;
	}

	// Token: 0x060002CB RID: 715 RVA: 0x0001A601 File Offset: 0x00018801
	public void SetContentFill(float itemContentFill)
	{
		this.m_ItemContentFill = itemContentFill;
	}

	// Token: 0x060002CC RID: 716 RVA: 0x0001A60A File Offset: 0x0001880A
	public void SetHideItemAfterFinishLerp()
	{
		this.m_IsHideAfterFinishLerp = true;
	}

	// Token: 0x060002CD RID: 717 RVA: 0x0001A613 File Offset: 0x00018813
	public void SetCurrentPrice(float price)
	{
		this.m_CurrentPrice = price;
	}

	// Token: 0x060002CE RID: 718 RVA: 0x0001A61C File Offset: 0x0001881C
	public float GetCurrentPrice()
	{
		return this.m_CurrentPrice;
	}

	// Token: 0x060002CF RID: 719 RVA: 0x0001A624 File Offset: 0x00018824
	public float GetItemVolume()
	{
		return this.m_ItemVolume;
	}

	// Token: 0x060002D0 RID: 720 RVA: 0x0001A62C File Offset: 0x0001882C
	public EItemType GetItemType()
	{
		return this.m_ItemType;
	}

	// Token: 0x060002D1 RID: 721 RVA: 0x0001A634 File Offset: 0x00018834
	public void DisableItem()
	{
		this.m_TargetTransform = null;
		this.m_IsLerpingToPos = false;
		this.m_IsSmoothLerpingToPos = false;
		ItemSpawnManager.DisableItem(this);
	}

	// Token: 0x0400032C RID: 812
	public MeshFilter m_MeshFilter;

	// Token: 0x0400032D RID: 813
	public MeshRenderer m_Mesh;

	// Token: 0x0400032E RID: 814
	public MeshFilter m_MeshFilterSecondary;

	// Token: 0x0400032F RID: 815
	public MeshRenderer m_MeshSecondary;

	// Token: 0x04000330 RID: 816
	public MeshFilter m_OutlineMeshFilter;

	// Token: 0x04000331 RID: 817
	public BoxCollider m_Collider;

	// Token: 0x04000332 RID: 818
	public Rigidbody m_Rigidbody;

	// Token: 0x04000333 RID: 819
	public InteractableScanItem m_InteractableScanItem;

	// Token: 0x04000334 RID: 820
	private bool m_IsLerpingToPos;

	// Token: 0x04000335 RID: 821
	private bool m_IsSmoothLerpingToPos;

	// Token: 0x04000336 RID: 822
	private bool m_IsHideAfterFinishLerp;

	// Token: 0x04000337 RID: 823
	private bool m_IsIgnoreUpForce;

	// Token: 0x04000338 RID: 824
	private float m_ItemVolume;

	// Token: 0x04000339 RID: 825
	private float m_Timer;

	// Token: 0x0400033A RID: 826
	private float m_UpTimer;

	// Token: 0x0400033B RID: 827
	private float m_LerpSpeed = 3f;

	// Token: 0x0400033C RID: 828
	private float m_Accelration;

	// Token: 0x0400033D RID: 829
	private float m_UpLerpSpeed = 5f;

	// Token: 0x0400033E RID: 830
	private float m_UpLerpHeight = 0.1f;

	// Token: 0x0400033F RID: 831
	private float m_CurrentPrice;

	// Token: 0x04000340 RID: 832
	private float m_ItemContentFill = 1f;

	// Token: 0x04000341 RID: 833
	private Vector3 m_StartPos;

	// Token: 0x04000342 RID: 834
	private Quaternion m_StartRot;

	// Token: 0x04000343 RID: 835
	private Vector3 m_StartScale;

	// Token: 0x04000344 RID: 836
	private Transform m_TargetTransform;

	// Token: 0x04000345 RID: 837
	private EItemType m_ItemType;
}
