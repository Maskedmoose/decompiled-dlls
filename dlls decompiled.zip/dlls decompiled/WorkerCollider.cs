﻿using System;
using UnityEngine;

// Token: 0x02000090 RID: 144
public class WorkerCollider : MonoBehaviour
{
	// Token: 0x060005BC RID: 1468 RVA: 0x00030630 File Offset: 0x0002E830
	public void OnRaycasted()
	{
		this.m_Worker.OnRaycasted();
	}

	// Token: 0x060005BD RID: 1469 RVA: 0x0003063D File Offset: 0x0002E83D
	public void OnRaycastEnded()
	{
		this.m_Worker.OnRaycastEnded();
	}

	// Token: 0x060005BE RID: 1470 RVA: 0x0003064A File Offset: 0x0002E84A
	public void OnMousePress()
	{
		this.m_Worker.OnMousePress();
	}

	// Token: 0x04000781 RID: 1921
	public Worker m_Worker;
}
