﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200002C RID: 44
public class InteractableWorkbench : InteractableObject
{
	// Token: 0x06000232 RID: 562 RVA: 0x000150D4 File Offset: 0x000132D4
	protected override void Awake()
	{
		base.Awake();
		ShelfManager.InitWorkbench(this);
		this.m_JankBoxAnim.gameObject.SetActive(false);
		for (int i = 0; i < this.m_CardEnterBoxAnimList.Count; i++)
		{
			Card3dUIGroup cardUI = CSingleton<Card3dUISpawner>.Instance.GetCardUI();
			cardUI.transform.position = this.m_InteractableCard3dList[i].transform.position;
			cardUI.transform.rotation = this.m_InteractableCard3dList[i].transform.rotation;
			this.m_InteractableCard3dList[i].SetCardUIFollow(cardUI);
			cardUI.SetVisibility(false);
			this.m_CardEnterBoxAnimList[i].gameObject.SetActive(false);
		}
	}

	// Token: 0x06000233 RID: 563 RVA: 0x00015198 File Offset: 0x00013398
	protected override void Update()
	{
		base.Update();
		if (this.m_IsPlayCardEnterAnim)
		{
			this.m_CardEnterTimer += Time.deltaTime;
			if (this.m_CardEnterTimer > 0.1f)
			{
				this.m_CardEnterBoxAnimList[this.m_CardEnterIndex].gameObject.SetActive(false);
				this.m_CardEnterBoxAnimList[this.m_CardEnterIndex].gameObject.SetActive(true);
				this.m_InteractableCard3dList[this.m_CardEnterIndex].m_Card3dUI.SetVisibility(true);
				this.m_CardEnterBoxAnimList[this.m_CardEnterIndex].Play();
				this.m_CardEnterTimer = 0f;
				this.m_CardEnterIndex++;
				if (this.m_CardEnterIndex >= this.m_InteractableCard3dList.Count)
				{
					this.m_IsPlayCardEnterAnim = false;
					this.m_CardEnterIndex = 0;
				}
			}
		}
	}

	// Token: 0x06000234 RID: 564 RVA: 0x00015280 File Offset: 0x00013480
	public override void OnMouseButtonUp()
	{
		CSingleton<InteractionPlayerController>.Instance.OnEnterWorkbenchMode();
		this.OnRaycastEnded();
		InteractionPlayerController.SetPlayerPos(this.m_LockPlayerPos.position);
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		CSingleton<InteractionPlayerController>.Instance.ForceLookAt(this.m_PlayerLookRot, 3f);
		this.m_NavMeshCutWhenManned.SetActive(true);
		WorkbenchUIScreen.OpenScreen(this);
	}

	// Token: 0x06000235 RID: 565 RVA: 0x000152DE File Offset: 0x000134DE
	public override void OnRightMouseButtonUp()
	{
		base.OnRightMouseButtonUp();
		Debug.Log("OnRightMouseButtonUp");
	}

	// Token: 0x06000236 RID: 566 RVA: 0x000152F0 File Offset: 0x000134F0
	public override void OnPressEsc()
	{
		CSingleton<InteractionPlayerController>.Instance.OnExitWorkbenchMode();
		this.m_NavMeshCutWhenManned.SetActive(false);
		this.m_JankBoxAnim.gameObject.SetActive(false);
		this.m_JankBoxAnim.SetBool("IsClosing", false);
		for (int i = 0; i < this.m_CardEnterBoxAnimList.Count; i++)
		{
			this.m_InteractableCard3dList[i].m_Card3dUI.SetVisibility(false);
			this.m_CardEnterBoxAnimList[i].gameObject.SetActive(false);
		}
	}

	// Token: 0x06000237 RID: 567 RVA: 0x0001537C File Offset: 0x0001357C
	public void PlayBundlingCardBoxSequence(List<CardData> cardDataListShown, ECardExpansionType cardExpansionType)
	{
		this.m_JankBoxAnim.gameObject.SetActive(true);
		this.m_JankBoxAnim.SetBool("IsClosing", true);
		ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(this.GetBulkBoxItemType(cardExpansionType));
		this.m_JankBoxSkinMesh.material = itemMeshData.material;
		for (int i = 0; i < cardDataListShown.Count; i++)
		{
			this.m_InteractableCard3dList[i].m_Card3dUI.m_CardUI.SetCardUI(cardDataListShown[i]);
		}
		this.m_IsPlayCardEnterAnim = true;
	}

	// Token: 0x06000238 RID: 568 RVA: 0x00015404 File Offset: 0x00013604
	public void OnTaskCompleted(ECardExpansionType cardExpansionType)
	{
		this.m_JankBoxAnim.gameObject.SetActive(false);
		EItemType bulkBoxItemType = this.GetBulkBoxItemType(cardExpansionType);
		ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(bulkBoxItemType);
		Item item = ItemSpawnManager.GetItem(this.m_SpawnItemPos);
		item.SetMesh(itemMeshData.mesh, itemMeshData.material, bulkBoxItemType, itemMeshData.meshSecondary, itemMeshData.materialSecondary);
		item.transform.position = this.m_SpawnItemPos.position;
		item.transform.rotation = this.m_SpawnItemPos.rotation;
		item.gameObject.SetActive(true);
		CSingleton<InteractionPlayerController>.Instance.AddHoldItemToFront(item);
	}

	// Token: 0x06000239 RID: 569 RVA: 0x000154A4 File Offset: 0x000136A4
	public EItemType GetBulkBoxItemType(ECardExpansionType cardExpansionType)
	{
		EItemType result = EItemType.BulkBox_TetramonBase;
		if (cardExpansionType == ECardExpansionType.Destiny)
		{
			result = EItemType.BulkBox_TetramonDestiny;
		}
		return result;
	}

	// Token: 0x0600023A RID: 570 RVA: 0x000154BC File Offset: 0x000136BC
	public void DispenseItemFromBox(InteractablePackagingBox_Item itemBox, bool isPlayer)
	{
		if (itemBox)
		{
			if (this.IsValidItemType(itemBox.m_ItemCompartment.GetItemType()))
			{
				if (itemBox.m_ItemCompartment.GetItemCount() > 0)
				{
					if (this.HasEnoughSlot())
					{
						Item firstItem = itemBox.m_ItemCompartment.GetFirstItem();
						this.AddItem(firstItem, true);
						itemBox.m_ItemCompartment.RemoveItem(firstItem);
						if (isPlayer)
						{
							SoundManager.GenericPop(1f, 1f);
							return;
						}
					}
					else if (isPlayer)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AutoCleanserNoSlot);
						return;
					}
				}
				else if (isPlayer)
				{
					NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxNoItem);
					return;
				}
			}
			else if (isPlayer)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CanOnlyPutBulkBox);
			}
		}
	}

	// Token: 0x0600023B RID: 571 RVA: 0x0001554C File Offset: 0x0001374C
	public void AddItem(Item item, bool addToFront)
	{
		this.m_ItemAmount++;
		if (addToFront)
		{
			this.m_StoredItemList.Insert(0, item);
		}
		else
		{
			this.m_StoredItemList.Add(item);
		}
		item.LerpToTransform(this.m_PosList[this.m_ItemAmount - 1], this.m_PosList[this.m_ItemAmount - 1], false);
	}

	// Token: 0x0600023C RID: 572 RVA: 0x000155B2 File Offset: 0x000137B2
	public void RemoveItem(Item item)
	{
		this.m_ItemAmount--;
		this.m_StoredItemList.Remove(item);
	}

	// Token: 0x0600023D RID: 573 RVA: 0x000155D0 File Offset: 0x000137D0
	public Item TakeItemToHand(bool getLastItem = true)
	{
		if (this.m_ItemAmount <= 0)
		{
			return null;
		}
		Item item = this.GetLastItem();
		if (!getLastItem)
		{
			item = this.GetFirstItem();
		}
		this.m_ItemAmount--;
		this.m_StoredItemList.Remove(item);
		return item;
	}

	// Token: 0x0600023E RID: 574 RVA: 0x00015615 File Offset: 0x00013815
	public bool HasEnoughSlot()
	{
		return this.m_ItemAmount < this.m_PosList.Count;
	}

	// Token: 0x0600023F RID: 575 RVA: 0x0001562D File Offset: 0x0001382D
	public int GetItemCount()
	{
		return this.m_ItemAmount;
	}

	// Token: 0x06000240 RID: 576 RVA: 0x00015635 File Offset: 0x00013835
	public Item GetFirstItem()
	{
		return this.m_StoredItemList[0];
	}

	// Token: 0x06000241 RID: 577 RVA: 0x00015643 File Offset: 0x00013843
	public Item GetLastItem()
	{
		if (this.m_StoredItemList.Count <= 0)
		{
			return null;
		}
		return this.m_StoredItemList[this.m_ItemAmount - 1];
	}

	// Token: 0x06000242 RID: 578 RVA: 0x00015668 File Offset: 0x00013868
	public bool IsValidItemType(EItemType itemType)
	{
		return itemType == EItemType.BulkBox_TetramonBase || itemType == EItemType.BulkBox_TetramonDestiny;
	}

	// Token: 0x06000243 RID: 579 RVA: 0x00015678 File Offset: 0x00013878
	public void LoadData(WorkbenchSaveData saveData)
	{
		for (int i = 0; i < saveData.itemTypeList.Count; i++)
		{
			ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(saveData.itemTypeList[i]);
			Item item = ItemSpawnManager.GetItem(this.m_PosList[i]);
			item.SetMesh(itemMeshData.mesh, itemMeshData.material, saveData.itemTypeList[i], itemMeshData.meshSecondary, itemMeshData.materialSecondary);
			item.transform.localPosition = Vector3.zero;
			item.transform.localRotation = Quaternion.identity;
			item.gameObject.SetActive(true);
			this.AddItem(item, true);
		}
	}

	// Token: 0x0400026E RID: 622
	public Transform m_LockPlayerPos;

	// Token: 0x0400026F RID: 623
	public Transform m_PlayerLookRot;

	// Token: 0x04000270 RID: 624
	public Transform m_SpawnItemPos;

	// Token: 0x04000271 RID: 625
	public List<Transform> m_PosList;

	// Token: 0x04000272 RID: 626
	public GameObject m_NavMeshCutWhenManned;

	// Token: 0x04000273 RID: 627
	public Animator m_JankBoxAnim;

	// Token: 0x04000274 RID: 628
	public SkinnedMeshRenderer m_JankBoxSkinMesh;

	// Token: 0x04000275 RID: 629
	public List<Animation> m_CardEnterBoxAnimList;

	// Token: 0x04000276 RID: 630
	public List<InteractableCard3d> m_InteractableCard3dList;

	// Token: 0x04000277 RID: 631
	private bool m_IsPlayCardEnterAnim;

	// Token: 0x04000278 RID: 632
	private int m_CardEnterIndex;

	// Token: 0x04000279 RID: 633
	private float m_CardEnterTimer;

	// Token: 0x0400027A RID: 634
	private int m_ItemAmount;

	// Token: 0x0400027B RID: 635
	public List<Item> m_StoredItemList;
}
