﻿using System;
using UnityEngine;

// Token: 0x02000094 RID: 148
public class WorldCanvasUIManager : CSingleton<WorldCanvasUIManager>
{
	// Token: 0x060005DC RID: 1500 RVA: 0x00030D57 File Offset: 0x0002EF57
	private void Awake()
	{
	}

	// Token: 0x060005DD RID: 1501 RVA: 0x00030D59 File Offset: 0x0002EF59
	public static UI_CashCounterScreen SpawnCashCounterScreenUI(Transform followTarget)
	{
		UI_CashCounterScreen ui_CashCounterScreen = Object.Instantiate<UI_CashCounterScreen>(CSingleton<WorldCanvasUIManager>.Instance.m_UICashCounterScreenPrefab, followTarget.position, followTarget.rotation, CSingleton<WorldCanvasUIManager>.Instance.m_UIParentGrp);
		ui_CashCounterScreen.m_FollowObject.SetFollowTarget(followTarget);
		ui_CashCounterScreen.m_FollowObject.enabled = true;
		return ui_CashCounterScreen;
	}

	// Token: 0x060005DE RID: 1502 RVA: 0x00030D98 File Offset: 0x0002EF98
	public static UI_CreditCardScreen SpawnCreditCardScreenUI(Transform followTarget)
	{
		UI_CreditCardScreen ui_CreditCardScreen = Object.Instantiate<UI_CreditCardScreen>(CSingleton<WorldCanvasUIManager>.Instance.m_UICreditCardScreenPrefab, followTarget.position, followTarget.rotation, CSingleton<WorldCanvasUIManager>.Instance.m_UIParentGrp);
		ui_CreditCardScreen.m_FollowObject.SetFollowTarget(followTarget);
		ui_CreditCardScreen.m_FollowObject.enabled = true;
		return ui_CreditCardScreen;
	}

	// Token: 0x040007A5 RID: 1957
	public static WorldCanvasUIManager m_Instance;

	// Token: 0x040007A6 RID: 1958
	public UI_CashCounterScreen m_UICashCounterScreenPrefab;

	// Token: 0x040007A7 RID: 1959
	public UI_CreditCardScreen m_UICreditCardScreenPrefab;

	// Token: 0x040007A8 RID: 1960
	public Transform m_UIParentGrp;
}
