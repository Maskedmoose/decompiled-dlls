﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001BA RID: 442
	public class Apparel_Menu : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000C87 RID: 3207 RVA: 0x0005794C File Offset: 0x00055B4C
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util parentUI)
		{
			this.customizer = customizerScript;
			this.RefreshUIElement();
		}

		// Token: 0x06000C88 RID: 3208 RVA: 0x0005795C File Offset: 0x00055B5C
		public void setOption(int i)
		{
			this.navIndex = i;
			this.OptionText.text = this.customizer.ApparelTables[i].Label;
			foreach (object obj in this.Container.transform)
			{
				Object.Destroy(((Transform)obj).gameObject);
			}
			foreach (scrObj_Apparel.Apparel apparel in this.customizer.ApparelTables[i].Items)
			{
				int Slot = i;
				for (int j = 0; j < apparel.Materials.Count; j++)
				{
					string name = apparel.Name;
					int matIndex = j;
					GameObject gameObject = Object.Instantiate<GameObject>(this.ButtonPrefab, this.Container.transform).gameObject;
					gameObject.GetComponentInChildren<Button>().onClick.AddListener(delegate()
					{
						this.customizer.setApparelByName(name, Slot, matIndex);
					});
					gameObject.GetComponentInChildren<TextMeshProUGUI>().text = apparel.Materials[j].Label + " " + apparel.DisplayName;
				}
				if (apparel.Materials.Count == 0)
				{
					string name = apparel.Name;
					GameObject gameObject2 = Object.Instantiate<GameObject>(this.ButtonPrefab, this.Container.transform).gameObject;
					gameObject2.GetComponentInChildren<Button>().onClick.AddListener(delegate()
					{
						this.customizer.setApparelByName(name, Slot, 0);
					});
					gameObject2.GetComponentInChildren<TextMeshProUGUI>().text = apparel.DisplayName;
				}
			}
		}

		// Token: 0x06000C89 RID: 3209 RVA: 0x00057B80 File Offset: 0x00055D80
		public void navLeft()
		{
			this.setOption((this.navIndex == 0) ? (this.optionsCount - 1) : (this.navIndex - 1));
		}

		// Token: 0x06000C8A RID: 3210 RVA: 0x00057BA2 File Offset: 0x00055DA2
		public void navRight()
		{
			this.setOption((this.navIndex == this.optionsCount - 1) ? 0 : (this.navIndex + 1));
		}

		// Token: 0x06000C8B RID: 3211 RVA: 0x00057BC5 File Offset: 0x00055DC5
		public void RefreshUIElement()
		{
			this.optionsCount = this.customizer.ApparelTables.Count;
			this.setOption(0);
		}

		// Token: 0x04001366 RID: 4966
		public GameObject ButtonPrefab;

		// Token: 0x04001367 RID: 4967
		public GameObject Container;

		// Token: 0x04001368 RID: 4968
		public TextMeshProUGUI OptionText;

		// Token: 0x04001369 RID: 4969
		private CharacterCustomization customizer;

		// Token: 0x0400136A RID: 4970
		private int navIndex;

		// Token: 0x0400136B RID: 4971
		private int optionsCount;
	}
}
