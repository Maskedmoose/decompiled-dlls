﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D8 RID: 472
	public abstract class Controller : MonoBehaviour
	{
		// Token: 0x06000D3F RID: 3391
		public abstract Vector3 GetVelocity();

		// Token: 0x06000D40 RID: 3392
		public abstract Vector3 GetMovementVelocity();

		// Token: 0x06000D41 RID: 3393
		public abstract bool IsGrounded();

		// Token: 0x04001434 RID: 5172
		public Controller.VectorEvent OnJump;

		// Token: 0x04001435 RID: 5173
		public Controller.VectorEvent OnLand;

		// Token: 0x0200027E RID: 638
		// (Invoke) Token: 0x06001010 RID: 4112
		public delegate void VectorEvent(Vector3 v);
	}
}
