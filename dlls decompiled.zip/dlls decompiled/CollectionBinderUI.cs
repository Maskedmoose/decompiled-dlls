﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x0200005D RID: 93
public class CollectionBinderUI : MonoBehaviour
{
	// Token: 0x0600041C RID: 1052 RVA: 0x00024686 File Offset: 0x00022886
	private void Awake()
	{
		this.m_ScreenGrp.SetActive(false);
		this.m_SortAlbumScreen.SetActive(false);
		this.m_CardNameText.gameObject.SetActive(false);
		this.m_CardFullRarityNameText.gameObject.SetActive(false);
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x000246C2 File Offset: 0x000228C2
	public void OpenScreen()
	{
		this.m_ScreenGrp.SetActive(true);
	}

	// Token: 0x0600041E RID: 1054 RVA: 0x000246D0 File Offset: 0x000228D0
	public void CloseScreen()
	{
		this.m_ScreenGrp.SetActive(false);
	}

	// Token: 0x0600041F RID: 1055 RVA: 0x000246DE File Offset: 0x000228DE
	public void SetMaxPage(int maxPage)
	{
		this.m_MaxPage = maxPage;
	}

	// Token: 0x06000420 RID: 1056 RVA: 0x000246E7 File Offset: 0x000228E7
	public void SetCardCollected(int current, ECardExpansionType expansionType)
	{
		this.m_CardCollectedText.text = current.ToString() + " / " + this.m_MaxCardCollectionCount.ToString();
	}

	// Token: 0x06000421 RID: 1057 RVA: 0x00024710 File Offset: 0x00022910
	public void SetMaxCardCollectCount(int maxCardCollectionCount)
	{
		this.m_MaxCardCollectionCount = maxCardCollectionCount;
	}

	// Token: 0x06000422 RID: 1058 RVA: 0x00024719 File Offset: 0x00022919
	public void SetTotalValue(float totalValue)
	{
		this.m_TotalValueText.text = GameInstance.GetPriceString(totalValue, false, true, false, "F2");
	}

	// Token: 0x06000423 RID: 1059 RVA: 0x00024734 File Offset: 0x00022934
	public void SetCurrentPage(int pageIndex)
	{
		this.m_PageText.text = pageIndex.ToString() + " / " + this.m_MaxPage.ToString();
	}

	// Token: 0x06000424 RID: 1060 RVA: 0x00024760 File Offset: 0x00022960
	public void OpenExpansionSelectScreen(int currentExpansionIndex)
	{
		if (this.m_ExpansionSelectScreen.activeSelf)
		{
			this.CloseExpansionSelectScreen();
			return;
		}
		InteractionPlayerController.TempHideToolTip();
		InteractionPlayerController.AddToolTip(EGameAction.CloseCardAlbum, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.BackF, false, false);
		CSingleton<InteractionPlayerController>.Instance.ShowCursor();
		SoundManager.GenericMenuOpen(1f, 1f);
		this.m_ExpansionSelectHighlightBtn.transform.position = this.m_ExpansionBtnList[currentExpansionIndex].position;
		this.m_ExpansionSelectScreen.SetActive(true);
	}

	// Token: 0x06000425 RID: 1061 RVA: 0x000247DE File Offset: 0x000229DE
	public void CloseExpansionSelectScreen()
	{
		InteractionPlayerController.RestoreHiddenToolTip();
		CSingleton<InteractionPlayerController>.Instance.HideCursor();
		SoundManager.GenericMenuClose(1f, 1f);
		this.m_ExpansionSelectScreen.SetActive(false);
	}

	// Token: 0x06000426 RID: 1062 RVA: 0x0002480C File Offset: 0x00022A0C
	public void OpenSortAlbumScreen(int sortingMethodIndex, int currentExpansionIndex)
	{
		if (this.m_SortAlbumScreen.activeSelf)
		{
			this.CloseSortAlbumScreen();
			return;
		}
		InteractionPlayerController.TempHideToolTip();
		InteractionPlayerController.AddToolTip(EGameAction.CloseCardAlbum, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.BackF, false, false);
		CSingleton<InteractionPlayerController>.Instance.ShowCursor();
		SoundManager.GenericMenuOpen(1f, 1f);
		this.m_SortAlbumHighlightBtn.transform.position = this.m_SortAlbumBtnList[sortingMethodIndex].position;
		this.m_ExpansionSelectHighlightBtn.transform.position = this.m_ExpansionBtnList[currentExpansionIndex].position;
		this.m_SortAlbumScreen.SetActive(true);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_SortAlbumScreenUIExtension);
	}

	// Token: 0x06000427 RID: 1063 RVA: 0x000248B6 File Offset: 0x00022AB6
	public void CloseSortAlbumScreen()
	{
		InteractionPlayerController.RestoreHiddenToolTip();
		CSingleton<InteractionPlayerController>.Instance.HideCursor();
		SoundManager.GenericMenuClose(1f, 1f);
		this.m_SortAlbumScreen.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_SortAlbumScreenUIExtension);
	}

	// Token: 0x06000428 RID: 1064 RVA: 0x000248ED File Offset: 0x00022AED
	public void OnPressSwitchSortingMethod(int sortingMethodIndex)
	{
		CSingleton<InteractionPlayerController>.Instance.HideCursor();
		SoundManager.GenericConfirm(1f, 1f);
		this.m_CollectionAlbum.OnPressSwitchSortingMethod(sortingMethodIndex);
		this.m_SortAlbumScreen.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_SortAlbumScreenUIExtension);
	}

	// Token: 0x06000429 RID: 1065 RVA: 0x0002492B File Offset: 0x00022B2B
	public void OnPressSwitchExpansion(int expansionIndex)
	{
		CSingleton<InteractionPlayerController>.Instance.HideCursor();
		SoundManager.GenericConfirm(1f, 1f);
		this.m_CollectionAlbum.OnPressSwitchExpansion(expansionIndex);
		this.m_SortAlbumScreen.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_SortAlbumScreenUIExtension);
	}

	// Token: 0x040004F7 RID: 1271
	public ControllerScreenUIExtension m_SortAlbumScreenUIExtension;

	// Token: 0x040004F8 RID: 1272
	public CollectionBinderFlipAnimCtrl m_CollectionAlbum;

	// Token: 0x040004F9 RID: 1273
	public GameObject m_ScreenGrp;

	// Token: 0x040004FA RID: 1274
	public GameObject m_SortAlbumScreen;

	// Token: 0x040004FB RID: 1275
	public GameObject m_SortAlbumHighlightBtn;

	// Token: 0x040004FC RID: 1276
	public GameObject m_ExpansionSelectScreen;

	// Token: 0x040004FD RID: 1277
	public GameObject m_ExpansionSelectHighlightBtn;

	// Token: 0x040004FE RID: 1278
	public List<Transform> m_SortAlbumBtnList;

	// Token: 0x040004FF RID: 1279
	public List<Transform> m_ExpansionBtnList;

	// Token: 0x04000500 RID: 1280
	public TextMeshProUGUI m_CardCollectedText;

	// Token: 0x04000501 RID: 1281
	public TextMeshProUGUI m_PageText;

	// Token: 0x04000502 RID: 1282
	public TextMeshProUGUI m_CardNameText;

	// Token: 0x04000503 RID: 1283
	public TextMeshProUGUI m_CardFullRarityNameText;

	// Token: 0x04000504 RID: 1284
	public TextMeshProUGUI m_TotalValueText;

	// Token: 0x04000505 RID: 1285
	public Animation m_CardNameFoilAnim;

	// Token: 0x04000506 RID: 1286
	public Animation m_CardFullRarityNameFoilAnim;

	// Token: 0x04000507 RID: 1287
	private int m_MaxPage;

	// Token: 0x04000508 RID: 1288
	private int m_MaxCardCollectionCount;
}
