﻿using System;
using UnityEngine;

// Token: 0x02000018 RID: 24
public class InteractableCard3d : InteractableObject
{
	// Token: 0x0600011C RID: 284 RVA: 0x0000F8D4 File Offset: 0x0000DAD4
	protected override void Start()
	{
		base.Start();
	}

	// Token: 0x0600011D RID: 285 RVA: 0x0000F8DC File Offset: 0x0000DADC
	public override void OnMouseButtonUp()
	{
		base.OnMouseButtonUp();
		if (this.m_CurrentCustomer)
		{
			this.OnCardScanned();
		}
	}

	// Token: 0x0600011E RID: 286 RVA: 0x0000F8F7 File Offset: 0x0000DAF7
	public void SetCardUIFollow(Card3dUIGroup card3dUI)
	{
		if (card3dUI)
		{
			this.m_IsCard3dUIFollow = true;
			this.m_Card3dUI = card3dUI;
			return;
		}
		this.m_IsCard3dUIFollow = false;
		this.m_Card3dUI = null;
	}

	// Token: 0x0600011F RID: 287 RVA: 0x0000F91E File Offset: 0x0000DB1E
	public void SetTargetRotation(Quaternion targetRot)
	{
		this.m_IsLerpingCardRot = true;
		this.m_CardTargetLerpRot = targetRot;
	}

	// Token: 0x06000120 RID: 288 RVA: 0x0000F92E File Offset: 0x0000DB2E
	public override void OnRaycasted()
	{
		if (this.m_IsLerpingToPos)
		{
			return;
		}
		base.OnRaycasted();
		if (this.m_CollectionBinderFlipAnimCtrl)
		{
			this.m_CollectionBinderFlipAnimCtrl.OnCardRaycasted(this);
		}
	}

	// Token: 0x06000121 RID: 289 RVA: 0x0000F958 File Offset: 0x0000DB58
	public override void OnRaycastEnded()
	{
		if (this.m_IsLerpingToPos)
		{
			return;
		}
		base.OnRaycastEnded();
		if (this.m_CollectionBinderFlipAnimCtrl)
		{
			this.m_CollectionBinderFlipAnimCtrl.OnCardRaycastEnded();
		}
	}

	// Token: 0x06000122 RID: 290 RVA: 0x0000F981 File Offset: 0x0000DB81
	public void SetEnableCollision(bool isEnable)
	{
		this.m_BoxCollider.enabled = isEnable;
	}

	// Token: 0x06000123 RID: 291 RVA: 0x0000F990 File Offset: 0x0000DB90
	protected override void LateUpdate()
	{
		if (this.m_IsCard3dUIFollow)
		{
			this.m_Card3dUI.transform.position = base.transform.position;
			this.m_Card3dUI.transform.rotation = base.transform.rotation;
		}
		if (this.m_IsLerpingCardRot)
		{
			this.m_Card3dUI.m_ScaleGrp.localRotation = Quaternion.Lerp(this.m_Card3dUI.m_ScaleGrp.localRotation, this.m_CardTargetLerpRot, Time.deltaTime * 5f);
		}
		base.LateUpdate();
	}

	// Token: 0x06000124 RID: 292 RVA: 0x0000FA20 File Offset: 0x0000DC20
	protected override void OnFinishLerp()
	{
		base.OnFinishLerp();
		if (this.m_IsHideAfterFinishLerp)
		{
			this.m_Card3dUI.gameObject.SetActive(false);
			base.gameObject.SetActive(false);
			if (this.m_CollectionBinderFlipAnimCtrl)
			{
				this.m_CollectionBinderFlipAnimCtrl.OnCardFinishLerpHide();
			}
		}
	}

	// Token: 0x06000125 RID: 293 RVA: 0x0000FA70 File Offset: 0x0000DC70
	public override void OnDestroyed()
	{
		if (this.m_Card3dUI && this.m_IsCard3dUIFollow)
		{
			this.m_Card3dUI.DisableCard();
		}
		this.m_CurrentCustomer = null;
		base.OnDestroyed();
	}

	// Token: 0x06000126 RID: 294 RVA: 0x0000FAA0 File Offset: 0x0000DCA0
	public void OnCardScanned()
	{
		this.m_Collider.enabled = false;
		this.m_Rigidbody.isKinematic = true;
		this.m_CurrentCustomer.OnCardScanned(this);
		this.m_CurrentCustomer = null;
		base.LerpToTransform(this.m_ScannedItemLerpPos, this.m_ScannedItemLerpPos);
		base.SetHideItemAfterFinishLerp();
	}

	// Token: 0x06000127 RID: 295 RVA: 0x0000FAF0 File Offset: 0x0000DCF0
	public void RegisterScanCard(Customer customer, Transform scannedItemLerpPos)
	{
		this.m_CurrentCustomer = customer;
		this.m_ScannedItemLerpPos = scannedItemLerpPos;
	}

	// Token: 0x06000128 RID: 296 RVA: 0x0000FB00 File Offset: 0x0000DD00
	public void SetCurrentPrice(float price)
	{
		this.m_CurrentPrice = price;
	}

	// Token: 0x06000129 RID: 297 RVA: 0x0000FB09 File Offset: 0x0000DD09
	public float GetCurrentPrice()
	{
		return this.m_CurrentPrice;
	}

	// Token: 0x0600012A RID: 298 RVA: 0x0000FB11 File Offset: 0x0000DD11
	public bool IsNotScanned()
	{
		return this.m_CurrentCustomer;
	}

	// Token: 0x0600012B RID: 299 RVA: 0x0000FB23 File Offset: 0x0000DD23
	public bool IsDisplayedOnShelf()
	{
		return this.m_IsDisplayedOnShelf;
	}

	// Token: 0x0600012C RID: 300 RVA: 0x0000FB2B File Offset: 0x0000DD2B
	public void SetIsDisplayedOnShelf(bool isDisplayedOnShelf)
	{
		this.m_CollectionBinderFlipAnimCtrl = null;
		this.m_IsDisplayedOnShelf = isDisplayedOnShelf;
	}

	// Token: 0x04000192 RID: 402
	public bool m_IsCardAlbumCard;

	// Token: 0x04000193 RID: 403
	public CollectionBinderFlipAnimCtrl m_CollectionBinderFlipAnimCtrl;

	// Token: 0x04000194 RID: 404
	public Card3dUIGroup m_Card3dUI;

	// Token: 0x04000195 RID: 405
	public BoxCollider m_Collider;

	// Token: 0x04000196 RID: 406
	public Rigidbody m_Rigidbody;

	// Token: 0x04000197 RID: 407
	public bool m_IsCard3dUIFollow;

	// Token: 0x04000198 RID: 408
	private bool m_IsLerpingCardRot;

	// Token: 0x04000199 RID: 409
	private bool m_IsDisplayedOnShelf;

	// Token: 0x0400019A RID: 410
	private float m_CurrentPrice;

	// Token: 0x0400019B RID: 411
	private Quaternion m_CardTargetLerpRot;

	// Token: 0x0400019C RID: 412
	private Customer m_CurrentCustomer;

	// Token: 0x0400019D RID: 413
	private Transform m_ScannedItemLerpPos;
}
