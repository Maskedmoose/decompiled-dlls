﻿using System;
using UnityEngine;

// Token: 0x02000123 RID: 291
public class TouchScrollVertical : MonoBehaviour
{
	// Token: 0x06000881 RID: 2177 RVA: 0x0003F2D8 File Offset: 0x0003D4D8
	private void OnEnable()
	{
		this.ResetTouch();
	}

	// Token: 0x06000882 RID: 2178 RVA: 0x0003F2E0 File Offset: 0x0003D4E0
	private void Start()
	{
		this.m_RectTransform = base.GetComponent<RectTransform>();
		if (this.m_ScrollIndicator && this.m_ScrollIndicatorEnd)
		{
			this.m_ScrollIndicatorStartPos = this.m_ScrollIndicator.transform.position;
			this.m_ScrollIndicatorEndPos = this.m_ScrollIndicatorEnd.transform.position;
		}
	}

	// Token: 0x06000883 RID: 2179 RVA: 0x0003F33F File Offset: 0x0003D53F
	private void Update()
	{
		this.SwipeDetection();
		this.EvaluateScrollIndicator();
	}

	// Token: 0x06000884 RID: 2180 RVA: 0x0003F34D File Offset: 0x0003D54D
	public void SetScrollingNormal()
	{
		this.m_IsScrollingInverse = false;
	}

	// Token: 0x06000885 RID: 2181 RVA: 0x0003F356 File Offset: 0x0003D556
	public void SetScrollingInverse()
	{
		this.m_IsScrollingInverse = true;
	}

	// Token: 0x06000886 RID: 2182 RVA: 0x0003F360 File Offset: 0x0003D560
	private void EvaluateScrollIndicator()
	{
		if (this.m_ScrollIndicator && this.m_ScrollIndicatorEnd)
		{
			this.m_ScrollIndicatorLerpAlpha = this.m_RectTransform.localPosition.y / this.m_ScrollLimitMinY;
			this.m_ScrollIndicator.transform.position = Vector3.Lerp(this.m_ScrollIndicatorStartPos, this.m_ScrollIndicatorEndPos, this.m_ScrollIndicatorLerpAlpha);
		}
	}

	// Token: 0x06000887 RID: 2183 RVA: 0x0003F3CB File Offset: 0x0003D5CB
	public void IsMouseDown()
	{
	}

	// Token: 0x06000888 RID: 2184 RVA: 0x0003F3CD File Offset: 0x0003D5CD
	public void IsMouseUp()
	{
	}

	// Token: 0x06000889 RID: 2185 RVA: 0x0003F3CF File Offset: 0x0003D5CF
	public void SetScrollLerpPos(float posY)
	{
		this.m_ScrollerLerpPos = new Vector3(0f, posY, 0f);
	}

	// Token: 0x0600088A RID: 2186 RVA: 0x0003F3E8 File Offset: 0x0003D5E8
	private void SwipeDetection()
	{
		this.m_RectTransform.localPosition = Vector3.Lerp(this.m_RectTransform.localPosition, this.m_ScrollerLerpPos, Time.deltaTime * this.m_ScrollerLerpSpeed);
		if (InputManager.GetKeyDownAction(EGameAction.InteractLeft))
		{
			this.mStartPosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
			this.mSwipeStartTime = Time.time;
			this.m_FingerTouched = true;
		}
		if (this.m_FingerTouched)
		{
			this.m_FingerTouchTime += Time.deltaTime;
		}
		Vector2 vector = new Vector2(Input.mousePosition.x, Input.mousePosition.y) - this.mStartPosition;
		float num = Time.time - this.mSwipeStartTime;
		float num2 = vector.magnitude / num;
		if (this.m_FingerTouchTime > 0.01f && this.m_RectTransform.localPosition.y <= this.m_ScrollLimitMinY && this.m_RectTransform.localPosition.y >= this.m_ScrollLimitMaxY)
		{
			float y;
			if (this.m_IsScrollingInverse)
			{
				y = vector.y * this.m_ScrollSensitivity;
			}
			else
			{
				y = vector.y * this.m_ScrollSensitivity * -1f;
			}
			this.m_ScrollerLerpPos += new Vector3(0f, y, 0f);
			this.mStartPosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
			if (this.m_ScrollerLerpPos.y > this.m_ScrollLimitMinY)
			{
				this.m_ScrollerLerpPos = new Vector3(0f, this.m_ScrollLimitMinY, 0f);
			}
			else if (this.m_ScrollerLerpPos.y < this.m_ScrollLimitMaxY)
			{
				this.m_ScrollerLerpPos = new Vector3(0f, this.m_ScrollLimitMaxY, 0f);
			}
			if (this.m_RectTransform.localPosition.y > this.m_ScrollLimitMinY)
			{
				this.m_RectTransform.localPosition = new Vector3(0f, this.m_ScrollLimitMinY, 0f);
			}
			else if (this.m_RectTransform.localPosition.y < this.m_ScrollLimitMaxY)
			{
				this.m_RectTransform.localPosition = new Vector3(0f, this.m_ScrollLimitMaxY, 0f);
			}
		}
		if (Input.GetMouseButtonUp(0) && this.m_FingerTouched)
		{
			this.m_FingerTouched = false;
			this.m_FingerTouchTime = 0f;
			num = Time.time - this.mSwipeStartTime;
			vector = new Vector2(Input.mousePosition.x, Input.mousePosition.y) - this.mStartPosition;
			if (vector.magnitude / num > 0.1f && vector.magnitude > 0.1f)
			{
				vector.Normalize();
				float num3 = Vector2.Dot(vector, this.mXAxis);
				num3 = Mathf.Acos(num3) * 57.29578f;
				if (num3 < 44f)
				{
					this.OnSwipeRight();
					return;
				}
				if (180f - num3 < 44f)
				{
					this.OnSwipeLeft();
					return;
				}
				num3 = Vector2.Dot(vector, this.mYAxis);
				num3 = Mathf.Acos(num3) * 57.29578f;
				if (num3 < 44f)
				{
					this.OnSwipeTop();
					return;
				}
				if (180f - num3 < 44f)
				{
					this.OnSwipeBottom();
					return;
				}
			}
			else
			{
				this.OnTapDetection();
			}
		}
	}

	// Token: 0x0600088B RID: 2187 RVA: 0x0003F741 File Offset: 0x0003D941
	private void ResetTouch()
	{
		this.m_FingerTouched = false;
		this.m_FingerTouchTime = 0f;
		this.m_ScrollerLerpPos = new Vector3(0f, 0f, 0f);
	}

	// Token: 0x0600088C RID: 2188 RVA: 0x0003F76F File Offset: 0x0003D96F
	private void OnTapDetection()
	{
	}

	// Token: 0x0600088D RID: 2189 RVA: 0x0003F771 File Offset: 0x0003D971
	private void OnSwipeLeft()
	{
	}

	// Token: 0x0600088E RID: 2190 RVA: 0x0003F773 File Offset: 0x0003D973
	private void OnSwipeRight()
	{
	}

	// Token: 0x0600088F RID: 2191 RVA: 0x0003F775 File Offset: 0x0003D975
	private void OnSwipeTop()
	{
	}

	// Token: 0x06000890 RID: 2192 RVA: 0x0003F777 File Offset: 0x0003D977
	private void OnSwipeBottom()
	{
	}

	// Token: 0x04001045 RID: 4165
	public float m_ScrollLimitMinY = 150f;

	// Token: 0x04001046 RID: 4166
	public float m_ScrollLimitMaxY;

	// Token: 0x04001047 RID: 4167
	public float m_ScrollerLerpSpeed = 5f;

	// Token: 0x04001048 RID: 4168
	public float m_ScrollSensitivity = 0.4f;

	// Token: 0x04001049 RID: 4169
	public float m_Inverse = -1f;

	// Token: 0x0400104A RID: 4170
	public GameObject m_ScrollIndicator;

	// Token: 0x0400104B RID: 4171
	public GameObject m_ScrollIndicatorEnd;

	// Token: 0x0400104C RID: 4172
	private Vector3 m_ScrollIndicatorStartPos;

	// Token: 0x0400104D RID: 4173
	private Vector3 m_ScrollIndicatorEndPos;

	// Token: 0x0400104E RID: 4174
	private float m_ScrollIndicatorLerpAlpha;

	// Token: 0x0400104F RID: 4175
	private bool m_IsScrollingInverse = true;

	// Token: 0x04001050 RID: 4176
	private RectTransform m_RectTransform;

	// Token: 0x04001051 RID: 4177
	private Vector3 m_ScrollerLerpPos;

	// Token: 0x04001052 RID: 4178
	private bool m_FingerTouched;

	// Token: 0x04001053 RID: 4179
	private float m_FingerTouchTime;

	// Token: 0x04001054 RID: 4180
	private readonly Vector2 mXAxis = new Vector2(1f, 0f);

	// Token: 0x04001055 RID: 4181
	private readonly Vector2 mYAxis = new Vector2(0f, 1f);

	// Token: 0x04001056 RID: 4182
	private const float mAngleRange = 44f;

	// Token: 0x04001057 RID: 4183
	private const float mMinSwipeDist = 0.1f;

	// Token: 0x04001058 RID: 4184
	private const float mMinVelocity = 0.1f;

	// Token: 0x04001059 RID: 4185
	private Vector2 mStartPosition;

	// Token: 0x0400105A RID: 4186
	private float mSwipeStartTime;
}
