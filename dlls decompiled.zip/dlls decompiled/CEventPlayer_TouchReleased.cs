﻿using System;
using UnityEngine;

// Token: 0x020000C7 RID: 199
public class CEventPlayer_TouchReleased : CEvent
{
	// Token: 0x17000024 RID: 36
	// (get) Token: 0x06000736 RID: 1846 RVA: 0x0003824F File Offset: 0x0003644F
	// (set) Token: 0x06000737 RID: 1847 RVA: 0x00038257 File Offset: 0x00036457
	public Vector3 m_ReleaseVector { get; private set; }

	// Token: 0x06000738 RID: 1848 RVA: 0x00038260 File Offset: 0x00036460
	public CEventPlayer_TouchReleased(Vector3 releaseVector)
	{
		this.m_ReleaseVector = releaseVector;
	}
}
