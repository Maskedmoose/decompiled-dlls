﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000086 RID: 134
public class UI_CashCounterScreen : MonoBehaviour
{
	// Token: 0x06000546 RID: 1350 RVA: 0x0002C78F File Offset: 0x0002A98F
	private void Awake()
	{
		this.ResetCounter();
	}

	// Token: 0x06000547 RID: 1351 RVA: 0x0002C797 File Offset: 0x0002A997
	public void Init(InteractableCashierCounter cashierCounter)
	{
		this.m_CashierCounter = cashierCounter;
	}

	// Token: 0x06000548 RID: 1352 RVA: 0x0002C7A0 File Offset: 0x0002A9A0
	private void Update()
	{
		this.m_PosX -= Input.mouseScrollDelta.y * this.m_MouseWheelScrollSpeed;
		this.m_PosX = Mathf.Clamp(this.m_PosX, this.m_MinPosX, this.m_MaxPosX);
		this.m_LerpPosX = Mathf.Lerp(this.m_LerpPosX, this.m_PosX, Time.deltaTime * CSingleton<TouchManager>.Instance.m_LerpSpeed);
		this.m_CheckoutBarSliderGrp.transform.localPosition = new Vector3(0f, this.m_LerpPosX, 0f);
	}

	// Token: 0x06000549 RID: 1353 RVA: 0x0002C834 File Offset: 0x0002AA34
	public void OnItemScanned(float value, EItemType itemType, float totalItemCost)
	{
		if (itemType == EItemType.None)
		{
			return;
		}
		if (this.m_ItemScannedListDict.ContainsKey(itemType))
		{
			Dictionary<EItemType, int> itemScannedListDict = this.m_ItemScannedListDict;
			itemScannedListDict[itemType]++;
			int index = this.m_ItemTypeList.IndexOf(itemType);
			this.m_CheckoutItemBarList[index].AddScannedItem(this.m_ItemScannedListDict[itemType]);
		}
		else
		{
			this.m_ItemScannedListDict.Add(itemType, 1);
			this.m_ItemTypeList.Add(itemType);
			for (int i = 0; i < this.m_CheckoutItemBarList.Count; i++)
			{
				if (!this.m_CheckoutItemBarList[i].gameObject.activeSelf)
				{
					string name = InventoryBase.GetItemData(itemType).GetName();
					this.m_CheckoutItemBarList[i].SetItemName(name, value);
					this.m_CheckoutItemBarList[i].gameObject.SetActive(true);
					this.m_ActiveBarCount++;
					this.m_MaxPosX = Mathf.Clamp((float)(this.m_ActiveBarCount - 8) * 7.5f, 0f, 240f);
					break;
				}
			}
		}
		this.m_TotalItemCost = totalItemCost;
		this.m_TotalItemListCostText.text = GameInstance.GetPriceString(this.m_TotalItemCost, false, true, false, "F2");
	}

	// Token: 0x0600054A RID: 1354 RVA: 0x0002C97C File Offset: 0x0002AB7C
	public void OnCardScanned(float value, CardData cardData, float totalItemCost)
	{
		if (cardData == null || cardData.monsterType == EMonsterType.None)
		{
			return;
		}
		for (int i = 0; i < this.m_CheckoutItemBarList.Count; i++)
		{
			if (!this.m_CheckoutItemBarList[i].gameObject.activeSelf)
			{
				string name = InventoryBase.GetMonsterData(cardData.monsterType).GetName() + " - " + CPlayerData.GetFullCardTypeName(cardData, true);
				this.m_CheckoutItemBarList[i].SetItemName(name, value);
				this.m_CheckoutItemBarList[i].gameObject.SetActive(true);
				this.m_ActiveBarCount++;
				this.m_MaxPosX = Mathf.Clamp((float)(this.m_ActiveBarCount - 8) * 7.5f, 0f, 240f);
				this.m_ItemTypeList.Add(EItemType.None);
				break;
			}
		}
		this.m_TotalItemCost = totalItemCost;
		this.m_TotalItemListCostText.text = GameInstance.GetPriceString(this.m_TotalItemCost, false, true, false, "F2");
	}

	// Token: 0x0600054B RID: 1355 RVA: 0x0002CA80 File Offset: 0x0002AC80
	public void OnStartGivingChange()
	{
		this.m_ItemListGrp.SetActive(false);
		this.m_GivingChangeGrp.SetActive(true);
		this.m_MoneyGuideFollowDrawerAnim.Play();
		if (this.m_CurrentMoneyCurrencyType != CSingleton<CGameManager>.Instance.m_CurrencyType)
		{
			this.m_CurrentMoneyCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
			this.UpdateChangeGuideText();
		}
	}

	// Token: 0x0600054C RID: 1356 RVA: 0x0002CADC File Offset: 0x0002ACDC
	private void UpdateChangeGuideText()
	{
		for (int i = 0; i < this.m_ChangeGuideTextList.Count; i++)
		{
			this.m_ChangeGuideTextList[i].text = GameInstance.GetPriceString(this.m_CashierCounter.m_InteractableCounterMoneyChangeList[i].m_Value, false, true, true, "F0");
		}
	}

	// Token: 0x0600054D RID: 1357 RVA: 0x0002CB34 File Offset: 0x0002AD34
	public void UpdateMoneyChangeAmount(bool isChangeReady, float customerPaidAmount, float totalScannedItemCost, float currentMoneyChangeValue)
	{
		this.m_CustomerGiveAmountText.text = GameInstance.GetPriceString(customerPaidAmount, false, true, false, "F2");
		this.m_TotalItemCostText.text = GameInstance.GetPriceString(totalScannedItemCost, false, true, false, "F2");
		this.m_ChangeToGiveAmountText.text = GameInstance.GetPriceString(customerPaidAmount - totalScannedItemCost, false, true, false, "F2");
		this.m_ChangeGivenAmountText.text = GameInstance.GetPriceString(currentMoneyChangeValue, false, true, false, "F2");
		if (isChangeReady)
		{
			this.m_ChangeGivenAmountText.color = this.m_ChangeReadyColor;
			return;
		}
		this.m_ChangeGivenAmountText.color = this.m_ChangeNotReadyColor;
	}

	// Token: 0x0600054E RID: 1358 RVA: 0x0002CBD0 File Offset: 0x0002ADD0
	public void ResetCounter()
	{
		this.m_ItemListGrp.SetActive(true);
		this.m_GivingChangeGrp.SetActive(false);
		this.m_TotalItemCost = 0f;
		this.m_TotalItemListCostText.text = GameInstance.GetPriceString(0f, false, true, false, "F2");
		this.UpdateMoneyChangeAmount(false, 0f, 0f, 0f);
		this.m_ItemTypeList.Clear();
		this.m_ItemScannedListDict.Clear();
		for (int i = 0; i < this.m_CheckoutItemBarList.Count; i++)
		{
			this.m_CheckoutItemBarList[i].gameObject.SetActive(false);
		}
		this.m_ActiveBarCount = 0;
		this.m_MaxPosX = 0f;
		this.m_CheckoutBarSliderGrp.transform.localPosition = Vector3.zero;
	}

	// Token: 0x0600054F RID: 1359 RVA: 0x0002CC9D File Offset: 0x0002AE9D
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000550 RID: 1360 RVA: 0x0002CCBE File Offset: 0x0002AEBE
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000551 RID: 1361 RVA: 0x0002CCE0 File Offset: 0x0002AEE0
	protected void OnMoneyCurrencyUpdated(CEventPlayer_OnMoneyCurrencyUpdated evt)
	{
		if (this.m_CurrentMoneyCurrencyType != CSingleton<CGameManager>.Instance.m_CurrencyType)
		{
			this.m_CurrentMoneyCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
			base.StartCoroutine(this.DelayUpdateCurrency());
			this.m_TotalItemListCostText.text = GameInstance.GetPriceString(this.m_TotalItemCost, false, true, false, "F2");
		}
	}

	// Token: 0x06000552 RID: 1362 RVA: 0x0002CD3A File Offset: 0x0002AF3A
	private IEnumerator DelayUpdateCurrency()
	{
		yield return new WaitForSeconds(0.01f);
		this.UpdateChangeGuideText();
		yield break;
	}

	// Token: 0x040006EC RID: 1772
	public FollowObject m_FollowObject;

	// Token: 0x040006ED RID: 1773
	public GameObject m_ItemListGrp;

	// Token: 0x040006EE RID: 1774
	public TextMeshProUGUI m_TotalItemListCostText;

	// Token: 0x040006EF RID: 1775
	public Transform m_CheckoutBarSliderGrp;

	// Token: 0x040006F0 RID: 1776
	public List<UI_CheckoutItemBar> m_CheckoutItemBarList;

	// Token: 0x040006F1 RID: 1777
	private Dictionary<EItemType, int> m_ItemScannedListDict = new Dictionary<EItemType, int>();

	// Token: 0x040006F2 RID: 1778
	private List<EItemType> m_ItemTypeList = new List<EItemType>();

	// Token: 0x040006F3 RID: 1779
	public GameObject m_GivingChangeGrp;

	// Token: 0x040006F4 RID: 1780
	public Animation m_MoneyGuideFollowDrawerAnim;

	// Token: 0x040006F5 RID: 1781
	public TextMeshProUGUI m_CustomerGiveAmountText;

	// Token: 0x040006F6 RID: 1782
	public TextMeshProUGUI m_TotalItemCostText;

	// Token: 0x040006F7 RID: 1783
	public TextMeshProUGUI m_ChangeToGiveAmountText;

	// Token: 0x040006F8 RID: 1784
	public TextMeshProUGUI m_ChangeGivenAmountText;

	// Token: 0x040006F9 RID: 1785
	public List<TextMeshProUGUI> m_ChangeGuideTextList;

	// Token: 0x040006FA RID: 1786
	public Color m_ChangeReadyColor;

	// Token: 0x040006FB RID: 1787
	public Color m_ChangeNotReadyColor;

	// Token: 0x040006FC RID: 1788
	private float m_MouseWheelScrollSpeed = 10f;

	// Token: 0x040006FD RID: 1789
	private float m_LerpPosX;

	// Token: 0x040006FE RID: 1790
	private float m_PosX;

	// Token: 0x040006FF RID: 1791
	private float m_MinPosX;

	// Token: 0x04000700 RID: 1792
	private float m_MaxPosX = 5000f;

	// Token: 0x04000701 RID: 1793
	private float m_TotalItemCost;

	// Token: 0x04000702 RID: 1794
	private int m_ActiveBarCount;

	// Token: 0x04000703 RID: 1795
	private InteractableCashierCounter m_CashierCounter;

	// Token: 0x04000704 RID: 1796
	private EMoneyCurrencyType m_CurrentMoneyCurrencyType;
}
