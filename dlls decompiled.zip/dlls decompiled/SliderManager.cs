﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000127 RID: 295
public class SliderManager : MonoBehaviour
{
	// Token: 0x060008A5 RID: 2213 RVA: 0x0003FB11 File Offset: 0x0003DD11
	private void Awake()
	{
		this.m_LerpSlider = this.m_Slider.GetComponent<LerpSlider>();
		this.m_PreviousBtnSetIndex = this.m_CurrentBtnSetIndex;
	}

	// Token: 0x060008A6 RID: 2214 RVA: 0x0003FB30 File Offset: 0x0003DD30
	private void Start()
	{
		this.m_SliderStartPos = this.m_Slider.transform.localPosition;
		this.EvaluateScrollerPosition();
	}

	// Token: 0x060008A7 RID: 2215 RVA: 0x0003FB4E File Offset: 0x0003DD4E
	private IEnumerator DelayEnable()
	{
		this.m_IsEnabled = false;
		this.m_IsMouseDown = false;
		yield return new WaitForSeconds(0.1f);
		this.m_IsEnabled = true;
		this.m_IsMouseDown = false;
		yield break;
	}

	// Token: 0x060008A8 RID: 2216 RVA: 0x0003FB5D File Offset: 0x0003DD5D
	private void Update()
	{
		this.EvaluateMouseSlider();
	}

	// Token: 0x060008A9 RID: 2217 RVA: 0x0003FB68 File Offset: 0x0003DD68
	private void EvaluateMouseSlider()
	{
		if (!this.m_Slider.activeSelf)
		{
			return;
		}
		if (!this.m_IsEnabled)
		{
			return;
		}
		if (InputManager.GetKeyDownAction(EGameAction.InteractLeft))
		{
			this.m_MouseStartPos = Input.mousePosition;
			this.m_MouseFirstStartPos = this.m_MouseStartPos;
			this.m_IsMouseDown = true;
		}
		if (Input.GetMouseButtonUp(0))
		{
			this.m_IsMouseDown = false;
			this.EvaluateScrollerPosition();
		}
		if (this.m_IsMouseDown)
		{
			float num = Input.mousePosition.x - this.m_MouseStartPos.x;
			float num2 = this.m_Slider.transform.localPosition.x + num * 1.5f;
			float num3 = Input.mousePosition.y - this.m_MouseStartPos.y;
			float num4 = this.m_Slider.transform.localPosition.y + num3 * 1.5f;
			if (this.m_ScrollYAxis)
			{
				this.m_MaxScrollY = (float)(this.m_MaxItemInABox - 1) * this.m_ScrollButtonOffsetY;
				num4 = Mathf.Clamp(num4, this.m_InitPosY, this.m_MaxScrollY);
				this.m_Slider.transform.localPosition = new Vector3(this.m_SliderStartPos.x, num4, 0f);
				this.m_LerpSlider.SetLerpPosY(num4);
				this.m_MouseStartPos = Input.mousePosition;
				if (num3 > 0f)
				{
					this.m_CurrentBtnSetIndex = Mathf.CeilToInt((num4 - this.m_ScrollButtonOffsetY * 0.1f) / this.m_ScrollButtonOffsetY);
				}
				else
				{
					this.m_CurrentBtnSetIndex = Mathf.CeilToInt((num4 - this.m_ScrollButtonOffsetY * 0.9f) / this.m_ScrollButtonOffsetY);
				}
			}
			else
			{
				this.m_MaxScrollX = (float)(this.m_MaxItemInABox - 1) * -this.m_ScrollButtonOffsetX;
				num2 = Mathf.Clamp(num2, this.m_MaxScrollX, 0f);
				this.m_Slider.transform.localPosition = new Vector3(num2, this.m_SliderStartPos.y, 0f);
				this.m_LerpSlider.SetLerpPos(num2);
				this.m_MouseStartPos = Input.mousePosition;
				if (num > 0f)
				{
					this.m_CurrentBtnSetIndex = Mathf.CeilToInt((num2 - this.m_ScrollButtonOffsetX * 0.1f) / this.m_ScrollButtonOffsetX) * -1;
				}
				else
				{
					this.m_CurrentBtnSetIndex = Mathf.CeilToInt((num2 - this.m_ScrollButtonOffsetX * 0.9f) / this.m_ScrollButtonOffsetX) * -1;
				}
			}
			if (this.m_CurrentBtnSetIndex != this.m_PreviousBtnSetIndex)
			{
				this.m_PreviousBtnSetIndex = this.m_CurrentBtnSetIndex;
			}
		}
	}

	// Token: 0x060008AA RID: 2218 RVA: 0x0003FDE0 File Offset: 0x0003DFE0
	private void EvaluateScrollerPosition()
	{
		if (this.m_ScrollYAxis)
		{
			float lerpPosY = -this.m_ScrollItemOffsetY * (float)this.m_CurrentBtnSetIndex;
			lerpPosY = this.m_ScrollButtonOffsetY * (float)this.m_CurrentBtnSetIndex;
			this.m_LerpSlider.SetLerpPosY(lerpPosY);
			return;
		}
		float lerpPos = -this.m_ScrollItemOffsetX * (float)this.m_CurrentBtnSetIndex;
		lerpPos = -this.m_ScrollButtonOffsetX * (float)this.m_CurrentBtnSetIndex;
		this.m_LerpSlider.SetLerpPos(lerpPos);
	}

	// Token: 0x060008AB RID: 2219 RVA: 0x0003FE4D File Offset: 0x0003E04D
	private void EvaluateItemSliderChanged()
	{
	}

	// Token: 0x060008AC RID: 2220 RVA: 0x0003FE4F File Offset: 0x0003E04F
	private void OnEnable()
	{
		base.StartCoroutine(this.DelayEnable());
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_TouchScreen>(new CEventManager.EventDelegate<CEventPlayer_TouchScreen>(this.CPlayer_OnTouchScreen));
		}
	}

	// Token: 0x060008AD RID: 2221 RVA: 0x0003FE7D File Offset: 0x0003E07D
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_TouchScreen>(new CEventManager.EventDelegate<CEventPlayer_TouchScreen>(this.CPlayer_OnTouchScreen));
		}
	}

	// Token: 0x060008AE RID: 2222 RVA: 0x0003FE9E File Offset: 0x0003E09E
	private void CPlayer_OnTouchScreen(CEventPlayer_TouchScreen evt)
	{
	}

	// Token: 0x04001068 RID: 4200
	public bool m_ScrollYAxis = true;

	// Token: 0x04001069 RID: 4201
	private float m_ScrollItemOffsetX = 0.4f;

	// Token: 0x0400106A RID: 4202
	public float m_ScrollButtonOffsetX = 1800f;

	// Token: 0x0400106B RID: 4203
	private float m_ScrollItemOffsetY = 0.4f;

	// Token: 0x0400106C RID: 4204
	public float m_ScrollButtonOffsetY = 800f;

	// Token: 0x0400106D RID: 4205
	public float m_InitPosY = -50f;

	// Token: 0x0400106E RID: 4206
	public int m_CurrentItemIndex;

	// Token: 0x0400106F RID: 4207
	public int m_CurrentBtnSetIndex;

	// Token: 0x04001070 RID: 4208
	private int m_PreviousBtnSetIndex;

	// Token: 0x04001071 RID: 4209
	private int m_PreviousItemIndex;

	// Token: 0x04001072 RID: 4210
	private float m_MaxScrollX;

	// Token: 0x04001073 RID: 4211
	private float m_MaxScrollY;

	// Token: 0x04001074 RID: 4212
	private bool m_IsMouseDown;

	// Token: 0x04001075 RID: 4213
	private bool m_IsSwiping;

	// Token: 0x04001076 RID: 4214
	private Vector2 m_MouseStartPos;

	// Token: 0x04001077 RID: 4215
	private Vector2 m_MouseFirstStartPos;

	// Token: 0x04001078 RID: 4216
	public GameObject m_Slider;

	// Token: 0x04001079 RID: 4217
	private LerpSlider m_LerpSlider;

	// Token: 0x0400107A RID: 4218
	private Vector3 m_SliderStartPos;

	// Token: 0x0400107B RID: 4219
	public int m_MaxItemInABox = 12;

	// Token: 0x0400107C RID: 4220
	private bool m_IsEnabled;
}
