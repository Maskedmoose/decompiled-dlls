﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E7 RID: 487
	public class CharacterKeyboardInput : CharacterInput
	{
		// Token: 0x06000DA0 RID: 3488 RVA: 0x0005D594 File Offset: 0x0005B794
		public unsafe override float GetHorizontalMovementInput()
		{
			if (InputManager.GetKeyHoldAction(EGameAction.MoveLeft) || InputManager.GetKeyHoldAction(EGameAction.MoveLeftAlt))
			{
				return -1f;
			}
			if (InputManager.GetKeyHoldAction(EGameAction.MoveRight) || InputManager.GetKeyHoldAction(EGameAction.MoveRightAlt))
			{
				return 1f;
			}
			if (CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				bool flag = this.useRawInput;
				return *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.x.value;
			}
			return 0f;
		}

		// Token: 0x06000DA1 RID: 3489 RVA: 0x0005D604 File Offset: 0x0005B804
		public unsafe override float GetVerticalMovementInput()
		{
			if (InputManager.GetKeyHoldAction(EGameAction.MoveForward) || InputManager.GetKeyHoldAction(EGameAction.MoveForwardAlt))
			{
				return 1f;
			}
			if (InputManager.GetKeyHoldAction(EGameAction.MoveBackward) || InputManager.GetKeyHoldAction(EGameAction.MoveBackwardAlt))
			{
				return -1f;
			}
			if (CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				bool flag = this.useRawInput;
				return *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.y.value;
			}
			return 0f;
		}

		// Token: 0x06000DA2 RID: 3490 RVA: 0x0005D674 File Offset: 0x0005B874
		public override bool IsJumpKeyPressed()
		{
			return CSingleton<InteractionPlayerController>.Instance.CanJump() && InputManager.GetKeyHoldAction(EGameAction.Jump);
		}

		// Token: 0x04001493 RID: 5267
		public string horizontalInputAxis = "Horizontal";

		// Token: 0x04001494 RID: 5268
		public string verticalInputAxis = "Vertical";

		// Token: 0x04001495 RID: 5269
		public KeyCode jumpKey = KeyCode.Space;

		// Token: 0x04001496 RID: 5270
		public KeyCode jumpKey2 = KeyCode.JoystickButton0;

		// Token: 0x04001497 RID: 5271
		public bool useRawInput = true;
	}
}
