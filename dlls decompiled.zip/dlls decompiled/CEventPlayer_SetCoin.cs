﻿using System;

// Token: 0x020000AE RID: 174
public class CEventPlayer_SetCoin : CEvent
{
	// Token: 0x17000010 RID: 16
	// (get) Token: 0x060006F5 RID: 1781 RVA: 0x00037FA7 File Offset: 0x000361A7
	// (set) Token: 0x060006F6 RID: 1782 RVA: 0x00037FAF File Offset: 0x000361AF
	public float m_CoinValue { get; private set; }

	// Token: 0x060006F7 RID: 1783 RVA: 0x00037FB8 File Offset: 0x000361B8
	public CEventPlayer_SetCoin(float coinValue)
	{
		this.m_CoinValue = coinValue;
	}
}
