﻿using System;

// Token: 0x0200001B RID: 27
public enum ECashierCounterState
{
	// Token: 0x040001AA RID: 426
	None = -1,
	// Token: 0x040001AB RID: 427
	Idle,
	// Token: 0x040001AC RID: 428
	ScanningItem,
	// Token: 0x040001AD RID: 429
	TakingCash,
	// Token: 0x040001AE RID: 430
	GivingChange
}
