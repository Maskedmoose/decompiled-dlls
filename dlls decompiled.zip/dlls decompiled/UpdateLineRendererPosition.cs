﻿using System;
using UnityEngine;

// Token: 0x0200012A RID: 298
public class UpdateLineRendererPosition : MonoBehaviour
{
	// Token: 0x060008C1 RID: 2241 RVA: 0x000407A9 File Offset: 0x0003E9A9
	private void Awake()
	{
		this.m_Line = base.GetComponent<LineRenderer>();
		this.rend = base.GetComponent<Renderer>();
	}

	// Token: 0x060008C2 RID: 2242 RVA: 0x000407C3 File Offset: 0x0003E9C3
	private void OnEnable()
	{
		this.m_Line.SetPosition(0, Vector3.zero);
		this.m_Line.SetPosition(1, Vector3.zero);
	}

	// Token: 0x060008C3 RID: 2243 RVA: 0x000407E8 File Offset: 0x0003E9E8
	private void Update()
	{
		this.m_Line.SetPosition(0, this.m_StartPosObject.transform.position);
		this.m_Line.SetPosition(1, this.m_MouseFollowObject.transform.position);
		this.rend.material.mainTextureScale = new Vector2((float)(Mathf.CeilToInt(Vector2.Distance(this.m_StartPosObject.transform.position, this.m_MouseFollowObject.transform.position) / 4f) * 2), 1f);
	}

	// Token: 0x040010A0 RID: 4256
	private LineRenderer m_Line;

	// Token: 0x040010A1 RID: 4257
	public GameObject m_StartPosObject;

	// Token: 0x040010A2 RID: 4258
	public GameObject m_MouseFollowObject;

	// Token: 0x040010A3 RID: 4259
	private Renderer rend;
}
