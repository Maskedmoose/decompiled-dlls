﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000148 RID: 328
public class ParticleCollisionInstance : MonoBehaviour
{
	// Token: 0x0600093E RID: 2366 RVA: 0x000431AE File Offset: 0x000413AE
	private void Start()
	{
		this.part = base.GetComponent<ParticleSystem>();
	}

	// Token: 0x0600093F RID: 2367 RVA: 0x000431BC File Offset: 0x000413BC
	private void OnParticleCollision(GameObject other)
	{
		int num = this.part.GetCollisionEvents(other, this.collisionEvents);
		for (int i = 0; i < num; i++)
		{
			GameObject[] effectsOnCollision = this.EffectsOnCollision;
			for (int j = 0; j < effectsOnCollision.Length; j++)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(effectsOnCollision[j], this.collisionEvents[i].intersection + this.collisionEvents[i].normal * this.Offset, default(Quaternion));
				if (!this.UseWorldSpacePosition)
				{
					gameObject.transform.parent = base.transform;
				}
				if (this.UseFirePointRotation)
				{
					gameObject.transform.LookAt(base.transform.position);
				}
				else if (this.rotationOffset != Vector3.zero && this.useOnlyRotationOffset)
				{
					gameObject.transform.rotation = Quaternion.Euler(this.rotationOffset);
				}
				else
				{
					gameObject.transform.LookAt(this.collisionEvents[i].intersection + this.collisionEvents[i].normal);
					gameObject.transform.rotation *= Quaternion.Euler(this.rotationOffset);
				}
				Object.Destroy(gameObject, this.DestroyTimeDelay);
			}
		}
		if (this.DestoyMainEffect)
		{
			Object.Destroy(base.gameObject, this.DestroyTimeDelay + 0.5f);
		}
	}

	// Token: 0x04001162 RID: 4450
	public GameObject[] EffectsOnCollision;

	// Token: 0x04001163 RID: 4451
	public float DestroyTimeDelay = 5f;

	// Token: 0x04001164 RID: 4452
	public bool UseWorldSpacePosition;

	// Token: 0x04001165 RID: 4453
	public float Offset;

	// Token: 0x04001166 RID: 4454
	public Vector3 rotationOffset = new Vector3(0f, 0f, 0f);

	// Token: 0x04001167 RID: 4455
	public bool useOnlyRotationOffset = true;

	// Token: 0x04001168 RID: 4456
	public bool UseFirePointRotation;

	// Token: 0x04001169 RID: 4457
	public bool DestoyMainEffect = true;

	// Token: 0x0400116A RID: 4458
	private ParticleSystem part;

	// Token: 0x0400116B RID: 4459
	private List<ParticleCollisionEvent> collisionEvents = new List<ParticleCollisionEvent>();

	// Token: 0x0400116C RID: 4460
	private ParticleSystem ps;
}
