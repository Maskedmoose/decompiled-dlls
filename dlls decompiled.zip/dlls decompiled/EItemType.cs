﻿using System;

// Token: 0x020000D9 RID: 217
public enum EItemType
{
	// Token: 0x040009B3 RID: 2483
	None = -1,
	// Token: 0x040009B4 RID: 2484
	BasicCardPack,
	// Token: 0x040009B5 RID: 2485
	BasicCardBox,
	// Token: 0x040009B6 RID: 2486
	RareCardPack,
	// Token: 0x040009B7 RID: 2487
	RareCardBox,
	// Token: 0x040009B8 RID: 2488
	EpicCardPack,
	// Token: 0x040009B9 RID: 2489
	EpicCardBox,
	// Token: 0x040009BA RID: 2490
	LegendaryCardPack,
	// Token: 0x040009BB RID: 2491
	LegendaryCardBox,
	// Token: 0x040009BC RID: 2492
	DestinyBasicCardPack,
	// Token: 0x040009BD RID: 2493
	DestinyBasicCardBox,
	// Token: 0x040009BE RID: 2494
	DestinyRareCardPack,
	// Token: 0x040009BF RID: 2495
	DestinyRareCardBox,
	// Token: 0x040009C0 RID: 2496
	DestinyEpicCardPack,
	// Token: 0x040009C1 RID: 2497
	DestinyEpicCardBox,
	// Token: 0x040009C2 RID: 2498
	DestinyLegendaryCardPack,
	// Token: 0x040009C3 RID: 2499
	DestinyLegendaryCardBox,
	// Token: 0x040009C4 RID: 2500
	GhostPack,
	// Token: 0x040009C5 RID: 2501
	MegabotPack,
	// Token: 0x040009C6 RID: 2502
	FantasyRPGPack,
	// Token: 0x040009C7 RID: 2503
	CatJobPack,
	// Token: 0x040009C8 RID: 2504
	FoodieGOPack,
	// Token: 0x040009C9 RID: 2505
	FoodieGOBWPack,
	// Token: 0x040009CA RID: 2506
	FoodieGOJPPack,
	// Token: 0x040009CB RID: 2507
	Deodorant,
	// Token: 0x040009CC RID: 2508
	DeckBox1,
	// Token: 0x040009CD RID: 2509
	DeckBox2,
	// Token: 0x040009CE RID: 2510
	DeckBox3,
	// Token: 0x040009CF RID: 2511
	DeckBox4,
	// Token: 0x040009D0 RID: 2512
	BinderBook,
	// Token: 0x040009D1 RID: 2513
	D20DiceBox,
	// Token: 0x040009D2 RID: 2514
	D20DiceBox2,
	// Token: 0x040009D3 RID: 2515
	D20DiceBox3,
	// Token: 0x040009D4 RID: 2516
	D20DiceBox4,
	// Token: 0x040009D5 RID: 2517
	Toy_PiggyA,
	// Token: 0x040009D6 RID: 2518
	Toy_GolemA,
	// Token: 0x040009D7 RID: 2519
	Toy_StarfishA,
	// Token: 0x040009D8 RID: 2520
	Toy_BatA,
	// Token: 0x040009D9 RID: 2521
	BulkBox_TetramonBase,
	// Token: 0x040009DA RID: 2522
	BulkBox_TetramonDestiny,
	// Token: 0x040009DB RID: 2523
	Toy_PiggyB,
	// Token: 0x040009DC RID: 2524
	Toy_PiggyC,
	// Token: 0x040009DD RID: 2525
	Toy_PiggyD,
	// Token: 0x040009DE RID: 2526
	Toy_GolemB,
	// Token: 0x040009DF RID: 2527
	Toy_GolemC,
	// Token: 0x040009E0 RID: 2528
	Toy_GolemD,
	// Token: 0x040009E1 RID: 2529
	Toy_StarfishB,
	// Token: 0x040009E2 RID: 2530
	Toy_StarfishC,
	// Token: 0x040009E3 RID: 2531
	Toy_StarfishD,
	// Token: 0x040009E4 RID: 2532
	Toy_BatB,
	// Token: 0x040009E5 RID: 2533
	Toy_BatC,
	// Token: 0x040009E6 RID: 2534
	Toy_BatD,
	// Token: 0x040009E7 RID: 2535
	Toy_Beetle,
	// Token: 0x040009E8 RID: 2536
	Toy_FoxB,
	// Token: 0x040009E9 RID: 2537
	Toy_ToonZ,
	// Token: 0x040009EA RID: 2538
	BinderBookPremium,
	// Token: 0x040009EB RID: 2539
	PreconDeck_Fire,
	// Token: 0x040009EC RID: 2540
	PreconDeck_Earth,
	// Token: 0x040009ED RID: 2541
	PreconDeck_Water,
	// Token: 0x040009EE RID: 2542
	PreconDeck_Wind,
	// Token: 0x040009EF RID: 2543
	PreconDeck_FireDestiny,
	// Token: 0x040009F0 RID: 2544
	PreconDeck_EarthDestiny,
	// Token: 0x040009F1 RID: 2545
	PreconDeck_WaterDestiny,
	// Token: 0x040009F2 RID: 2546
	PreconDeck_WindDestiny,
	// Token: 0x040009F3 RID: 2547
	CardSleeve_Clear,
	// Token: 0x040009F4 RID: 2548
	CardSleeve_Tetramon,
	// Token: 0x040009F5 RID: 2549
	CardSleeve_Fire,
	// Token: 0x040009F6 RID: 2550
	CardSleeve_Earth,
	// Token: 0x040009F7 RID: 2551
	CardSleeve_Water,
	// Token: 0x040009F8 RID: 2552
	CardSleeve_Wind,
	// Token: 0x040009F9 RID: 2553
	Playmat1,
	// Token: 0x040009FA RID: 2554
	Playmat2,
	// Token: 0x040009FB RID: 2555
	Playmat2b,
	// Token: 0x040009FC RID: 2556
	Playmat3,
	// Token: 0x040009FD RID: 2557
	Playmat4,
	// Token: 0x040009FE RID: 2558
	Playmat5,
	// Token: 0x040009FF RID: 2559
	Playmat6,
	// Token: 0x04000A00 RID: 2560
	Playmat7,
	// Token: 0x04000A01 RID: 2561
	Playmat8,
	// Token: 0x04000A02 RID: 2562
	Playmat9,
	// Token: 0x04000A03 RID: 2563
	Playmat10,
	// Token: 0x04000A04 RID: 2564
	Playmat11,
	// Token: 0x04000A05 RID: 2565
	Playmat12,
	// Token: 0x04000A06 RID: 2566
	Playmat13,
	// Token: 0x04000A07 RID: 2567
	Playmat14,
	// Token: 0x04000A08 RID: 2568
	Max
}
