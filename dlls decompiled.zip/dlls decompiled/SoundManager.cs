﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000D4 RID: 212
public class SoundManager : CSingleton<SoundManager>
{
	// Token: 0x0600075D RID: 1885 RVA: 0x00038508 File Offset: 0x00036708
	protected SoundManager()
	{
	}

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x0600075E RID: 1886 RVA: 0x00038547 File Offset: 0x00036747
	// (set) Token: 0x0600075F RID: 1887 RVA: 0x0003854E File Offset: 0x0003674E
	public static int MusicIndex
	{
		get
		{
			return SoundManager.m_MusicIndex;
		}
		set
		{
			SoundManager.m_MusicIndex = value;
		}
	}

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000760 RID: 1888 RVA: 0x00038556 File Offset: 0x00036756
	// (set) Token: 0x06000761 RID: 1889 RVA: 0x0003855D File Offset: 0x0003675D
	public static int SFXIndex
	{
		get
		{
			return SoundManager.m_SFXIndex;
		}
		set
		{
			SoundManager.m_SFXIndex = value;
		}
	}

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x06000762 RID: 1890 RVA: 0x00038565 File Offset: 0x00036765
	// (set) Token: 0x06000763 RID: 1891 RVA: 0x0003856C File Offset: 0x0003676C
	public static float MusicVolume
	{
		get
		{
			return SoundManager.m_MusicVolume;
		}
		set
		{
			SoundManager.m_MusicVolume = value;
			SoundManager.SaveData();
		}
	}

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x06000764 RID: 1892 RVA: 0x00038579 File Offset: 0x00036779
	// (set) Token: 0x06000765 RID: 1893 RVA: 0x00038580 File Offset: 0x00036780
	public static float SFXVolume
	{
		get
		{
			return SoundManager.m_SFXVolume;
		}
		set
		{
			SoundManager.m_SFXVolume = value;
			SoundManager.SaveData();
		}
	}

	// Token: 0x06000766 RID: 1894 RVA: 0x00038590 File Offset: 0x00036790
	private void Awake()
	{
		if (CSingleton<SoundManager>.Instance != null && CSingleton<SoundManager>.Instance != this)
		{
			Object.Destroy(base.gameObject);
			return;
		}
		Object.DontDestroyOnLoad(base.gameObject);
		this.m_FrameLoopLimit = this.m_AudioSrcList.Count;
		this.m_MusicVolume01 = 1f;
		this.m_MusicVolume02 = 0f;
	}

	// Token: 0x06000767 RID: 1895 RVA: 0x000385F5 File Offset: 0x000367F5
	public static void MuteAllSound()
	{
		SoundManager.m_IsMute = true;
		CSingleton<SoundManager>.Instance.EvaluateSoundVolume();
	}

	// Token: 0x06000768 RID: 1896 RVA: 0x00038607 File Offset: 0x00036807
	public static void UnMuteAllSound()
	{
		SoundManager.m_IsMute = false;
		CSingleton<SoundManager>.Instance.EvaluateSoundVolume();
	}

	// Token: 0x06000769 RID: 1897 RVA: 0x00038619 File Offset: 0x00036819
	private IEnumerator DelayLoadData()
	{
		SoundManager.m_MusicVolume = 0f;
		SoundManager.m_SFXVolume = 0f;
		yield return new WaitForSeconds(0.1f);
		this.LoadData();
		yield break;
	}

	// Token: 0x0600076A RID: 1898 RVA: 0x00038628 File Offset: 0x00036828
	private void Update()
	{
		this.EvaluateAudioSourceOver();
		this.EvaluateFrame();
		this.EvaluateLerpMusic();
	}

	// Token: 0x0600076B RID: 1899 RVA: 0x0003863C File Offset: 0x0003683C
	private void EvaluateMusicEnding()
	{
	}

	// Token: 0x0600076C RID: 1900 RVA: 0x0003863E File Offset: 0x0003683E
	private void EvaluateFrame()
	{
		this.m_CurrentFrame++;
		this.m_CheckFrameIndex = this.m_CurrentFrame % this.m_FrameLoopLimit;
	}

	// Token: 0x0600076D RID: 1901 RVA: 0x00038661 File Offset: 0x00036861
	public static void PlayAudio(string audioName, float volume = 1f, float pitch = 1f)
	{
		CSingleton<SoundManager>.Instance.PlayAudioPrivate(audioName, volume, pitch);
	}

	// Token: 0x0600076E RID: 1902 RVA: 0x00038670 File Offset: 0x00036870
	public static void PlayAudioDelayed(string audioName, float delayTime, float volume = 1f, float pitch = 1f)
	{
		CSingleton<SoundManager>.Instance.StartCoroutine(CSingleton<SoundManager>.Instance.DelayPlayAudio(audioName, delayTime, volume, pitch));
	}

	// Token: 0x0600076F RID: 1903 RVA: 0x0003868B File Offset: 0x0003688B
	private IEnumerator DelayPlayAudio(string audioName, float delayTime, float volume = 1f, float pitch = 1f)
	{
		yield return new WaitForSeconds(delayTime);
		CSingleton<SoundManager>.Instance.PlayAudioPrivate(audioName, volume, pitch);
		yield break;
	}

	// Token: 0x06000770 RID: 1904 RVA: 0x000386B0 File Offset: 0x000368B0
	private void PlayAudioPrivate(string audioName, float volume = 1f, float pitch = 1f)
	{
		if (!GameInstance.m_HasFinishHideLoadingScreen)
		{
			return;
		}
		AudioSource emptyAudioSource = this.GetEmptyAudioSource();
		if (emptyAudioSource != null)
		{
			emptyAudioSource.clip = this.GetAudioClip(audioName);
			emptyAudioSource.pitch = pitch;
			emptyAudioSource.volume = volume * SoundManager.m_SFXVolume * SoundManager.m_SFXVolume * this.m_SFXVolumeMultiplier;
			emptyAudioSource.Play();
		}
	}

	// Token: 0x06000771 RID: 1905 RVA: 0x00038709 File Offset: 0x00036909
	public static void PlayAudioForceChannel(string audioName, float volume = 1f, float pitch = 1f, int channel = 0)
	{
		CSingleton<SoundManager>.Instance.PlayAudioForceChannelPrivate(audioName, volume, pitch, channel);
	}

	// Token: 0x06000772 RID: 1906 RVA: 0x0003871C File Offset: 0x0003691C
	private void PlayAudioForceChannelPrivate(string audioName, float volume = 1f, float pitch = 1f, int channel = 0)
	{
		if (!GameInstance.m_HasFinishHideLoadingScreen)
		{
			return;
		}
		AudioSource audioSource = this.m_AudioSrcList[channel];
		if (audioSource != null)
		{
			AudioClip audioClip = this.GetAudioClip(audioName);
			if (audioClip == audioSource.clip)
			{
				return;
			}
			audioSource.clip = audioClip;
			audioSource.pitch = pitch;
			audioSource.volume = volume * SoundManager.m_SFXVolume * SoundManager.m_SFXVolume * this.m_SFXVolumeMultiplier;
			audioSource.Play();
		}
	}

	// Token: 0x06000773 RID: 1907 RVA: 0x00038790 File Offset: 0x00036990
	private AudioClip GetAudioClip(string audioName)
	{
		AudioClip audioClip;
		if (!this.m_LoadedAudioClip.TryGetValue(audioName, out audioClip))
		{
			audioClip = (Resources.Load("SFX/" + audioName) as AudioClip);
			this.m_LoadedAudioClip.Add(audioName, audioClip);
		}
		if (audioClip)
		{
			return audioClip;
		}
		return null;
	}

	// Token: 0x06000774 RID: 1908 RVA: 0x000387DC File Offset: 0x000369DC
	private AudioSource GetEmptyAudioSource()
	{
		for (int i = 0; i < this.m_AudioSrcList.Count; i++)
		{
			if (this.m_AudioSrcList[i].clip == null)
			{
				return this.m_AudioSrcList[i];
			}
		}
		return null;
	}

	// Token: 0x06000775 RID: 1909 RVA: 0x00038828 File Offset: 0x00036A28
	private void EvaluateAudioSourceOver()
	{
		if (this.m_AudioSrcList[this.m_CheckFrameIndex].clip && !this.m_AudioSrcList[this.m_CheckFrameIndex].isPlaying)
		{
			this.m_AudioSrcList[this.m_CheckFrameIndex].clip = null;
		}
	}

	// Token: 0x06000776 RID: 1910 RVA: 0x00038881 File Offset: 0x00036A81
	public static void SetAndPlayMusic(string audioName, int index)
	{
		CSingleton<SoundManager>.Instance.SetAndPlayMusicPrivate(audioName, index);
	}

	// Token: 0x06000777 RID: 1911 RVA: 0x0003888F File Offset: 0x00036A8F
	private void SetAndPlayMusicPrivate(string audioName, int index)
	{
		if (index == 0)
		{
			this.m_MusicSrc01.clip = this.GetAudioClip(audioName);
			this.m_MusicSrc01.Play();
			return;
		}
		this.m_MusicSrc02.clip = this.GetAudioClip(audioName);
		this.m_MusicSrc02.Play();
	}

	// Token: 0x06000778 RID: 1912 RVA: 0x000388CF File Offset: 0x00036ACF
	public static void PlayMusic()
	{
		CSingleton<SoundManager>.Instance.PlayMusicPrivate();
	}

	// Token: 0x06000779 RID: 1913 RVA: 0x000388DB File Offset: 0x00036ADB
	private void PlayMusicPrivate()
	{
		if (this.m_IsMusic02)
		{
			this.m_MusicSrc02.Play();
			return;
		}
		this.m_MusicSrc01.Play();
	}

	// Token: 0x0600077A RID: 1914 RVA: 0x000388FC File Offset: 0x00036AFC
	public static void PauseMusic()
	{
		CSingleton<SoundManager>.Instance.PauseMusicPrivate();
	}

	// Token: 0x0600077B RID: 1915 RVA: 0x00038908 File Offset: 0x00036B08
	private void PauseMusicPrivate()
	{
		this.m_MusicSrc01.Pause();
		this.m_MusicSrc02.Pause();
	}

	// Token: 0x0600077C RID: 1916 RVA: 0x00038920 File Offset: 0x00036B20
	public static void StopMusic()
	{
		CSingleton<SoundManager>.Instance.StopMusicPrivate();
	}

	// Token: 0x0600077D RID: 1917 RVA: 0x0003892C File Offset: 0x00036B2C
	private void StopMusicPrivate()
	{
		this.m_MusicSrc01.Stop();
		this.m_MusicSrc02.Stop();
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x00038944 File Offset: 0x00036B44
	public static void QueueMusic(string startAudioName, string audioName, float blendSpeed)
	{
		CSingleton<SoundManager>.Instance.QueueMusicPrivate(startAudioName, audioName, blendSpeed);
	}

	// Token: 0x0600077F RID: 1919 RVA: 0x00038954 File Offset: 0x00036B54
	private void QueueMusicPrivate(string startAudioName, string audioName, float blendSpeed)
	{
		double dspTime = AudioSettings.dspTime;
		AudioClip audioClip = this.GetAudioClip(startAudioName);
		double num = (double)audioClip.samples / (double)audioClip.frequency;
		float smoothDeltaTime = Time.smoothDeltaTime;
		Debug.Log("timeOffset " + smoothDeltaTime.ToString());
		this.m_QueuedMusic = this.GetAudioClip(audioName);
		if (this.m_IsMusic02)
		{
			this.m_MusicSrc01.Stop();
			this.m_MusicSrc01.volume = this.m_MusicSrc02.volume;
			this.m_MusicSrc01.clip = this.m_QueuedMusic;
			this.m_MusicSrc01.PlayScheduled(dspTime + num + (double)smoothDeltaTime);
			this.m_MusicSrc02.SetScheduledEndTime(dspTime + num + (double)smoothDeltaTime);
			return;
		}
		this.m_MusicSrc02.Stop();
		this.m_MusicSrc02.volume = this.m_MusicSrc01.volume;
		this.m_MusicSrc02.clip = this.m_QueuedMusic;
		this.m_MusicSrc02.PlayScheduled(dspTime + num + (double)smoothDeltaTime);
		this.m_MusicSrc01.SetScheduledEndTime(dspTime + num + (double)smoothDeltaTime);
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x00038A5C File Offset: 0x00036C5C
	public static void StopQueueMusic()
	{
		CSingleton<SoundManager>.Instance.m_QueuedMusic = null;
		if (CSingleton<SoundManager>.Instance.m_IsMusic02)
		{
			CSingleton<SoundManager>.Instance.m_MusicSrc01.Stop();
			CSingleton<SoundManager>.Instance.m_MusicSrc01.clip = null;
			return;
		}
		CSingleton<SoundManager>.Instance.m_MusicSrc02.Stop();
		CSingleton<SoundManager>.Instance.m_MusicSrc02.clip = null;
	}

	// Token: 0x06000781 RID: 1921 RVA: 0x00038ABF File Offset: 0x00036CBF
	public static void BlendToMusic(string audioName, float blendSpeed, bool isLinearBlend)
	{
		CSingleton<SoundManager>.Instance.BlendToMusicPrivate(audioName, blendSpeed, isLinearBlend);
	}

	// Token: 0x06000782 RID: 1922 RVA: 0x00038AD0 File Offset: 0x00036CD0
	private void BlendToMusicPrivate(string audioName, float blendSpeed, bool isLinearBlend)
	{
		if (this.m_IsMusic02)
		{
			if (this.m_MusicSrc02.clip == this.GetAudioClip(audioName))
			{
				return;
			}
		}
		else if (this.m_MusicSrc01.clip == this.GetAudioClip(audioName))
		{
			return;
		}
		this.m_QueuedMusic = null;
		this.m_MusicBlendSpeed = blendSpeed;
		this.m_IsLinearBlend = isLinearBlend;
		if (this.m_MusicSrc02.clip == null)
		{
			this.m_MusicSrc02.clip = this.GetAudioClip(audioName);
			this.m_IsMusic02 = true;
			this.m_IsBlendingMusic = true;
			this.m_MusicSrc02.Play();
		}
		else if (this.m_MusicSrc01.clip == null)
		{
			this.m_MusicSrc01.clip = this.GetAudioClip(audioName);
			this.m_IsMusic02 = false;
			this.m_IsBlendingMusic = true;
			this.m_MusicSrc01.Play();
		}
		else
		{
			this.m_MusicSrc01.clip = this.GetAudioClip(audioName);
			this.m_IsMusic02 = false;
			this.m_IsBlendingMusic = true;
			this.m_MusicSrc01.Play();
		}
		this.m_StopEvaluateMusicEnd = false;
	}

	// Token: 0x06000783 RID: 1923 RVA: 0x00038BE0 File Offset: 0x00036DE0
	private void EvaluateLerpMusic()
	{
		if (this.m_IsBlendingMusic)
		{
			if (this.m_IsMusic02)
			{
				if (this.m_IsLinearBlend)
				{
					this.m_LinearBlendAmount += Time.deltaTime * this.m_MusicBlendSpeed;
					this.m_MusicVolume01 = Mathf.Lerp(1f, 0f, this.m_LinearBlendAmount);
					this.m_MusicVolume02 = Mathf.Lerp(0f, 1f, this.m_LinearBlendAmount);
				}
				else
				{
					this.m_MusicVolume01 = Mathf.Lerp(this.m_MusicVolume01, 0f, Time.deltaTime * this.m_MusicBlendSpeed);
					this.m_MusicVolume02 = Mathf.Lerp(this.m_MusicVolume02, 1f, Time.deltaTime * this.m_MusicBlendSpeed);
				}
				if (this.m_MusicVolume01 < this.m_MusicLerpClipLower)
				{
					this.m_LinearBlendAmount = 0f;
					this.m_MusicVolume01 = 0f;
					this.m_MusicVolume02 = 1f;
					this.m_IsBlendingMusic = false;
					if (this.m_QueuedMusic == null)
					{
						this.m_MusicSrc01.clip = null;
						this.m_MusicSrc01.Stop();
					}
				}
			}
			else if (!this.m_IsMusic02)
			{
				if (this.m_IsLinearBlend)
				{
					this.m_LinearBlendAmount += Time.deltaTime * this.m_MusicBlendSpeed;
					this.m_MusicVolume01 = Mathf.Lerp(0f, 1f, this.m_LinearBlendAmount);
					this.m_MusicVolume02 = Mathf.Lerp(1f, 0f, this.m_LinearBlendAmount);
				}
				else
				{
					this.m_MusicVolume02 = Mathf.Lerp(this.m_MusicVolume02, 0f, Time.deltaTime * this.m_MusicBlendSpeed);
					this.m_MusicVolume01 = Mathf.Lerp(this.m_MusicVolume01, 1f, Time.deltaTime * this.m_MusicBlendSpeed);
				}
				if (this.m_MusicVolume02 < this.m_MusicLerpClipLower)
				{
					this.m_LinearBlendAmount = 0f;
					this.m_MusicVolume02 = 0f;
					this.m_MusicVolume01 = 1f;
					this.m_IsBlendingMusic = false;
					if (this.m_QueuedMusic == null)
					{
						this.m_MusicSrc02.clip = null;
						this.m_MusicSrc02.Stop();
					}
				}
			}
			if (this.m_QueuedMusic)
			{
				this.m_MusicVolume02 = 1f;
				this.m_MusicVolume01 = 1f;
			}
			this.m_MusicSrc01.volume = this.m_MusicVolume01 * SoundManager.m_MusicVolume * this.m_MusicVolumeMultiplier;
			this.m_MusicSrc02.volume = this.m_MusicVolume02 * SoundManager.m_MusicVolume * this.m_MusicVolumeMultiplier;
		}
	}

	// Token: 0x06000784 RID: 1924 RVA: 0x00038E68 File Offset: 0x00037068
	private void LoadData()
	{
		this.EvaluateSoundVolume();
	}

	// Token: 0x06000785 RID: 1925 RVA: 0x00038E70 File Offset: 0x00037070
	private static void SaveData()
	{
	}

	// Token: 0x06000786 RID: 1926 RVA: 0x00038E72 File Offset: 0x00037072
	private void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_VolumeChanged>(new CEventManager.EventDelegate<CEventPlayer_VolumeChanged>(this.CPlayer_OnVolumeChanged));
		}
	}

	// Token: 0x06000787 RID: 1927 RVA: 0x00038E93 File Offset: 0x00037093
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_VolumeChanged>(new CEventManager.EventDelegate<CEventPlayer_VolumeChanged>(this.CPlayer_OnVolumeChanged));
		}
	}

	// Token: 0x06000788 RID: 1928 RVA: 0x00038EB4 File Offset: 0x000370B4
	private void CPlayer_OnVolumeChanged(CEventPlayer_VolumeChanged evt)
	{
	}

	// Token: 0x06000789 RID: 1929 RVA: 0x00038EB8 File Offset: 0x000370B8
	public void EvaluateSoundVolume()
	{
		float musicVolume = SoundManager.m_MusicVolume;
		float volume = SoundManager.m_SFXVolume;
		if (SoundManager.m_IsMute)
		{
			volume = 0f;
		}
		for (int i = 0; i < this.m_AudioSrcList.Count; i++)
		{
			this.m_AudioSrcList[i].volume = volume;
		}
		this.m_MusicSrc01.volume = this.m_MusicVolume01 * musicVolume * this.m_MusicVolumeMultiplier;
		this.m_MusicSrc02.volume = this.m_MusicVolume02 * musicVolume * this.m_MusicVolumeMultiplier;
		this.m_ExpIncrease.volume = volume;
		this.m_CoinIncrease.volume = volume;
		this.m_GemIncrease.volume = volume;
		this.m_TPIncrease.volume = volume;
		for (int j = 0; j < this.m_ExternalAudioSrcList.Count; j++)
		{
			this.m_ExternalAudioSrcList[j].volume = volume;
		}
	}

	// Token: 0x0600078A RID: 1930 RVA: 0x00038F92 File Offset: 0x00037192
	public static void GenericLightTap(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.4f, pitch);
	}

	// Token: 0x0600078B RID: 1931 RVA: 0x00038FA4 File Offset: 0x000371A4
	public static void GenericPop(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_Popup_Low", volume, pitch);
	}

	// Token: 0x0600078C RID: 1932 RVA: 0x00038FB2 File Offset: 0x000371B2
	public static void GenericConfirm(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_Popup2", 0.6f, 0.5f);
	}

	// Token: 0x0600078D RID: 1933 RVA: 0x00038FC8 File Offset: 0x000371C8
	public static void GenericCancel(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_Popup2", 0.6f, 0.4f);
	}

	// Token: 0x0600078E RID: 1934 RVA: 0x00038FDE File Offset: 0x000371DE
	public static void GenericMenuOpen(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_Popup2", 0.6f, 0.5f);
	}

	// Token: 0x0600078F RID: 1935 RVA: 0x00038FF4 File Offset: 0x000371F4
	public static void GenericMenuClose(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_Popup2", 0.6f, 0.4f);
	}

	// Token: 0x06000790 RID: 1936 RVA: 0x0003900A File Offset: 0x0003720A
	public static void GenericPurchase(float volume = 1f, float pitch = 1f)
	{
		SoundManager.PlayAudio("SFX_CustomerBuy", volume, pitch);
	}

	// Token: 0x06000791 RID: 1937 RVA: 0x00039018 File Offset: 0x00037218
	public static void SetEnableSound_ExpIncrease(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_ExpIncrease.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_ExpIncrease.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_ExpIncrease.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_ExpIncrease.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_ExpIncrease.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_ExpIncrease.Stop();
		}
	}

	// Token: 0x06000792 RID: 1938 RVA: 0x0003909C File Offset: 0x0003729C
	public static void SetEnableSound_CoinIncrease(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_CoinIncrease.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_CoinIncrease.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_CoinIncrease.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_CoinIncrease.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_CoinIncrease.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_CoinIncrease.Stop();
		}
	}

	// Token: 0x06000793 RID: 1939 RVA: 0x00039120 File Offset: 0x00037320
	public static void SetEnableSound_GemIncrease(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_GemIncrease.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_GemIncrease.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_GemIncrease.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_GemIncrease.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_GemIncrease.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_GemIncrease.Stop();
		}
	}

	// Token: 0x06000794 RID: 1940 RVA: 0x000391A4 File Offset: 0x000373A4
	public static void SetEnableSound_TamerPointIncrease(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_TPIncrease.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_TPIncrease.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_TPIncrease.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_TPIncrease.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_TPIncrease.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_TPIncrease.Stop();
		}
	}

	// Token: 0x06000795 RID: 1941 RVA: 0x00039228 File Offset: 0x00037428
	public static void SetEnableSound_LevelupExpLoop(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_LevelUpExpLoop.Stop();
		}
	}

	// Token: 0x06000796 RID: 1942 RVA: 0x000392AC File Offset: 0x000374AC
	public static void SetEnableSound_SprayLoop(bool isEnable)
	{
		if (SoundManager.m_SFXVolume == 0f)
		{
			CSingleton<SoundManager>.Instance.m_SprayLoop.Stop();
			return;
		}
		if (CSingleton<SoundManager>.Instance.m_SprayLoop.enabled != isEnable)
		{
			CSingleton<SoundManager>.Instance.m_SprayLoop.enabled = isEnable;
			if (isEnable)
			{
				CSingleton<SoundManager>.Instance.m_SprayLoop.volume = SoundManager.m_SFXVolume;
				CSingleton<SoundManager>.Instance.m_SprayLoop.Play();
				return;
			}
			CSingleton<SoundManager>.Instance.m_SprayLoop.Stop();
		}
	}

	// Token: 0x04000961 RID: 2401
	private int m_CurrentFrame;

	// Token: 0x04000962 RID: 2402
	private int m_FrameLoopLimit;

	// Token: 0x04000963 RID: 2403
	private int m_CheckFrameIndex;

	// Token: 0x04000964 RID: 2404
	private float m_MusicVolume01;

	// Token: 0x04000965 RID: 2405
	private float m_MusicVolume02;

	// Token: 0x04000966 RID: 2406
	private float m_MusicBlendSpeed = 1f;

	// Token: 0x04000967 RID: 2407
	private float m_LinearBlendAmount;

	// Token: 0x04000968 RID: 2408
	private float m_MusicLerpClipLower = 0.05f;

	// Token: 0x04000969 RID: 2409
	private float m_MusicVolumeMultiplier = 0.3f;

	// Token: 0x0400096A RID: 2410
	private float m_SFXVolumeMultiplier = 2f;

	// Token: 0x0400096B RID: 2411
	private bool m_IsMusic02;

	// Token: 0x0400096C RID: 2412
	private bool m_IsBlendingMusic;

	// Token: 0x0400096D RID: 2413
	private bool m_IsLinearBlend;

	// Token: 0x0400096E RID: 2414
	private bool m_StopEvaluateMusicEnd;

	// Token: 0x0400096F RID: 2415
	private AudioClip m_VoiceRecordClip1;

	// Token: 0x04000970 RID: 2416
	private string m_VoiceRecordFilePath;

	// Token: 0x04000971 RID: 2417
	private bool m_IsRecording;

	// Token: 0x04000972 RID: 2418
	public AudioSource m_MusicSrc01;

	// Token: 0x04000973 RID: 2419
	public AudioSource m_MusicSrc02;

	// Token: 0x04000974 RID: 2420
	public List<AudioSource> m_AudioSrcList;

	// Token: 0x04000975 RID: 2421
	public List<AudioSource> m_ExternalAudioSrcList;

	// Token: 0x04000976 RID: 2422
	private Dictionary<string, AudioClip> m_LoadedAudioClip = new Dictionary<string, AudioClip>();

	// Token: 0x04000977 RID: 2423
	private AudioClip m_QueuedMusic;

	// Token: 0x04000978 RID: 2424
	public AudioSource m_ExpIncrease;

	// Token: 0x04000979 RID: 2425
	public AudioSource m_CoinIncrease;

	// Token: 0x0400097A RID: 2426
	public AudioSource m_GemIncrease;

	// Token: 0x0400097B RID: 2427
	public AudioSource m_TPIncrease;

	// Token: 0x0400097C RID: 2428
	public AudioSource m_LevelUpExpLoop;

	// Token: 0x0400097D RID: 2429
	public AudioSource m_SprayLoop;

	// Token: 0x0400097E RID: 2430
	private static int m_MusicIndex = 7;

	// Token: 0x0400097F RID: 2431
	private static int m_SFXIndex = 7;

	// Token: 0x04000980 RID: 2432
	private static float m_MusicVolume = 1f;

	// Token: 0x04000981 RID: 2433
	private static float m_SFXVolume = 1f;

	// Token: 0x04000982 RID: 2434
	private static bool m_IsMute;
}
