﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace CC
{
	// Token: 0x020001C5 RID: 453
	public class CC_InputField : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CB8 RID: 3256 RVA: 0x00058702 File Offset: 0x00056902
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util parentUI)
		{
			this.customizer = customizerScript;
			this.RefreshUIElement();
			base.gameObject.GetComponent<TMP_InputField>().onValueChanged.AddListener(new UnityAction<string>(this.customizer.setCharacterName));
		}

		// Token: 0x06000CB9 RID: 3257 RVA: 0x00058737 File Offset: 0x00056937
		public void RefreshUIElement()
		{
			base.gameObject.GetComponent<TMP_InputField>().text = this.customizer.CharacterName;
		}

		// Token: 0x04001399 RID: 5017
		private CharacterCustomization customizer;
	}
}
