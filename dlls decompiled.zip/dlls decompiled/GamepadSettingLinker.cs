﻿using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000110 RID: 272
public class GamepadSettingLinker : MonoBehaviour
{
	// Token: 0x060007F7 RID: 2039 RVA: 0x0003B40A File Offset: 0x0003960A
	private void Awake()
	{
		if (this.m_SliderActiveThumbstickIcon)
		{
			this.m_SliderActiveThumbstickIcon.SetActive(false);
		}
	}

	// Token: 0x060007F8 RID: 2040 RVA: 0x0003B428 File Offset: 0x00039628
	public void OnPressConfirm()
	{
		if (this.m_Toggle)
		{
			this.m_Toggle.isOn = !this.m_Toggle.isOn;
		}
		if (this.m_Dropdown)
		{
			if (!this.m_IsShown)
			{
				this.m_Dropdown.Show();
				this.m_IsShown = true;
				ControllerScreenUIExtManager.SetLockLJoystickVertical(true);
				CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(true);
				InputManager.SetSliderActive(true);
			}
			else
			{
				this.m_Dropdown.Hide();
				this.m_Dropdown.interactable = false;
				this.m_Dropdown.interactable = true;
				this.m_IsShown = false;
				ControllerScreenUIExtManager.SetLockLJoystickVertical(false);
				CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(false);
				InputManager.SetSliderActive(false);
			}
		}
		if (this.m_Slider)
		{
			if (!this.m_IsShown)
			{
				this.m_Slider.interactable = true;
				this.m_Slider.Select();
				this.m_IsShown = true;
				ControllerScreenUIExtManager.SetLockLJoystickVertical(true);
				CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(true);
				this.m_SliderActiveThumbstickIcon.SetActive(true);
				InputManager.SetSliderActive(true);
			}
			else
			{
				this.m_Slider.interactable = false;
				this.m_Slider.interactable = true;
				this.m_IsShown = false;
				ControllerScreenUIExtManager.SetLockLJoystickVertical(false);
				CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(false);
				this.m_SliderActiveThumbstickIcon.SetActive(false);
				InputManager.SetSliderActive(false);
			}
		}
		if (this.m_KeybindSetting && this.m_KeybindSetting.m_IsGamepad && this.m_CanUpdateKeybind && !this.m_IsShown)
		{
			this.m_IsShown = true;
			this.m_KeybindSetting.OnPressButton();
			ControllerScreenUIExtManager.SetLockLJoystickVertical(true);
		}
	}

	// Token: 0x060007F9 RID: 2041 RVA: 0x0003B5BC File Offset: 0x000397BC
	public void OnPressCancel()
	{
		if (this.m_Dropdown && this.m_IsShown)
		{
			this.m_Dropdown.Hide();
			this.m_Dropdown.interactable = false;
			this.m_Dropdown.interactable = true;
			this.m_IsShown = false;
			ControllerScreenUIExtManager.SetLockLJoystickVertical(false);
			CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(false);
			InputManager.SetSliderActive(false);
		}
		if (this.m_Slider && this.m_IsShown)
		{
			this.m_Slider.interactable = false;
			this.m_Slider.interactable = true;
			this.m_IsShown = false;
			ControllerScreenUIExtManager.SetLockLJoystickVertical(false);
			CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(false);
			InputManager.SetSliderActive(false);
			this.m_SliderActiveThumbstickIcon.SetActive(false);
		}
	}

	// Token: 0x060007FA RID: 2042 RVA: 0x0003B676 File Offset: 0x00039876
	public void OnFinishSetGamepadKeybind()
	{
		if (this.m_KeybindSetting && this.m_IsShown)
		{
			this.m_IsShown = false;
			ControllerScreenUIExtManager.SetLockLJoystickVertical(false);
			base.StartCoroutine(this.ResetCanUpdateKeybind());
		}
	}

	// Token: 0x060007FB RID: 2043 RVA: 0x0003B6A7 File Offset: 0x000398A7
	private IEnumerator ResetCanUpdateKeybind()
	{
		this.m_CanUpdateKeybind = false;
		yield return new WaitForSecondsRealtime(0.1f);
		this.m_CanUpdateKeybind = true;
		yield break;
	}

	// Token: 0x04000F33 RID: 3891
	public Toggle m_Toggle;

	// Token: 0x04000F34 RID: 3892
	public TMP_Dropdown m_Dropdown;

	// Token: 0x04000F35 RID: 3893
	public Slider m_Slider;

	// Token: 0x04000F36 RID: 3894
	public GameObject m_SliderActiveThumbstickIcon;

	// Token: 0x04000F37 RID: 3895
	public KeybindSetting m_KeybindSetting;

	// Token: 0x04000F38 RID: 3896
	private bool m_IsShown;

	// Token: 0x04000F39 RID: 3897
	private bool m_CanUpdateKeybind = true;
}
