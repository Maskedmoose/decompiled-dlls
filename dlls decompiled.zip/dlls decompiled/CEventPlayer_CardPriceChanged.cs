﻿using System;

// Token: 0x020000B7 RID: 183
public class CEventPlayer_CardPriceChanged : CEvent
{
	// Token: 0x1700001C RID: 28
	// (get) Token: 0x06000716 RID: 1814 RVA: 0x0003810F File Offset: 0x0003630F
	// (set) Token: 0x06000717 RID: 1815 RVA: 0x00038117 File Offset: 0x00036317
	public CardData m_CardData { get; private set; }

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x06000718 RID: 1816 RVA: 0x00038120 File Offset: 0x00036320
	// (set) Token: 0x06000719 RID: 1817 RVA: 0x00038128 File Offset: 0x00036328
	public float m_Price { get; private set; }

	// Token: 0x0600071A RID: 1818 RVA: 0x00038131 File Offset: 0x00036331
	public CEventPlayer_CardPriceChanged(CardData cardData, float price)
	{
		this.m_CardData = cardData;
		this.m_Price = price;
	}
}
