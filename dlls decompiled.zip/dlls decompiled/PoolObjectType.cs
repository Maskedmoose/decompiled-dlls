﻿using System;

// Token: 0x020000D2 RID: 210
public enum PoolObjectType
{
	// Token: 0x04000954 RID: 2388
	none,
	// Token: 0x04000955 RID: 2389
	slashHitFX,
	// Token: 0x04000956 RID: 2390
	explosionFX
}
