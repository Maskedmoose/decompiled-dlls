﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200006B RID: 107
public class HireWorkerPanelUI : UIElementBase
{
	// Token: 0x06000494 RID: 1172 RVA: 0x00027774 File Offset: 0x00025974
	public void Init(HireWorkerScreen hireWorkerScreen, int index)
	{
		this.m_HireWorkerScreen = hireWorkerScreen;
		this.m_Index = index;
		WorkerData workerData = WorkerManager.GetWorkerData(index);
		this.m_IconImage.sprite = workerData.icon;
		this.m_NameText.text = workerData.GetName();
		this.m_RestockSpeedText.text = workerData.GetRestockSpeedText();
		this.m_CheckoutSpeedText.text = workerData.GetCheckoutSpeedText();
		this.m_SalaryCostText.text = workerData.GetSalaryCostText();
		this.m_Description.text = workerData.GetDescription();
		this.m_TotalHireFee = workerData.hiringCost;
		this.m_LevelRequired = workerData.shopLevelRequired;
		this.m_HireFeeText.text = GameInstance.GetPriceString(this.m_TotalHireFee, false, true, false, "F2");
		if (this.m_LevelRequirementString == "")
		{
			this.m_LevelRequirementString = this.m_LevelRequirementText.text;
		}
		if (CPlayerData.m_ShopLevel + 1 >= this.m_LevelRequired)
		{
			this.m_LevelRequirementText.gameObject.SetActive(false);
			this.m_HireFeeText.gameObject.SetActive(true);
			this.m_LockPurchaseBtn.gameObject.SetActive(false);
		}
		else
		{
			this.m_LevelRequirementText.text = LocalizationManager.GetTranslation(this.m_LevelRequirementString, true, 0, true, false, null, null, true).Replace("XXX", this.m_LevelRequired.ToString());
			this.m_LevelRequirementText.gameObject.SetActive(true);
			this.m_HireFeeText.gameObject.SetActive(false);
			this.m_LockPurchaseBtn.gameObject.SetActive(true);
		}
		this.EvaluateHired();
		if (CSingleton<CGameManager>.Instance.m_IsPrologue && !workerData.prologueShow)
		{
			this.m_PrologueUIGrp.SetActive(true);
			this.m_LockPurchaseBtn.gameObject.SetActive(true);
			return;
		}
		this.m_PrologueUIGrp.SetActive(false);
	}

	// Token: 0x06000495 RID: 1173 RVA: 0x00027944 File Offset: 0x00025B44
	private void EvaluateHired()
	{
		this.m_IsHired = CPlayerData.GetIsWorkerHired(this.m_Index);
		if (this.m_IsHired)
		{
			this.m_HiredText.SetActive(true);
			this.m_PurchaseBtn.SetActive(false);
			this.m_HireFeeText.gameObject.SetActive(false);
			return;
		}
		this.m_HiredText.SetActive(false);
		this.m_PurchaseBtn.SetActive(true);
	}

	// Token: 0x06000496 RID: 1174 RVA: 0x000279AC File Offset: 0x00025BAC
	public void OnPressHireButton()
	{
		if (this.m_IsHired)
		{
			return;
		}
		if (CPlayerData.m_ShopLevel + 1 < this.m_LevelRequired)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShopLevelNotEnough);
			return;
		}
		if (CPlayerData.m_CoinAmount >= this.m_TotalHireFee)
		{
			CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(this.m_TotalHireFee, false));
			CPlayerData.SetIsWorkerHired(this.m_Index, true);
			CSingleton<WorkerManager>.Instance.ActivateWorker(this.m_Index, true);
			CPlayerData.m_GameReportDataCollect.employeeCost = CPlayerData.m_GameReportDataCollect.employeeCost - this.m_TotalHireFee;
			CPlayerData.m_GameReportDataCollectPermanent.employeeCost = CPlayerData.m_GameReportDataCollectPermanent.employeeCost - this.m_TotalHireFee;
			int num = 0;
			for (int i = 0; i < CPlayerData.m_IsWorkerHired.Count; i++)
			{
				if (CPlayerData.m_IsWorkerHired[i])
				{
					num++;
				}
			}
			AchievementManager.OnStaffHired(num);
			SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
			this.EvaluateHired();
			return;
		}
		NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
	}

	// Token: 0x040005AE RID: 1454
	public Image m_IconImage;

	// Token: 0x040005AF RID: 1455
	public TextMeshProUGUI m_NameText;

	// Token: 0x040005B0 RID: 1456
	public TextMeshProUGUI m_RestockSpeedText;

	// Token: 0x040005B1 RID: 1457
	public TextMeshProUGUI m_CheckoutSpeedText;

	// Token: 0x040005B2 RID: 1458
	public TextMeshProUGUI m_SalaryCostText;

	// Token: 0x040005B3 RID: 1459
	public TextMeshProUGUI m_HireFeeText;

	// Token: 0x040005B4 RID: 1460
	public TextMeshProUGUI m_LevelRequirementText;

	// Token: 0x040005B5 RID: 1461
	public TextMeshProUGUI m_Description;

	// Token: 0x040005B6 RID: 1462
	private string m_LevelRequirementString = "";

	// Token: 0x040005B7 RID: 1463
	public GameObject m_HiredText;

	// Token: 0x040005B8 RID: 1464
	public GameObject m_PurchaseBtn;

	// Token: 0x040005B9 RID: 1465
	public GameObject m_LockPurchaseBtn;

	// Token: 0x040005BA RID: 1466
	public GameObject m_PrologueUIGrp;

	// Token: 0x040005BB RID: 1467
	private HireWorkerScreen m_HireWorkerScreen;

	// Token: 0x040005BC RID: 1468
	private bool m_IsHired;

	// Token: 0x040005BD RID: 1469
	private int m_Index;

	// Token: 0x040005BE RID: 1470
	private int m_LevelRequired;

	// Token: 0x040005BF RID: 1471
	private float m_TotalHireFee;
}
