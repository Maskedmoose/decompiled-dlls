﻿using System;

// Token: 0x02000050 RID: 80
[Serializable]
public class PackageBoxItemaveData
{
	// Token: 0x0400046A RID: 1130
	public ItemTypeAmount itemTypeAmount;

	// Token: 0x0400046B RID: 1131
	public bool isBigBox;

	// Token: 0x0400046C RID: 1132
	public bool isStored;

	// Token: 0x0400046D RID: 1133
	public int storedWarehouseShelfIndex;

	// Token: 0x0400046E RID: 1134
	public int storageCompartmentIndex;

	// Token: 0x0400046F RID: 1135
	public Vector3Serializer pos;

	// Token: 0x04000470 RID: 1136
	public QuaternionSerializer rot;
}
