﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001CB RID: 459
	public class Option_Slider : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CDF RID: 3295 RVA: 0x00059448 File Offset: 0x00057648
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util ParentUI)
		{
			this.defaultValue = this.slider.value;
			this.customizer = customizerScript;
			this.parentUI = ParentUI;
			this.slider = base.GetComponentInChildren<Slider>();
			this.RefreshUIElement();
		}

		// Token: 0x06000CE0 RID: 3296 RVA: 0x0005947C File Offset: 0x0005767C
		public void RefreshUIElement()
		{
			Option_Slider.Type customizationType = this.CustomizationType;
			if (customizationType != Option_Slider.Type.Blendshape)
			{
				if (customizationType != Option_Slider.Type.Scalar)
				{
					return;
				}
				int num = this.customizer.StoredCharacterData.FloatProperties.FindIndex((CC_Property t) => t.propertyName == this.Property.propertyName && t.materialIndex == this.Property.materialIndex && t.meshTag == this.Property.meshTag);
				if (num != -1)
				{
					this.slider.SetValueWithoutNotify(this.customizer.StoredCharacterData.FloatProperties[num].floatValue);
					return;
				}
				this.slider.SetValueWithoutNotify(this.defaultValue);
				return;
			}
			else
			{
				int num2 = this.customizer.StoredCharacterData.Blendshapes.FindIndex((CC_Property t) => t.propertyName == this.Property.propertyName);
				if (num2 != -1)
				{
					this.slider.SetValueWithoutNotify(this.customizer.StoredCharacterData.Blendshapes[num2].floatValue);
					return;
				}
				this.slider.SetValueWithoutNotify(this.defaultValue);
				return;
			}
		}

		// Token: 0x06000CE1 RID: 3297 RVA: 0x00059558 File Offset: 0x00057758
		public void setProperty(float value)
		{
			this.Property.floatValue = value;
			Option_Slider.Type customizationType = this.CustomizationType;
			if (customizationType == Option_Slider.Type.Blendshape)
			{
				this.customizer.setBlendshapeByName(this.Property.propertyName, value, true);
				return;
			}
			if (customizationType != Option_Slider.Type.Scalar)
			{
				return;
			}
			Debug.Log(value);
			this.customizer.setFloatProperty(this.Property, true);
		}

		// Token: 0x06000CE2 RID: 3298 RVA: 0x000595B6 File Offset: 0x000577B6
		public void randomize()
		{
			this.slider.value = Random.Range(this.slider.minValue, this.slider.maxValue);
		}

		// Token: 0x040013C7 RID: 5063
		public Option_Slider.Type CustomizationType;

		// Token: 0x040013C8 RID: 5064
		public CC_Property Property;

		// Token: 0x040013C9 RID: 5065
		public Slider slider;

		// Token: 0x040013CA RID: 5066
		private float defaultValue;

		// Token: 0x040013CB RID: 5067
		private CharacterCustomization customizer;

		// Token: 0x040013CC RID: 5068
		private CC_UI_Util parentUI;

		// Token: 0x0200027A RID: 634
		public enum Type
		{
			// Token: 0x04001689 RID: 5769
			Blendshape,
			// Token: 0x0400168A RID: 5770
			Scalar
		}
	}
}
