﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000008 RID: 8
public class Card3dUISpawner : CSingleton<Card3dUISpawner>
{
	// Token: 0x06000025 RID: 37 RVA: 0x000028BC File Offset: 0x00000ABC
	private void Awake()
	{
		if (Card3dUISpawner.m_Instance == null)
		{
			Card3dUISpawner.m_Instance = this;
		}
		else if (Card3dUISpawner.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
		this.m_Card3dUIList = new List<Card3dUIGroup>();
		for (int i = 0; i < base.transform.childCount; i++)
		{
			this.m_Card3dUIList.Add(base.transform.GetChild(i).gameObject.GetComponent<Card3dUIGroup>());
		}
		for (int j = 0; j < 30; j++)
		{
			this.AddCardPrefab();
		}
		for (int k = 0; k < this.m_Card3dUIList.Count; k++)
		{
			this.m_Card3dUIList[k].gameObject.SetActive(false);
		}
		this.UpdateSimplifyCardDistance();
	}

	// Token: 0x06000026 RID: 38 RVA: 0x00002988 File Offset: 0x00000B88
	private void Update()
	{
		this.m_CullLoopCount = 0;
		for (int i = 0; i < this.m_Card3dUIList.Count; i++)
		{
			if (this.m_Card3dUIList[this.m_CullIndex] && !this.m_Card3dUIList[this.m_CullIndex].m_IgnoreCulling)
			{
				float num = Vector3.Dot((this.m_Card3dUIList[this.m_CullIndex].m_ScaleGrp.position - CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.position).normalized, CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.forward);
				float magnitude = (this.m_Card3dUIList[this.m_CullIndex].m_ScaleGrp.position - CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.transform.position).magnitude;
				float num2 = Vector3.Angle(this.m_Card3dUIList[this.m_CullIndex].m_ScaleGrp.TransformDirection(Vector3.forward), CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.TransformDirection(Vector3.forward));
				if (magnitude > this.m_SimplifyCardDistance)
				{
					this.m_Card3dUIList[this.m_CullIndex].m_CardUI.SetFoilCullListVisibility(false);
					this.m_Card3dUIList[this.m_CullIndex].m_CardUI.SetFarDistanceCull();
				}
				else
				{
					this.m_Card3dUIList[this.m_CullIndex].m_CardUI.SetFoilCullListVisibility(true);
					this.m_Card3dUIList[this.m_CullIndex].m_CardUI.ResetFarDistanceCull();
				}
				if (magnitude > 9f || (magnitude > 1f && num < this.m_DotCullLimit) || num2 > 110f)
				{
					this.m_Card3dUIList[this.m_CullIndex].m_CardUIAnimGrp.gameObject.SetActive(false);
				}
				else
				{
					this.m_Card3dUIList[this.m_CullIndex].m_CardUIAnimGrp.gameObject.SetActive(true);
				}
			}
			this.m_CullIndex++;
			if (this.m_CullIndex >= this.m_Card3dUIList.Count)
			{
				this.m_CullIndex = 0;
			}
			this.m_CullLoopCount++;
			if (this.m_CullLoopCount >= this.m_CullLoopCountMaxPerFrame)
			{
				this.m_CullLoopCount = 0;
				return;
			}
		}
	}

	// Token: 0x06000027 RID: 39 RVA: 0x00002BF0 File Offset: 0x00000DF0
	public Card3dUIGroup GetCardUI()
	{
		for (int i = 0; i < this.m_Card3dUIList.Count; i++)
		{
			if (!this.m_Card3dUIList[i].IsActive())
			{
				this.m_Card3dUIList[i].ActivateCard();
				this.m_Card3dUIList[i].gameObject.SetActive(true);
				return this.m_Card3dUIList[i];
			}
		}
		Card3dUIGroup card3dUIGroup = this.AddCardPrefab();
		card3dUIGroup.ActivateCard();
		card3dUIGroup.gameObject.SetActive(true);
		return card3dUIGroup;
	}

	// Token: 0x06000028 RID: 40 RVA: 0x00002C74 File Offset: 0x00000E74
	private Card3dUIGroup AddCardPrefab()
	{
		Card3dUIGroup card3dUIGroup = Object.Instantiate<Card3dUIGroup>(this.m_Card3dUIPrefab, new Vector3(0f, 0f, 0f), Quaternion.identity, base.transform);
		card3dUIGroup.transform.localRotation = Quaternion.identity;
		card3dUIGroup.name = "Card3dUIGrp_" + this.m_SpawnedCardCount.ToString();
		card3dUIGroup.gameObject.SetActive(false);
		this.m_Card3dUIList.Add(card3dUIGroup);
		this.m_SpawnedCardCount++;
		return card3dUIGroup;
	}

	// Token: 0x06000029 RID: 41 RVA: 0x00002D00 File Offset: 0x00000F00
	public static void DisableCard(Card3dUIGroup card3dUI)
	{
		card3dUI.transform.parent = CSingleton<Card3dUISpawner>.Instance.transform;
		card3dUI.transform.localPosition = Vector3.zero;
		card3dUI.transform.localRotation = Quaternion.identity;
		card3dUI.gameObject.SetActive(false);
	}

	// Token: 0x0600002A RID: 42 RVA: 0x00002D4E File Offset: 0x00000F4E
	public static void AddCardToManager(Card3dUIGroup card3dUI)
	{
		if (!CSingleton<Card3dUISpawner>.Instance.m_AllCard3dUIList.Contains(card3dUI))
		{
			CSingleton<Card3dUISpawner>.Instance.m_AllCard3dUIList.Add(card3dUI);
		}
	}

	// Token: 0x0600002B RID: 43 RVA: 0x00002D72 File Offset: 0x00000F72
	public static void RemoveCardFromManager(Card3dUIGroup card3dUI)
	{
		if (CSingleton<Card3dUISpawner>.Instance.m_AllCard3dUIList.Contains(card3dUI))
		{
			CSingleton<Card3dUISpawner>.Instance.m_AllCard3dUIList.Remove(card3dUI);
		}
	}

	// Token: 0x0600002C RID: 44 RVA: 0x00002D98 File Offset: 0x00000F98
	public static void SetAllCardUIBrightness(float brightness)
	{
		for (int i = 0; i < CSingleton<Card3dUISpawner>.Instance.m_AllCard3dUIList.Count; i++)
		{
			if (CSingleton<Card3dUISpawner>.Instance.m_AllCard3dUIList[i].m_CardUI)
			{
				CSingleton<Card3dUISpawner>.Instance.m_AllCard3dUIList[i].m_CardUI.SetBrightness(brightness);
			}
		}
	}

	// Token: 0x0600002D RID: 45 RVA: 0x00002DF6 File Offset: 0x00000FF6
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x0600002E RID: 46 RVA: 0x00002E17 File Offset: 0x00001017
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x0600002F RID: 47 RVA: 0x00002E38 File Offset: 0x00001038
	protected void OnSettingUpdated(CEventPlayer_OnSettingUpdated evt)
	{
		this.m_DotCullLimit = Mathf.Lerp(0.75f, 0.35f, CSingleton<CGameManager>.Instance.m_CameraFOVSlider);
		this.UpdateSimplifyCardDistance();
	}

	// Token: 0x06000030 RID: 48 RVA: 0x00002E60 File Offset: 0x00001060
	private void UpdateSimplifyCardDistance()
	{
		if (CSingleton<CGameManager>.Instance.m_QualitySettingIndex == 0)
		{
			this.m_SimplifyCardDistance = 2.3f;
			return;
		}
		if (CSingleton<CGameManager>.Instance.m_QualitySettingIndex == 1)
		{
			this.m_SimplifyCardDistance = 1.5f;
			return;
		}
		if (CSingleton<CGameManager>.Instance.m_QualitySettingIndex == 2)
		{
			this.m_SimplifyCardDistance = 0f;
		}
	}

	// Token: 0x04000027 RID: 39
	public static Card3dUISpawner m_Instance;

	// Token: 0x04000028 RID: 40
	public Card3dUIGroup m_Card3dUIPrefab;

	// Token: 0x04000029 RID: 41
	public List<Material> m_FoilMaterialTangentView;

	// Token: 0x0400002A RID: 42
	public List<Material> m_FoilMaterialWorldView;

	// Token: 0x0400002B RID: 43
	public List<Material> m_FoilBlendedMaterialTangentView;

	// Token: 0x0400002C RID: 44
	public List<Material> m_FoilBlendedMaterialWorldView;

	// Token: 0x0400002D RID: 45
	private List<Card3dUIGroup> m_Card3dUIList = new List<Card3dUIGroup>();

	// Token: 0x0400002E RID: 46
	private List<Card3dUIGroup> m_AllCard3dUIList = new List<Card3dUIGroup>();

	// Token: 0x0400002F RID: 47
	private int m_SpawnedCardCount;

	// Token: 0x04000030 RID: 48
	private int m_CullIndex;

	// Token: 0x04000031 RID: 49
	private int m_CullLoopCount;

	// Token: 0x04000032 RID: 50
	private int m_CullLoopCountMaxPerFrame = 50;

	// Token: 0x04000033 RID: 51
	private float m_DotCullLimit = 0.65f;

	// Token: 0x04000034 RID: 52
	private float m_SimplifyCardDistance = 2f;
}
