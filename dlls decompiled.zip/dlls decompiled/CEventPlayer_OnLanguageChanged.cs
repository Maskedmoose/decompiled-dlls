﻿using System;

// Token: 0x020000CE RID: 206
public class CEventPlayer_OnLanguageChanged : CEvent
{
}
