﻿using System;
using UnityEngine;

// Token: 0x0200001D RID: 29
[Serializable]
public class CounterMoneyChangeCurrencyData
{
	// Token: 0x040001D8 RID: 472
	public string name;

	// Token: 0x040001D9 RID: 473
	public EMoneyCurrencyType currencyType;

	// Token: 0x040001DA RID: 474
	public bool isCoin;

	// Token: 0x040001DB RID: 475
	public float value;

	// Token: 0x040001DC RID: 476
	public Material changeMaterial;
}
