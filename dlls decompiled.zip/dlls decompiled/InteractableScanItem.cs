﻿using System;
using UnityEngine;

// Token: 0x02000028 RID: 40
public class InteractableScanItem : InteractableObject
{
	// Token: 0x06000220 RID: 544 RVA: 0x00014E30 File Offset: 0x00013030
	public override void OnMouseButtonUp()
	{
		this.m_Item.m_Collider.enabled = false;
		this.m_Item.m_Rigidbody.isKinematic = true;
		this.m_CurrentCustomer.OnItemScanned(this.m_Item);
		this.m_CurrentCustomer = null;
		base.LerpToTransform(this.m_ScannedItemLerpPos, this.m_ScannedItemLerpPos);
		base.SetHideItemAfterFinishLerp();
	}

	// Token: 0x06000221 RID: 545 RVA: 0x00014E8F File Offset: 0x0001308F
	public void RegisterScanItem(Customer customer, Transform scannedItemLerpPos)
	{
		this.m_CurrentCustomer = customer;
		this.m_ScannedItemLerpPos = scannedItemLerpPos;
	}

	// Token: 0x06000222 RID: 546 RVA: 0x00014E9F File Offset: 0x0001309F
	public bool IsNotScanned()
	{
		return this.m_CurrentCustomer;
	}

	// Token: 0x04000264 RID: 612
	public Item m_Item;

	// Token: 0x04000265 RID: 613
	private Customer m_CurrentCustomer;

	// Token: 0x04000266 RID: 614
	private Transform m_ScannedItemLerpPos;
}
