﻿using System;

// Token: 0x020000C5 RID: 197
public class CEventPlayer_GhostCardEffectUpdated : CEvent
{
	// Token: 0x17000023 RID: 35
	// (get) Token: 0x06000732 RID: 1842 RVA: 0x00038227 File Offset: 0x00036427
	// (set) Token: 0x06000733 RID: 1843 RVA: 0x0003822F File Offset: 0x0003642F
	public bool m_GetNewCard { get; private set; }

	// Token: 0x06000734 RID: 1844 RVA: 0x00038238 File Offset: 0x00036438
	public CEventPlayer_GhostCardEffectUpdated(bool getNewCard)
	{
		this.m_GetNewCard = getNewCard;
	}
}
