﻿using System;

// Token: 0x020000CA RID: 202
public class CEventPlayer_ParticleSpawnerReachedDestination : CEvent
{
	// Token: 0x17000026 RID: 38
	// (get) Token: 0x0600073D RID: 1853 RVA: 0x00038297 File Offset: 0x00036497
	// (set) Token: 0x0600073E RID: 1854 RVA: 0x0003829F File Offset: 0x0003649F
	public ECurrencyType m_CurrencyType { get; private set; }

	// Token: 0x0600073F RID: 1855 RVA: 0x000382A8 File Offset: 0x000364A8
	public CEventPlayer_ParticleSpawnerReachedDestination(ECurrencyType CurrencyType)
	{
		this.m_CurrencyType = CurrencyType;
	}
}
