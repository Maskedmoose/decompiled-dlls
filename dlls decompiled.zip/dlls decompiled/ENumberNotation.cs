﻿using System;

// Token: 0x020000D8 RID: 216
public enum ENumberNotation
{
	// Token: 0x04000993 RID: 2451
	None,
	// Token: 0x04000994 RID: 2452
	K,
	// Token: 0x04000995 RID: 2453
	M,
	// Token: 0x04000996 RID: 2454
	B,
	// Token: 0x04000997 RID: 2455
	T,
	// Token: 0x04000998 RID: 2456
	Qa,
	// Token: 0x04000999 RID: 2457
	Qb,
	// Token: 0x0400099A RID: 2458
	Qc,
	// Token: 0x0400099B RID: 2459
	Qd,
	// Token: 0x0400099C RID: 2460
	Qe,
	// Token: 0x0400099D RID: 2461
	Qf,
	// Token: 0x0400099E RID: 2462
	Qg,
	// Token: 0x0400099F RID: 2463
	Qh,
	// Token: 0x040009A0 RID: 2464
	Qi,
	// Token: 0x040009A1 RID: 2465
	Qj,
	// Token: 0x040009A2 RID: 2466
	Qk,
	// Token: 0x040009A3 RID: 2467
	Ql,
	// Token: 0x040009A4 RID: 2468
	Qm,
	// Token: 0x040009A5 RID: 2469
	Qn,
	// Token: 0x040009A6 RID: 2470
	Qo,
	// Token: 0x040009A7 RID: 2471
	Qp,
	// Token: 0x040009A8 RID: 2472
	Qq,
	// Token: 0x040009A9 RID: 2473
	Qr,
	// Token: 0x040009AA RID: 2474
	Qs,
	// Token: 0x040009AB RID: 2475
	Qt,
	// Token: 0x040009AC RID: 2476
	Qu,
	// Token: 0x040009AD RID: 2477
	Qv,
	// Token: 0x040009AE RID: 2478
	Qw,
	// Token: 0x040009AF RID: 2479
	Qx,
	// Token: 0x040009B0 RID: 2480
	Qy,
	// Token: 0x040009B1 RID: 2481
	Qz
}
