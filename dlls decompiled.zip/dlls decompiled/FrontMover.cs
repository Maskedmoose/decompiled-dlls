﻿using System;
using UnityEngine;

// Token: 0x02000146 RID: 326
public class FrontMover : MonoBehaviour
{
	// Token: 0x06000937 RID: 2359 RVA: 0x00043029 File Offset: 0x00041229
	private void Start()
	{
		base.InvokeRepeating("StartAgain", 0f, this.repeatingTime);
		this.effect.Play();
		this.startSpeed = this.speed;
	}

	// Token: 0x06000938 RID: 2360 RVA: 0x00043058 File Offset: 0x00041258
	private void StartAgain()
	{
		this.startSpeed = this.speed;
		base.transform.position = this.pivot.position;
	}

	// Token: 0x06000939 RID: 2361 RVA: 0x0004307C File Offset: 0x0004127C
	private void Update()
	{
		this.startSpeed *= this.drug;
		base.transform.position += base.transform.forward * (this.startSpeed * Time.deltaTime);
	}

	// Token: 0x04001154 RID: 4436
	public Transform pivot;

	// Token: 0x04001155 RID: 4437
	public ParticleSystem effect;

	// Token: 0x04001156 RID: 4438
	public float speed = 15f;

	// Token: 0x04001157 RID: 4439
	public float drug = 1f;

	// Token: 0x04001158 RID: 4440
	public float repeatingTime = 1f;

	// Token: 0x04001159 RID: 4441
	private float startSpeed;
}
