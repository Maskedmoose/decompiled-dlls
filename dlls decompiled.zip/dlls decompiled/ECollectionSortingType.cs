﻿using System;

// Token: 0x0200000F RID: 15
public enum ECollectionSortingType
{
	// Token: 0x040000B2 RID: 178
	Default,
	// Token: 0x040000B3 RID: 179
	Amount,
	// Token: 0x040000B4 RID: 180
	Price,
	// Token: 0x040000B5 RID: 181
	Type,
	// Token: 0x040000B6 RID: 182
	Rarity,
	// Token: 0x040000B7 RID: 183
	DuplicatePrice,
	// Token: 0x040000B8 RID: 184
	TotalValue,
	// Token: 0x040000B9 RID: 185
	MAX
}
