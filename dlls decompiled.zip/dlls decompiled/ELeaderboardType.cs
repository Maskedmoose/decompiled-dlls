﻿using System;

// Token: 0x020000FE RID: 254
public enum ELeaderboardType
{
	// Token: 0x04000E98 RID: 3736
	GlobalPoint
}
