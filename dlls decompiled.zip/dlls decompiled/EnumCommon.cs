﻿using System;
using UnityEngine;

// Token: 0x020000D5 RID: 213
public class EnumCommon : MonoBehaviour
{
}
