﻿using System;

// Token: 0x020000BD RID: 189
public class CEventPlayer_OnDayStarted : CEvent
{
}
