﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000089 RID: 137
public class UI_PhoneScreen : UIScreenBase
{
	// Token: 0x06000564 RID: 1380 RVA: 0x0002D34E File Offset: 0x0002B54E
	protected override void RunUpdate()
	{
		base.RunUpdate();
		this.m_TimeText.text = CSingleton<LightManager>.Instance.m_TimeString;
		this.m_BatteryFill.fillAmount = 1f - CSingleton<LightManager>.Instance.GetPercentTillDayEnd();
	}

	// Token: 0x06000565 RID: 1381 RVA: 0x0002D386 File Offset: 0x0002B586
	protected override void OnOpenScreen()
	{
		base.OnOpenScreen();
		this.SetPhoneButtonRaycastEnable(true);
		this.m_DayText.text = CSingleton<GameUIScreen>.Instance.m_DayText.text;
	}

	// Token: 0x06000566 RID: 1382 RVA: 0x0002D3AF File Offset: 0x0002B5AF
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
		this.SetPhoneButtonRaycastEnable(false);
	}

	// Token: 0x06000567 RID: 1383 RVA: 0x0002D3BE File Offset: 0x0002B5BE
	public void OnPressExitPhoneMode()
	{
		PhoneManager.ExitPhoneMode();
	}

	// Token: 0x06000568 RID: 1384 RVA: 0x0002D3C5 File Offset: 0x0002B5C5
	public void OnPressBuyProductBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_RestockItemScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneRestock();
	}

	// Token: 0x06000569 RID: 1385 RVA: 0x0002D3FD File Offset: 0x0002B5FD
	public void OnPressBuyFurnitureBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_FurnitureShopUIScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneBuyShelf();
	}

	// Token: 0x0600056A RID: 1386 RVA: 0x0002D435 File Offset: 0x0002B635
	public void OnPressExpandShopBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_ExpandShopUIScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneShopExpansion();
	}

	// Token: 0x0600056B RID: 1387 RVA: 0x0002D46D File Offset: 0x0002B66D
	public void OnPressSettingBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		SettingScreen.OpenScreen(false);
	}

	// Token: 0x0600056C RID: 1388 RVA: 0x0002D489 File Offset: 0x0002B689
	public void OnPressManageEventBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_SetGameEventUIScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneManageEvent();
	}

	// Token: 0x0600056D RID: 1389 RVA: 0x0002D4C1 File Offset: 0x0002B6C1
	public void OnPressHireWorkerBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_HireWorkerScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneHireWorker();
	}

	// Token: 0x0600056E RID: 1390 RVA: 0x0002D4F9 File Offset: 0x0002B6F9
	public void OnPressCheckPriceScreenBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_CheckPriceScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneCheckPrice();
	}

	// Token: 0x0600056F RID: 1391 RVA: 0x0002D531 File Offset: 0x0002B731
	public void OnPressRentBillBtn()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.15f, 1f);
		base.OpenChildScreen(CSingleton<PhoneManager>.Instance.m_RentBillScreen);
		PhoneManager.SetCanClosePhone(false);
		this.SetPhoneButtonRaycastEnable(false);
		UnityAnalytic.PhoneHireWorker();
	}

	// Token: 0x06000570 RID: 1392 RVA: 0x0002D569 File Offset: 0x0002B769
	public void SetBillNotificationVisible(bool isVisible)
	{
		this.m_RentBillNotification.SetActive(isVisible);
	}

	// Token: 0x06000571 RID: 1393 RVA: 0x0002D577 File Offset: 0x0002B777
	protected override void OnChildScreenClosed(UIScreenBase childScreen)
	{
		PhoneManager.SetCanClosePhone(true);
		this.SetPhoneButtonRaycastEnable(true);
	}

	// Token: 0x06000572 RID: 1394 RVA: 0x0002D588 File Offset: 0x0002B788
	private void SetPhoneButtonRaycastEnable(bool isEnable)
	{
		for (int i = 0; i < this.m_PhoneButtonList.Count; i++)
		{
			this.m_PhoneButtonList[i].interactable = isEnable;
		}
	}

	// Token: 0x04000713 RID: 1811
	public TextMeshProUGUI m_TimeText;

	// Token: 0x04000714 RID: 1812
	public TextMeshProUGUI m_DayText;

	// Token: 0x04000715 RID: 1813
	public Image m_BatteryFill;

	// Token: 0x04000716 RID: 1814
	public List<Button> m_PhoneButtonList;

	// Token: 0x04000717 RID: 1815
	public GameObject m_RentBillNotification;
}
