﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001BE RID: 446
	public class ExpandableWindow : MonoBehaviour
	{
		// Token: 0x06000CA0 RID: 3232 RVA: 0x00057E74 File Offset: 0x00056074
		private void Start()
		{
			this.rT = base.gameObject.GetComponent<RectTransform>();
			this.TargetHeight = (this.CurrentHeight = (this.Expanded ? this.ExpandedHeight : this.ClosedHeight));
			this.rT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this.CurrentHeight);
		}

		// Token: 0x06000CA1 RID: 3233 RVA: 0x00057EC9 File Offset: 0x000560C9
		public void setExpandedState()
		{
			this.Expanded = !this.Expanded;
			this.TargetHeight = (this.Expanded ? this.ExpandedHeight : this.ClosedHeight);
		}

		// Token: 0x06000CA2 RID: 3234 RVA: 0x00057EF8 File Offset: 0x000560F8
		private void Update()
		{
			if (Mathf.Abs(this.CurrentHeight - this.TargetHeight) > 1f)
			{
				this.CurrentHeight = Mathf.Lerp(this.CurrentHeight, this.TargetHeight, Time.deltaTime * 5f);
				this.rT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this.CurrentHeight);
			}
		}

		// Token: 0x04001374 RID: 4980
		public float ExpandedHeight;

		// Token: 0x04001375 RID: 4981
		public float ClosedHeight;

		// Token: 0x04001376 RID: 4982
		public bool Expanded;

		// Token: 0x04001377 RID: 4983
		private float TargetHeight;

		// Token: 0x04001378 RID: 4984
		private float CurrentHeight;

		// Token: 0x04001379 RID: 4985
		private RectTransform rT;
	}
}
