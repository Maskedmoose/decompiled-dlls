﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000095 RID: 149
public class KeybindSetting : MonoBehaviour
{
	// Token: 0x060005E0 RID: 1504 RVA: 0x00030DDF File Offset: 0x0002EFDF
	public void Start()
	{
		this.UpdateInputUI();
	}

	// Token: 0x060005E1 RID: 1505 RVA: 0x00030DE8 File Offset: 0x0002EFE8
	public void UpdateInputUI()
	{
		if (this.m_IsGamepad)
		{
			EGamepadControlBtn baseGamepadBtnBind = InputManager.GetBaseGamepadBtnBind(this.m_GameBaseKey);
			this.m_TooltipUI.SetGamepadInputTooltip(EGameAction.None, baseGamepadBtnBind, InputManager.GetGamepadButtonName(baseGamepadBtnBind), false);
			return;
		}
		KeyCode baseKeycodeBind = InputManager.GetBaseKeycodeBind(this.m_GameBaseKey);
		this.m_TooltipUI.SetInputTooltip(EGameAction.None, baseKeycodeBind, InputManager.GetKeycodeName(baseKeycodeBind), false);
	}

	// Token: 0x060005E2 RID: 1506 RVA: 0x00030E40 File Offset: 0x0002F040
	public void OnPressButton()
	{
		if (this.m_IsGamepad && !CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			return;
		}
		if (!this.m_IsGamepad && CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			return;
		}
		if (!SettingScreen.IsChangingKeybind())
		{
			this.m_UpdatingGrp.SetActive(true);
			CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(true);
			InputManager.OnPressKeybindButton(this, this.m_IsGamepad, this.m_GameBaseKey, this.m_GameBaseKeySecondary);
		}
	}

	// Token: 0x060005E3 RID: 1507 RVA: 0x00030EAD File Offset: 0x0002F0AD
	public void OnFinishSetKeybind(KeyCode keycode)
	{
		this.m_UpdatingGrp.SetActive(false);
		CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(false);
		this.UpdateInputUI();
	}

	// Token: 0x060005E4 RID: 1508 RVA: 0x00030ECC File Offset: 0x0002F0CC
	public void OnFinishSetGamepadKeybind(EGamepadControlBtn controlBtn)
	{
		if (this.m_GamepadSettingLinker)
		{
			this.m_GamepadSettingLinker.OnFinishSetGamepadKeybind();
		}
		this.m_UpdatingGrp.SetActive(false);
		base.StartCoroutine(this.DelaySetIsChangingKeybind(false));
		this.UpdateInputUI();
	}

	// Token: 0x060005E5 RID: 1509 RVA: 0x00030F06 File Offset: 0x0002F106
	private IEnumerator DelaySetIsChangingKeybind(bool isChangingKeybind)
	{
		yield return new WaitForSecondsRealtime(0.1f);
		CSingleton<SettingScreen>.Instance.SetIsChangingKeybind(isChangingKeybind);
		yield break;
	}

	// Token: 0x040007A9 RID: 1961
	public EGameBaseKey m_GameBaseKey;

	// Token: 0x040007AA RID: 1962
	public EGameBaseKey m_GameBaseKeySecondary;

	// Token: 0x040007AB RID: 1963
	public bool m_IsGamepad;

	// Token: 0x040007AC RID: 1964
	public GameObject m_UpdatingGrp;

	// Token: 0x040007AD RID: 1965
	public InputTooltipUI m_TooltipUI;

	// Token: 0x040007AE RID: 1966
	public GamepadSettingLinker m_GamepadSettingLinker;
}
