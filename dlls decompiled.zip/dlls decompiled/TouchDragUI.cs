﻿using System;
using UnityEngine;

// Token: 0x02000128 RID: 296
public class TouchDragUI : MonoBehaviour
{
	// Token: 0x060008B0 RID: 2224 RVA: 0x0003FEF9 File Offset: 0x0003E0F9
	private void Awake()
	{
		this.m_StartDragIconGrp.SetActive(false);
		this.m_CurrentDragIconImage.SetActive(false);
		this.m_LineRendererIcon.SetActive(false);
	}

	// Token: 0x060008B1 RID: 2225 RVA: 0x0003FF1F File Offset: 0x0003E11F
	private void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_TouchReleased>(new CEventManager.EventDelegate<CEventPlayer_TouchReleased>(this.CPlayer_OnTouchReleased));
			CEventManager.AddListener<CEventPlayer_TouchScreen>(new CEventManager.EventDelegate<CEventPlayer_TouchScreen>(this.CPlayer_OnTouchScreen));
		}
	}

	// Token: 0x060008B2 RID: 2226 RVA: 0x0003FF51 File Offset: 0x0003E151
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_TouchReleased>(new CEventManager.EventDelegate<CEventPlayer_TouchReleased>(this.CPlayer_OnTouchReleased));
			CEventManager.RemoveListener<CEventPlayer_TouchScreen>(new CEventManager.EventDelegate<CEventPlayer_TouchScreen>(this.CPlayer_OnTouchScreen));
		}
	}

	// Token: 0x060008B3 RID: 2227 RVA: 0x0003FF83 File Offset: 0x0003E183
	private void CPlayer_OnTouchReleased(CEventPlayer_TouchReleased evt)
	{
		this.m_StartDragIconGrp.SetActive(false);
		this.m_CurrentDragIconImage.SetActive(false);
		this.m_LineRendererIcon.SetActive(false);
	}

	// Token: 0x060008B4 RID: 2228 RVA: 0x0003FFAC File Offset: 0x0003E1AC
	private void CPlayer_OnTouchScreen(CEventPlayer_TouchScreen evt)
	{
		this.m_StartDragIconGrp.SetActive(true);
		this.m_CurrentDragIconImage.SetActive(true);
		this.m_LineRendererIcon.SetActive(true);
		Vector3 mousePosition = Input.mousePosition;
		mousePosition.z = 2f;
		this.m_StartDragIconGrp.transform.position = Camera.main.ScreenToWorldPoint(mousePosition);
	}

	// Token: 0x0400107D RID: 4221
	public GameObject m_StartDragIconGrp;

	// Token: 0x0400107E RID: 4222
	public GameObject m_CurrentDragIconImage;

	// Token: 0x0400107F RID: 4223
	public GameObject m_CurrentDragIconGrp;

	// Token: 0x04001080 RID: 4224
	public GameObject m_LineRendererIcon;
}
