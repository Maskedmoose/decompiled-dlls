﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B8 RID: 440
	public class ScaleCharacter : MonoBehaviour
	{
		// Token: 0x06000C80 RID: 3200 RVA: 0x00057669 File Offset: 0x00055869
		public void SetHeight(float _Height)
		{
			this.Height = _Height;
			this.TargetScale = new Vector3(this.Height * this.Width, this.Height * this.Width, this.Height);
		}

		// Token: 0x06000C81 RID: 3201 RVA: 0x0005769D File Offset: 0x0005589D
		public void SetWidth(float _Width)
		{
			this.Width = _Width;
			this.TargetScale = new Vector3(this.Height * this.Width, this.Height * this.Width, this.Height);
		}

		// Token: 0x06000C82 RID: 3202 RVA: 0x000576D4 File Offset: 0x000558D4
		private void LateUpdate()
		{
			ScaleCharacter.mode mode = this.Mode;
			if (mode == ScaleCharacter.mode.Scale)
			{
				base.transform.localScale = this.TargetScale;
				return;
			}
			if (mode != ScaleCharacter.mode.CounterScale)
			{
				return;
			}
			base.transform.localScale = new Vector3(1f / this.TargetScale.z * Mathf.Lerp(this.TargetScale.z, 1f, this.CounterScaleLerp), 1f / this.TargetScale.y * Mathf.Lerp(this.TargetScale.z, 1f, this.CounterScaleLerp), 1f / this.TargetScale.x * Mathf.Lerp(this.TargetScale.z, 1f, this.CounterScaleLerp));
		}

		// Token: 0x0400135E RID: 4958
		public Vector3 TargetScale = new Vector3(1f, 1f, 1f);

		// Token: 0x0400135F RID: 4959
		public float Height = 1f;

		// Token: 0x04001360 RID: 4960
		public float Width = 1f;

		// Token: 0x04001361 RID: 4961
		public float CounterScaleLerp = 0.5f;

		// Token: 0x04001362 RID: 4962
		public ScaleCharacter.mode Mode;

		// Token: 0x0200026A RID: 618
		public enum mode
		{
			// Token: 0x0400165C RID: 5724
			Scale,
			// Token: 0x0400165D RID: 5725
			CounterScale
		}
	}
}
