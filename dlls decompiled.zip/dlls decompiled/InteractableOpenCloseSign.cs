﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000022 RID: 34
public class InteractableOpenCloseSign : InteractableObject
{
	// Token: 0x060001A6 RID: 422 RVA: 0x000130A4 File Offset: 0x000112A4
	public override void OnMouseButtonUp()
	{
		if (CPlayerData.m_TutorialIndex < 5 && CPlayerData.m_ShopLevel < 1)
		{
			Debug.Log(CPlayerData.m_TutorialIndex.ToString() + " " + CPlayerData.m_ShopLevel.ToString());
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CannotOpenShopYet);
			return;
		}
		if (this.m_IsSwapping)
		{
			return;
		}
		CPlayerData.m_IsShopOpen = !CPlayerData.m_IsShopOpen;
		if (!CPlayerData.m_IsShopOnceOpen && CPlayerData.m_IsShopOpen)
		{
			CPlayerData.m_IsShopOnceOpen = true;
			TutorialManager.AddTaskValue(ETutorialTaskCondition.OpenShop, 1f);
		}
		this.m_IsSwapping = true;
		this.m_Anim.Play();
		base.StartCoroutine(this.DelaySwapMesh());
		SoundManager.GenericPop(1f, 1f);
	}

	// Token: 0x060001A7 RID: 423 RVA: 0x00013150 File Offset: 0x00011350
	private IEnumerator DelaySwapMesh()
	{
		yield return new WaitForSeconds(0.6f);
		SoundManager.PlayAudio("SFX_WhipSoft", 0.4f, 1.2f);
		this.EvaluateSignOpenCloseMesh();
		yield return new WaitForSeconds(0.7f);
		this.m_IsSwapping = false;
		yield break;
	}

	// Token: 0x060001A8 RID: 424 RVA: 0x0001315F File Offset: 0x0001135F
	private void EvaluateSignOpenCloseMesh()
	{
		this.m_OpenShopMesh.SetActive(CPlayerData.m_IsShopOpen);
		this.m_CloseShopMesh.SetActive(!CPlayerData.m_IsShopOpen);
	}

	// Token: 0x060001A9 RID: 425 RVA: 0x00013184 File Offset: 0x00011384
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.AddListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
		}
	}

	// Token: 0x060001AA RID: 426 RVA: 0x000131D4 File Offset: 0x000113D4
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.RemoveListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
		}
	}

	// Token: 0x060001AB RID: 427 RVA: 0x00013222 File Offset: 0x00011422
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.EvaluateSignOpenCloseMesh();
	}

	// Token: 0x060001AC RID: 428 RVA: 0x0001322A File Offset: 0x0001142A
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		this.m_IsDayEnded = false;
		CPlayerData.m_IsShopOpen = false;
		CPlayerData.m_IsShopOnceOpen = false;
		this.EvaluateSignOpenCloseMesh();
	}

	// Token: 0x060001AD RID: 429 RVA: 0x00013245 File Offset: 0x00011445
	protected void OnDayEnded(CEventPlayer_OnDayEnded evt)
	{
		this.m_IsDayEnded = true;
	}

	// Token: 0x04000227 RID: 551
	public Animation m_Anim;

	// Token: 0x04000228 RID: 552
	public GameObject m_OpenShopMesh;

	// Token: 0x04000229 RID: 553
	public GameObject m_CloseShopMesh;

	// Token: 0x0400022A RID: 554
	private bool m_IsSwapping;

	// Token: 0x0400022B RID: 555
	private bool m_IsDayEnded;
}
