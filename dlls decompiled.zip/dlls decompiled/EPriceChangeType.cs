﻿using System;

// Token: 0x020000DD RID: 221
public enum EPriceChangeType
{
	// Token: 0x04000A35 RID: 2613
	None = -1,
	// Token: 0x04000A36 RID: 2614
	CommonPackCard,
	// Token: 0x04000A37 RID: 2615
	RarePackCard,
	// Token: 0x04000A38 RID: 2616
	EpicPackCard,
	// Token: 0x04000A39 RID: 2617
	LegendPackCard,
	// Token: 0x04000A3A RID: 2618
	NoneCommonPackCard,
	// Token: 0x04000A3B RID: 2619
	RandomRarityPackCard,
	// Token: 0x04000A3C RID: 2620
	FireElement,
	// Token: 0x04000A3D RID: 2621
	EarthElement,
	// Token: 0x04000A3E RID: 2622
	WaterElement,
	// Token: 0x04000A3F RID: 2623
	WindElement,
	// Token: 0x04000A40 RID: 2624
	RandomElement,
	// Token: 0x04000A41 RID: 2625
	FirstEdition,
	// Token: 0x04000A42 RID: 2626
	SilverBorder,
	// Token: 0x04000A43 RID: 2627
	GoldBorder,
	// Token: 0x04000A44 RID: 2628
	ExBorder,
	// Token: 0x04000A45 RID: 2629
	FullArtBorder,
	// Token: 0x04000A46 RID: 2630
	RandomBorder,
	// Token: 0x04000A47 RID: 2631
	Foil,
	// Token: 0x04000A48 RID: 2632
	NonFoil,
	// Token: 0x04000A49 RID: 2633
	RandomEffect,
	// Token: 0x04000A4A RID: 2634
	Figurine,
	// Token: 0x04000A4B RID: 2635
	ExpansionTetramon
}
