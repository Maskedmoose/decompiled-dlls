﻿using System;

// Token: 0x020000DE RID: 222
public enum EPlacedObjectIndex
{
	// Token: 0x04000A4D RID: 2637
	None = -1,
	// Token: 0x04000A4E RID: 2638
	MainCounter,
	// Token: 0x04000A4F RID: 2639
	SmallShelf,
	// Token: 0x04000A50 RID: 2640
	MediumShelf,
	// Token: 0x04000A51 RID: 2641
	LargeShelf,
	// Token: 0x04000A52 RID: 2642
	SmallTable,
	// Token: 0x04000A53 RID: 2643
	LongTable,
	// Token: 0x04000A54 RID: 2644
	VendingMachine,
	// Token: 0x04000A55 RID: 2645
	SmallRack,
	// Token: 0x04000A56 RID: 2646
	MediumTable,
	// Token: 0x04000A57 RID: 2647
	GiantShelf,
	// Token: 0x04000A58 RID: 2648
	SHELFMAX,
	// Token: 0x04000A59 RID: 2649
	Statue_PiggyA = 3000,
	// Token: 0x04000A5A RID: 2650
	Statue_PiggyB,
	// Token: 0x04000A5B RID: 2651
	Statue_PiggyC,
	// Token: 0x04000A5C RID: 2652
	Statue_PiggyD,
	// Token: 0x04000A5D RID: 2653
	TapBooster,
	// Token: 0x04000A5E RID: 2654
	CustomerBuyingPowerBooster,
	// Token: 0x04000A5F RID: 2655
	CustomerBuyAmountBooster,
	// Token: 0x04000A60 RID: 2656
	PackStorage,
	// Token: 0x04000A61 RID: 2657
	Statue_StarfishA,
	// Token: 0x04000A62 RID: 2658
	Statue_StarfishB,
	// Token: 0x04000A63 RID: 2659
	Statue_StarfishC,
	// Token: 0x04000A64 RID: 2660
	Statue_StarfishD,
	// Token: 0x04000A65 RID: 2661
	Statue_GolemA,
	// Token: 0x04000A66 RID: 2662
	Statue_GolemB,
	// Token: 0x04000A67 RID: 2663
	Statue_GolemC,
	// Token: 0x04000A68 RID: 2664
	Statue_GolemD,
	// Token: 0x04000A69 RID: 2665
	Statue_BatA,
	// Token: 0x04000A6A RID: 2666
	Statue_BatB,
	// Token: 0x04000A6B RID: 2667
	Statue_BatC,
	// Token: 0x04000A6C RID: 2668
	Statue_BatD,
	// Token: 0x04000A6D RID: 2669
	SellCardDisplay,
	// Token: 0x04000A6E RID: 2670
	BOOSTERMAX,
	// Token: 0x04000A6F RID: 2671
	Builder = 10000,
	// Token: 0x04000A70 RID: 2672
	TrashCan,
	// Token: 0x04000A71 RID: 2673
	Plant,
	// Token: 0x04000A72 RID: 2674
	OrangeLamp,
	// Token: 0x04000A73 RID: 2675
	WhiteLamp,
	// Token: 0x04000A74 RID: 2676
	RoundLeafPlant,
	// Token: 0x04000A75 RID: 2677
	GreenPlant,
	// Token: 0x04000A76 RID: 2678
	YellowPlant,
	// Token: 0x04000A77 RID: 2679
	PinkPlant,
	// Token: 0x04000A78 RID: 2680
	BushyPlant,
	// Token: 0x04000A79 RID: 2681
	WaterDispenser,
	// Token: 0x04000A7A RID: 2682
	SnackMachine,
	// Token: 0x04000A7B RID: 2683
	RedBeanBag,
	// Token: 0x04000A7C RID: 2684
	BeigeArmChair,
	// Token: 0x04000A7D RID: 2685
	OrangeArmChair,
	// Token: 0x04000A7E RID: 2686
	GamingStation,
	// Token: 0x04000A7F RID: 2687
	Bonsai,
	// Token: 0x04000A80 RID: 2688
	BambooPot,
	// Token: 0x04000A81 RID: 2689
	StoneLantern,
	// Token: 0x04000A82 RID: 2690
	KatanaDisplay,
	// Token: 0x04000A83 RID: 2691
	ArcadeMachine,
	// Token: 0x04000A84 RID: 2692
	ArcadeClaw,
	// Token: 0x04000A85 RID: 2693
	EarlyPlayerTrophy,
	// Token: 0x04000A86 RID: 2694
	LuckyCatStatue,
	// Token: 0x04000A87 RID: 2695
	DECOMAX
}
