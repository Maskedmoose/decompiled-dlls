﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x0200005C RID: 92
public class CheckPriceScreen : GenericSliderScreen
{
	// Token: 0x0600040E RID: 1038 RVA: 0x00023F7A File Offset: 0x0002217A
	protected override void Init()
	{
		this.m_PageIndex = -1;
		this.m_CardPageOptionGrp.SetActive(false);
		this.OnPressChangePageButton(0);
		base.Init();
	}

	// Token: 0x0600040F RID: 1039 RVA: 0x00023F9C File Offset: 0x0002219C
	public void OnPressChangePageButton(int index)
	{
		if (this.m_PageIndex == index)
		{
			return;
		}
		this.m_PageIndex = index;
		for (int i = 0; i < this.m_PageButtonHighlightList.Count; i++)
		{
			this.m_PageButtonHighlightList[i].SetActive(false);
		}
		this.m_PageButtonHighlightList[this.m_PageIndex].SetActive(true);
		if (index < 4)
		{
			this.EvaluateItemPanelUI(index);
		}
		else
		{
			this.EvaluateCardPanelUI(this.m_CardPageIndex);
		}
		base.StartCoroutine(base.EvaluateActiveRestockUIScroller());
		this.m_PosX = 0f;
		this.m_LerpPosX = 0f;
	}

	// Token: 0x06000410 RID: 1040 RVA: 0x00024038 File Offset: 0x00022238
	private void EvaluateItemPanelUI(int pageIndex)
	{
		List<EItemType> list = new List<EItemType>();
		if (pageIndex == 0)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownItemType;
		}
		else if (pageIndex == 1)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownAccessoryItemType;
		}
		else if (pageIndex == 2)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownFigurineItemType;
		}
		else if (pageIndex == 3)
		{
			for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownItemType.Count; i++)
			{
				list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownItemType[i]);
			}
			for (int j = 0; j < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownAccessoryItemType.Count; j++)
			{
				list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownAccessoryItemType[j]);
			}
			for (int k = 0; k < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownFigurineItemType.Count; k++)
			{
				list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownFigurineItemType[k]);
			}
		}
		for (int l = 0; l < this.m_CheckPricePanelUIList.Count; l++)
		{
			this.m_CheckPricePanelUIList[l].SetActive(false);
		}
		for (int m = 0; m < list.Count; m++)
		{
			this.m_CheckPricePanelUIList[m].InitItem(this, list[m]);
			this.m_CheckPricePanelUIList[m].SetActive(true);
			this.m_ScrollEndParent.transform.parent = this.m_CheckPricePanelUIList[m].transform;
			this.m_ScrollEndParent.transform.position = this.m_CheckPricePanelUIList[m].transform.position;
			this.m_ScrollEndPosParent = this.m_ScrollEndParent;
		}
		this.m_CardPageOptionGrp.SetActive(false);
	}

	// Token: 0x06000411 RID: 1041 RVA: 0x00024221 File Offset: 0x00022421
	public void OnPressNextCardPage()
	{
		if (this.m_CardPageIndex < this.m_CardPageMaxIndex)
		{
			this.m_CardPageIndex++;
			this.EvaluateCardPanelUI(this.m_CardPageIndex);
		}
	}

	// Token: 0x06000412 RID: 1042 RVA: 0x0002424B File Offset: 0x0002244B
	public void OnPressPreviousCardPage()
	{
		if (this.m_CardPageIndex > 0)
		{
			this.m_CardPageIndex--;
			this.EvaluateCardPanelUI(this.m_CardPageIndex);
		}
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x00024270 File Offset: 0x00022470
	public void OnPressNext10CardPage()
	{
		if (this.m_CardPageIndex < this.m_CardPageMaxIndex)
		{
			this.m_CardPageIndex += 10;
			if (this.m_CardPageIndex > this.m_CardPageMaxIndex)
			{
				this.m_CardPageIndex = this.m_CardPageMaxIndex;
			}
			this.EvaluateCardPanelUI(this.m_CardPageIndex);
		}
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x000242C0 File Offset: 0x000224C0
	public void OnPressPrevious10CardPage()
	{
		if (this.m_CardPageIndex > 0)
		{
			this.m_CardPageIndex -= 10;
			if (this.m_CardPageIndex < 0)
			{
				this.m_CardPageIndex = 0;
			}
			this.EvaluateCardPanelUI(this.m_CardPageIndex);
		}
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x000242F6 File Offset: 0x000224F6
	public void OnPressChangeCardExpansion()
	{
		SoundManager.GenericMenuOpen(1f, 1f);
		CardExpansionSelectScreen.OpenScreen(this.m_CurrentExpansionType);
		CEventManager.AddListener<CEventPlayer_OnCardExpansionSelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardExpansionSelectScreenUpdated>(this.OnCardExpansionUpdated));
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x00024324 File Offset: 0x00022524
	protected void OnCardExpansionUpdated(CEventPlayer_OnCardExpansionSelectScreenUpdated evt)
	{
		this.m_CurrentExpansionType = (ECardExpansionType)evt.m_CardExpansionTypeIndex;
		this.m_CardExpansionText.text = InventoryBase.GetCardExpansionName(this.m_CurrentExpansionType);
		this.m_CardPageIndex = 0;
		this.m_CardPageMaxIndex = InventoryBase.GetShownMonsterList(this.m_CurrentExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_CurrentExpansionType, true) / this.m_MaxCardUICountPerPage - 1;
		if (this.m_CurrentExpansionType == ECardExpansionType.Ghost)
		{
			this.m_CardPageMaxIndex *= 2;
		}
		this.EvaluateCardPanelUI(this.m_CardPageIndex);
		CEventManager.RemoveListener<CEventPlayer_OnCardExpansionSelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardExpansionSelectScreenUpdated>(this.OnCardExpansionUpdated));
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x000243BC File Offset: 0x000225BC
	private void EvaluateCardPanelUI(int cardPageIndex)
	{
		this.m_PosX = 0f;
		this.m_LerpPosX = 0f;
		for (int i = 0; i < this.m_CheckPricePanelUIList.Count; i++)
		{
			this.m_CheckPricePanelUIList[i].SetActive(false);
		}
		this.m_CardExpansionText.text = InventoryBase.GetCardExpansionName(this.m_CurrentExpansionType);
		int num = cardPageIndex * this.m_MaxCardUICountPerPage;
		int num2 = num;
		int num3 = InventoryBase.GetShownMonsterList(this.m_CurrentExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_CurrentExpansionType, true);
		if (this.m_CurrentExpansionType == ECardExpansionType.Ghost)
		{
			num3 *= 2;
		}
		this.m_CardPageMaxIndex = Mathf.CeilToInt((float)num3 / (float)this.m_MaxCardUICountPerPage) - 1;
		for (int j = 0; j < this.m_MaxCardUICountPerPage; j++)
		{
			if (num >= num3)
			{
				this.m_CheckPricePanelUIList[j].SetActive(false);
			}
			else
			{
				bool isDestiny = false;
				if (this.m_CurrentExpansionType == ECardExpansionType.Ghost)
				{
					if (num2 >= InventoryBase.GetShownMonsterList(this.m_CurrentExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_CurrentExpansionType, true))
					{
						isDestiny = true;
						num2 -= InventoryBase.GetShownMonsterList(this.m_CurrentExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_CurrentExpansionType, true);
					}
					this.m_CheckPricePanelUIList[j].InitCard(this, num2, this.m_CurrentExpansionType, isDestiny);
				}
				else
				{
					this.m_CheckPricePanelUIList[j].InitCard(this, num, this.m_CurrentExpansionType, isDestiny);
				}
				this.m_CheckPricePanelUIList[j].SetActive(true);
				this.m_ScrollEndParent.transform.parent = this.m_CheckPricePanelUIList[j].transform;
				this.m_ScrollEndParent.transform.position = this.m_CheckPricePanelUIList[j].transform.position;
				Vector3 position = this.m_ScrollEndParent.transform.position;
				position.y += this.m_CardScrollOffsetPosEnd.position.y - this.m_CardScrollOffsetPosStart.position.y;
				this.m_ScrollEndParent.transform.position = position;
				this.m_ScrollEndPosParent = this.m_ScrollEndParent;
				num++;
				num2 = num;
			}
		}
		this.m_PageText.text = (this.m_CardPageIndex + 1).ToString() + " / " + (this.m_CardPageMaxIndex + 1).ToString();
		this.m_CardPageOptionGrp.SetActive(true);
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x0002462B File Offset: 0x0002282B
	protected override void OnOpenScreen()
	{
		this.Init();
		base.OnOpenScreen();
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x00024639 File Offset: 0x00022839
	public void OnPressOpenItemPriceGraph(EItemType itemType)
	{
		this.m_ItemPriceGraphScreen.ShowItemPriceChart(itemType);
		base.OpenChildScreen(this.m_ItemPriceGraphScreen);
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x00024653 File Offset: 0x00022853
	public void OnPressOpenCardPriceGraph(int cardIndex, ECardExpansionType expansionType, bool isDestiny)
	{
		this.m_ItemPriceGraphScreen.ShowCardPriceChart(cardIndex, expansionType, isDestiny);
		base.OpenChildScreen(this.m_ItemPriceGraphScreen);
	}

	// Token: 0x040004E6 RID: 1254
	public List<CheckPricePanelUI> m_CheckPricePanelUIList;

	// Token: 0x040004E7 RID: 1255
	public List<GameObject> m_PageButtonHighlightList;

	// Token: 0x040004E8 RID: 1256
	public ItemPriceGraphScreen m_ItemPriceGraphScreen;

	// Token: 0x040004E9 RID: 1257
	public GameObject m_CardPageOptionGrp;

	// Token: 0x040004EA RID: 1258
	public GameObject m_ScrollEndParent;

	// Token: 0x040004EB RID: 1259
	public Transform m_CardScrollOffsetPosStart;

	// Token: 0x040004EC RID: 1260
	public Transform m_CardScrollOffsetPosEnd;

	// Token: 0x040004ED RID: 1261
	public TextMeshProUGUI m_PageText;

	// Token: 0x040004EE RID: 1262
	public TextMeshProUGUI m_CardExpansionText;

	// Token: 0x040004EF RID: 1263
	public Color m_PositiveColor;

	// Token: 0x040004F0 RID: 1264
	public Color m_NegativeColor;

	// Token: 0x040004F1 RID: 1265
	public Color m_NeutralColor;

	// Token: 0x040004F2 RID: 1266
	private int m_PageIndex = -1;

	// Token: 0x040004F3 RID: 1267
	private int m_CardPageIndex;

	// Token: 0x040004F4 RID: 1268
	private int m_CardPageMaxIndex;

	// Token: 0x040004F5 RID: 1269
	public int m_MaxCardUICountPerPage = 12;

	// Token: 0x040004F6 RID: 1270
	private ECardExpansionType m_CurrentExpansionType;
}
