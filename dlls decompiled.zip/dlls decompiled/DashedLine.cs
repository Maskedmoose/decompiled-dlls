﻿using System;
using UnityEngine;

// Token: 0x02000016 RID: 22
public class DashedLine : MonoBehaviour
{
	// Token: 0x060000FE RID: 254 RVA: 0x0000EF00 File Offset: 0x0000D100
	private void Awake()
	{
		this.m_MatHorizontal = this.m_RendererHorizontal1.material;
		this.m_RendererHorizontal1.material = this.m_MatHorizontal;
		this.m_RendererHorizontal2.material = this.m_MatHorizontal;
		this.m_MatVertical = this.m_RendererVertical1.material;
		this.m_RendererVertical1.material = this.m_MatVertical;
		this.m_RendererVertical2.material = this.m_MatVertical;
		ShelfManager.AddDashedLine(this);
		base.gameObject.SetActive(false);
		this.m_MatHorizontal.mainTextureScale = new Vector2(this.m_TilingAmount * base.transform.lossyScale.x, 1f);
		Vector3 one = Vector3.one;
		one.z = this.m_ScaleAmount / base.transform.lossyScale.z * 2f;
		this.m_RendererHorizontal1.transform.localScale = one;
		this.m_RendererHorizontal2.transform.localScale = one;
		this.m_MatVertical.mainTextureScale = new Vector2(this.m_TilingAmount * base.transform.lossyScale.z, 1f);
		Vector3 one2 = Vector3.one;
		one2.z = this.m_ScaleAmount / base.transform.lossyScale.x * 2f;
		this.m_RendererVertical1.transform.localScale = one2;
		this.m_RendererVertical2.transform.localScale = one2;
	}

	// Token: 0x0400017C RID: 380
	private float m_TilingAmount = 8f;

	// Token: 0x0400017D RID: 381
	private float m_ScaleAmount = 0.05f;

	// Token: 0x0400017E RID: 382
	public MeshRenderer m_RendererHorizontal1;

	// Token: 0x0400017F RID: 383
	public MeshRenderer m_RendererHorizontal2;

	// Token: 0x04000180 RID: 384
	public MeshRenderer m_RendererVertical1;

	// Token: 0x04000181 RID: 385
	public MeshRenderer m_RendererVertical2;

	// Token: 0x04000182 RID: 386
	private Material m_MatHorizontal;

	// Token: 0x04000183 RID: 387
	private Material m_MatVertical;
}
