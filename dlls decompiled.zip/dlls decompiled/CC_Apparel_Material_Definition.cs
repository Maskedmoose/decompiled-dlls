﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001AD RID: 429
	[Serializable]
	public class CC_Apparel_Material_Definition
	{
		// Token: 0x0400132D RID: 4909
		public Color MainTint;

		// Token: 0x0400132E RID: 4910
		public Color TintR;

		// Token: 0x0400132F RID: 4911
		public Color TintG;

		// Token: 0x04001330 RID: 4912
		public Color TintB;

		// Token: 0x04001331 RID: 4913
		public Texture2D Print;
	}
}
