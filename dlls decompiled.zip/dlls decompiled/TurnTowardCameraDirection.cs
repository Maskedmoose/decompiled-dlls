﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D1 RID: 465
	public class TurnTowardCameraDirection : MonoBehaviour
	{
		// Token: 0x06000CFC RID: 3324 RVA: 0x00059CC1 File Offset: 0x00057EC1
		private void Start()
		{
			this.tr = base.transform;
			if (this.cameraController == null)
			{
				Debug.LogWarning("No camera controller reference has been assigned to this script.", this);
			}
		}

		// Token: 0x06000CFD RID: 3325 RVA: 0x00059CE8 File Offset: 0x00057EE8
		private void LateUpdate()
		{
			if (!this.cameraController)
			{
				return;
			}
			Vector3 facingDirection = this.cameraController.GetFacingDirection();
			Vector3 upDirection = this.cameraController.GetUpDirection();
			this.tr.rotation = Quaternion.LookRotation(facingDirection, upDirection);
		}

		// Token: 0x040013EA RID: 5098
		public CameraController cameraController;

		// Token: 0x040013EB RID: 5099
		private Transform tr;
	}
}
