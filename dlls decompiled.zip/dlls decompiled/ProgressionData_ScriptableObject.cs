﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;

// Token: 0x0200012F RID: 303
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 8)]
public class ProgressionData_ScriptableObject : ScriptableObject
{
	// Token: 0x060008DF RID: 2271 RVA: 0x000411E3 File Offset: 0x0003F3E3
	public string GetTamerLevelUpUnlockText(int level)
	{
		return LocalizationManager.GetTranslation(this.m_TamerLevelUpUnlockedText[level], true, 0, true, false, null, null, true);
	}

	// Token: 0x060008E0 RID: 2272 RVA: 0x000411FD File Offset: 0x0003F3FD
	public ProgressionArenaData GetProgressionData(int playerRank, bool hasFinishTutorial)
	{
		if (!hasFinishTutorial)
		{
			return this.m_TutorialArenaData;
		}
		if (playerRank >= 0 && playerRank < this.m_ProgressionArenaDataList.Count)
		{
			return this.m_ProgressionArenaDataList[playerRank];
		}
		return this.m_EmptyData;
	}

	// Token: 0x040010CF RID: 4303
	public ProgressionArenaData m_EmptyData;

	// Token: 0x040010D0 RID: 4304
	public ProgressionArenaData m_TutorialArenaData;

	// Token: 0x040010D1 RID: 4305
	public List<ProgressionArenaData> m_ProgressionArenaDataList;

	// Token: 0x040010D2 RID: 4306
	public List<int> m_TamerLevelUpExpRequiredList;

	// Token: 0x040010D3 RID: 4307
	public List<string> m_TamerLevelUpUnlockedText;
}
