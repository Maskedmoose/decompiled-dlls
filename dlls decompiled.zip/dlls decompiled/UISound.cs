﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001CE RID: 462
	public class UISound : MonoBehaviour
	{
		// Token: 0x06000CEC RID: 3308 RVA: 0x000597DC File Offset: 0x000579DC
		public void playUISound(int index)
		{
			CC_UI_Manager.instance.playUIAudio(index);
		}
	}
}
