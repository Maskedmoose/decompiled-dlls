﻿using System;

// Token: 0x020000EE RID: 238
public enum EStatusEffect
{
	// Token: 0x04000D38 RID: 3384
	None,
	// Token: 0x04000D39 RID: 3385
	Poison,
	// Token: 0x04000D3A RID: 3386
	Blind,
	// Token: 0x04000D3B RID: 3387
	Stun,
	// Token: 0x04000D3C RID: 3388
	Beserk,
	// Token: 0x04000D3D RID: 3389
	Drain,
	// Token: 0x04000D3E RID: 3390
	Wall,
	// Token: 0x04000D3F RID: 3391
	PowerUp,
	// Token: 0x04000D40 RID: 3392
	DefUp,
	// Token: 0x04000D41 RID: 3393
	HPRegen,
	// Token: 0x04000D42 RID: 3394
	Splash,
	// Token: 0x04000D43 RID: 3395
	SPRegen,
	// Token: 0x04000D44 RID: 3396
	Sticky,
	// Token: 0x04000D45 RID: 3397
	Cleanse,
	// Token: 0x04000D46 RID: 3398
	FocusFire,
	// Token: 0x04000D47 RID: 3399
	Sleep,
	// Token: 0x04000D48 RID: 3400
	SpeedUp,
	// Token: 0x04000D49 RID: 3401
	SpeedDown,
	// Token: 0x04000D4A RID: 3402
	Guard,
	// Token: 0x04000D4B RID: 3403
	MAX
}
