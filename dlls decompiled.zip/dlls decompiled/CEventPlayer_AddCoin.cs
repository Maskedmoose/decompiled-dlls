﻿using System;

// Token: 0x020000AC RID: 172
public class CEventPlayer_AddCoin : CEvent
{
	// Token: 0x1700000C RID: 12
	// (get) Token: 0x060006EB RID: 1771 RVA: 0x00037F37 File Offset: 0x00036137
	// (set) Token: 0x060006EC RID: 1772 RVA: 0x00037F3F File Offset: 0x0003613F
	public float m_CoinValue { get; private set; }

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x060006ED RID: 1773 RVA: 0x00037F48 File Offset: 0x00036148
	// (set) Token: 0x060006EE RID: 1774 RVA: 0x00037F50 File Offset: 0x00036150
	public bool m_NoLerp { get; private set; }

	// Token: 0x060006EF RID: 1775 RVA: 0x00037F59 File Offset: 0x00036159
	public CEventPlayer_AddCoin(float coinValue, bool noLerp = false)
	{
		this.m_CoinValue = coinValue;
		this.m_NoLerp = noLerp;
	}
}
