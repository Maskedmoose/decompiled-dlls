﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000061 RID: 97
public class EndDayReportTextUI : MonoBehaviour
{
	// Token: 0x0600043D RID: 1085 RVA: 0x00024C08 File Offset: 0x00022E08
	public void SetNumber(float start, float end, float lerpTime, Color positiveColor, Color negativeColor, Color neutralColor)
	{
		this.m_IsLerpEnded = false;
		this.m_LerpTimer = 0f;
		this.m_LerpTime = lerpTime;
		if (this.m_LerpTime <= 0f)
		{
			this.m_LerpTime = 0.01f;
		}
		this.m_LerpStart = start;
		this.m_LerpTarget = end;
		if (this.m_LerpStart == this.m_LerpTarget)
		{
			this.m_LerpTime /= 2f;
		}
		base.gameObject.SetActive(false);
		if (end > 0f)
		{
			this.m_Text.color = positiveColor;
			return;
		}
		if (end < 0f)
		{
			this.m_Text.color = negativeColor;
			return;
		}
		this.m_Text.color = neutralColor;
	}

	// Token: 0x0600043E RID: 1086 RVA: 0x00024CBC File Offset: 0x00022EBC
	public void UpdateLerp()
	{
		if (this.m_IsLerpEnded)
		{
			return;
		}
		if (this.m_LerpTimer == 0f)
		{
			base.gameObject.SetActive(true);
			if (this.m_LerpStart != this.m_LerpTarget)
			{
				SoundManager.SetEnableSound_CoinIncrease(true);
			}
		}
		this.m_LerpTimer += Time.deltaTime / this.m_LerpTime;
		this.m_LerpNumber = Mathf.Lerp(this.m_LerpStart, this.m_LerpTarget, this.m_LerpTimer);
		if (this.m_IsTime)
		{
			this.m_Text.text = GameInstance.GetTimeString((float)Mathf.FloorToInt(this.m_LerpNumber), false, true, true, false, false, true);
		}
		else if (this.m_IsInt)
		{
			if (this.m_IsShowPlusSymbol && this.m_LerpNumber > 0f)
			{
				this.m_Text.text = "+" + Mathf.FloorToInt(this.m_LerpNumber).ToString();
			}
			else
			{
				this.m_Text.text = Mathf.FloorToInt(this.m_LerpNumber).ToString();
			}
		}
		else if (this.m_IsPrice)
		{
			if (this.m_IsShowPlusSymbol && this.m_LerpNumber > 0f)
			{
				this.m_Text.text = "+" + GameInstance.GetPriceString(this.m_LerpNumber, false, true, false, "F2");
			}
			else
			{
				this.m_Text.text = GameInstance.GetPriceString(this.m_LerpNumber, false, true, false, "F2");
			}
		}
		else if (this.m_IsShowPlusSymbol && this.m_LerpNumber > 0f)
		{
			this.m_Text.text = "+" + this.m_LerpNumber.ToString("F2");
		}
		else
		{
			this.m_Text.text = this.m_LerpNumber.ToString("F2");
		}
		if (this.m_LerpTimer >= 1f)
		{
			this.m_IsLerpEnded = true;
			SoundManager.SetEnableSound_CoinIncrease(false);
		}
	}

	// Token: 0x0600043F RID: 1087 RVA: 0x00024EA9 File Offset: 0x000230A9
	public void EndLerpInstantly()
	{
		base.gameObject.SetActive(true);
		this.m_LerpTimer = 1f;
		this.UpdateLerp();
	}

	// Token: 0x06000440 RID: 1088 RVA: 0x00024EC8 File Offset: 0x000230C8
	public bool IsLerpEnded()
	{
		return this.m_IsLerpEnded;
	}

	// Token: 0x0400050C RID: 1292
	public TextMeshProUGUI m_Text;

	// Token: 0x0400050D RID: 1293
	public bool m_IsInt;

	// Token: 0x0400050E RID: 1294
	public bool m_IsPrice;

	// Token: 0x0400050F RID: 1295
	public bool m_IsTime;

	// Token: 0x04000510 RID: 1296
	public bool m_IsShowPlusSymbol;

	// Token: 0x04000511 RID: 1297
	private bool m_IsLerpEnded;

	// Token: 0x04000512 RID: 1298
	private float m_LerpNumber;

	// Token: 0x04000513 RID: 1299
	private float m_LerpStart;

	// Token: 0x04000514 RID: 1300
	private float m_LerpTarget;

	// Token: 0x04000515 RID: 1301
	private float m_LerpTimer;

	// Token: 0x04000516 RID: 1302
	private float m_LerpTime;
}
