﻿using System;

// Token: 0x020000D7 RID: 215
public enum EGameState
{
	// Token: 0x04000986 RID: 2438
	DefaultState,
	// Token: 0x04000987 RID: 2439
	HoldingBoxState,
	// Token: 0x04000988 RID: 2440
	HoldingCardState,
	// Token: 0x04000989 RID: 2441
	HoldingItemState,
	// Token: 0x0400098A RID: 2442
	ViewAlbumState,
	// Token: 0x0400098B RID: 2443
	MovingObjectState,
	// Token: 0x0400098C RID: 2444
	CashCounterState,
	// Token: 0x0400098D RID: 2445
	PhoneState,
	// Token: 0x0400098E RID: 2446
	OpeningPackState,
	// Token: 0x0400098F RID: 2447
	HoldSprayState,
	// Token: 0x04000990 RID: 2448
	WorkerInteractState,
	// Token: 0x04000991 RID: 2449
	MovingBoxState
}
