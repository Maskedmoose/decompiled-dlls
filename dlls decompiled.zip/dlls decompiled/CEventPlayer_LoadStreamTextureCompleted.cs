﻿using System;

// Token: 0x020000D1 RID: 209
public class CEventPlayer_LoadStreamTextureCompleted : CEvent
{
	// Token: 0x1700002D RID: 45
	// (get) Token: 0x06000752 RID: 1874 RVA: 0x00038377 File Offset: 0x00036577
	// (set) Token: 0x06000753 RID: 1875 RVA: 0x0003837F File Offset: 0x0003657F
	public bool m_IsSuccess { get; private set; }

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x06000754 RID: 1876 RVA: 0x00038388 File Offset: 0x00036588
	// (set) Token: 0x06000755 RID: 1877 RVA: 0x00038390 File Offset: 0x00036590
	public string m_FileName { get; private set; }

	// Token: 0x06000756 RID: 1878 RVA: 0x00038399 File Offset: 0x00036599
	public CEventPlayer_LoadStreamTextureCompleted(bool isSuccess, string fileName)
	{
		this.m_IsSuccess = isSuccess;
		this.m_FileName = fileName;
	}
}
