﻿using System;

// Token: 0x0200008D RID: 141
public enum EWorkerState
{
	// Token: 0x04000729 RID: 1833
	None = -1,
	// Token: 0x0400072A RID: 1834
	Idle,
	// Token: 0x0400072B RID: 1835
	WalkingToCounter,
	// Token: 0x0400072C RID: 1836
	ManningCounter,
	// Token: 0x0400072D RID: 1837
	WalkingToRestOutside,
	// Token: 0x0400072E RID: 1838
	RestOutside,
	// Token: 0x0400072F RID: 1839
	SearchingForBox,
	// Token: 0x04000730 RID: 1840
	FindingShelfToRestock,
	// Token: 0x04000731 RID: 1841
	WalkToShelf,
	// Token: 0x04000732 RID: 1842
	RestockingShelf,
	// Token: 0x04000733 RID: 1843
	TrashingBox,
	// Token: 0x04000734 RID: 1844
	ReadyToTrashBox,
	// Token: 0x04000735 RID: 1845
	FindingWarehouseShelf,
	// Token: 0x04000736 RID: 1846
	WalkToWarehouseShelf,
	// Token: 0x04000737 RID: 1847
	StoreBoxOnWarehouseShelf,
	// Token: 0x04000738 RID: 1848
	SearchingForBoxToStore,
	// Token: 0x04000739 RID: 1849
	TakingItemFromShelf,
	// Token: 0x0400073A RID: 1850
	ExitingShop,
	// Token: 0x0400073B RID: 1851
	ShopNotOpen
}
