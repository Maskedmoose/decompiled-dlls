﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D6 RID: 470
	public class ThirdPersonCameraController : CameraController
	{
		// Token: 0x06000D20 RID: 3360 RVA: 0x0005A7EC File Offset: 0x000589EC
		protected override void Setup()
		{
			if (this.controller == null)
			{
				Debug.LogWarning("No controller reference has been assigned to this script.", base.gameObject);
			}
		}

		// Token: 0x06000D21 RID: 3361 RVA: 0x0005A80C File Offset: 0x00058A0C
		protected override void HandleCameraRotation()
		{
			base.HandleCameraRotation();
			if (this.controller == null)
			{
				return;
			}
			if (this.turnCameraTowardMovementDirection && this.controller != null)
			{
				Vector3 velocity = this.controller.GetVelocity();
				this.RotateTowardsVelocity(velocity, this.cameraTurnSpeed);
			}
		}

		// Token: 0x06000D22 RID: 3362 RVA: 0x0005A860 File Offset: 0x00058A60
		public void RotateTowardsVelocity(Vector3 _velocity, float _speed)
		{
			_velocity = VectorMath.RemoveDotVector(_velocity, base.GetUpDirection());
			float angle = VectorMath.GetAngle(base.GetFacingDirection(), _velocity, base.GetUpDirection());
			float num = Mathf.Sign(angle);
			float num2 = Time.deltaTime * _speed * num * Mathf.Abs(angle / 90f);
			if (Mathf.Abs(angle) > 90f)
			{
				num2 = Time.deltaTime * _speed * num * (Mathf.Abs(180f - Mathf.Abs(angle)) / 90f);
			}
			if (Mathf.Abs(num2) > Mathf.Abs(angle))
			{
				num2 = angle;
			}
			num2 *= Mathf.InverseLerp(0f, this.maximumMovementSpeed, _velocity.magnitude);
			base.SetRotationAngles(base.GetCurrentXAngle(), base.GetCurrentYAngle() + num2);
		}

		// Token: 0x04001414 RID: 5140
		public bool turnCameraTowardMovementDirection = true;

		// Token: 0x04001415 RID: 5141
		public Controller controller;

		// Token: 0x04001416 RID: 5142
		public float maximumMovementSpeed = 7f;

		// Token: 0x04001417 RID: 5143
		public float cameraTurnSpeed = 120f;
	}
}
