﻿using System;

// Token: 0x020000A6 RID: 166
public class CEvent
{
}
