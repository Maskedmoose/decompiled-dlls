﻿using System;

// Token: 0x0200004A RID: 74
[Serializable]
public class ItemTypeAmount
{
	// Token: 0x0400043C RID: 1084
	public EItemType itemType;

	// Token: 0x0400043D RID: 1085
	public int amount;
}
