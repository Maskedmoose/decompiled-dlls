﻿using System;

// Token: 0x020000BB RID: 187
public class CEventPlayer_OpenLoadingScreen : CEvent
{
}
