﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000085 RID: 133
public class WorkerOptionUIScreen : MonoBehaviour
{
	// Token: 0x06000542 RID: 1346 RVA: 0x0002C6CD File Offset: 0x0002A8CD
	public void OpenScreen(Worker worker, int taskIndex)
	{
		this.m_Worker = worker;
		this.m_TaskIndex = taskIndex;
		this.m_ScreenGrp.SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x06000543 RID: 1347 RVA: 0x0002C703 File Offset: 0x0002A903
	public void CloseScreen()
	{
		this.m_ScreenGrp.SetActive(false);
		SoundManager.GenericMenuClose(1f, 1f);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x06000544 RID: 1348 RVA: 0x0002C72C File Offset: 0x0002A92C
	public void OnPressRestockShelfWithNoLabel(bool isFillShelfWithoutLabel)
	{
		this.m_Worker.SetRestockShelfWithNoLabel(isFillShelfWithoutLabel);
		this.m_Worker.SetTask((EWorkerTask)this.m_TaskIndex);
		this.m_Worker.SetLastTask((EWorkerTask)this.m_TaskIndex);
		SoundManager.GenericConfirm(1f, 1f);
		this.m_Worker.OnPressStopInteract();
		this.CloseScreen();
	}

	// Token: 0x040006E7 RID: 1767
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040006E8 RID: 1768
	public GameObject m_ScreenGrp;

	// Token: 0x040006E9 RID: 1769
	public TextMeshProUGUI m_OptionText;

	// Token: 0x040006EA RID: 1770
	private Worker m_Worker;

	// Token: 0x040006EB RID: 1771
	private int m_TaskIndex;
}
