﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B4 RID: 436
	[CreateAssetMenu(fileName = "Presets", menuName = "ScriptableObjects/Presets")]
	public class scrObj_Presets : ScriptableObject
	{
		// Token: 0x04001354 RID: 4948
		public List<CC_CharacterData> Presets = new List<CC_CharacterData>();
	}
}
