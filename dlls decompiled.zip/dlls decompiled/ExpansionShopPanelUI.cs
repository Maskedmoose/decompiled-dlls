﻿using System;
using System.Collections.Generic;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x02000064 RID: 100
public class ExpansionShopPanelUI : UIElementBase
{
	// Token: 0x0600044D RID: 1101 RVA: 0x000258D8 File Offset: 0x00023AD8
	public void Init(ExpansionShopUIScreen expansionShopUIScreen, int index, bool isShopB)
	{
		this.m_ExpansionShopUIScreen = expansionShopUIScreen;
		this.m_Index = index;
		this.m_IsShopB = isShopB;
		for (int i = 0; i < this.m_ShopB_EnableList.Count; i++)
		{
			this.m_ShopB_EnableList[i].SetActive(this.m_IsShopB);
		}
		if (!isShopB && CSingleton<CGameManager>.Instance.m_IsPrologue && index > 3)
		{
			this.m_UIGrp.SetActive(false);
			this.m_PrologueUIGrp.SetActive(true);
		}
		else if (isShopB && CSingleton<CGameManager>.Instance.m_IsPrologue && index > -1)
		{
			this.m_UIGrp.SetActive(false);
			this.m_PrologueUIGrp.SetActive(true);
		}
		int num = Mathf.Clamp(index * 2 + 1, 2, 50);
		int num2 = index / 4 * 2;
		num += num2;
		if (isShopB)
		{
			num = 20 + index * 5 + index / 4 * 10;
		}
		if (this.m_LevelRequirementString == "")
		{
			this.m_LevelRequirementString = this.m_LevelRequirementText.text;
		}
		bool flag = false;
		this.m_UnlockPreviousFirst = false;
		int num3 = CPlayerData.m_UnlockRoomCount;
		if (this.m_IsShopB)
		{
			num3 = CPlayerData.m_UnlockWarehouseRoomCount;
		}
		if (num3 > this.m_Index)
		{
			this.m_PurchasedBtn.gameObject.SetActive(true);
			this.m_LockPurchaseBtn.gameObject.SetActive(false);
			flag = true;
		}
		else if (num3 == index)
		{
			this.m_PurchasedBtn.gameObject.SetActive(false);
			this.m_LockPurchaseBtn.gameObject.SetActive(false);
		}
		else
		{
			this.m_PurchasedBtn.gameObject.SetActive(false);
			this.m_LockPurchaseBtn.gameObject.SetActive(true);
			this.m_UnlockPreviousFirst = true;
		}
		this.m_LevelRequired = num;
		if (CPlayerData.m_ShopLevel + 1 >= this.m_LevelRequired || flag)
		{
			this.m_LevelRequirementText.gameObject.SetActive(false);
			if (!this.m_UnlockPreviousFirst)
			{
				this.m_LockPurchaseBtn.gameObject.SetActive(false);
			}
		}
		else
		{
			this.m_LevelRequirementText.text = LocalizationManager.GetTranslation(this.m_LevelRequirementString, true, 0, true, false, null, null, true).Replace("XXX", this.m_LevelRequired.ToString());
			this.m_LevelRequirementText.gameObject.SetActive(true);
			this.m_LockPurchaseBtn.gameObject.SetActive(true);
		}
		this.m_NameText.text = LocalizationManager.GetTranslation("Shop Expansion", true, 0, true, false, null, null, true) + " " + (index + 1).ToString();
		this.m_UpgradeCost = CPlayerData.GetUnlockShopRoomCost(index);
		this.m_PriceText.text = GameInstance.GetPriceString(this.m_UpgradeCost, false, true, false, "F2");
	}

	// Token: 0x0600044E RID: 1102 RVA: 0x00025B68 File Offset: 0x00023D68
	public override void OnPressButton()
	{
		int num = CPlayerData.m_UnlockRoomCount;
		if (this.m_IsShopB)
		{
			num = CPlayerData.m_UnlockWarehouseRoomCount;
		}
		if (num > this.m_Index)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AlreadyPurchased);
			return;
		}
		if (this.m_UnlockPreviousFirst)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.UnlockPreviousRoomExpansionFirst);
			return;
		}
		if (CPlayerData.m_ShopLevel + 1 < this.m_LevelRequired)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShopLevelNotEnough);
			return;
		}
		if (CPlayerData.m_CoinAmount >= this.m_UpgradeCost)
		{
			this.m_ExpansionShopUIScreen.EvaluateCartCheckout(this.m_UpgradeCost, this.m_Index, this.m_IsShopB);
			return;
		}
		NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
	}

	// Token: 0x04000540 RID: 1344
	public TextMeshProUGUI m_NameText;

	// Token: 0x04000541 RID: 1345
	public TextMeshProUGUI m_PriceText;

	// Token: 0x04000542 RID: 1346
	public TextMeshProUGUI m_LevelRequirementText;

	// Token: 0x04000543 RID: 1347
	public GameObject m_LockPurchaseBtn;

	// Token: 0x04000544 RID: 1348
	public GameObject m_PurchasedBtn;

	// Token: 0x04000545 RID: 1349
	public GameObject m_PrologueUIGrp;

	// Token: 0x04000546 RID: 1350
	public List<GameObject> m_ShopB_EnableList;

	// Token: 0x04000547 RID: 1351
	private ExpansionShopUIScreen m_ExpansionShopUIScreen;

	// Token: 0x04000548 RID: 1352
	private bool m_UnlockPreviousFirst;

	// Token: 0x04000549 RID: 1353
	private bool m_IsShopB;

	// Token: 0x0400054A RID: 1354
	private int m_Index;

	// Token: 0x0400054B RID: 1355
	private int m_LevelRequired;

	// Token: 0x0400054C RID: 1356
	private float m_UpgradeCost;

	// Token: 0x0400054D RID: 1357
	private string m_LevelRequirementString = "";
}
