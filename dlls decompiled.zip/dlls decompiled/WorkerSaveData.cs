﻿using System;

// Token: 0x02000092 RID: 146
[Serializable]
public class WorkerSaveData
{
	// Token: 0x0400078F RID: 1935
	public EWorkerTask workerTask;

	// Token: 0x04000790 RID: 1936
	public EWorkerState currentState;

	// Token: 0x04000791 RID: 1937
	public Vector3Serializer pos;

	// Token: 0x04000792 RID: 1938
	public QuaternionSerializer rot;

	// Token: 0x04000793 RID: 1939
	public bool isFillShelfWithoutLabel;
}
