﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B7 RID: 439
	public class MipBiasAdjust : MonoBehaviour
	{
		// Token: 0x06000C7E RID: 3198 RVA: 0x0005762C File Offset: 0x0005582C
		public void Start()
		{
			for (int i = 0; i < this.Textures.Length; i++)
			{
				this.Textures[i].mipMapBias = this.MipBias[i];
			}
		}

		// Token: 0x0400135C RID: 4956
		public float[] MipBias;

		// Token: 0x0400135D RID: 4957
		public Texture[] Textures;
	}
}
