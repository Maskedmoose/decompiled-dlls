﻿using System;

namespace CC
{
	// Token: 0x020001C4 RID: 452
	public interface ICustomizerUI
	{
		// Token: 0x06000CB6 RID: 3254
		void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util parentUI);

		// Token: 0x06000CB7 RID: 3255
		void RefreshUIElement();
	}
}
