﻿using System;

// Token: 0x02000073 RID: 115
public enum EBillType
{
	// Token: 0x0400061A RID: 1562
	None,
	// Token: 0x0400061B RID: 1563
	Rent,
	// Token: 0x0400061C RID: 1564
	Electric,
	// Token: 0x0400061D RID: 1565
	Employee
}
