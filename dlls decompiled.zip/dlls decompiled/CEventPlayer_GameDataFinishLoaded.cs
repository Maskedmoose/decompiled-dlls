﻿using System;

// Token: 0x020000BA RID: 186
public class CEventPlayer_GameDataFinishLoaded : CEvent
{
}
