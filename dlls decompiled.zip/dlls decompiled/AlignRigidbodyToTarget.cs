﻿using System;
using UnityEngine;

// Token: 0x0200014B RID: 331
public class AlignRigidbodyToTarget : MonoBehaviour
{
	// Token: 0x06000956 RID: 2390 RVA: 0x000439FB File Offset: 0x00041BFB
	private void Start()
	{
		this.tr = base.transform;
		this.r = base.GetComponent<Rigidbody>();
		if (this.target == null)
		{
			Debug.LogWarning("No target has been assigned.", this);
			base.enabled = false;
		}
	}

	// Token: 0x06000957 RID: 2391 RVA: 0x00043A38 File Offset: 0x00041C38
	private void FixedUpdate()
	{
		Vector3 forward = this.tr.forward;
		Vector3 normalized = (this.tr.position - this.target.position).normalized;
		Quaternion rot = Quaternion.LookRotation(Quaternion.FromToRotation(this.tr.up, normalized) * forward, normalized);
		this.r.MoveRotation(rot);
	}

	// Token: 0x04001187 RID: 4487
	public Transform target;

	// Token: 0x04001188 RID: 4488
	private Transform tr;

	// Token: 0x04001189 RID: 4489
	private Rigidbody r;
}
