﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Networking;
using UnityEngine.UI;

// Token: 0x02000106 RID: 262
public class LoadStreamTexture : CSingleton<LoadStreamTexture>
{
	// Token: 0x060007AB RID: 1963 RVA: 0x000397E0 File Offset: 0x000379E0
	private void Awake()
	{
		if (LoadStreamTexture.m_Instance == null)
		{
			LoadStreamTexture.m_Instance = this;
		}
		else if (LoadStreamTexture.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x060007AC RID: 1964 RVA: 0x00039818 File Offset: 0x00037A18
	private void Update()
	{
		if (this.m_IsPreloading && !this.m_IsWaitingPreloadCallback && this.m_CurrentPreloadExpansionIndex >= this.m_ExpasionTypeToPreLoadList.Count && this.m_CurrentPreloadExpansionIndex >= this.m_ExpasionTypeToPreLoadList.Count)
		{
			this.m_IsPreloading = false;
			this.m_IsWaitingPreloadCallback = false;
		}
	}

	// Token: 0x060007AD RID: 1965 RVA: 0x00039869 File Offset: 0x00037A69
	private void OnPreloadFinish()
	{
		this.m_CurrentPreloadIndex++;
		this.m_IsWaitingPreloadCallback = false;
	}

	// Token: 0x060007AE RID: 1966 RVA: 0x00039880 File Offset: 0x00037A80
	public static Sprite GetImage(string fileName)
	{
		Sprite sprite = null;
		if (CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteDict.ContainsKey(fileName))
		{
			CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteDict.TryGetValue(fileName, out sprite);
			if (sprite != null)
			{
				CSingleton<LoadStreamTexture>.Instance.m_Image.sprite = sprite;
				return sprite;
			}
		}
		Texture2D texture2D = LoadStreamTexture.LoadPNG(fileName);
		if (texture2D != null)
		{
			sprite = Sprite.Create(texture2D, new Rect(0f, 0f, (float)texture2D.width, (float)texture2D.height), Vector2.zero);
			sprite.name = fileName;
			if (!CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteDict.ContainsKey(fileName))
			{
				CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteList.Add(sprite);
				CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteDict.TryAdd(fileName, sprite);
			}
			else
			{
				CSingleton<LoadStreamTexture>.Instance.m_LoadedSpriteDict[fileName] = sprite;
			}
			return sprite;
		}
		if (!CSingleton<LoadStreamTexture>.Instance.m_CurrentLoadingFileNameList.Contains(fileName))
		{
			CSingleton<LoadStreamTexture>.Instance.m_CurrentLoadingFileNameList.Add(fileName);
			CSingleton<LoadStreamTexture>.Instance.StartCoroutine(CSingleton<LoadStreamTexture>.Instance.LoadTextureFromWeb(fileName));
		}
		return null;
	}

	// Token: 0x060007AF RID: 1967 RVA: 0x00039991 File Offset: 0x00037B91
	private IEnumerator LoadTextureFromWeb(string fileName)
	{
		UnityWebRequest www = UnityWebRequestTexture.GetTexture(this.m_ImageURL + fileName + ".png");
		yield return www.SendWebRequest();
		if (www.result == UnityWebRequest.Result.ConnectionError || www.result == UnityWebRequest.Result.DataProcessingError || www.result == UnityWebRequest.Result.ProtocolError)
		{
			Debug.LogError("Error: " + www.error);
			CSingleton<LoadStreamTexture>.Instance.m_CurrentLoadingFileNameList.Remove(fileName);
			if (this.m_IsPreloading)
			{
				this.OnPreloadFinish();
			}
		}
		else
		{
			Texture2D content = DownloadHandlerTexture.GetContent(www);
			content.ignoreMipmapLimit = true;
			Sprite sprite = Sprite.Create(content, new Rect(0f, 0f, (float)content.width, (float)content.height), Vector2.zero);
			sprite.name = fileName;
			if (!this.m_LoadedSpriteDict.ContainsKey(fileName))
			{
				this.m_LoadedSpriteList.Add(sprite);
				this.m_LoadedSpriteDict.TryAdd(fileName, sprite);
			}
			else
			{
				this.m_LoadedSpriteDict[fileName] = sprite;
			}
			CSingleton<LoadStreamTexture>.Instance.m_Image.sprite = sprite;
			this.WriteImageOnDisk(content, fileName);
			CSingleton<LoadStreamTexture>.Instance.m_CurrentLoadingFileNameList.Remove(fileName);
			if (this.m_IsPreloading)
			{
				this.OnPreloadFinish();
			}
		}
		yield break;
	}

	// Token: 0x060007B0 RID: 1968 RVA: 0x000399A8 File Offset: 0x00037BA8
	private void WriteImageOnDisk(Texture2D texture, string fileName)
	{
		byte[] bytes = texture.EncodeToPNG();
		File.WriteAllBytes(Application.persistentDataPath + "/" + fileName + ".png", bytes);
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x000399D8 File Offset: 0x00037BD8
	private static Texture2D LoadPNG(string fileName)
	{
		string path = Application.persistentDataPath + "/" + fileName + ".png";
		if (File.Exists(path))
		{
			byte[] data = File.ReadAllBytes(path);
			Texture2D texture2D = new Texture2D(2, 2, DefaultFormat.LDR, TextureCreationFlags.None);
			texture2D.LoadImage(data);
			return texture2D;
		}
		return null;
	}

	// Token: 0x060007B2 RID: 1970 RVA: 0x00039A1D File Offset: 0x00037C1D
	private void OnEnable()
	{
		if (!Application.isPlaying)
		{
			bool isMobilePlatform = Application.isMobilePlatform;
		}
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x00039A2C File Offset: 0x00037C2C
	private void OnDisable()
	{
		if (!Application.isPlaying)
		{
			bool isMobilePlatform = Application.isMobilePlatform;
		}
	}

	// Token: 0x04000EE3 RID: 3811
	public static LoadStreamTexture m_Instance;

	// Token: 0x04000EE4 RID: 3812
	public Sprite m_LoadingSprite;

	// Token: 0x04000EE5 RID: 3813
	public List<Sprite> m_LoadedSpriteList;

	// Token: 0x04000EE6 RID: 3814
	private Dictionary<string, Sprite> m_LoadedSpriteDict = new Dictionary<string, Sprite>();

	// Token: 0x04000EE7 RID: 3815
	public string m_ImageURL = "https://www.opneon.com/streamTexture/";

	// Token: 0x04000EE8 RID: 3816
	public Image m_Image;

	// Token: 0x04000EE9 RID: 3817
	public List<string> m_CurrentLoadingFileNameList = new List<string>();

	// Token: 0x04000EEA RID: 3818
	public bool m_IsPreloading;

	// Token: 0x04000EEB RID: 3819
	public bool m_IsWaitingPreloadCallback;

	// Token: 0x04000EEC RID: 3820
	public int m_CurrentPreloadExpansionIndex;

	// Token: 0x04000EED RID: 3821
	public int m_CurrentPreloadIndex;

	// Token: 0x04000EEE RID: 3822
	public List<ECardExpansionType> m_ExpasionTypeToPreLoadList;
}
