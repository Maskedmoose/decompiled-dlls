﻿using System;
using UnityEngine;

// Token: 0x0200001F RID: 31
public class InteractableCustomerCash : InteractableObject
{
	// Token: 0x0600017C RID: 380 RVA: 0x000120E5 File Offset: 0x000102E5
	public void Init(Customer customer)
	{
		this.m_CurrentCustomer = customer;
	}

	// Token: 0x0600017D RID: 381 RVA: 0x000120F0 File Offset: 0x000102F0
	public void SetIsCard(bool isCard)
	{
		this.m_IsCard = isCard;
		this.m_CashModel.SetActive(!this.m_IsCard);
		this.m_CardModel.SetActive(this.m_IsCard);
		this.m_CashOutlineModel.SetActive(!this.m_IsCard);
		this.m_CardOutlineModel.SetActive(this.m_IsCard);
		if (!this.m_IsCard && this.m_CurrentCurrencyType != CSingleton<CGameManager>.Instance.m_CurrencyType)
		{
			this.m_CurrentCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
			this.m_CashMeshRender.material = InventoryBase.GetCurrencyMaterial(this.m_CurrentCurrencyType);
		}
	}

	// Token: 0x0600017E RID: 382 RVA: 0x0001218E File Offset: 0x0001038E
	public override void OnMouseButtonUp()
	{
		this.m_CurrentCustomer.OnCashTaken(this.m_IsCard);
	}

	// Token: 0x0600017F RID: 383 RVA: 0x000121A1 File Offset: 0x000103A1
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000180 RID: 384 RVA: 0x000121C2 File Offset: 0x000103C2
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000181 RID: 385 RVA: 0x000121E3 File Offset: 0x000103E3
	protected void OnMoneyCurrencyUpdated(CEventPlayer_OnMoneyCurrencyUpdated evt)
	{
		if (!this.m_IsCard)
		{
			this.SetIsCard(false);
		}
	}

	// Token: 0x040001F4 RID: 500
	public bool m_IsCard;

	// Token: 0x040001F5 RID: 501
	public GameObject m_CashModel;

	// Token: 0x040001F6 RID: 502
	public GameObject m_CardModel;

	// Token: 0x040001F7 RID: 503
	public GameObject m_CashOutlineModel;

	// Token: 0x040001F8 RID: 504
	public GameObject m_CardOutlineModel;

	// Token: 0x040001F9 RID: 505
	public MeshRenderer m_CashMeshRender;

	// Token: 0x040001FA RID: 506
	private Customer m_CurrentCustomer;

	// Token: 0x040001FB RID: 507
	private EMoneyCurrencyType m_CurrentCurrencyType;
}
