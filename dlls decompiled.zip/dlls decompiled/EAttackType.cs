﻿using System;

// Token: 0x020000EF RID: 239
public enum EAttackType
{
	// Token: 0x04000D4D RID: 3405
	None,
	// Token: 0x04000D4E RID: 3406
	Special,
	// Token: 0x04000D4F RID: 3407
	Magic,
	// Token: 0x04000D50 RID: 3408
	Skill
}
