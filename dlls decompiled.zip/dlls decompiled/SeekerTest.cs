﻿using System;
using Pathfinding;
using UnityEngine;

// Token: 0x0200009D RID: 157
public class SeekerTest : MonoBehaviour
{
	// Token: 0x06000626 RID: 1574 RVA: 0x0003229E File Offset: 0x0003049E
	public void Start()
	{
		this.seeker = base.GetComponent<Seeker>();
		this.seeker.StartPath(base.transform.position, this.targetPosition.position, new OnPathDelegate(this.OnPathComplete));
	}

	// Token: 0x06000627 RID: 1575 RVA: 0x000322DC File Offset: 0x000304DC
	public void OnPathComplete(Path p)
	{
		Debug.Log("A path was calculated. Did it fail with an error? " + p.error.ToString());
		p.Claim(this);
		if (!p.error)
		{
			if (this.path != null)
			{
				this.path.Release(this, false);
			}
			this.path = p;
			this.currentWaypoint = 0;
			return;
		}
		p.Release(this, false);
	}

	// Token: 0x06000628 RID: 1576 RVA: 0x00032344 File Offset: 0x00030544
	public void Update()
	{
		if (Time.time > this.lastRepath + this.repathRate && this.seeker.IsDone())
		{
			this.lastRepath = Time.time;
			this.seeker.StartPath(base.transform.position, this.targetPosition.position, new OnPathDelegate(this.OnPathComplete));
		}
		if (this.path == null)
		{
			return;
		}
		this.reachedEndOfPath = false;
		float num;
		for (;;)
		{
			num = Vector3.Distance(base.transform.position, this.path.vectorPath[this.currentWaypoint]);
			if (num >= this.nextWaypointDistance)
			{
				goto IL_CB;
			}
			if (this.currentWaypoint + 1 >= this.path.vectorPath.Count)
			{
				break;
			}
			this.currentWaypoint++;
		}
		this.reachedEndOfPath = true;
		IL_CB:
		float d = this.reachedEndOfPath ? Mathf.Sqrt(num / this.nextWaypointDistance) : 1f;
		(this.path.vectorPath[this.currentWaypoint] - base.transform.position).normalized * this.speed * d;
		base.transform.position = Vector3.MoveTowards(base.transform.position, this.path.vectorPath[this.currentWaypoint], this.speed);
	}

	// Token: 0x040007EE RID: 2030
	public Transform targetPosition;

	// Token: 0x040007EF RID: 2031
	private Seeker seeker;

	// Token: 0x040007F0 RID: 2032
	public Path path;

	// Token: 0x040007F1 RID: 2033
	public float speed = 2f;

	// Token: 0x040007F2 RID: 2034
	public float nextWaypointDistance = 3f;

	// Token: 0x040007F3 RID: 2035
	private int currentWaypoint;

	// Token: 0x040007F4 RID: 2036
	public float repathRate = 0.5f;

	// Token: 0x040007F5 RID: 2037
	private float lastRepath = float.NegativeInfinity;

	// Token: 0x040007F6 RID: 2038
	public bool reachedEndOfPath;
}
