﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001CD RID: 461
	public class Tab_Manager : MonoBehaviour
	{
		// Token: 0x06000CE9 RID: 3305 RVA: 0x00059678 File Offset: 0x00057878
		private void Start()
		{
			for (int i = 0; i < base.transform.childCount; i++)
			{
				GameObject gameObject = base.transform.GetChild(i).gameObject;
				int index = i;
				this.tabs.Add(gameObject);
				gameObject.GetComponentInChildren<Button>().onClick.AddListener(delegate()
				{
					this.switchTab(index);
				});
			}
			foreach (object obj in this.TabParent.transform)
			{
				Transform transform = (Transform)obj;
				this.tabMenus.Add(transform.gameObject);
			}
			this.switchTab(0);
		}

		// Token: 0x06000CEA RID: 3306 RVA: 0x00059750 File Offset: 0x00057950
		public void switchTab(int tab)
		{
			for (int i = 0; i < this.tabs.Count; i++)
			{
				this.tabs[i].GetComponentInChildren<Button>().colors = ((tab == i) ? this.TabColorActive : this.TabColorInactive);
				if (this.tabMenus.Count > i)
				{
					this.tabMenus[i].SetActive(tab == i);
				}
			}
		}

		// Token: 0x040013CE RID: 5070
		[Header("Button Active Colors")]
		public ColorBlock TabColorActive;

		// Token: 0x040013CF RID: 5071
		[Header("Button Inactive Colors")]
		public ColorBlock TabColorInactive;

		// Token: 0x040013D0 RID: 5072
		public GameObject TabParent;

		// Token: 0x040013D1 RID: 5073
		private List<GameObject> tabs = new List<GameObject>();

		// Token: 0x040013D2 RID: 5074
		private List<GameObject> tabMenus = new List<GameObject>();
	}
}
