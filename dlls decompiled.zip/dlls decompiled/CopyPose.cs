﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B5 RID: 437
	public class CopyPose : MonoBehaviour
	{
		// Token: 0x06000C79 RID: 3193 RVA: 0x00057484 File Offset: 0x00055684
		private void Start()
		{
			this.sourceRoot = base.transform.parent.GetComponentInChildren<SkinnedMeshRenderer>().rootBone;
			this.targetRoot = this.getRootBone(base.transform.GetComponentInChildren<SkinnedMeshRenderer>().rootBone);
			Transform[] componentsInChildren = this.targetRoot.GetComponentsInChildren<Transform>();
			Transform[] componentsInChildren2 = this.sourceRoot.GetComponentsInChildren<Transform>();
			for (int i = 0; i < componentsInChildren2.Length; i++)
			{
				Transform sourceBone = componentsInChildren2[i];
				Transform transform = componentsInChildren.FirstOrDefault((Transform t) => t.name == sourceBone.name);
				if (transform != null)
				{
					this.sourceBones.Add(sourceBone);
					this.targetBones.Add(transform);
				}
			}
		}

		// Token: 0x06000C7A RID: 3194 RVA: 0x00057539 File Offset: 0x00055739
		private Transform getRootBone(Transform bone)
		{
			if (bone.parent == null || bone.parent == base.gameObject.transform)
			{
				return bone;
			}
			return this.getRootBone(bone.parent);
		}

		// Token: 0x06000C7B RID: 3195 RVA: 0x00057570 File Offset: 0x00055770
		private void LateUpdate()
		{
			for (int i = 0; i < this.sourceBones.Count; i++)
			{
				this.targetBones[i].localPosition = this.sourceBones[i].localPosition;
				this.targetBones[i].localRotation = this.sourceBones[i].localRotation;
				this.targetBones[i].localScale = this.sourceBones[i].localScale;
			}
		}

		// Token: 0x04001355 RID: 4949
		private Transform sourceRoot;

		// Token: 0x04001356 RID: 4950
		private Transform targetRoot;

		// Token: 0x04001357 RID: 4951
		private List<Transform> sourceBones = new List<Transform>();

		// Token: 0x04001358 RID: 4952
		private List<Transform> targetBones = new List<Transform>();
	}
}
