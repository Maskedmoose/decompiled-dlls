﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B9 RID: 441
	public class TransformBone : MonoBehaviour
	{
		// Token: 0x06000C84 RID: 3204 RVA: 0x000577EC File Offset: 0x000559EC
		public void SetOffset(FootOffset footOffset)
		{
			float num;
			switch (this.Mode)
			{
			case TransformBone.mode.Height:
				num = footOffset.HeightOffset;
				break;
			case TransformBone.mode.FootRotation:
				num = footOffset.FootRotation;
				break;
			case TransformBone.mode.BallRotation:
				num = footOffset.BallRotation;
				break;
			default:
				num = 0f;
				break;
			}
			switch (this.Axis)
			{
			case TransformBone.axis.X:
				this.offset = new Vector3(num, 0f, 0f);
				return;
			case TransformBone.axis.Y:
				this.offset = new Vector3(0f, num, 0f);
				return;
			case TransformBone.axis.Z:
				this.offset = new Vector3(0f, 0f, num);
				return;
			default:
				return;
			}
		}

		// Token: 0x06000C85 RID: 3205 RVA: 0x00057894 File Offset: 0x00055A94
		private void LateUpdate()
		{
			switch (this.Mode)
			{
			case TransformBone.mode.Height:
				base.transform.position = base.transform.position + this.offset / 100f;
				return;
			case TransformBone.mode.FootRotation:
				base.transform.eulerAngles = base.transform.eulerAngles + this.offset;
				return;
			case TransformBone.mode.BallRotation:
				base.transform.eulerAngles = base.transform.eulerAngles + this.offset;
				return;
			default:
				return;
			}
		}

		// Token: 0x04001363 RID: 4963
		public Vector3 offset = new Vector3(0f, 0f, 0f);

		// Token: 0x04001364 RID: 4964
		public TransformBone.axis Axis;

		// Token: 0x04001365 RID: 4965
		public TransformBone.mode Mode;

		// Token: 0x0200026B RID: 619
		public enum mode
		{
			// Token: 0x0400165F RID: 5727
			Height,
			// Token: 0x04001660 RID: 5728
			FootRotation,
			// Token: 0x04001661 RID: 5729
			BallRotation
		}

		// Token: 0x0200026C RID: 620
		public enum axis
		{
			// Token: 0x04001663 RID: 5731
			X,
			// Token: 0x04001664 RID: 5732
			Y,
			// Token: 0x04001665 RID: 5733
			Z
		}
	}
}
