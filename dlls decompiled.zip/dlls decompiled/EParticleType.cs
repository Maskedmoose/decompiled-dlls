﻿using System;

// Token: 0x02000097 RID: 151
public enum EParticleType
{
	// Token: 0x040007BC RID: 1980
	ArenaRankUpFirework,
	// Token: 0x040007BD RID: 1981
	StarStream
}
