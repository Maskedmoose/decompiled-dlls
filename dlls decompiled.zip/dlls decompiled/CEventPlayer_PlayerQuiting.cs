﻿using System;

// Token: 0x020000A9 RID: 169
public class CEventPlayer_PlayerQuiting : CEvent
{
}
