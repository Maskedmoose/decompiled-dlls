﻿using System;
using I2.Loc;
using UnityEngine;

// Token: 0x02000131 RID: 305
[Serializable]
public class FurniturePurchaseData
{
	// Token: 0x060008E4 RID: 2276 RVA: 0x00041252 File Offset: 0x0003F452
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true);
	}

	// Token: 0x060008E5 RID: 2277 RVA: 0x00041266 File Offset: 0x0003F466
	public string GetDescription()
	{
		return LocalizationManager.GetTranslation(this.description, true, 0, true, false, null, null, true);
	}

	// Token: 0x040010D7 RID: 4311
	public string name;

	// Token: 0x040010D8 RID: 4312
	public string description;

	// Token: 0x040010D9 RID: 4313
	public int levelRequirement;

	// Token: 0x040010DA RID: 4314
	public float price;

	// Token: 0x040010DB RID: 4315
	public EObjectType objectType;

	// Token: 0x040010DC RID: 4316
	public Sprite icon;
}
