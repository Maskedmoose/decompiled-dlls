﻿using System;

// Token: 0x020000F1 RID: 241
public enum EDamageType
{
	// Token: 0x04000D58 RID: 3416
	None,
	// Token: 0x04000D59 RID: 3417
	Damage,
	// Token: 0x04000D5A RID: 3418
	Buff,
	// Token: 0x04000D5B RID: 3419
	Heal,
	// Token: 0x04000D5C RID: 3420
	Charge,
	// Token: 0x04000D5D RID: 3421
	Barrier
}
