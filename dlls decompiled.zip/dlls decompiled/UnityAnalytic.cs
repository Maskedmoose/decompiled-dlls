﻿using System;
using Unity.Services.Analytics;
using UnityEngine;

// Token: 0x02000109 RID: 265
public class UnityAnalytic : CSingleton<UnityAnalytic>
{
	// Token: 0x060007BD RID: 1981 RVA: 0x00039BE3 File Offset: 0x00037DE3
	private void Awake()
	{
		if (UnityAnalytic.m_Instance == null)
		{
			UnityAnalytic.m_Instance = this;
		}
		else if (UnityAnalytic.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x060007BE RID: 1982 RVA: 0x00039C18 File Offset: 0x00037E18
	private void StartCollection()
	{
		if (!this.m_HasStart)
		{
			this.m_HasStart = true;
		}
	}

	// Token: 0x060007BF RID: 1983 RVA: 0x00039C2C File Offset: 0x00037E2C
	public static void StartTutorial(int index)
	{
	}

	// Token: 0x060007C0 RID: 1984 RVA: 0x00039C39 File Offset: 0x00037E39
	public static void SetUserSegmentIndex(int index)
	{
	}

	// Token: 0x060007C1 RID: 1985 RVA: 0x00039C3C File Offset: 0x00037E3C
	public static void JoinDiscord()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("JoinDiscord");
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007C2 RID: 1986 RVA: 0x00039C74 File Offset: 0x00037E74
	public static void PressFeedback(int index)
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("PressFeedback")
		{
			{
				"Index",
				index
			}
		};
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007C3 RID: 1987 RVA: 0x00039CBC File Offset: 0x00037EBC
	public static void PressWishlist(int index)
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("PressWishlist")
		{
			{
				"Index",
				index
			}
		};
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007C4 RID: 1988 RVA: 0x00039D04 File Offset: 0x00037F04
	public static void PressLoadGame()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("PressLoadGame");
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007C5 RID: 1989 RVA: 0x00039D3C File Offset: 0x00037F3C
	public static void PressOverwriteSave()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("PressOverwriteSave");
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007C6 RID: 1990 RVA: 0x00039D74 File Offset: 0x00037F74
	public static void GoNextDay(int index)
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("GoNextDay")
		{
			{
				"Day",
				index
			}
		};
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007C7 RID: 1991 RVA: 0x00039DBC File Offset: 0x00037FBC
	public static void ShopLevelUp(int index)
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("ShopLevelUp")
		{
			{
				"Level",
				index
			}
		};
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007C8 RID: 1992 RVA: 0x00039E04 File Offset: 0x00038004
	public static void UnlockNewRoom(int index)
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("UnlockNewRoom")
		{
			{
				"roomUnlocked",
				index
			}
		};
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007C9 RID: 1993 RVA: 0x00039E4C File Offset: 0x0003804C
	public static void OpenPack()
	{
	}

	// Token: 0x060007CA RID: 1994 RVA: 0x00039E5C File Offset: 0x0003805C
	public static void OpenAlbum()
	{
	}

	// Token: 0x060007CB RID: 1995 RVA: 0x00039E6C File Offset: 0x0003806C
	public static void OpenPhone()
	{
	}

	// Token: 0x060007CC RID: 1996 RVA: 0x00039E7C File Offset: 0x0003807C
	public static void PhoneRestock()
	{
	}

	// Token: 0x060007CD RID: 1997 RVA: 0x00039E8C File Offset: 0x0003808C
	public static void PhoneBuyShelf()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("PhoneBuyShelf");
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007CE RID: 1998 RVA: 0x00039EC4 File Offset: 0x000380C4
	public static void PhoneShopExpansion()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("PhoneShopExpansion");
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007CF RID: 1999 RVA: 0x00039EFC File Offset: 0x000380FC
	public static void PhoneManageEvent()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("PhoneManageEvent");
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007D0 RID: 2000 RVA: 0x00039F34 File Offset: 0x00038134
	public static void PhoneHireWorker()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("PhoneHireWorker");
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x060007D1 RID: 2001 RVA: 0x00039F6C File Offset: 0x0003816C
	public static void PhoneCheckPrice()
	{
		if (!UnityAnalytic.m_CanUseAnalytic)
		{
			return;
		}
		CSingleton<UnityAnalytic>.Instance.StartCollection();
		CustomEvent e = new CustomEvent("PhoneCheckPrice");
		AnalyticsService.Instance.RecordEvent(e);
	}

	// Token: 0x04000EF8 RID: 3832
	public static UnityAnalytic m_Instance;

	// Token: 0x04000EF9 RID: 3833
	private static bool m_CanUseAnalytic;

	// Token: 0x04000EFA RID: 3834
	private bool m_HasStart;
}
