﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x02000071 RID: 113
public class RentBillPanelUI : MonoBehaviour
{
	// Token: 0x060004AA RID: 1194 RVA: 0x0002880A File Offset: 0x00026A0A
	public void Init(RentBillScreen rentBillScreen, EBillType billType)
	{
		this.m_RentBillScreen = rentBillScreen;
		this.m_BillType = billType;
	}

	// Token: 0x060004AB RID: 1195 RVA: 0x0002881C File Offset: 0x00026A1C
	public void EvaluateUI()
	{
		BillData bill = CPlayerData.GetBill(this.m_BillType);
		if (bill == null)
		{
			this.m_DueDay = 0;
			this.m_AmountDue = 0f;
			this.m_BillDayPassed = 0;
		}
		else
		{
			this.m_DueDay = this.m_RentBillScreen.GetDueDayMax() - bill.billDayPassed;
			this.m_AmountDue = bill.amountToPay;
			this.m_BillDayPassed = bill.billDayPassed;
		}
		if (this.m_AmountDue <= 0f && this.m_BillDayPassed == 0)
		{
			this.m_DayDueText.text = "";
			this.m_AmountDueText.text = "";
			this.m_LockBtnGrp.SetActive(true);
			this.m_LatePaymentText.enabled = false;
			this.m_DayDueText.color = this.m_RentBillScreen.m_NormalDayColor;
			this.m_TickIcon.gameObject.SetActive(true);
			return;
		}
		if (this.m_AmountDue > 0f)
		{
			this.m_AmountDueText.text = GameInstance.GetPriceString(this.m_AmountDue, false, true, false, "F2");
			this.m_LockBtnGrp.SetActive(false);
			this.m_TickIcon.gameObject.SetActive(false);
			if (this.m_DueDay < 0)
			{
				this.m_DayDueText.color = this.m_RentBillScreen.m_LateDayColor;
				this.m_LatePaymentText.enabled = true;
				int num = Mathf.Abs(this.m_DueDay);
				if (num == 1)
				{
					this.m_DayDueText.text = LocalizationManager.GetTranslation("Late By XXX Day", true, 0, true, false, null, null, true).Replace("XXX", num.ToString());
					return;
				}
				this.m_DayDueText.text = LocalizationManager.GetTranslation("Late By XXX Days", true, 0, true, false, null, null, true).Replace("XXX", num.ToString());
				return;
			}
			else
			{
				if (this.m_DueDay < 3)
				{
					this.m_DayDueText.color = this.m_RentBillScreen.m_WarningDayColor;
				}
				else
				{
					this.m_DayDueText.color = this.m_RentBillScreen.m_NormalDayColor;
				}
				this.m_LatePaymentText.enabled = false;
				if (this.m_DueDay == 1)
				{
					this.m_DayDueText.text = this.m_DueDay.ToString() + " " + LocalizationManager.GetTranslation("Day", true, 0, true, false, null, null, true);
					return;
				}
				if (this.m_DueDay == 0)
				{
					this.m_DayDueText.text = LocalizationManager.GetTranslation("Today", true, 0, true, false, null, null, true);
					return;
				}
				this.m_DayDueText.text = this.m_DueDay.ToString() + " " + LocalizationManager.GetTranslation("Days", true, 0, true, false, null, null, true);
			}
		}
	}

	// Token: 0x060004AC RID: 1196 RVA: 0x00028AB4 File Offset: 0x00026CB4
	public void OnPressButton()
	{
		if (this.m_BillType == EBillType.Rent)
		{
			this.m_RentBillScreen.OnPressPayRentBill(false);
			return;
		}
		if (this.m_BillType == EBillType.Electric)
		{
			this.m_RentBillScreen.OnPressPayElectricBill(false);
			return;
		}
		if (this.m_BillType == EBillType.Employee)
		{
			this.m_RentBillScreen.OnPressPaySalaryBill(false);
		}
	}

	// Token: 0x0400060C RID: 1548
	public TextMeshProUGUI m_DayDueText;

	// Token: 0x0400060D RID: 1549
	public TextMeshProUGUI m_AmountDueText;

	// Token: 0x0400060E RID: 1550
	public TextMeshProUGUI m_LatePaymentText;

	// Token: 0x0400060F RID: 1551
	public GameObject m_LockBtnGrp;

	// Token: 0x04000610 RID: 1552
	public GameObject m_TickIcon;

	// Token: 0x04000611 RID: 1553
	private EBillType m_BillType;

	// Token: 0x04000612 RID: 1554
	private RentBillScreen m_RentBillScreen;

	// Token: 0x04000613 RID: 1555
	private int m_DueDay;

	// Token: 0x04000614 RID: 1556
	private int m_BillDayPassed;

	// Token: 0x04000615 RID: 1557
	private float m_AmountDue;
}
