﻿using System;

// Token: 0x020000B3 RID: 179
public class CEventPlayer_SetShopExp : CEvent
{
	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000708 RID: 1800 RVA: 0x00038077 File Offset: 0x00036277
	// (set) Token: 0x06000709 RID: 1801 RVA: 0x0003807F File Offset: 0x0003627F
	public int m_ExpValue { get; private set; }

	// Token: 0x0600070A RID: 1802 RVA: 0x00038088 File Offset: 0x00036288
	public CEventPlayer_SetShopExp(int ExpValue)
	{
		this.m_ExpValue = ExpValue;
	}
}
