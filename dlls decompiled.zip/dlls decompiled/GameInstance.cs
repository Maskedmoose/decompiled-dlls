﻿using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

// Token: 0x020000A5 RID: 165
public class GameInstance : CSingleton<GameInstance>
{
	// Token: 0x060006A3 RID: 1699 RVA: 0x00036DA8 File Offset: 0x00034FA8
	public void Start()
	{
		if (GameInstance.m_Instance == null)
		{
			GameInstance.m_Instance = this;
		}
		else if (GameInstance.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x060006A4 RID: 1700 RVA: 0x00036DE0 File Offset: 0x00034FE0
	public static float GetInvariantCultureDecimal(string text)
	{
		string text2 = text.Replace(",", ".");
		List<int> list = new List<int>();
		int num = 0;
		string text3 = text2;
		for (int i = 0; i < text3.Length; i++)
		{
			if (text3[i] == '.')
			{
				list.Add(num);
			}
			num++;
		}
		if (list.Count > 1)
		{
			for (int j = list.Count - 2; j >= 0; j--)
			{
				text2 = text2.Remove(list[j], 1);
			}
		}
		float result;
		try
		{
			result = float.Parse(text2, CultureInfo.InvariantCulture);
		}
		catch
		{
			result = 0f;
		}
		return result;
	}

	// Token: 0x060006A5 RID: 1701 RVA: 0x00036E90 File Offset: 0x00035090
	public static string GetPriceString(float price, bool useDashAsZero = false, bool useCurrencySymbol = true, bool useCentSymbol = false, string decimalString = "F2")
	{
		if (price <= 0f && useDashAsZero)
		{
			return "-";
		}
		if (GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price) < 1f)
		{
			decimalString = "F2";
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Euro)
		{
			if (!useCurrencySymbol)
			{
				return GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
			}
			if (useCentSymbol && price < 1f)
			{
				return (GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price) * 100f).ToString("F0") + "¢";
			}
			return "€" + GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
		}
		else if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			if (decimalString == "F2" || decimalString == "N2")
			{
				decimalString = "N0";
			}
			if (useCurrencySymbol)
			{
				return "¥" + Mathf.RoundToInt(GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price)).ToString(decimalString);
			}
			return Mathf.RoundToInt(GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price)).ToString(decimalString);
		}
		else if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.GBP)
		{
			if (!useCurrencySymbol)
			{
				return GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
			}
			if (useCentSymbol && price < 1f)
			{
				return (GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price) * 100f).ToString("F0") + "p";
			}
			return "£" + GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
		}
		else if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.CNY)
		{
			if (useCurrencySymbol)
			{
				return "¥" + GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
			}
			return GameInstance.GetCurrencyValue(CSingleton<CGameManager>.Instance.m_CurrencyType, price).ToString(decimalString);
		}
		else
		{
			if (!useCurrencySymbol)
			{
				return price.ToString(decimalString);
			}
			if (useCentSymbol && price < 1f)
			{
				return (price * 100f).ToString("F0") + "¢";
			}
			return "$" + price.ToString(decimalString);
		}
	}

	// Token: 0x060006A6 RID: 1702 RVA: 0x000370F9 File Offset: 0x000352F9
	public static float GetConvertedCurrencyPrice(float price)
	{
		return (float)Mathf.RoundToInt(price * GameInstance.GetCurrencyConversionRate() * 100f) / 100f;
	}

	// Token: 0x060006A7 RID: 1703 RVA: 0x00037114 File Offset: 0x00035314
	public static float GetCurrencyConversionRate()
	{
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Euro)
		{
			return 1f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			return 100f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.GBP)
		{
			return 1f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.CNY)
		{
			return 2.5f;
		}
		return 1f;
	}

	// Token: 0x060006A8 RID: 1704 RVA: 0x00037172 File Offset: 0x00035372
	public static float GetCurrencyRoundDivideAmount()
	{
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.CNY)
		{
			return 1000f;
		}
		return 100f;
	}

	// Token: 0x060006A9 RID: 1705 RVA: 0x0003718C File Offset: 0x0003538C
	public static float GetCurrencyValue(EMoneyCurrencyType currencyType, float baseValue)
	{
		return baseValue * GameInstance.GetCurrencyConversionRate();
	}

	// Token: 0x060006AA RID: 1706 RVA: 0x00037195 File Offset: 0x00035395
	public static bool GetCurrencyHasDecimal(EMoneyCurrencyType currencyType)
	{
		return currencyType != EMoneyCurrencyType.Yen;
	}

	// Token: 0x060006AB RID: 1707 RVA: 0x000371A0 File Offset: 0x000353A0
	public static string GetTimeString(float time, bool showDay = true, bool showHour = true, bool showMinutes = true, bool showSeconds = true, bool removeZero = false, bool convertDayToHour = false)
	{
		if (time < 0f)
		{
			time = 0f;
		}
		GameInstance.m_Day = (int)time / 86400;
		GameInstance.m_Hour = (int)time / 3600;
		if (!convertDayToHour)
		{
			GameInstance.m_Hour = (int)time % 86400 / 3600;
		}
		GameInstance.m_Minute = (int)time % 3600 / 60;
		GameInstance.m_Second = (int)time % 60;
		if (GameInstance.m_Day == 0)
		{
			showDay = false;
		}
		if (GameInstance.m_Hour == 0)
		{
			showHour = false;
		}
		if (GameInstance.m_Minute == 0)
		{
			showMinutes = false;
		}
		if (GameInstance.m_Second == 0)
		{
			showSeconds = false;
		}
		GameInstance.m_TimeString = "";
		if (showDay)
		{
			GameInstance.m_TimeString = GameInstance.m_Day.ToString() + GameInstance.m_DayTranslatedText;
			if (showMinutes || showSeconds)
			{
				showHour = true;
			}
		}
		if (showHour)
		{
			if (GameInstance.m_TimeString != "")
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + " " + GameInstance.m_Hour.ToString() + GameInstance.m_HourTranslatedText;
			}
			else
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + GameInstance.m_Hour.ToString() + GameInstance.m_HourTranslatedText;
			}
			if (showSeconds)
			{
				showMinutes = true;
			}
		}
		if (showDay && showHour && removeZero)
		{
			if (GameInstance.m_Minute == 0)
			{
				showMinutes = false;
				showSeconds = false;
			}
			else
			{
				showMinutes = true;
			}
		}
		if (showMinutes)
		{
			if (GameInstance.m_TimeString != "")
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + " " + GameInstance.m_Minute.ToString() + GameInstance.m_MinTranslatedText;
			}
			else
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + GameInstance.m_Minute.ToString() + GameInstance.m_MinTranslatedText;
			}
		}
		if (!showDay && !showHour && !showMinutes)
		{
			showSeconds = true;
		}
		if (!showDay && !showHour)
		{
			showSeconds = true;
		}
		if (removeZero && GameInstance.m_Second == 0)
		{
			showSeconds = false;
		}
		if (showSeconds)
		{
			if (GameInstance.m_TimeString != "")
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + " " + GameInstance.m_Second.ToString() + GameInstance.m_SecondTranslatedText;
			}
			else
			{
				GameInstance.m_TimeString = GameInstance.m_TimeString + GameInstance.m_Second.ToString() + GameInstance.m_SecondTranslatedText;
			}
		}
		return GameInstance.m_TimeString;
	}

	// Token: 0x060006AC RID: 1708 RVA: 0x000373AE File Offset: 0x000355AE
	public static int GetDigit(float value, int digit)
	{
		return (int)(value / Mathf.Pow(10f, (float)(digit - 1))) % 10;
	}

	// Token: 0x060006AD RID: 1709 RVA: 0x000373C5 File Offset: 0x000355C5
	public static int GetDecimal(float value, int digit)
	{
		return GameInstance.GetDigit((float)Mathf.FloorToInt(value * Mathf.Pow(10f, (float)digit)), digit);
	}

	// Token: 0x060006AE RID: 1710 RVA: 0x000373E4 File Offset: 0x000355E4
	public static void SetIsSaveDataDirtySyncToCloud(bool isDirty, int priorityPoint = 1, float upgradeTime = 0f)
	{
		if (GameInstance.m_IsSaveDataDirtySyncToCloud != isDirty)
		{
			GameInstance.m_IsSaveDataDirtySyncToCloud = isDirty;
		}
		if (isDirty)
		{
			GameInstance.m_SaveDataDirtySyncToCloudCount += priorityPoint + Mathf.FloorToInt(upgradeTime / 1800f);
			if (GameInstance.m_SaveDataDirtySyncToCloudCount > 2 && CGameManager.m_ForceSyncCloudResetTimer > 6f)
			{
				CGameManager.m_ForceSyncCloudResetTimer = 0f;
				GameInstance.m_SaveDataDirtySyncToCloudCount = 0;
				CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
				CSingleton<CGameManager>.Instance.SaveGameData(false, false);
				return;
			}
		}
		else
		{
			GameInstance.m_SaveDataDirtySyncToCloudCount = 0;
			CGameManager.m_ForceSyncCloudResetTimer = 0f;
		}
	}

	// Token: 0x040008D8 RID: 2264
	public static GameInstance m_Instance = null;

	// Token: 0x040008D9 RID: 2265
	public static bool m_HasFinishHideLoadingScreen = false;

	// Token: 0x040008DA RID: 2266
	public static bool m_IsRestartingGameDeleteAll = false;

	// Token: 0x040008DB RID: 2267
	public static bool m_HasLoadingError = false;

	// Token: 0x040008DC RID: 2268
	public static bool m_IsSaveDataDirtySyncToCloud = false;

	// Token: 0x040008DD RID: 2269
	public static bool m_SaveFileNotFound = false;

	// Token: 0x040008DE RID: 2270
	public static bool m_LoadingDifferentAccount = false;

	// Token: 0x040008DF RID: 2271
	public static bool m_StopCoinGemTextLerp = false;

	// Token: 0x040008E0 RID: 2272
	public static bool m_CanDragMainMenuSlider = false;

	// Token: 0x040008E1 RID: 2273
	public static bool m_FinishedSavefileLoading = false;

	// Token: 0x040008E2 RID: 2274
	public static int m_SaveDataDirtySyncToCloudCount = 0;

	// Token: 0x040008E3 RID: 2275
	public static int m_CurrentSceneIndex = 0;

	// Token: 0x040008E4 RID: 2276
	private static string m_DayTranslatedText = "d";

	// Token: 0x040008E5 RID: 2277
	private static string m_HourTranslatedText = "h";

	// Token: 0x040008E6 RID: 2278
	private static string m_MinTranslatedText = "min";

	// Token: 0x040008E7 RID: 2279
	private static string m_SecondTranslatedText = "s";

	// Token: 0x040008E8 RID: 2280
	private static int m_Day = 0;

	// Token: 0x040008E9 RID: 2281
	private static int m_Hour = 0;

	// Token: 0x040008EA RID: 2282
	private static int m_Minute = 0;

	// Token: 0x040008EB RID: 2283
	private static int m_Second = 0;

	// Token: 0x040008EC RID: 2284
	private static string m_TimeString;
}
