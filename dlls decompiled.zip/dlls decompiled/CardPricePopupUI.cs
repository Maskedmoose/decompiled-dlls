﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200000E RID: 14
public class CardPricePopupUI : MonoBehaviour
{
	// Token: 0x06000067 RID: 103 RVA: 0x00006CFD File Offset: 0x00004EFD
	private void Start()
	{
		this.m_TargetLookAt = CSingleton<InteractionPlayerController>.Instance.m_Cam.transform;
		this.HideCardPricePopup();
	}

	// Token: 0x06000068 RID: 104 RVA: 0x00006D1A File Offset: 0x00004F1A
	private void Update()
	{
		if (!this.m_IsActive)
		{
			return;
		}
		this.m_UIGrp.LookAt(this.m_TargetLookAt.position);
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00006D3C File Offset: 0x00004F3C
	public void ShowCardPricePopup(float price, Vector3 targetPos)
	{
		this.m_UIGrp.gameObject.SetActive(false);
		this.m_UIGrp.LookAt(this.m_TargetLookAt.position);
		this.m_UIGrp.gameObject.SetActive(true);
		this.m_PriceText.text = GameInstance.GetPriceString(price, false, true, false, "F2");
		base.transform.position = targetPos;
		this.m_IsActive = true;
		SoundManager.GenericPop(0.7f, 0.8f);
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00006DBC File Offset: 0x00004FBC
	public void HideCardPricePopup()
	{
		this.m_UIGrp.gameObject.SetActive(false);
		this.m_IsActive = false;
	}

	// Token: 0x040000AD RID: 173
	public Transform m_UIGrp;

	// Token: 0x040000AE RID: 174
	public TextMeshProUGUI m_PriceText;

	// Token: 0x040000AF RID: 175
	public Transform m_TargetLookAt;

	// Token: 0x040000B0 RID: 176
	public bool m_IsActive;
}
