﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200000D RID: 13
public class BinderPageGrp : MonoBehaviour
{
	// Token: 0x06000063 RID: 99 RVA: 0x00006B26 File Offset: 0x00004D26
	public void SetVisibility(bool isVisible)
	{
		this.m_Mesh.SetActive(isVisible);
		this.m_Mesh2.SetActive(isVisible);
		this.m_Joint.SetActive(isVisible);
	}

	// Token: 0x06000064 RID: 100 RVA: 0x00006B4C File Offset: 0x00004D4C
	public void SetCard(int index, ECardExpansionType cardExpansionType, bool isDimensionCard)
	{
		if (index <= 0)
		{
			return;
		}
		for (int i = 0; i < this.m_CardList.Count; i++)
		{
			int num = (index - 1) * CPlayerData.GetCardAmountPerMonsterType(cardExpansionType, true) + i;
			int cardAmountByIndex = CPlayerData.GetCardAmountByIndex(num, cardExpansionType, isDimensionCard);
			if (cardAmountByIndex <= 0)
			{
				this.m_CardList[i].SetVisibility(false);
			}
			else
			{
				bool isDestiny = false;
				if (cardExpansionType == ECardExpansionType.Ghost && num >= InventoryBase.GetShownMonsterList(cardExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(cardExpansionType, true))
				{
					isDestiny = true;
					num -= InventoryBase.GetShownMonsterList(cardExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(cardExpansionType, true);
				}
				CardData cardData = new CardData();
				ECardBorderType borderType = (ECardBorderType)(i % CPlayerData.GetCardAmountPerMonsterType(cardExpansionType, false));
				cardData.monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(num, cardExpansionType);
				cardData.borderType = borderType;
				cardData.expansionType = cardExpansionType;
				cardData.isDestiny = isDestiny;
				cardData.isNew = false;
				cardData.isFoil = (i >= CPlayerData.GetCardAmountPerMonsterType(cardExpansionType, false));
				this.m_CardList[i].m_CardUI.SetCardUI(cardData);
				this.m_CardList[i].SetVisibility(true);
				this.m_CardList[i].SetCardCountText(cardAmountByIndex);
				this.m_CardList[i].SetCardCountTextVisibility(true);
			}
		}
	}

	// Token: 0x06000065 RID: 101 RVA: 0x00006C84 File Offset: 0x00004E84
	public void SetSingleCard(int cardIndex, CardData cardData, int cardCount)
	{
		if (cardCount <= 0)
		{
			this.m_CardList[cardIndex].SetVisibility(false);
			return;
		}
		this.m_CardList[cardIndex].m_CardUI.SetCardUI(cardData);
		this.m_CardList[cardIndex].SetVisibility(true);
		this.m_CardList[cardIndex].SetCardCountText(cardCount);
		this.m_CardList[cardIndex].SetCardCountTextVisibility(true);
	}

	// Token: 0x040000A8 RID: 168
	public Animator m_Anim;

	// Token: 0x040000A9 RID: 169
	public GameObject m_Mesh;

	// Token: 0x040000AA RID: 170
	public GameObject m_Mesh2;

	// Token: 0x040000AB RID: 171
	public GameObject m_Joint;

	// Token: 0x040000AC RID: 172
	public List<Card3dUIGroup> m_CardList;
}
