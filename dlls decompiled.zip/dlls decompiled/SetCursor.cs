﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace CC
{
	// Token: 0x020001CC RID: 460
	public class SetCursor : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
	{
		// Token: 0x06000CE6 RID: 3302 RVA: 0x00059650 File Offset: 0x00057850
		public void OnPointerEnter(PointerEventData eventData)
		{
			CameraController.instance.setCursor(this.cursorTexture);
		}

		// Token: 0x06000CE7 RID: 3303 RVA: 0x00059662 File Offset: 0x00057862
		public void OnPointerExit(PointerEventData eventData)
		{
			CameraController.instance.setDefaultCursor();
		}

		// Token: 0x040013CD RID: 5069
		public Texture2D cursorTexture;
	}
}
