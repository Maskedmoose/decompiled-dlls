﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001EF RID: 495
	public class SmoothRotation : MonoBehaviour
	{
		// Token: 0x06000DC2 RID: 3522 RVA: 0x0005DCD7 File Offset: 0x0005BED7
		private void Awake()
		{
			if (this.target == null)
			{
				this.target = base.transform.parent;
			}
			this.tr = base.transform;
			this.currentRotation = base.transform.rotation;
		}

		// Token: 0x06000DC3 RID: 3523 RVA: 0x0005DD15 File Offset: 0x0005BF15
		private void OnEnable()
		{
			this.ResetCurrentRotation();
		}

		// Token: 0x06000DC4 RID: 3524 RVA: 0x0005DD1D File Offset: 0x0005BF1D
		private void Update()
		{
			if (this.updateType == SmoothRotation.UpdateType.LateUpdate)
			{
				return;
			}
			this.SmoothUpdate();
		}

		// Token: 0x06000DC5 RID: 3525 RVA: 0x0005DD2F File Offset: 0x0005BF2F
		private void LateUpdate()
		{
			if (this.updateType == SmoothRotation.UpdateType.Update)
			{
				return;
			}
			this.SmoothUpdate();
		}

		// Token: 0x06000DC6 RID: 3526 RVA: 0x0005DD40 File Offset: 0x0005BF40
		private void SmoothUpdate()
		{
			this.currentRotation = this.Smooth(this.currentRotation, this.target.rotation, this.smoothSpeed);
			this.tr.rotation = this.currentRotation;
		}

		// Token: 0x06000DC7 RID: 3527 RVA: 0x0005DD78 File Offset: 0x0005BF78
		private Quaternion Smooth(Quaternion _currentRotation, Quaternion _targetRotation, float _smoothSpeed)
		{
			if (this.extrapolateRotation && Quaternion.Angle(_currentRotation, _targetRotation) < 90f)
			{
				Quaternion rhs = _targetRotation * Quaternion.Inverse(_currentRotation);
				_targetRotation *= rhs;
			}
			return Quaternion.Slerp(_currentRotation, _targetRotation, Time.deltaTime * _smoothSpeed);
		}

		// Token: 0x06000DC8 RID: 3528 RVA: 0x0005DDBF File Offset: 0x0005BFBF
		public void ResetCurrentRotation()
		{
			this.currentRotation = this.target.rotation;
		}

		// Token: 0x040014BB RID: 5307
		public Transform target;

		// Token: 0x040014BC RID: 5308
		private Transform tr;

		// Token: 0x040014BD RID: 5309
		private Quaternion currentRotation;

		// Token: 0x040014BE RID: 5310
		public float smoothSpeed = 20f;

		// Token: 0x040014BF RID: 5311
		public bool extrapolateRotation;

		// Token: 0x040014C0 RID: 5312
		public SmoothRotation.UpdateType updateType;

		// Token: 0x02000285 RID: 645
		public enum UpdateType
		{
			// Token: 0x040016B0 RID: 5808
			Update,
			// Token: 0x040016B1 RID: 5809
			LateUpdate
		}
	}
}
