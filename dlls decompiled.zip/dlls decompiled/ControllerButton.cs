﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200010A RID: 266
public class ControllerButton : MonoBehaviour
{
	// Token: 0x060007D3 RID: 2003 RVA: 0x00039FAC File Offset: 0x000381AC
	private void Awake()
	{
		if (this.m_ButtonHighlight)
		{
			this.m_ButtonHighlight.SetActive(false);
		}
		for (int i = 0; i < this.m_OverlayButtonHighlight.Count; i++)
		{
			this.m_OverlayButtonHighlight[i].SetActive(false);
		}
	}

	// Token: 0x060007D4 RID: 2004 RVA: 0x00039FFC File Offset: 0x000381FC
	public void OnSelectionActive()
	{
		if (!CSingleton<ControllerScreenUIExtManager>.Instance.m_IsControllerActive)
		{
			return;
		}
		if (!this.m_ButtonHighlight && this.m_OverlayButtonHighlight.Count == 0)
		{
			ControllerScreenUIExtManager.SetControllerSelectorUI(this, this.m_RectTransformOffsetMultiplier, this.m_BtnHighlightSpriteScale);
			return;
		}
		for (int i = 0; i < this.m_OverlayButtonHighlight.Count; i++)
		{
			if (this.m_OverlayButtonHighlight[i].activeInHierarchy)
			{
				return;
			}
		}
		this.m_ButtonHighlight.SetActive(true);
	}

	// Token: 0x060007D5 RID: 2005 RVA: 0x0003A07C File Offset: 0x0003827C
	public void OnSelectionDeactivate()
	{
		if (!this.m_ButtonHighlight && this.m_OverlayButtonHighlight.Count == 0)
		{
			ControllerScreenUIExtManager.SetControllerSelectorUI(null, 1f, 1f);
			return;
		}
		for (int i = 0; i < this.m_OverlayButtonHighlight.Count; i++)
		{
			if (this.m_OverlayButtonHighlight[i].activeInHierarchy)
			{
				this.m_OverlayButtonHighlight[i].SetActive(false);
				return;
			}
		}
		this.m_ButtonHighlight.SetActive(false);
	}

	// Token: 0x060007D6 RID: 2006 RVA: 0x0003A0FC File Offset: 0x000382FC
	public void OnPressConfirm()
	{
		if (this.m_GamepadSettingLinker)
		{
			this.m_GamepadSettingLinker.OnPressConfirm();
			return;
		}
		for (int i = 0; i < this.m_OverlayButton.Count; i++)
		{
			if (this.m_OverlayButton[i].gameObject.activeInHierarchy)
			{
				this.m_OverlayButton[i].onClick.Invoke();
				return;
			}
		}
		if (!this.m_EnableVirtualKeyboard)
		{
			this.m_Button.onClick.Invoke();
			return;
		}
		if (this.m_InitVirtualKeyboardWithInputString)
		{
			ControllerScreenUIExtManager.StartVirtualKeyboard(this.m_VirtualKeyboardInputText.text, this.m_VirtualKeyboardInputText);
			return;
		}
		ControllerScreenUIExtManager.StartVirtualKeyboard("", this.m_VirtualKeyboardInputText);
	}

	// Token: 0x060007D7 RID: 2007 RVA: 0x0003A1B0 File Offset: 0x000383B0
	public bool OnPressCancel()
	{
		if (this.m_GamepadSettingLinker && InputManager.IsSliderActive())
		{
			this.m_GamepadSettingLinker.OnPressCancel();
			return true;
		}
		return false;
	}

	// Token: 0x060007D8 RID: 2008 RVA: 0x0003A1E0 File Offset: 0x000383E0
	public bool IsActive()
	{
		if (this.m_GamepadSettingLinker)
		{
			return base.gameObject.activeInHierarchy;
		}
		for (int i = 0; i < this.m_OverlayButton.Count; i++)
		{
			if (this.m_OverlayButton[i].gameObject.activeInHierarchy)
			{
				return true;
			}
		}
		if (this.m_EnableVirtualKeyboard)
		{
			return base.gameObject.activeInHierarchy;
		}
		return this.m_Button.gameObject.activeInHierarchy;
	}

	// Token: 0x04000EFB RID: 3835
	public bool m_CanScrollerSlide = true;

	// Token: 0x04000EFC RID: 3836
	public Button m_Button;

	// Token: 0x04000EFD RID: 3837
	public ControllerSelectorUIGrp m_ButtonHighlight;

	// Token: 0x04000EFE RID: 3838
	public float m_RectTransformOffsetMultiplier = 1f;

	// Token: 0x04000EFF RID: 3839
	public float m_BtnHighlightSpriteScale = 1f;

	// Token: 0x04000F00 RID: 3840
	public List<Button> m_OverlayButton;

	// Token: 0x04000F01 RID: 3841
	public List<GameObject> m_OverlayButtonHighlight;

	// Token: 0x04000F02 RID: 3842
	public bool m_EnableVirtualKeyboard;

	// Token: 0x04000F03 RID: 3843
	public bool m_InitVirtualKeyboardWithInputString;

	// Token: 0x04000F04 RID: 3844
	public TMP_InputField m_VirtualKeyboardInputText;

	// Token: 0x04000F05 RID: 3845
	public GamepadSettingLinker m_GamepadSettingLinker;
}
