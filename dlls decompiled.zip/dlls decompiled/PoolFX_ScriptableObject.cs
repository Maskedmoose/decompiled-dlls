﻿using System;
using UnityEngine;

// Token: 0x0200012D RID: 301
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 2)]
public class PoolFX_ScriptableObject : ScriptableObject
{
	// Token: 0x040010BF RID: 4287
	public GameObject m_SlashHitFXPrefab;

	// Token: 0x040010C0 RID: 4288
	public GameObject m_ExplosionFXPrefab;

	// Token: 0x040010C1 RID: 4289
	public GameObject m_FlameHitFXPrefab;

	// Token: 0x040010C2 RID: 4290
	public GameObject m_RocketHitFXPrefab;

	// Token: 0x040010C3 RID: 4291
	public GameObject m_SonicBlasterFXPrefab;

	// Token: 0x040010C4 RID: 4292
	public GameObject m_BasicHitFXPrefab;

	// Token: 0x040010C5 RID: 4293
	public GameObject m_RobotDestroyedExplosionFXPrefab;

	// Token: 0x040010C6 RID: 4294
	public GameObject m_ShockBurstFXPrefab;

	// Token: 0x040010C7 RID: 4295
	public GameObject m_ShockHitFXPrefab;

	// Token: 0x040010C8 RID: 4296
	public GameObject m_FreezeHitFXPrefab;

	// Token: 0x040010C9 RID: 4297
	public GameObject m_FreezeExplosionFXPrefab;

	// Token: 0x040010CA RID: 4298
	public GameObject m_ChillMissleHitFXPrefab;

	// Token: 0x040010CB RID: 4299
	public GameObject m_EnergyExplodeFXPrefab;
}
