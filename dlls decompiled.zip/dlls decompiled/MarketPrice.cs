﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000034 RID: 52
[Serializable]
public class MarketPrice
{
	// Token: 0x060002A5 RID: 677 RVA: 0x00019856 File Offset: 0x00017A56
	public float GetMarketPrice()
	{
		return (float)Mathf.RoundToInt(this.generatedMarketPrice * (1f + this.pricePercentChangeList / 100f) * 100f) / 100f;
	}

	// Token: 0x060002A6 RID: 678 RVA: 0x00019883 File Offset: 0x00017A83
	public float GetMarketPriceCustomPercent(float percent)
	{
		return (float)Mathf.RoundToInt(this.generatedMarketPrice * (1f + percent / 100f) * 100f) / 100f;
	}

	// Token: 0x0400031B RID: 795
	public float generatedMarketPrice;

	// Token: 0x0400031C RID: 796
	public float pricePercentChangeList;

	// Token: 0x0400031D RID: 797
	public List<float> pastPricePercentChangeList;
}
