﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x0200007C RID: 124
public class SaveLoadSlotPanelUI : MonoBehaviour
{
	// Token: 0x060004ED RID: 1261 RVA: 0x0002A7F4 File Offset: 0x000289F4
	public void SetSaveOrLoadState(bool isSave)
	{
		this.m_IsSaveState = isSave;
		if (this.m_IsSaveState)
		{
			this.m_SaveBtn.SetActive(true);
			this.m_LoadBtn.SetActive(false);
			if (this.m_SlotIndex == 0)
			{
				this.m_SaveBtn.SetActive(false);
				return;
			}
		}
		else
		{
			this.m_SaveBtn.SetActive(false);
			this.m_LoadBtn.SetActive(true);
		}
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x0002A858 File Offset: 0x00028A58
	public void LoadSlotData(LoadSavedSlotData loadSavedSlotData)
	{
		if (loadSavedSlotData.hasSaveData)
		{
			this.m_ShopName.text = loadSavedSlotData.name;
			this.m_Money.text = GameInstance.GetPriceString(loadSavedSlotData.moneyAmount, false, true, false, "F2");
			this.m_Level.text = "Lv " + (loadSavedSlotData.level + 1).ToString();
			this.m_DaysPassed.text = LocalizationManager.GetTranslation("Day XXX", true, 0, true, false, null, null, true).Replace("XXX", (loadSavedSlotData.daysPassed + 1).ToString());
			return;
		}
		this.m_ShopName.text = "-";
		this.m_Money.text = "-";
		this.m_Level.text = "-";
		this.m_DaysPassed.text = "-";
	}

	// Token: 0x060004EF RID: 1263 RVA: 0x0002A93B File Offset: 0x00028B3B
	public void OnPressLoadGame()
	{
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.OnPressLoadGame(this.m_SlotIndex);
	}

	// Token: 0x060004F0 RID: 1264 RVA: 0x0002A94D File Offset: 0x00028B4D
	public void OnPressSaveGame()
	{
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.OnPressSaveGame(this.m_SlotIndex);
	}

	// Token: 0x0400067D RID: 1661
	public int m_SlotIndex;

	// Token: 0x0400067E RID: 1662
	public GameObject m_SaveBtn;

	// Token: 0x0400067F RID: 1663
	public GameObject m_LoadBtn;

	// Token: 0x04000680 RID: 1664
	public TextMeshProUGUI m_ShopName;

	// Token: 0x04000681 RID: 1665
	public TextMeshProUGUI m_Money;

	// Token: 0x04000682 RID: 1666
	public TextMeshProUGUI m_Level;

	// Token: 0x04000683 RID: 1667
	public TextMeshProUGUI m_DaysPassed;

	// Token: 0x04000684 RID: 1668
	private bool m_IsSaveState;
}
