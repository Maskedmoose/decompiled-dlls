﻿using System;
using System.Collections.Generic;
using I2.Loc;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000083 RID: 131
public class WorkbenchUIScreen : CSingleton<WorkbenchUIScreen>
{
	// Token: 0x0600052F RID: 1327 RVA: 0x0002BCCC File Offset: 0x00029ECC
	private void Update()
	{
		if (this.m_IsWorkingOnTask)
		{
			this.m_TaskTimer += Time.deltaTime;
			this.m_TaskFinishCirlceFillBar.fillAmount = Mathf.Lerp(0f, 1f, this.m_TaskTimer / this.m_TaskTime);
			if (this.m_TaskTimer >= this.m_TaskTime)
			{
				this.m_TaskTimer = 0f;
				this.m_IsWorkingOnTask = false;
				this.OnTaskCompleted();
			}
		}
	}

	// Token: 0x06000530 RID: 1328 RVA: 0x0002BD40 File Offset: 0x00029F40
	private void OnTaskCompleted()
	{
		this.m_CurrentInteractableWorkbench.OnTaskCompleted(this.m_CurrentCardExpansionType);
		this.m_SliderPriceLimit.interactable = true;
		this.m_SliderMinCard.interactable = true;
		this.m_TaskFinishCirlceGrp.SetActive(false);
		this.CloseScreen(false);
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x0002BD80 File Offset: 0x00029F80
	public static void OpenScreen(InteractableWorkbench interactableWorkbench)
	{
		if (CPlayerData.m_WorkbenchPriceLimit > 0f)
		{
			CSingleton<WorkbenchUIScreen>.Instance.m_MinimumCardLimit = CPlayerData.m_WorkbenchMinimumCardLimit;
			CSingleton<WorkbenchUIScreen>.Instance.m_PriceLimit = CPlayerData.m_WorkbenchPriceLimit;
			CSingleton<WorkbenchUIScreen>.Instance.m_RarityLimit = CPlayerData.m_WorkbenchRarityLimit;
			CSingleton<WorkbenchUIScreen>.Instance.m_CurrentCardExpansionType = CPlayerData.m_WorkbenchCardExpansionType;
		}
		CSingleton<WorkbenchUIScreen>.Instance.m_IgnoreSliderUpdateFunction = true;
		CSingleton<WorkbenchUIScreen>.Instance.m_SliderPriceLimit.value = CPlayerData.m_WorkbenchPriceLimit * 100f;
		CSingleton<WorkbenchUIScreen>.Instance.m_SliderMinCard.value = (float)CPlayerData.m_WorkbenchMinimumCardLimit / 10f * 10f;
		CSingleton<WorkbenchUIScreen>.Instance.m_PriceLimitMinText.text = GameInstance.GetPriceString(0.01f, false, true, false, "F2");
		CSingleton<WorkbenchUIScreen>.Instance.m_PriceLimitMaxText.text = GameInstance.GetPriceString(1f, false, true, false, "F2");
		CSingleton<WorkbenchUIScreen>.Instance.m_IgnoreSliderUpdateFunction = false;
		CSingleton<WorkbenchUIScreen>.Instance.m_MinimumCardLimit = CPlayerData.m_WorkbenchMinimumCardLimit;
		CSingleton<WorkbenchUIScreen>.Instance.m_CardExpansionText.text = InventoryBase.GetCardExpansionName(CSingleton<WorkbenchUIScreen>.Instance.m_CurrentCardExpansionType);
		if (CSingleton<WorkbenchUIScreen>.Instance.m_HasRarityLimit)
		{
			CSingleton<WorkbenchUIScreen>.Instance.m_RarityLimitText.text = LocalizationManager.GetTranslation(CSingleton<WorkbenchUIScreen>.Instance.m_RarityLimit.ToString(), true, 0, true, false, null, null, true);
		}
		else
		{
			CSingleton<WorkbenchUIScreen>.Instance.m_RarityLimitText.text = LocalizationManager.GetTranslation("Any Rarity", true, 0, true, false, null, null, true);
		}
		CSingleton<WorkbenchUIScreen>.Instance.m_PriceLimitText.text = GameInstance.GetPriceString(CSingleton<WorkbenchUIScreen>.Instance.m_PriceLimit, false, true, false, "F2");
		CSingleton<WorkbenchUIScreen>.Instance.m_MinimumCardText.text = CSingleton<WorkbenchUIScreen>.Instance.m_MinimumCardLimit.ToString();
		CSingleton<WorkbenchUIScreen>.Instance.m_TaskFinishCirlceGrp.SetActive(false);
		CSingleton<WorkbenchUIScreen>.Instance.m_CurrentInteractableWorkbench = interactableWorkbench;
		CSingleton<WorkbenchUIScreen>.Instance.m_ScreenGrp.SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<WorkbenchUIScreen>.Instance.m_ControllerScreenUIExtension);
		TutorialManager.SetGameUIVisible(false);
	}

	// Token: 0x06000532 RID: 1330 RVA: 0x0002BF88 File Offset: 0x0002A188
	public void CloseScreen(bool playSound)
	{
		if (InputManager.IsSliderActive())
		{
			return;
		}
		if (this.m_IsWorkingOnTask)
		{
			return;
		}
		if (playSound)
		{
			SoundManager.GenericMenuClose(1f, 1f);
		}
		this.m_PriceLimitText.text = GameInstance.GetPriceString(this.m_PriceLimit, false, true, false, "F2");
		this.m_MinimumCardText.text = this.m_MinimumCardLimit.ToString();
		this.m_CardExpansionText.text = InventoryBase.GetCardExpansionName(this.m_CurrentCardExpansionType);
		if (this.m_HasRarityLimit)
		{
			this.m_RarityLimitText.text = LocalizationManager.GetTranslation(this.m_RarityLimit.ToString(), true, 0, true, false, null, null, true);
		}
		else
		{
			this.m_RarityLimitText.text = LocalizationManager.GetTranslation("Any Rarity", true, 0, true, false, null, null, true);
		}
		CSingleton<WorkbenchUIScreen>.Instance.m_CurrentInteractableWorkbench.OnPressEsc();
		this.m_ScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<WorkbenchUIScreen>.Instance.m_ControllerScreenUIExtension);
		TutorialManager.SetGameUIVisible(true);
	}

	// Token: 0x06000533 RID: 1331 RVA: 0x0002C080 File Offset: 0x0002A280
	public void OpenBundleCardScreen()
	{
		if (this.m_IsWorkingOnTask)
		{
			return;
		}
		bool flag = false;
		EItemType bulkBoxItemType = this.m_CurrentInteractableWorkbench.GetBulkBoxItemType(this.m_CurrentCardExpansionType);
		if (ShelfManager.GetShelfListToRestockItem(bulkBoxItemType, false).Count > 0)
		{
			flag = true;
		}
		else if (RestockManager.GetItemPackagingBoxListWithSpaceForItem(bulkBoxItemType).Count > 0)
		{
			flag = true;
		}
		SoundManager.GenericConfirm(1f, 1f);
		if (flag)
		{
			this.RunBundleCardBulkFunction();
			return;
		}
		NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.NoSpaceToStartBundle);
	}

	// Token: 0x06000534 RID: 1332 RVA: 0x0002C0ED File Offset: 0x0002A2ED
	public void OnPressChangeCardExpannsionButton()
	{
		if (this.m_IsWorkingOnTask)
		{
			return;
		}
		SoundManager.GenericMenuOpen(1f, 1f);
		CardExpansionSelectScreen.OpenScreen(this.m_CurrentCardExpansionType);
		CEventManager.AddListener<CEventPlayer_OnCardExpansionSelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardExpansionSelectScreenUpdated>(this.OnCardExpansionUpdated));
	}

	// Token: 0x06000535 RID: 1333 RVA: 0x0002C123 File Offset: 0x0002A323
	protected void OnCardExpansionUpdated(CEventPlayer_OnCardExpansionSelectScreenUpdated evt)
	{
		this.m_CurrentCardExpansionType = (ECardExpansionType)evt.m_CardExpansionTypeIndex;
		CPlayerData.m_WorkbenchCardExpansionType = this.m_CurrentCardExpansionType;
		this.m_CardExpansionText.text = InventoryBase.GetCardExpansionName(this.m_CurrentCardExpansionType);
		CEventManager.RemoveListener<CEventPlayer_OnCardExpansionSelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardExpansionSelectScreenUpdated>(this.OnCardExpansionUpdated));
	}

	// Token: 0x06000536 RID: 1334 RVA: 0x0002C163 File Offset: 0x0002A363
	public void OnPressChangeRarityButton()
	{
		if (this.m_IsWorkingOnTask)
		{
			return;
		}
		SoundManager.GenericMenuOpen(1f, 1f);
		CardRaritySelectScreen.OpenScreen(this.m_RarityLimit);
		CEventManager.AddListener<CEventPlayer_OnCardRaritySelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardRaritySelectScreenUpdated>(this.OnRarityLimitUpdated));
	}

	// Token: 0x06000537 RID: 1335 RVA: 0x0002C19C File Offset: 0x0002A39C
	public void OnRarityLimitUpdated(CEventPlayer_OnCardRaritySelectScreenUpdated evt)
	{
		if (evt.m_CardRarityIndex == -1)
		{
			this.m_HasRarityLimit = false;
		}
		else
		{
			this.m_HasRarityLimit = true;
			this.m_RarityLimit = (ERarity)evt.m_CardRarityIndex;
		}
		CPlayerData.m_WorkbenchRarityLimit = this.m_RarityLimit;
		if (this.m_HasRarityLimit)
		{
			this.m_RarityLimitText.text = LocalizationManager.GetTranslation(this.m_RarityLimit.ToString(), true, 0, true, false, null, null, true);
		}
		else
		{
			this.m_RarityLimitText.text = LocalizationManager.GetTranslation("Any Rarity", true, 0, true, false, null, null, true);
		}
		CEventManager.RemoveListener<CEventPlayer_OnCardRaritySelectScreenUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnCardRaritySelectScreenUpdated>(this.OnRarityLimitUpdated));
	}

	// Token: 0x06000538 RID: 1336 RVA: 0x0002C238 File Offset: 0x0002A438
	public void OnSliderValueChanged_PriceLimit()
	{
		if (this.m_IgnoreSliderUpdateFunction)
		{
			return;
		}
		this.m_PriceLimit = (float)Mathf.RoundToInt(this.m_SliderPriceLimit.value) / 100f;
		this.m_PriceLimitText.text = GameInstance.GetPriceString(this.m_PriceLimit, false, true, false, "F2");
		CPlayerData.m_WorkbenchPriceLimit = this.m_PriceLimit;
	}

	// Token: 0x06000539 RID: 1337 RVA: 0x0002C294 File Offset: 0x0002A494
	public void OnSliderValueChanged_MinimumCard()
	{
		if (this.m_IgnoreSliderUpdateFunction)
		{
			return;
		}
		this.m_MinimumCardLimit = Mathf.CeilToInt(this.m_SliderMinCard.value);
		this.m_MinimumCardText.text = this.m_MinimumCardLimit.ToString();
		CPlayerData.m_WorkbenchMinimumCardLimit = this.m_MinimumCardLimit;
	}

	// Token: 0x0600053A RID: 1338 RVA: 0x0002C2E4 File Offset: 0x0002A4E4
	private void RunBundleCardBulkFunction()
	{
		ECardExpansionType currentCardExpansionType = this.m_CurrentCardExpansionType;
		bool flag = false;
		int num = 0;
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < InventoryBase.GetShownMonsterList(currentCardExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(currentCardExpansionType, true); i++)
		{
			int index = i;
			EMonsterType monsterTypeFromCardSaveIndex = CPlayerData.GetMonsterTypeFromCardSaveIndex(index, currentCardExpansionType);
			float cardMarketPrice = CPlayerData.GetCardMarketPrice(index, currentCardExpansionType, flag);
			ERarity rarity = InventoryBase.GetMonsterData(monsterTypeFromCardSaveIndex).Rarity;
			int cardAmountByIndex = CPlayerData.GetCardAmountByIndex(index, currentCardExpansionType, flag);
			if (cardMarketPrice < this.m_PriceLimit && (!this.m_HasRarityLimit || this.m_RarityLimit == rarity) && cardAmountByIndex > CPlayerData.m_WorkbenchMinimumCardLimit)
			{
				list.Add(i);
				list2.Add(cardAmountByIndex - CPlayerData.m_WorkbenchMinimumCardLimit);
				num += cardAmountByIndex - CPlayerData.m_WorkbenchMinimumCardLimit;
			}
		}
		if (num < 100)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.NotEnoughCardForBundle);
			return;
		}
		this.m_SliderPriceLimit.interactable = false;
		this.m_SliderMinCard.interactable = false;
		int j = 0;
		int num2 = 0;
		float num3 = 0f;
		List<CardData> list3 = new List<CardData>();
		while (j < 100)
		{
			for (int k = 0; k < list.Count; k++)
			{
				if (list2[k] > 0)
				{
					int num4 = Mathf.Clamp(Random.Range(1, list2[k] + 5), 1, 10);
					if (num4 > list2[k])
					{
						num4 = list2[k];
					}
					if (num4 > 100 - j)
					{
						num4 = 100 - j;
					}
					j += num4;
					if (list3.Count < 10)
					{
						list3.Add(CPlayerData.GetCardData(list[k], currentCardExpansionType, flag));
					}
					num3 += CPlayerData.GetCardMarketPrice(list[k], currentCardExpansionType, flag) * (float)num4;
					CPlayerData.ReduceCardUsingIndex(list[k], currentCardExpansionType, flag, num4);
					if (j >= 100)
					{
						break;
					}
				}
			}
			num2++;
			if (num2 > 10000)
			{
				break;
			}
		}
		this.m_CurrentCardExpansionType = currentCardExpansionType;
		this.m_CurrentInteractableWorkbench.PlayBundlingCardBoxSequence(list3, currentCardExpansionType);
		this.m_IsWorkingOnTask = true;
		this.m_TaskFinishCirlceGrp.SetActive(true);
	}

	// Token: 0x040006C9 RID: 1737
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040006CA RID: 1738
	public GameObject m_ScreenGrp;

	// Token: 0x040006CB RID: 1739
	public GameObject m_TaskFinishCirlceGrp;

	// Token: 0x040006CC RID: 1740
	public Image m_TaskFinishCirlceFillBar;

	// Token: 0x040006CD RID: 1741
	public Slider m_SliderPriceLimit;

	// Token: 0x040006CE RID: 1742
	public Slider m_SliderMinCard;

	// Token: 0x040006CF RID: 1743
	public TextMeshProUGUI m_PriceLimitText;

	// Token: 0x040006D0 RID: 1744
	public TextMeshProUGUI m_MinimumCardText;

	// Token: 0x040006D1 RID: 1745
	public TextMeshProUGUI m_CardExpansionText;

	// Token: 0x040006D2 RID: 1746
	public TextMeshProUGUI m_RarityLimitText;

	// Token: 0x040006D3 RID: 1747
	public TextMeshProUGUI m_PriceLimitMinText;

	// Token: 0x040006D4 RID: 1748
	public TextMeshProUGUI m_PriceLimitMaxText;

	// Token: 0x040006D5 RID: 1749
	private bool m_IsWorkingOnTask;

	// Token: 0x040006D6 RID: 1750
	private bool m_HasRarityLimit;

	// Token: 0x040006D7 RID: 1751
	private bool m_IgnoreSliderUpdateFunction;

	// Token: 0x040006D8 RID: 1752
	private int m_MinimumCardLimit = 4;

	// Token: 0x040006D9 RID: 1753
	private float m_TaskTime = 5f;

	// Token: 0x040006DA RID: 1754
	private float m_TaskTimer;

	// Token: 0x040006DB RID: 1755
	private float m_PriceLimit = 0.5f;

	// Token: 0x040006DC RID: 1756
	private ERarity m_RarityLimit = ERarity.None;

	// Token: 0x040006DD RID: 1757
	private ECardExpansionType m_CurrentCardExpansionType;

	// Token: 0x040006DE RID: 1758
	private InteractableWorkbench m_CurrentInteractableWorkbench;
}
