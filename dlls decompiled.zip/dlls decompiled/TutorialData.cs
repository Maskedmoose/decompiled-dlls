﻿using System;

// Token: 0x02000054 RID: 84
[Serializable]
public class TutorialData
{
	// Token: 0x040004A4 RID: 1188
	public ETutorialTaskCondition tutorialTaskCondition;

	// Token: 0x040004A5 RID: 1189
	public float value;
}
