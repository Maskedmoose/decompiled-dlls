﻿using System;
using System.Collections.Generic;

namespace CC
{
	// Token: 0x020001AC RID: 428
	[Serializable]
	public class CC_Apparel_Material_Collection
	{
		// Token: 0x0400132B RID: 4907
		public string Label;

		// Token: 0x0400132C RID: 4908
		public List<CC_Apparel_Material_Definition> MaterialDefinitions = new List<CC_Apparel_Material_Definition>();
	}
}
