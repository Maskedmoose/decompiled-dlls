﻿using System;

// Token: 0x020000B9 RID: 185
public class CEventPlayer_ChangeScene : CEvent
{
	// Token: 0x1700001F RID: 31
	// (get) Token: 0x0600071E RID: 1822 RVA: 0x00038167 File Offset: 0x00036367
	// (set) Token: 0x0600071F RID: 1823 RVA: 0x0003816F File Offset: 0x0003636F
	public ELevelName m_SceneName { get; private set; }

	// Token: 0x06000720 RID: 1824 RVA: 0x00038178 File Offset: 0x00036378
	public CEventPlayer_ChangeScene(ELevelName SceneName)
	{
		this.m_SceneName = SceneName;
	}
}
