﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E6 RID: 486
	public class CharacterJoystickInput : CharacterInput
	{
		// Token: 0x06000D9C RID: 3484 RVA: 0x0005D4C4 File Offset: 0x0005B6C4
		public override float GetHorizontalMovementInput()
		{
			float num;
			if (this.useRawInput)
			{
				num = Input.GetAxisRaw(this.horizontalInputAxis);
			}
			else
			{
				num = Input.GetAxis(this.horizontalInputAxis);
			}
			if (Mathf.Abs(num) < this.deadZoneThreshold)
			{
				num = 0f;
			}
			return num;
		}

		// Token: 0x06000D9D RID: 3485 RVA: 0x0005D508 File Offset: 0x0005B708
		public override float GetVerticalMovementInput()
		{
			float num;
			if (this.useRawInput)
			{
				num = Input.GetAxisRaw(this.verticalInputAxis);
			}
			else
			{
				num = Input.GetAxis(this.verticalInputAxis);
			}
			if (Mathf.Abs(num) < this.deadZoneThreshold)
			{
				num = 0f;
			}
			return num;
		}

		// Token: 0x06000D9E RID: 3486 RVA: 0x0005D54C File Offset: 0x0005B74C
		public override bool IsJumpKeyPressed()
		{
			return Input.GetKey(this.jumpKey);
		}

		// Token: 0x0400148E RID: 5262
		public string horizontalInputAxis = "Horizontal";

		// Token: 0x0400148F RID: 5263
		public string verticalInputAxis = "Vertical";

		// Token: 0x04001490 RID: 5264
		public KeyCode jumpKey = KeyCode.Joystick1Button0;

		// Token: 0x04001491 RID: 5265
		public bool useRawInput = true;

		// Token: 0x04001492 RID: 5266
		public float deadZoneThreshold = 0.2f;
	}
}
