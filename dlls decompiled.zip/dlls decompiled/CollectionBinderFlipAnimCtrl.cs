﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000010 RID: 16
public class CollectionBinderFlipAnimCtrl : MonoBehaviour
{
	// Token: 0x0600006C RID: 108 RVA: 0x00006DE0 File Offset: 0x00004FE0
	private void Awake()
	{
		this.m_ShowHideAnim.gameObject.SetActive(false);
		this.m_BinderPageGrpList[0].m_Anim.SetTrigger("CloseBinder");
		this.m_BinderPageGrpList[1].m_Anim.SetTrigger("CloseBinder");
		this.m_BinderPageGrpList[2].m_Anim.SetTrigger("CloseBinder");
		this.m_BinderPageGrpList[1].SetVisibility(false);
		this.m_BinderPageGrpList[2].SetVisibility(false);
		this.m_Index = 1;
		if (this.m_CanFlipCoroutine != null)
		{
			base.StopCoroutine(this.m_CanFlipCoroutine);
		}
		this.m_CanFlipCoroutine = base.StartCoroutine(this.DelayResetCanFlipBook(CSingleton<InteractionPlayerController>.Instance.m_HideCardAlbumTime));
		base.transform.position = Vector3.one * -100000f;
	}

	// Token: 0x0600006D RID: 109 RVA: 0x00006EC4 File Offset: 0x000050C4
	public void OnMouseButtonUp()
	{
		if (this.m_CollectionBinderUI.m_SortAlbumScreen.activeSelf)
		{
			return;
		}
		if (InteractionPlayerController.GetCurrentHoldCard())
		{
			return;
		}
		if (!this.m_IsHoldingCardCloseUp && !this.m_IsExitingCardCloseUp)
		{
			this.EnterViewUpCloseState();
			return;
		}
		if (this.m_IsHoldingCardCloseUp && !this.m_IsExitingCardCloseUp)
		{
			this.ExitViewUpCloseState();
		}
	}

	// Token: 0x0600006E RID: 110 RVA: 0x00006F20 File Offset: 0x00005120
	public void OnRightMouseButtonUp()
	{
		if ((this.m_IsHoldingCardCloseUp || this.m_IsExitingCardCloseUp) && this.m_IsHoldingCardCloseUp)
		{
			bool isExitingCardCloseUp = this.m_IsExitingCardCloseUp;
		}
		if (this.m_CurrentRaycastedInteractableCard3d)
		{
			if (!InteractionPlayerController.HasEnoughSlotToHoldCard())
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.HandFull);
				return;
			}
			Card3dUIGroup cardUI = CSingleton<Card3dUISpawner>.Instance.GetCardUI();
			this.m_CurrentSpawnedInteractableCard3d = ShelfManager.SpawnInteractableObject(EObjectType.Card3d).GetComponent<InteractableCard3d>();
			cardUI.m_CardUI.SetCardUI(this.m_CurrentRaycastedInteractableCard3d.m_Card3dUI.m_CardUI.GetCardData());
			cardUI.transform.position = this.m_CurrentRaycastedInteractableCard3d.transform.position;
			cardUI.transform.rotation = this.m_CurrentRaycastedInteractableCard3d.transform.rotation;
			this.m_CurrentSpawnedInteractableCard3d.transform.position = this.m_CurrentRaycastedInteractableCard3d.transform.position;
			this.m_CurrentSpawnedInteractableCard3d.transform.rotation = this.m_CurrentRaycastedInteractableCard3d.transform.rotation;
			this.m_CurrentSpawnedInteractableCard3d.SetCardUIFollow(cardUI);
			this.m_CurrentSpawnedInteractableCard3d.SetEnableCollision(false);
			CardData cardData = this.m_CurrentRaycastedInteractableCard3d.m_Card3dUI.m_CardUI.GetCardData();
			CPlayerData.ReduceCard(cardData, 1);
			int cardAmount = CPlayerData.GetCardAmount(cardData);
			this.m_BinderPageGrpList[0].SetSingleCard(this.m_CurrentRaycastedCardIndex, cardData, cardAmount);
			if (cardAmount <= 0)
			{
				this.m_CurrentRaycastedInteractableCard3d.m_Card3dUI.gameObject.SetActive(false);
				this.m_CurrentRaycastedInteractableCard3d.gameObject.SetActive(false);
				this.m_CurrentRaycastedInteractableCard3d.OnRaycastEnded();
				this.m_CurrentRaycastedInteractableCard3d = null;
			}
			InteractionPlayerController.AddHoldCard(this.m_CurrentSpawnedInteractableCard3d);
			InteractionPlayerController.RemoveToolTip(EGameAction.ViewAlbumCard);
		}
	}

	// Token: 0x0600006F RID: 111 RVA: 0x000070C4 File Offset: 0x000052C4
	private void EnterViewUpCloseState()
	{
		if (this.m_IsHoldingCardCloseUp)
		{
			return;
		}
		if (this.m_CurrentRaycastedInteractableCard3d)
		{
			CenterDot.SetVisibility(false);
			this.m_IsHoldingCardCloseUp = true;
			InteractionPlayerController.TempHideToolTip();
			InteractionPlayerController.AddToolTip(EGameAction.CloseCardAlbum, false, false);
			InteractionPlayerController.AddToolTip(EGameAction.PutCard, false, false);
			if (!this.m_CurrentSpawnedInteractableCard3d)
			{
				Card3dUIGroup cardUI = CSingleton<Card3dUISpawner>.Instance.GetCardUI();
				this.m_CurrentSpawnedInteractableCard3d = ShelfManager.SpawnInteractableObject(EObjectType.Card3d).GetComponent<InteractableCard3d>();
				cardUI.m_IgnoreCulling = true;
				cardUI.m_CardUIAnimGrp.gameObject.SetActive(true);
				cardUI.m_CardUI.SetFoilCullListVisibility(true);
				cardUI.m_CardUI.ResetFarDistanceCull();
				cardUI.m_CardUI.SetFoilMaterialList(CSingleton<Card3dUISpawner>.Instance.m_FoilMaterialTangentView);
				cardUI.m_CardUI.SetFoilBlendedMaterialList(CSingleton<Card3dUISpawner>.Instance.m_FoilBlendedMaterialTangentView);
				cardUI.m_CardUI.SetCardUI(this.m_CurrentRaycastedInteractableCard3d.m_Card3dUI.m_CardUI.GetCardData());
				cardUI.transform.position = this.m_CurrentRaycastedInteractableCard3d.transform.position;
				cardUI.transform.rotation = this.m_CurrentRaycastedInteractableCard3d.transform.rotation;
				this.m_CurrentSpawnedInteractableCard3d.transform.position = this.m_CurrentRaycastedInteractableCard3d.transform.position;
				this.m_CurrentSpawnedInteractableCard3d.transform.rotation = this.m_CurrentRaycastedInteractableCard3d.transform.rotation;
				this.m_CurrentSpawnedInteractableCard3d.SetCardUIFollow(cardUI);
				this.m_CurrentSpawnedInteractableCard3d.LerpToTransform(CSingleton<InteractionPlayerController>.Instance.m_HoldCardCloseUpPos, CSingleton<InteractionPlayerController>.Instance.m_HoldCardCloseUpPos);
				this.m_CurrentSpawnedInteractableCard3d.SetEnableCollision(false);
				this.m_CurrentSpawnedInteractableCard3d.m_CollectionBinderFlipAnimCtrl = this;
			}
			else if (this.m_CurrentSpawnedInteractableCard3d)
			{
				this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.m_IgnoreCulling = true;
				this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.m_CardUIAnimGrp.gameObject.SetActive(true);
				this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.m_CardUI.SetFoilCullListVisibility(true);
				this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.m_CardUI.ResetFarDistanceCull();
				this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.m_CardUI.SetFoilMaterialList(CSingleton<Card3dUISpawner>.Instance.m_FoilMaterialTangentView);
				this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.m_CardUI.SetFoilBlendedMaterialList(CSingleton<Card3dUISpawner>.Instance.m_FoilBlendedMaterialTangentView);
				this.m_CurrentSpawnedInteractableCard3d.StopLerpToTransform();
				this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.m_CardUI.SetCardUI(this.m_CurrentRaycastedInteractableCard3d.m_Card3dUI.m_CardUI.GetCardData());
				this.m_CurrentSpawnedInteractableCard3d.transform.position = this.m_CurrentRaycastedInteractableCard3d.transform.position;
				this.m_CurrentSpawnedInteractableCard3d.transform.rotation = this.m_CurrentRaycastedInteractableCard3d.transform.rotation;
				this.m_CurrentSpawnedInteractableCard3d.LerpToTransform(CSingleton<InteractionPlayerController>.Instance.m_HoldCardCloseUpPos, CSingleton<InteractionPlayerController>.Instance.m_HoldCardCloseUpPos);
				this.m_CurrentSpawnedInteractableCard3d.SetEnableCollision(false);
				this.m_CurrentSpawnedInteractableCard3d.m_CollectionBinderFlipAnimCtrl = this;
				this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.transform.position = this.m_CurrentSpawnedInteractableCard3d.transform.position;
				this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.transform.rotation = this.m_CurrentSpawnedInteractableCard3d.transform.rotation;
				this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.gameObject.SetActive(true);
				this.m_CurrentSpawnedInteractableCard3d.gameObject.SetActive(true);
			}
			this.m_CurrentViewInteractableCard3d = this.m_CurrentRaycastedInteractableCard3d;
			CardData cardData = this.m_CurrentRaycastedInteractableCard3d.m_Card3dUI.m_CardUI.GetCardData();
			if (CPlayerData.GetCardAmount(cardData) <= 1)
			{
				this.m_CurrentViewInteractableCard3d.m_Card3dUI.gameObject.SetActive(false);
				this.m_CurrentViewInteractableCard3d.OnRaycastEnded();
			}
			if (this.m_CurrentRaycastedInteractableCard3d)
			{
				this.m_CurrentRaycastedInteractableCard3d.OnRaycastEnded();
				this.m_CurrentRaycastedInteractableCard3d = null;
			}
			this.m_CollectionBinderUI.CloseScreen();
			float cardMarketPrice = CPlayerData.GetCardMarketPrice(this.m_CurrentViewInteractableCard3d.m_Card3dUI.m_CardUI.GetCardData());
			this.m_CardOpeningSequenceUI.ShowSingleCardValue(cardMarketPrice);
			this.m_CollectionBinderUI.m_CardNameText.text = InventoryBase.GetMonsterData(cardData.monsterType).GetName();
			this.m_CollectionBinderUI.m_CardFullRarityNameText.text = CPlayerData.GetFullCardTypeName(cardData, false);
			if (cardData.isFoil)
			{
				this.m_CollectionBinderUI.m_CardNameFoilAnim.Play("FoilText");
				this.m_CollectionBinderUI.m_CardFullRarityNameFoilAnim.Play("FoilText");
			}
			else
			{
				this.m_CollectionBinderUI.m_CardNameFoilAnim.Play("NoFoilText");
				this.m_CollectionBinderUI.m_CardFullRarityNameFoilAnim.Play("NoFoilText");
			}
			this.m_CollectionBinderUI.m_CardNameText.gameObject.SetActive(true);
			this.m_CollectionBinderUI.m_CardFullRarityNameText.gameObject.SetActive(true);
			this.m_BlackBGFade.SetFadeIn(3f, 0.2f);
			SoundManager.GenericPop(1f, 1f);
			if (CSingleton<InteractionPlayerController>.Instance.IsPuttingCardOnDisplay())
			{
				CSingleton<InteractionPlayerController>.Instance.ExitViewCardAlbumMode();
			}
		}
	}

	// Token: 0x06000070 RID: 112 RVA: 0x000075D0 File Offset: 0x000057D0
	private void ExitViewUpCloseState()
	{
		if (this.m_IsHoldingCardCloseUp && !this.m_IsExitingCardCloseUp)
		{
			CenterDot.SetVisibility(true);
			InteractionPlayerController.RestoreHiddenToolTip();
			this.m_IsExitingCardCloseUp = true;
			this.m_InteractableCardFollowTransform.position = this.m_CurrentViewInteractableCard3d.m_Card3dUI.m_CardFrontMeshPos.transform.position;
			this.m_InteractableCardFollowTransform.rotation = this.m_CurrentViewInteractableCard3d.m_Card3dUI.m_CardFrontMeshPos.transform.rotation;
			this.m_CurrentSpawnedInteractableCard3d.SetTargetRotation(Quaternion.identity);
			this.m_CurrentSpawnedInteractableCard3d.LerpToTransform(this.m_InteractableCardFollowTransform, this.m_InteractableCardFollowTransform);
			this.m_CurrentSpawnedInteractableCard3d.SetHideItemAfterFinishLerp();
			this.m_CollectionBinderUI.OpenScreen();
			this.m_CardOpeningSequenceUI.HideSingleCardValue();
			this.m_CollectionBinderUI.m_CardNameText.gameObject.SetActive(false);
			this.m_CollectionBinderUI.m_CardFullRarityNameText.gameObject.SetActive(false);
			this.m_BlackBGFade.SetFadeOut(12f, 0f);
			SoundManager.GenericPop(1f, 0.9f);
		}
	}

	// Token: 0x06000071 RID: 113 RVA: 0x000076E7 File Offset: 0x000058E7
	public void OnCardFinishLerpHide()
	{
		this.m_IsHoldingCardCloseUp = false;
		this.m_IsExitingCardCloseUp = false;
		this.m_CurrentViewInteractableCard3d.m_Card3dUI.gameObject.SetActive(true);
	}

	// Token: 0x06000072 RID: 114 RVA: 0x00007710 File Offset: 0x00005910
	public void OnCardRaycasted(InteractableCard3d interactableCard)
	{
		if (this.m_IsHoldingCardCloseUp)
		{
			return;
		}
		this.m_CurrentRaycastedInteractableCard3d = interactableCard;
		float cardMarketPrice = CPlayerData.GetCardMarketPrice(this.m_CurrentRaycastedInteractableCard3d.m_Card3dUI.m_CardUI.GetCardData());
		this.m_CardPricePopupUI.ShowCardPricePopup(cardMarketPrice, this.m_CurrentRaycastedInteractableCard3d.transform.position);
		this.m_CurrentRaycastedCardIndex = this.m_InteractableCard3dList.IndexOf(this.m_CurrentRaycastedInteractableCard3d);
	}

	// Token: 0x06000073 RID: 115 RVA: 0x0000777B File Offset: 0x0000597B
	public void OnCardRaycastEnded()
	{
		this.m_CurrentRaycastedInteractableCard3d = null;
		this.m_CardPricePopupUI.HideCardPricePopup();
	}

	// Token: 0x06000074 RID: 116 RVA: 0x00007790 File Offset: 0x00005990
	public void StartShowCardAlbum(Transform targetFollowPos)
	{
		if (!this.m_IsSorting && InteractionPlayerController.GetCurrentHoldCard())
		{
			this.m_IsHoldingCardCloseUp = false;
			InteractionPlayerController.RemoveAllCard();
			this.m_CanUpdateSort = true;
		}
		this.m_OpenBinder = true;
		this.m_IsInViewCardAlbumMode = true;
		this.m_IsLerpingPos = true;
		base.StartCoroutine(this.DelayStopLerpPos());
		this.m_TargetFollowPos = targetFollowPos;
		this.m_TargetLerpPos = this.m_TargetFollowPos.position;
		this.m_TargetLerpRot = this.m_TargetFollowPos.rotation;
		base.transform.position = this.m_TargetFollowPos.position;
		base.transform.rotation = this.m_TargetFollowPos.rotation;
		this.m_ShowHideAnim.Play("ShowCardAlbum");
		base.gameObject.SetActive(true);
		if (this.m_CanFlipCoroutine != null)
		{
			base.StopCoroutine(this.m_CanFlipCoroutine);
		}
		this.m_CanFlipCoroutine = base.StartCoroutine(this.DelayResetCanFlipBook(CSingleton<InteractionPlayerController>.Instance.m_HideCardAlbumTime));
		SoundManager.PlayAudio("SFX_AlbumOpen", 0.6f, 1f);
		SoundManager.PlayAudio("SFX_WhipSoft", 0.6f, 1f);
	}

	// Token: 0x06000075 RID: 117 RVA: 0x000078B0 File Offset: 0x00005AB0
	public void HideCardAlbum()
	{
		if (this.m_IsHoldingCardCloseUp && this.m_CurrentSpawnedInteractableCard3d && InteractionPlayerController.HasEnoughSlotToHoldCard())
		{
			CenterDot.SetVisibility(true);
			this.m_IsHoldingCardCloseUp = false;
			this.m_IsExitingCardCloseUp = false;
			this.m_CurrentSpawnedInteractableCard3d.m_CollectionBinderFlipAnimCtrl = null;
			this.m_CurrentSpawnedInteractableCard3d.SetTargetRotation(Quaternion.identity);
			CPlayerData.ReduceCard(this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.m_CardUI.GetCardData(), 1);
			InteractionPlayerController.AddHoldCard(this.m_CurrentSpawnedInteractableCard3d);
			CSingleton<InteractionPlayerController>.Instance.EnterHoldCardMode();
			this.m_CurrentSpawnedInteractableCard3d = null;
		}
		else if (!this.m_IsSorting)
		{
			CSingleton<InteractionPlayerController>.Instance.SetIsPuttingCardOnDisplay(false);
			if (InteractionPlayerController.GetCurrentHoldCard())
			{
				this.m_CurrentSpawnedInteractableCard3d = null;
				CSingleton<InteractionPlayerController>.Instance.EnterHoldCardMode();
			}
		}
		if (this.m_CurrentRaycastedInteractableCard3d)
		{
			this.m_CurrentRaycastedInteractableCard3d.OnRaycastEnded();
			this.m_CurrentRaycastedInteractableCard3d = null;
		}
		if (this.m_CollectionBinderUI.m_SortAlbumScreen.activeSelf)
		{
			this.m_CollectionBinderUI.CloseSortAlbumScreen();
		}
		this.m_OffsetPos = this.m_TargetFollowPos.position - base.transform.position;
		this.m_StartRot = base.transform.rotation;
		this.m_LerpTimer = 0f;
		this.m_IsLerpingPos = true;
		this.m_IsHidingAlbum = true;
		this.m_CloseBinder = true;
		this.m_ShowHideAnim.Play("HideCardAlbum");
		base.StartCoroutine(this.DelayStopLerpPos());
		base.StartCoroutine(this.DelayHideCardAlbum());
		if (this.m_CanFlipCoroutine != null)
		{
			base.StopCoroutine(this.m_CanFlipCoroutine);
		}
		this.m_CanFlipCoroutine = base.StartCoroutine(this.DelayResetCanFlipBook(CSingleton<InteractionPlayerController>.Instance.m_HideCardAlbumTime + 0.1f));
		this.m_CollectionBinderUI.CloseScreen();
		this.m_CardOpeningSequenceUI.HideSingleCardValue();
		this.m_CollectionBinderUI.m_CardNameText.gameObject.SetActive(false);
		this.m_CollectionBinderUI.m_CardFullRarityNameText.gameObject.SetActive(false);
		this.m_BlackBGFade.SetFadeOut(12f, 0f);
		SoundManager.PlayAudio("SFX_AlbumOpen", 0.6f, 1f);
	}

	// Token: 0x06000076 RID: 118 RVA: 0x00007ACC File Offset: 0x00005CCC
	public void FlipNextPage()
	{
		if (this.m_IsHoldingCardCloseUp)
		{
			return;
		}
		this.m_GoNext = true;
	}

	// Token: 0x06000077 RID: 119 RVA: 0x00007ADE File Offset: 0x00005CDE
	public void FlipNext10Page()
	{
		if (this.m_IsHoldingCardCloseUp)
		{
			return;
		}
		this.m_GoNext10 = true;
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00007AF0 File Offset: 0x00005CF0
	public void FlipPreviousPage()
	{
		if (this.m_IsHoldingCardCloseUp)
		{
			return;
		}
		this.m_GoPrevious = true;
	}

	// Token: 0x06000079 RID: 121 RVA: 0x00007B02 File Offset: 0x00005D02
	public void FlipPrevious10Page()
	{
		if (this.m_IsHoldingCardCloseUp)
		{
			return;
		}
		this.m_GoPrevious10 = true;
	}

	// Token: 0x0600007A RID: 122 RVA: 0x00007B14 File Offset: 0x00005D14
	private IEnumerator DelayStopLerpPos()
	{
		yield return new WaitForSeconds(CSingleton<InteractionPlayerController>.Instance.m_HideCardAlbumTime - 0.1f);
		this.m_IsLerpingPos = false;
		yield break;
	}

	// Token: 0x0600007B RID: 123 RVA: 0x00007B23 File Offset: 0x00005D23
	private IEnumerator DelayHideCardAlbum()
	{
		yield return new WaitForSeconds(CSingleton<InteractionPlayerController>.Instance.m_HideCardAlbumTime);
		this.m_IsInViewCardAlbumMode = false;
		base.transform.position = Vector3.one * -100000f;
		this.m_IsHidingAlbum = false;
		this.m_ShowHideAnim.gameObject.SetActive(false);
		yield break;
	}

	// Token: 0x0600007C RID: 124 RVA: 0x00007B32 File Offset: 0x00005D32
	private IEnumerator DelaySetBinderPageVisibility(bool isVisible)
	{
		yield return new WaitForSeconds(0.5f);
		this.m_BinderPageGrpList[1].SetVisibility(isVisible);
		this.m_BinderPageGrpList[2].SetVisibility(isVisible);
		yield break;
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00007B48 File Offset: 0x00005D48
	private IEnumerator DelayResetCanFlipBook(float delayTime)
	{
		this.HideCurrentInteractableCard3dList();
		this.m_CanFlip = false;
		yield return new WaitForSeconds(delayTime);
		this.m_CanFlip = true;
		yield return new WaitForSeconds(0.1f);
		this.UpdateCurrentInteractableCard3dList();
		yield break;
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00007B60 File Offset: 0x00005D60
	private void HideCurrentInteractableCard3dList()
	{
		for (int i = 0; i < this.m_InteractableCard3dList.Count; i++)
		{
			this.m_InteractableCard3dList[i].gameObject.SetActive(false);
		}
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00007B9C File Offset: 0x00005D9C
	private void UpdateCurrentInteractableCard3dList()
	{
		for (int i = 0; i < this.m_InteractableCard3dList.Count; i++)
		{
			this.m_InteractableCard3dList[i].m_Card3dUI = this.m_BinderPageGrpList[0].m_CardList[i];
			this.m_InteractableCard3dList[i].transform.position = this.m_BinderPageGrpList[0].m_CardList[i].transform.position;
			this.m_InteractableCard3dList[i].transform.rotation = this.m_BinderPageGrpList[0].m_CardList[i].transform.rotation;
			this.m_InteractableCard3dList[i].gameObject.SetActive(this.m_BinderPageGrpList[0].m_CardList[i].gameObject.activeSelf);
		}
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00007C94 File Offset: 0x00005E94
	private void LateUpdate()
	{
		if (this.m_IsLerpingPos)
		{
			this.m_TargetLerpPos = this.m_TargetFollowPos.position;
			this.m_TargetLerpRot = this.m_TargetFollowPos.rotation;
			if (!this.m_IsHidingAlbum)
			{
				CSingleton<InteractionPlayerController>.Instance.m_CameraController.EnterViewCardAlbumMode();
			}
		}
		if (this.m_IsInViewCardAlbumMode)
		{
			if (this.m_IsHidingAlbum)
			{
				this.m_LerpTimer += Time.deltaTime / CSingleton<InteractionPlayerController>.Instance.m_HideCardAlbumTime;
				base.transform.position = this.m_TargetFollowPos.position - this.m_OffsetPos;
				base.transform.rotation = Quaternion.Lerp(this.m_StartRot, this.m_TargetFollowPos.rotation, this.m_LerpTimer);
				return;
			}
			base.transform.position = Vector3.Lerp(base.transform.position, this.m_TargetLerpPos, Time.deltaTime * 5f);
			base.transform.rotation = Quaternion.Lerp(base.transform.rotation, this.m_TargetLerpRot, Time.deltaTime * 5f);
		}
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00007DB4 File Offset: 0x00005FB4
	private void Update()
	{
		if (this.m_IsBookOpen && this.m_IsHoldingCardCloseUp && !this.m_IsExitingCardCloseUp)
		{
			float x = Mathf.Clamp(CSingleton<InteractionPlayerController>.Instance.m_CameraController.GetViewCardDeltaAngleX() * 1.5f, -15f, 15f);
			float num = Mathf.Clamp(CSingleton<InteractionPlayerController>.Instance.m_CameraController.GetViewCardDeltaAngleY(), -35f, 35f);
			Quaternion localRotation = this.m_CurrentSpawnedInteractableCard3d.m_Card3dUI.m_ScaleGrp.transform.localRotation;
			Vector3 eulerAngles = localRotation.eulerAngles;
			eulerAngles.x = x;
			eulerAngles.y = -num;
			eulerAngles.z = 0f;
			localRotation.eulerAngles = eulerAngles;
			this.m_CurrentSpawnedInteractableCard3d.SetTargetRotation(localRotation);
		}
		if (this.m_OpenBinder && !this.m_IsBookOpen)
		{
			this.m_ShowHideAnim.gameObject.SetActive(true);
			this.m_OpenBinder = false;
			this.m_IsBookOpen = true;
			this.m_BookAnim.SetTrigger("OpenBinder");
			this.m_BinderThicknessAnim.SetTrigger("OpenBinder");
			this.m_BinderPageGrpList[0].m_Anim.SetTrigger("OpenBinder");
			this.m_BinderPageGrpList[1].m_Anim.SetTrigger("SetHideNextIdle");
			this.m_BinderPageGrpList[2].m_Anim.SetTrigger("SetHidePreviousIdle");
			base.StartCoroutine(this.DelaySetBinderPageVisibility(true));
			if (this.m_CanFlipCoroutine != null)
			{
				base.StopCoroutine(this.m_CanFlipCoroutine);
			}
			this.m_CanFlipCoroutine = base.StartCoroutine(this.DelayResetCanFlipBook(CSingleton<InteractionPlayerController>.Instance.m_HideCardAlbumTime + 0.3f));
			int num2 = InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true);
			if (this.m_ExpansionType == ECardExpansionType.Ghost)
			{
				num2 *= 2;
			}
			this.m_MaxIndex = Mathf.CeilToInt((float)num2 / 12f);
			this.m_CollectionBinderUI.SetMaxPage(this.m_MaxIndex);
			this.m_CollectionBinderUI.SetCurrentPage(this.m_Index);
			this.m_CollectionBinderUI.SetMaxCardCollectCount(num2);
			if (this.m_ExpansionType == ECardExpansionType.Ghost)
			{
				this.m_CollectionBinderUI.SetCardCollected(CPlayerData.GetCardCollectedAmount(this.m_ExpansionType, false) + CPlayerData.GetCardCollectedAmount(this.m_ExpansionType, true), this.m_ExpansionType);
				this.m_CollectionBinderUI.SetTotalValue(CPlayerData.GetCardAlbumTotalValue(this.m_ExpansionType, false) + CPlayerData.GetCardAlbumTotalValue(this.m_ExpansionType, true));
			}
			else
			{
				this.m_CollectionBinderUI.SetCardCollected(CPlayerData.GetCardCollectedAmount(this.m_ExpansionType, false), this.m_ExpansionType);
				this.m_CollectionBinderUI.SetTotalValue(CPlayerData.GetCardAlbumTotalValue(this.m_ExpansionType, false));
			}
			this.m_CollectionBinderUI.OpenScreen();
			this.m_SortingType = (ECollectionSortingType)CPlayerData.m_CollectionSortingMethodIndexList[(int)this.m_ExpansionType];
			if (this.m_SortingType < ECollectionSortingType.Default || this.m_SortingType >= ECollectionSortingType.MAX)
			{
				this.m_SortingType = ECollectionSortingType.Price;
				CPlayerData.m_CollectionSortingMethodIndexList[(int)this.m_ExpansionType] = (int)this.m_SortingType;
			}
			this.OnSortingMethodUpdated(false);
			UnityAnalytic.OpenAlbum();
		}
		if (this.m_IsBookOpen)
		{
			if (this.m_CloseBinder)
			{
				this.m_IsBookOpen = false;
				this.m_BookAnim.Play("CollectionBookClose");
				this.m_BinderThicknessAnim.Play("CollectionBookClose");
				this.m_BinderPageGrpList[0].m_Anim.Play("BinderClose");
				this.m_BinderPageGrpList[1].m_Anim.SetTrigger("SetHideNextIdle");
				this.m_BinderPageGrpList[2].m_Anim.SetTrigger("SetHidePreviousIdle");
				this.m_BinderPageGrpList[1].SetVisibility(false);
				this.m_BinderPageGrpList[2].SetVisibility(false);
				this.m_CloseBinder = false;
				if (this.m_CanFlipCoroutine != null)
				{
					base.StopCoroutine(this.m_CanFlipCoroutine);
				}
				this.m_CanFlipCoroutine = base.StartCoroutine(this.DelayResetCanFlipBook(0.5f));
				SoundManager.PlayAudio("SFX_AlbumFlip", 0.6f, 1f);
			}
			if (!this.m_CanFlip)
			{
				this.m_GoNext = false;
				this.m_GoPrevious = false;
				this.m_GoNext10 = false;
				this.m_GoPrevious10 = false;
				return;
			}
			if (this.m_GoNext && this.m_Index < this.m_MaxIndex)
			{
				this.m_BinderPageGrpList[0].m_Anim.SetTrigger("GoNextPage");
				this.m_BinderPageGrpList[1].m_Anim.SetTrigger("GoNextPage");
				this.m_BinderPageGrpList[2].m_Anim.SetTrigger("SetHideNextIdle");
				BinderPageGrp item = this.m_BinderPageGrpList[0];
				this.m_BinderPageGrpList.RemoveAt(0);
				this.m_BinderPageGrpList.Add(item);
				this.m_GoNext = false;
				this.m_Index++;
				if (this.m_CanFlipCoroutine != null)
				{
					base.StopCoroutine(this.m_CanFlipCoroutine);
				}
				this.m_CanFlipCoroutine = base.StartCoroutine(this.DelayResetCanFlipBook(0.55f));
				this.m_CollectionBinderUI.SetCurrentPage(this.m_Index);
				SoundManager.PlayAudio("SFX_AlbumFlip", 0.6f, 1f);
				if (this.m_Index < this.m_MaxIndex)
				{
					this.UpdateBinderAllCardUI(1, this.m_Index + 1);
				}
			}
			if (this.m_GoPrevious && this.m_Index > 1)
			{
				this.m_BinderPageGrpList[2].m_Anim.SetTrigger("GoPreviousPage");
				this.m_BinderPageGrpList[1].m_Anim.SetTrigger("SetHidePreviousIdle");
				this.m_BinderPageGrpList[0].m_Anim.SetTrigger("GoPreviousPage");
				BinderPageGrp item2 = this.m_BinderPageGrpList[2];
				this.m_BinderPageGrpList.RemoveAt(2);
				this.m_BinderPageGrpList.Insert(0, item2);
				this.m_GoPrevious = false;
				this.m_Index--;
				if (this.m_CanFlipCoroutine != null)
				{
					base.StopCoroutine(this.m_CanFlipCoroutine);
				}
				this.m_CanFlipCoroutine = base.StartCoroutine(this.DelayResetCanFlipBook(0.55f));
				this.m_CollectionBinderUI.SetCurrentPage(this.m_Index);
				SoundManager.PlayAudio("SFX_AlbumFlip", 0.6f, 1f);
				if (this.m_Index > 1)
				{
					this.UpdateBinderAllCardUI(2, this.m_Index - 1);
				}
			}
			if (this.m_GoNext10 && this.m_Index < this.m_MaxIndex)
			{
				this.m_BinderPageGrpList[0].m_Anim.SetTrigger("GoNextPage");
				this.m_BinderPageGrpList[1].m_Anim.SetTrigger("GoNextPage");
				this.m_BinderPageGrpList[2].m_Anim.SetTrigger("SetHideNextIdle");
				BinderPageGrp item3 = this.m_BinderPageGrpList[0];
				this.m_BinderPageGrpList.RemoveAt(0);
				this.m_BinderPageGrpList.Add(item3);
				this.m_GoNext10 = false;
				this.m_Index += 10;
				if (this.m_Index > this.m_MaxIndex)
				{
					this.m_Index = this.m_MaxIndex;
				}
				if (this.m_CanFlipCoroutine != null)
				{
					base.StopCoroutine(this.m_CanFlipCoroutine);
				}
				this.m_CanFlipCoroutine = base.StartCoroutine(this.DelayResetCanFlipBook(0.55f));
				this.UpdateBinderAllCardUI(0, this.m_Index);
				base.StartCoroutine(this.DelaySetBinderPageCardIndex(2, this.m_Index - 1));
				this.m_CollectionBinderUI.SetCurrentPage(this.m_Index);
				SoundManager.PlayAudio("SFX_AlbumFlip", 0.6f, 1f);
				if (this.m_Index < this.m_MaxIndex)
				{
					base.StartCoroutine(this.DelaySetBinderPageCardIndex(1, this.m_Index + 1));
				}
			}
			if (this.m_GoPrevious10 && this.m_Index > 1)
			{
				this.m_BinderPageGrpList[2].m_Anim.SetTrigger("GoPreviousPage");
				this.m_BinderPageGrpList[1].m_Anim.SetTrigger("SetHidePreviousIdle");
				this.m_BinderPageGrpList[0].m_Anim.SetTrigger("GoPreviousPage");
				BinderPageGrp item4 = this.m_BinderPageGrpList[2];
				this.m_BinderPageGrpList.RemoveAt(2);
				this.m_BinderPageGrpList.Insert(0, item4);
				this.m_GoPrevious10 = false;
				this.m_Index -= 10;
				if (this.m_Index < 1)
				{
					this.m_Index = 1;
				}
				if (this.m_CanFlipCoroutine != null)
				{
					base.StopCoroutine(this.m_CanFlipCoroutine);
				}
				this.m_CanFlipCoroutine = base.StartCoroutine(this.DelayResetCanFlipBook(0.55f));
				this.UpdateBinderAllCardUI(0, this.m_Index);
				base.StartCoroutine(this.DelaySetBinderPageCardIndex(1, this.m_Index + 1));
				this.m_CollectionBinderUI.SetCurrentPage(this.m_Index);
				if (this.m_Index > 1)
				{
					base.StartCoroutine(this.DelaySetBinderPageCardIndex(2, this.m_Index - 1));
				}
				SoundManager.PlayAudio("SFX_AlbumFlip", 0.6f, 1f);
			}
		}
		this.m_OpenBinder = false;
		this.m_CloseBinder = false;
		this.m_GoNext = false;
		this.m_GoPrevious = false;
		this.m_GoNext10 = false;
		this.m_GoPrevious10 = false;
	}

	// Token: 0x06000082 RID: 130 RVA: 0x000086CB File Offset: 0x000068CB
	private IEnumerator DelaySetBinderPageCardIndex(int binderIndex, int pageIndex)
	{
		yield return new WaitForSeconds(0.5f);
		this.UpdateBinderAllCardUI(binderIndex, pageIndex);
		yield break;
	}

	// Token: 0x06000083 RID: 131 RVA: 0x000086E8 File Offset: 0x000068E8
	public void OpenSortAlbumScreen()
	{
		if (!this.m_CanFlip || this.m_IsHoldingCardCloseUp || this.m_IsExitingCardCloseUp)
		{
			return;
		}
		this.m_CollectionBinderUI.OpenSortAlbumScreen((int)this.m_SortingType, (int)this.m_ExpansionType);
	}

	// Token: 0x06000084 RID: 132 RVA: 0x0000871A File Offset: 0x0000691A
	public void OpenExpansionSelectScreen()
	{
		if (!this.m_CanFlip || this.m_IsHoldingCardCloseUp || this.m_IsExitingCardCloseUp)
		{
			return;
		}
		this.m_CollectionBinderUI.OpenExpansionSelectScreen((int)this.m_ExpansionType);
	}

	// Token: 0x06000085 RID: 133 RVA: 0x00008748 File Offset: 0x00006948
	public void OnPressSwitchSortingMethod(int sortingMethodIndex)
	{
		this.m_CanUpdateSort = true;
		SoundManager.GenericConfirm(1f, 1f);
		this.m_SortingType = (ECollectionSortingType)sortingMethodIndex;
		CPlayerData.m_CollectionSortingMethodIndexList[(int)this.m_ExpansionType] = (int)this.m_SortingType;
		base.StartCoroutine(this.DelayAlbumSort());
	}

	// Token: 0x06000086 RID: 134 RVA: 0x00008795 File Offset: 0x00006995
	public void OnPressSwitchExpansion(int expansionIndex)
	{
		this.m_CanUpdateSort = true;
		SoundManager.GenericConfirm(1f, 1f);
		this.m_ExpansionType = (ECardExpansionType)expansionIndex;
		base.StartCoroutine(this.DelayAlbumSort());
	}

	// Token: 0x06000087 RID: 135 RVA: 0x000087C1 File Offset: 0x000069C1
	private IEnumerator DelayAlbumSort()
	{
		this.m_IsSorting = true;
		this.HideCardAlbum();
		yield return new WaitForSeconds(0.6f);
		this.OnSortingMethodUpdated(true);
		yield return new WaitForSeconds(0.05f);
		this.StartShowCardAlbum(this.m_TargetFollowPos);
		this.m_IsSorting = false;
		yield break;
	}

	// Token: 0x06000088 RID: 136 RVA: 0x000087D0 File Offset: 0x000069D0
	private void SortByDefault()
	{
		this.m_SortedIndexList.Clear();
		this.m_SortTempList.Clear();
		int num = 0;
		for (int i = 0; i < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; i++)
		{
			for (int j = 0; j < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); j++)
			{
				this.m_SortedIndexList.Add(num);
				num++;
			}
		}
		if (this.m_ExpansionType == ECardExpansionType.Ghost)
		{
			for (int k = 0; k < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; k++)
			{
				for (int l = 0; l < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); l++)
				{
					this.m_SortedIndexList.Add(num);
					num++;
				}
			}
		}
	}

	// Token: 0x06000089 RID: 137 RVA: 0x00008888 File Offset: 0x00006A88
	private void SortByCardAmount()
	{
		this.m_SortedIndexList.Clear();
		this.m_SortTempList.Clear();
		int num = 0;
		for (int i = 0; i < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; i++)
		{
			for (int j = 0; j < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); j++)
			{
				int cardAmountByIndex = CPlayerData.GetCardAmountByIndex(num, this.m_ExpansionType, false);
				int index = this.m_SortTempList.Count;
				for (int k = 0; k < this.m_SortTempList.Count; k++)
				{
					if (cardAmountByIndex > this.m_SortTempList[k])
					{
						index = k;
						break;
					}
				}
				this.m_SortTempList.Insert(index, cardAmountByIndex);
				this.m_SortedIndexList.Insert(index, num);
				num++;
			}
		}
		if (this.m_ExpansionType == ECardExpansionType.Ghost)
		{
			int num2 = 0;
			for (int l = 0; l < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; l++)
			{
				for (int m = 0; m < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); m++)
				{
					int cardAmountByIndex2 = CPlayerData.GetCardAmountByIndex(num2, this.m_ExpansionType, true);
					int index2 = this.m_SortTempList.Count;
					for (int n = 0; n < this.m_SortTempList.Count; n++)
					{
						if (cardAmountByIndex2 > this.m_SortTempList[n])
						{
							index2 = n;
							break;
						}
					}
					this.m_SortTempList.Insert(index2, cardAmountByIndex2);
					this.m_SortedIndexList.Insert(index2, num);
					num++;
					num2++;
				}
			}
		}
	}

	// Token: 0x0600008A RID: 138 RVA: 0x00008A18 File Offset: 0x00006C18
	private void SortByPriceAmount()
	{
		this.m_SortedIndexList.Clear();
		this.m_SortTempList.Clear();
		int num = 0;
		for (int i = 0; i < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; i++)
		{
			for (int j = 0; j < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); j++)
			{
				CardData cardData = new CardData();
				cardData.monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(num, this.m_ExpansionType);
				cardData.borderType = (ECardBorderType)(num % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
				cardData.isFoil = (num % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
				cardData.isDestiny = false;
				cardData.expansionType = this.m_ExpansionType;
				int cardAmount = CPlayerData.GetCardAmount(cardData);
				int num2 = 0;
				if (cardAmount > 0)
				{
					num2 = Mathf.RoundToInt(CPlayerData.GetCardMarketPrice(cardData) * 100f);
				}
				int index = this.m_SortTempList.Count;
				for (int k = 0; k < this.m_SortTempList.Count; k++)
				{
					if (num2 > this.m_SortTempList[k])
					{
						index = k;
						break;
					}
				}
				this.m_SortTempList.Insert(index, num2);
				this.m_SortedIndexList.Insert(index, num);
				num++;
			}
		}
		if (this.m_ExpansionType == ECardExpansionType.Ghost)
		{
			int num3 = 0;
			for (int l = 0; l < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; l++)
			{
				for (int m = 0; m < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); m++)
				{
					CardData cardData2 = new CardData();
					cardData2.monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(num3, this.m_ExpansionType);
					cardData2.borderType = (ECardBorderType)(num3 % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
					cardData2.isFoil = (num3 % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
					cardData2.isDestiny = true;
					cardData2.expansionType = this.m_ExpansionType;
					int cardAmount2 = CPlayerData.GetCardAmount(cardData2);
					int num4 = 0;
					if (cardAmount2 > 0)
					{
						num4 = Mathf.RoundToInt(CPlayerData.GetCardMarketPrice(cardData2) * 100f);
					}
					int index2 = this.m_SortTempList.Count;
					for (int n = 0; n < this.m_SortTempList.Count; n++)
					{
						if (num4 > this.m_SortTempList[n])
						{
							index2 = n;
							break;
						}
					}
					this.m_SortTempList.Insert(index2, num4);
					this.m_SortedIndexList.Insert(index2, num);
					num++;
					num3++;
				}
			}
		}
	}

	// Token: 0x0600008B RID: 139 RVA: 0x00008CA8 File Offset: 0x00006EA8
	private void SortByDuplicatePriceAmount()
	{
		this.m_SortedIndexList.Clear();
		this.m_SortTempList.Clear();
		int num = 0;
		for (int i = 0; i < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; i++)
		{
			for (int j = 0; j < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); j++)
			{
				CardData cardData = new CardData();
				cardData.monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(num, this.m_ExpansionType);
				cardData.borderType = (ECardBorderType)(num % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
				cardData.isFoil = (num % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
				cardData.isDestiny = false;
				cardData.expansionType = this.m_ExpansionType;
				int cardAmount = CPlayerData.GetCardAmount(cardData);
				int num2 = 0;
				if (cardAmount > 1)
				{
					num2 = Mathf.RoundToInt(CPlayerData.GetCardMarketPrice(cardData) * 100000f);
				}
				else if (cardAmount == 1)
				{
					num2 = Mathf.RoundToInt(CPlayerData.GetCardMarketPrice(cardData) * 1f);
				}
				int index = this.m_SortTempList.Count;
				for (int k = 0; k < this.m_SortTempList.Count; k++)
				{
					if (num2 > this.m_SortTempList[k])
					{
						index = k;
						break;
					}
				}
				this.m_SortTempList.Insert(index, num2);
				this.m_SortedIndexList.Insert(index, num);
				num++;
			}
		}
		if (this.m_ExpansionType == ECardExpansionType.Ghost)
		{
			int num3 = 0;
			for (int l = 0; l < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; l++)
			{
				for (int m = 0; m < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); m++)
				{
					CardData cardData2 = new CardData();
					cardData2.monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(num3, this.m_ExpansionType);
					cardData2.borderType = (ECardBorderType)(num3 % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
					cardData2.isFoil = (num3 % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
					cardData2.isDestiny = true;
					cardData2.expansionType = this.m_ExpansionType;
					int cardAmount2 = CPlayerData.GetCardAmount(cardData2);
					int num4 = 0;
					if (cardAmount2 > 1)
					{
						num4 = Mathf.RoundToInt(CPlayerData.GetCardMarketPrice(cardData2) * 100000f);
					}
					else if (cardAmount2 == 1)
					{
						num4 = Mathf.RoundToInt(CPlayerData.GetCardMarketPrice(cardData2) * 1f);
					}
					int index2 = this.m_SortTempList.Count;
					for (int n = 0; n < this.m_SortTempList.Count; n++)
					{
						if (num4 > this.m_SortTempList[n])
						{
							index2 = n;
							break;
						}
					}
					this.m_SortTempList.Insert(index2, num4);
					this.m_SortedIndexList.Insert(index2, num);
					num++;
					num3++;
				}
			}
		}
	}

	// Token: 0x0600008C RID: 140 RVA: 0x00008F74 File Offset: 0x00007174
	private void SortByTotalValueAmount()
	{
		this.m_SortedIndexList.Clear();
		this.m_SortTempList.Clear();
		int num = 0;
		for (int i = 0; i < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; i++)
		{
			for (int j = 0; j < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); j++)
			{
				CardData cardData = new CardData();
				cardData.monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(num, this.m_ExpansionType);
				cardData.borderType = (ECardBorderType)(num % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
				cardData.isFoil = (num % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
				cardData.isDestiny = false;
				cardData.expansionType = this.m_ExpansionType;
				int cardAmount = CPlayerData.GetCardAmount(cardData);
				int num2 = 0;
				if (cardAmount > 0)
				{
					num2 = cardAmount * Mathf.RoundToInt(CPlayerData.GetCardMarketPrice(cardData) * 100f);
				}
				int index = this.m_SortTempList.Count;
				for (int k = 0; k < this.m_SortTempList.Count; k++)
				{
					if (num2 > this.m_SortTempList[k])
					{
						index = k;
						break;
					}
				}
				this.m_SortTempList.Insert(index, num2);
				this.m_SortedIndexList.Insert(index, num);
				num++;
			}
		}
		if (this.m_ExpansionType == ECardExpansionType.Ghost)
		{
			int num3 = 0;
			for (int l = 0; l < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; l++)
			{
				for (int m = 0; m < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); m++)
				{
					CardData cardData2 = new CardData();
					cardData2.monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(num3, this.m_ExpansionType);
					cardData2.borderType = (ECardBorderType)(num3 % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
					cardData2.isFoil = (num3 % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
					cardData2.isDestiny = true;
					cardData2.expansionType = this.m_ExpansionType;
					int cardAmount2 = CPlayerData.GetCardAmount(cardData2);
					int num4 = 0;
					if (cardAmount2 > 0)
					{
						num4 = cardAmount2 * Mathf.RoundToInt(CPlayerData.GetCardMarketPrice(cardData2) * 100f);
					}
					int index2 = this.m_SortTempList.Count;
					for (int n = 0; n < this.m_SortTempList.Count; n++)
					{
						if (num4 > this.m_SortTempList[n])
						{
							index2 = n;
							break;
						}
					}
					this.m_SortTempList.Insert(index2, num4);
					this.m_SortedIndexList.Insert(index2, num);
					num++;
					num3++;
				}
			}
		}
	}

	// Token: 0x0600008D RID: 141 RVA: 0x00009210 File Offset: 0x00007410
	private void SortByCardType(bool isCompactView)
	{
		this.m_SortedIndexList.Clear();
		this.m_SortTempList.Clear();
		for (int i = 0; i < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); i++)
		{
			for (int j = 0; j < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; j++)
			{
				int num = j * CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true) + i;
				int cardAmountByIndex = CPlayerData.GetCardAmountByIndex(num, this.m_ExpansionType, false);
				if (isCompactView && cardAmountByIndex == 0)
				{
					this.m_SortTempList.Add(num);
				}
				else
				{
					this.m_SortedIndexList.Add(num);
				}
			}
		}
		if (this.m_ExpansionType == ECardExpansionType.Ghost)
		{
			int num2 = 0;
			for (int k = 0; k < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); k++)
			{
				for (int l = 0; l < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; l++)
				{
					int num = l * CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true) + k + InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true);
					int cardAmountByIndex2 = CPlayerData.GetCardAmountByIndex(num2, this.m_ExpansionType, true);
					if (isCompactView && cardAmountByIndex2 == 0)
					{
						this.m_SortTempList.Add(num);
					}
					else
					{
						this.m_SortedIndexList.Add(num);
					}
					num2++;
				}
			}
		}
		for (int m = 0; m < this.m_SortTempList.Count; m++)
		{
			this.m_SortedIndexList.Add(this.m_SortTempList[m]);
		}
	}

	// Token: 0x0600008E RID: 142 RVA: 0x00009394 File Offset: 0x00007594
	private void SortByCardRarity(bool isCompactView)
	{
		this.m_SortedIndexList.Clear();
		this.m_SortTempList.Clear();
		for (int i = 0; i < 4; i++)
		{
			int num = 0;
			for (int j = 0; j < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; j++)
			{
				for (int k = 0; k < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); k++)
				{
					if (InventoryBase.GetMonsterData(CPlayerData.GetMonsterTypeFromCardSaveIndex(num, this.m_ExpansionType)).Rarity == (ERarity)i)
					{
						int cardAmountByIndex = CPlayerData.GetCardAmountByIndex(num, this.m_ExpansionType, false);
						if (isCompactView && cardAmountByIndex == 0)
						{
							this.m_SortTempList.Add(num);
						}
						else
						{
							this.m_SortedIndexList.Add(num);
						}
					}
					num++;
				}
			}
		}
		if (this.m_ExpansionType == ECardExpansionType.Ghost)
		{
			for (int l = 0; l < 4; l++)
			{
				int num = 0;
				for (int m = 0; m < InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count; m++)
				{
					for (int n = 0; n < CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true); n++)
					{
						if (InventoryBase.GetMonsterData(CPlayerData.GetMonsterTypeFromCardSaveIndex(num, this.m_ExpansionType)).Rarity == (ERarity)l)
						{
							int cardAmountByIndex2 = CPlayerData.GetCardAmountByIndex(num, this.m_ExpansionType, true);
							if (isCompactView && cardAmountByIndex2 == 0)
							{
								this.m_SortTempList.Add(num + InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true));
							}
							else
							{
								this.m_SortedIndexList.Add(num + InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true));
							}
						}
						num++;
					}
				}
			}
		}
		for (int num2 = 0; num2 < this.m_SortTempList.Count; num2++)
		{
			this.m_SortedIndexList.Add(this.m_SortTempList[num2]);
		}
	}

	// Token: 0x0600008F RID: 143 RVA: 0x00009574 File Offset: 0x00007774
	private void OnSortingMethodUpdated(bool backToFirstPage)
	{
		if (backToFirstPage)
		{
			this.m_Index = 1;
		}
		if (this.m_CanUpdateSort)
		{
			this.m_CanUpdateSort = false;
			switch (this.m_SortingType)
			{
			case ECollectionSortingType.Default:
				this.SortByDefault();
				break;
			case ECollectionSortingType.Amount:
				this.SortByCardAmount();
				break;
			case ECollectionSortingType.Price:
				this.SortByPriceAmount();
				break;
			case ECollectionSortingType.Type:
				this.SortByCardType(false);
				break;
			case ECollectionSortingType.Rarity:
				this.SortByCardRarity(false);
				break;
			case ECollectionSortingType.DuplicatePrice:
				this.SortByDuplicatePriceAmount();
				break;
			case ECollectionSortingType.TotalValue:
				this.SortByTotalValueAmount();
				break;
			}
		}
		this.UpdateBinderAllCardUI(0, this.m_Index);
		this.UpdateBinderAllCardUI(1, this.m_Index + 1);
		this.UpdateBinderAllCardUI(2, this.m_Index - 1);
	}

	// Token: 0x06000090 RID: 144 RVA: 0x00009628 File Offset: 0x00007828
	private void UpdateBinderAllCardUI(int binderIndex, int pageIndex)
	{
		if (pageIndex <= 0 || pageIndex > this.m_MaxIndex)
		{
			return;
		}
		for (int i = 0; i < this.m_BinderPageGrpList[binderIndex].m_CardList.Count; i++)
		{
			int num = (pageIndex - 1) * 12 + i;
			if (num >= this.m_SortedIndexList.Count)
			{
				this.m_BinderPageGrpList[binderIndex].SetSingleCard(i, null, 0);
			}
			else
			{
				int num2 = this.m_SortedIndexList[num];
				bool isDestiny = false;
				if (this.m_ExpansionType == ECardExpansionType.Ghost && num2 >= InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true))
				{
					isDestiny = true;
					num2 -= InventoryBase.GetShownMonsterList(this.m_ExpansionType).Count * CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true);
				}
				CardData cardData = new CardData();
				cardData.monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(num2, this.m_ExpansionType);
				cardData.isFoil = (num2 % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
				cardData.borderType = (ECardBorderType)(num2 % CPlayerData.GetCardAmountPerMonsterType(this.m_ExpansionType, false));
				cardData.isDestiny = isDestiny;
				cardData.expansionType = this.m_ExpansionType;
				int cardAmountByIndex = CPlayerData.GetCardAmountByIndex(num2, cardData.expansionType, cardData.isDestiny);
				this.m_BinderPageGrpList[binderIndex].SetSingleCard(i, cardData, cardAmountByIndex);
			}
		}
	}

	// Token: 0x06000091 RID: 145 RVA: 0x0000978A File Offset: 0x0000798A
	public void SetCanUpdateSort(bool canSort)
	{
		this.m_CanUpdateSort = canSort;
	}

	// Token: 0x040000BA RID: 186
	public Animator m_BookAnim;

	// Token: 0x040000BB RID: 187
	public Animator m_BinderThicknessAnim;

	// Token: 0x040000BC RID: 188
	public List<BinderPageGrp> m_BinderPageGrpList;

	// Token: 0x040000BD RID: 189
	public Animation m_ShowHideAnim;

	// Token: 0x040000BE RID: 190
	public Transform m_InteractableCardFollowTransform;

	// Token: 0x040000BF RID: 191
	public List<InteractableCard3d> m_InteractableCard3dList;

	// Token: 0x040000C0 RID: 192
	public CollectionBinderUI m_CollectionBinderUI;

	// Token: 0x040000C1 RID: 193
	public CardOpeningSequenceUI m_CardOpeningSequenceUI;

	// Token: 0x040000C2 RID: 194
	public ImageFadeInOut m_BlackBGFade;

	// Token: 0x040000C3 RID: 195
	public CardPricePopupUI m_CardPricePopupUI;

	// Token: 0x040000C4 RID: 196
	private bool m_OpenBinder;

	// Token: 0x040000C5 RID: 197
	private bool m_CloseBinder;

	// Token: 0x040000C6 RID: 198
	private bool m_GoNext;

	// Token: 0x040000C7 RID: 199
	private bool m_GoPrevious;

	// Token: 0x040000C8 RID: 200
	private bool m_GoNext10;

	// Token: 0x040000C9 RID: 201
	private bool m_GoPrevious10;

	// Token: 0x040000CA RID: 202
	private bool m_CanFlip = true;

	// Token: 0x040000CB RID: 203
	private bool m_IsBookOpen;

	// Token: 0x040000CC RID: 204
	private bool m_CanUpdateSort = true;

	// Token: 0x040000CD RID: 205
	private int m_Index = 1;

	// Token: 0x040000CE RID: 206
	private int m_MaxIndex = 1;

	// Token: 0x040000CF RID: 207
	private int m_CurrentRaycastedCardIndex;

	// Token: 0x040000D0 RID: 208
	private ECardExpansionType m_ExpansionType;

	// Token: 0x040000D1 RID: 209
	private Transform m_TargetFollowPos;

	// Token: 0x040000D2 RID: 210
	private Vector3 m_TargetLerpPos;

	// Token: 0x040000D3 RID: 211
	private Vector3 m_OffsetPos;

	// Token: 0x040000D4 RID: 212
	private Quaternion m_StartRot;

	// Token: 0x040000D5 RID: 213
	private Quaternion m_TargetLerpRot;

	// Token: 0x040000D6 RID: 214
	private float m_LerpTimer;

	// Token: 0x040000D7 RID: 215
	private bool m_IsInViewCardAlbumMode;

	// Token: 0x040000D8 RID: 216
	private bool m_IsLerpingPos;

	// Token: 0x040000D9 RID: 217
	private bool m_IsHidingAlbum;

	// Token: 0x040000DA RID: 218
	private bool m_IsSorting;

	// Token: 0x040000DB RID: 219
	private Coroutine m_CanFlipCoroutine;

	// Token: 0x040000DC RID: 220
	private List<int> m_SortedIndexList = new List<int>();

	// Token: 0x040000DD RID: 221
	private List<int> m_SortTempList = new List<int>();

	// Token: 0x040000DE RID: 222
	private ECollectionSortingType m_SortingType;

	// Token: 0x040000DF RID: 223
	public bool m_IsHoldingCardCloseUp;

	// Token: 0x040000E0 RID: 224
	public bool m_IsExitingCardCloseUp;

	// Token: 0x040000E1 RID: 225
	public InteractableCard3d m_CurrentRaycastedInteractableCard3d;

	// Token: 0x040000E2 RID: 226
	public InteractableCard3d m_CurrentViewInteractableCard3d;

	// Token: 0x040000E3 RID: 227
	public InteractableCard3d m_CurrentSpawnedInteractableCard3d;
}
