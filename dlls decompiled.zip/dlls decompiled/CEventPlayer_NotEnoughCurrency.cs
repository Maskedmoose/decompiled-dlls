﻿using System;

// Token: 0x020000AF RID: 175
public class CEventPlayer_NotEnoughCurrency : CEvent
{
	// Token: 0x17000011 RID: 17
	// (get) Token: 0x060006F8 RID: 1784 RVA: 0x00037FC7 File Offset: 0x000361C7
	// (set) Token: 0x060006F9 RID: 1785 RVA: 0x00037FCF File Offset: 0x000361CF
	public int m_ResourceIndex { get; private set; }

	// Token: 0x060006FA RID: 1786 RVA: 0x00037FD8 File Offset: 0x000361D8
	public CEventPlayer_NotEnoughCurrency(int resourceIndex)
	{
		this.m_ResourceIndex = resourceIndex;
	}
}
