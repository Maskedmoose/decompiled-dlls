﻿using System;
using UnityEngine;

// Token: 0x0200013A RID: 314
public class RotateMoveCamera : MonoBehaviour
{
	// Token: 0x060008FA RID: 2298 RVA: 0x000418AC File Offset: 0x0003FAAC
	private void Update()
	{
		float axis = Input.GetAxis("Mouse X");
		float axis2 = Input.GetAxis("Mouse Y");
		if (axis != this.MouseX || axis2 != this.MouseY)
		{
			this.rotationX += axis * this.sensX * Time.deltaTime;
			this.rotationY += axis2 * this.sensY * Time.deltaTime;
			this.rotationY = Mathf.Clamp(this.rotationY, this.minY, this.maxY);
			this.MouseX = axis;
			this.MouseY = axis2;
			this.Camera.transform.localEulerAngles = new Vector3(-this.rotationY, this.rotationX, 0f);
		}
		if (Input.GetKey(KeyCode.W))
		{
			base.transform.Translate(new Vector3(0f, 0f, 0.01f));
		}
		else if (Input.GetKey(KeyCode.S))
		{
			base.transform.Translate(new Vector3(0f, 0f, -0.01f));
		}
		if (Input.GetKey(KeyCode.D))
		{
			base.transform.Translate(new Vector3(0.01f, 0f, 0f));
			return;
		}
		if (Input.GetKey(KeyCode.A))
		{
			base.transform.Translate(new Vector3(-0.01f, 0f, 0f));
		}
	}

	// Token: 0x0400110A RID: 4362
	public GameObject Camera;

	// Token: 0x0400110B RID: 4363
	public float minX = -360f;

	// Token: 0x0400110C RID: 4364
	public float maxX = 360f;

	// Token: 0x0400110D RID: 4365
	public float minY = -45f;

	// Token: 0x0400110E RID: 4366
	public float maxY = 45f;

	// Token: 0x0400110F RID: 4367
	public float sensX = 100f;

	// Token: 0x04001110 RID: 4368
	public float sensY = 100f;

	// Token: 0x04001111 RID: 4369
	private float rotationY;

	// Token: 0x04001112 RID: 4370
	private float rotationX;

	// Token: 0x04001113 RID: 4371
	private float MouseX;

	// Token: 0x04001114 RID: 4372
	private float MouseY;
}
