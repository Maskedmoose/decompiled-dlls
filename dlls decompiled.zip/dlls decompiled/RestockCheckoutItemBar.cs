﻿using System;
using TMPro;

// Token: 0x02000075 RID: 117
public class RestockCheckoutItemBar : UIElementBase
{
	// Token: 0x060004BB RID: 1211 RVA: 0x00029275 File Offset: 0x00027475
	public void Init(RestockItemScreen restockItemScreen)
	{
		this.m_RestockItemScreen = restockItemScreen;
	}

	// Token: 0x060004BC RID: 1212 RVA: 0x00029280 File Offset: 0x00027480
	public void UpdateData(int index, int boxCount)
	{
		this.m_Index = index;
		this.m_BoxCount = boxCount;
		RestockData restockData = InventoryBase.GetRestockData(index);
		this.m_ItemType = restockData.itemType;
		ItemData itemData = InventoryBase.GetItemData(this.m_ItemType);
		int maxItemCountInBox = RestockManager.GetMaxItemCountInBox(this.m_ItemType, restockData.isBigBox);
		this.m_TotalItemUnitCount = this.m_BoxCount * maxItemCountInBox;
		this.m_UnitPrice = CPlayerData.GetItemCost(this.m_ItemType);
		this.m_TotalPrice = this.m_UnitPrice * (float)this.m_TotalItemUnitCount;
		this.m_ItemNameText.text = itemData.GetName() + " (" + maxItemCountInBox.ToString() + ")";
		this.m_AmountText.text = this.m_BoxCount.ToString();
		this.m_UnitPriceText.text = GameInstance.GetPriceString(this.m_UnitPrice, false, true, false, "F2");
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_TotalPrice, false, true, false, "F2");
	}

	// Token: 0x060004BD RID: 1213 RVA: 0x00029378 File Offset: 0x00027578
	public float GetUnitPrice()
	{
		return this.m_UnitPrice;
	}

	// Token: 0x060004BE RID: 1214 RVA: 0x00029380 File Offset: 0x00027580
	public float GetTotalPrice()
	{
		return this.m_TotalPrice;
	}

	// Token: 0x060004BF RID: 1215 RVA: 0x00029388 File Offset: 0x00027588
	public int GetTotalUnit()
	{
		return this.m_TotalItemUnitCount;
	}

	// Token: 0x060004C0 RID: 1216 RVA: 0x00029390 File Offset: 0x00027590
	public EItemType GetItemType()
	{
		return this.m_ItemType;
	}

	// Token: 0x060004C1 RID: 1217 RVA: 0x00029398 File Offset: 0x00027598
	public void OnPressAddItem()
	{
		this.m_RestockItemScreen.AddToCartForCheckout(this.m_Index, 1);
	}

	// Token: 0x060004C2 RID: 1218 RVA: 0x000293AC File Offset: 0x000275AC
	public void OnPressRemoveItem()
	{
		this.m_RestockItemScreen.RemoveFromCartForCheckout(this.m_Index, 1);
	}

	// Token: 0x060004C3 RID: 1219 RVA: 0x000293C0 File Offset: 0x000275C0
	public void OnPressClearItem()
	{
		this.m_RestockItemScreen.RemoveFromCartForCheckout(this.m_Index, this.m_BoxCount);
	}

	// Token: 0x04000628 RID: 1576
	public TextMeshProUGUI m_ItemNameText;

	// Token: 0x04000629 RID: 1577
	public TextMeshProUGUI m_AmountText;

	// Token: 0x0400062A RID: 1578
	public TextMeshProUGUI m_UnitPriceText;

	// Token: 0x0400062B RID: 1579
	public TextMeshProUGUI m_TotalPriceText;

	// Token: 0x0400062C RID: 1580
	private int m_Index;

	// Token: 0x0400062D RID: 1581
	private int m_BoxCount;

	// Token: 0x0400062E RID: 1582
	private int m_TotalItemUnitCount;

	// Token: 0x0400062F RID: 1583
	private float m_UnitPrice;

	// Token: 0x04000630 RID: 1584
	private float m_TotalPrice;

	// Token: 0x04000631 RID: 1585
	private EItemType m_ItemType;

	// Token: 0x04000632 RID: 1586
	private RestockItemScreen m_RestockItemScreen;
}
