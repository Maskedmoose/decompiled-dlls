﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000102 RID: 258
public class DeactivateAfterTime : MonoBehaviour
{
	// Token: 0x06000799 RID: 1945 RVA: 0x00039357 File Offset: 0x00037557
	private void OnEnable()
	{
		this.m_CurrentCoroutine = base.StartCoroutine(this.DestroyDelay());
	}

	// Token: 0x0600079A RID: 1946 RVA: 0x0003936B File Offset: 0x0003756B
	private void OnDisable()
	{
		if (this.m_CurrentCoroutine != null)
		{
			base.StopCoroutine(this.m_CurrentCoroutine);
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x0600079B RID: 1947 RVA: 0x0003938D File Offset: 0x0003758D
	private IEnumerator DestroyDelay()
	{
		yield return new WaitForSeconds(this.m_Timer);
		base.gameObject.SetActive(false);
		yield break;
	}

	// Token: 0x04000ECF RID: 3791
	public float m_Timer = 1f;

	// Token: 0x04000ED0 RID: 3792
	private Coroutine m_CurrentCoroutine;
}
