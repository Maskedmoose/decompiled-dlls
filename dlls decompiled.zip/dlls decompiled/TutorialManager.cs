﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000055 RID: 85
public class TutorialManager : CSingleton<TutorialManager>
{
	// Token: 0x060003E1 RID: 993 RVA: 0x00022B64 File Offset: 0x00020D64
	private void Awake()
	{
		for (int i = 0; i < CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList.Count; i++)
		{
			CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[i].CloseScreen();
		}
	}

	// Token: 0x060003E2 RID: 994 RVA: 0x00022BA0 File Offset: 0x00020DA0
	private void Update()
	{
		if (this.m_FinishedTutorial)
		{
			return;
		}
		this.m_TempShowTutorialIndex = CPlayerData.m_TutorialIndex;
		this.m_TutorialDataList = CPlayerData.m_TutorialDataList;
		if (this.m_IsShowingCanvasGrpAlpha)
		{
			this.m_CanvasGrpAlphaLerpTimer += Time.deltaTime * 2f;
			this.m_CanvasGrp.alpha = Mathf.Lerp(0f, 1f, this.m_CanvasGrpAlphaLerpTimer);
			if (this.m_CanvasGrpAlphaLerpTimer >= 1f)
			{
				this.m_IsShowingCanvasGrpAlpha = false;
				this.m_CanvasGrpAlphaLerpTimer = 1f;
				return;
			}
		}
		else if (this.m_IsHidingCanvasGrpAlpha)
		{
			this.m_CanvasGrpAlphaLerpTimer -= Time.deltaTime * 2f;
			this.m_CanvasGrp.alpha = Mathf.Lerp(0f, 1f, this.m_CanvasGrpAlphaLerpTimer);
			if (this.m_CanvasGrpAlphaLerpTimer <= 0f)
			{
				this.m_IsShowingCanvasGrpAlpha = false;
				this.m_CanvasGrpAlphaLerpTimer = 0f;
			}
		}
	}

	// Token: 0x060003E3 RID: 995 RVA: 0x00022C8C File Offset: 0x00020E8C
	public static void AddTaskValue(ETutorialTaskCondition tutorialTaskCondition, float valueAdd)
	{
		if (CSingleton<TutorialManager>.Instance.m_FinishedTutorial)
		{
			return;
		}
		bool flag = false;
		for (int i = 0; i < CPlayerData.m_TutorialDataList.Count; i++)
		{
			if (CPlayerData.m_TutorialDataList[i].tutorialTaskCondition == tutorialTaskCondition)
			{
				flag = true;
				CPlayerData.m_TutorialDataList[i].value += valueAdd;
			}
		}
		if (!flag)
		{
			TutorialData tutorialData = new TutorialData();
			tutorialData.tutorialTaskCondition = tutorialTaskCondition;
			tutorialData.value = valueAdd;
			CPlayerData.m_TutorialDataList.Add(tutorialData);
		}
		for (int j = 0; j < CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList.Count; j++)
		{
			CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[j].AddTaskValue(valueAdd, tutorialTaskCondition);
		}
		CSingleton<TutorialManager>.Instance.EvaluateTaskVisibility();
	}

	// Token: 0x060003E4 RID: 996 RVA: 0x00022D48 File Offset: 0x00020F48
	public void EvaluateTaskVisibility()
	{
		bool flag = false;
		for (int i = 0; i < CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList.Count; i++)
		{
			if (CPlayerData.m_TutorialIndex == 0 || flag || CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[i].IsTaskFinish())
			{
				CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[i].CloseScreen();
			}
			else
			{
				flag = true;
				CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[i].OpenScreen();
				CPlayerData.m_TutorialIndex = i + 1;
			}
		}
		if (!flag)
		{
			this.m_FinishedTutorial = true;
		}
	}

	// Token: 0x060003E5 RID: 997 RVA: 0x00022DD4 File Offset: 0x00020FD4
	public static void SetGameUIVisible(bool isVisible)
	{
		if (isVisible)
		{
			if (CSingleton<TutorialManager>.Instance.m_CanvasGrp.alpha != 1f)
			{
				CSingleton<TutorialManager>.Instance.m_IsShowingCanvasGrpAlpha = true;
				CSingleton<TutorialManager>.Instance.m_IsHidingCanvasGrpAlpha = false;
				return;
			}
		}
		else if (CSingleton<TutorialManager>.Instance.m_CanvasGrp.alpha != 0f)
		{
			CSingleton<TutorialManager>.Instance.m_IsShowingCanvasGrpAlpha = false;
			CSingleton<TutorialManager>.Instance.m_IsHidingCanvasGrpAlpha = true;
		}
	}

	// Token: 0x060003E6 RID: 998 RVA: 0x00022E3D File Offset: 0x0002103D
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x060003E7 RID: 999 RVA: 0x00022E5E File Offset: 0x0002105E
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x060003E8 RID: 1000 RVA: 0x00022E80 File Offset: 0x00021080
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		if (CPlayerData.m_TutorialIndex == 0)
		{
			this.m_TutorialTargetIndicator.gameObject.SetActive(true);
			this.m_ShopRenamer.SetIsTutorial();
			return;
		}
		if (CPlayerData.GetIsItemLicenseUnlocked(2) || CPlayerData.GetIsItemLicenseUnlocked(3))
		{
			bool flag = false;
			for (int i = 0; i < CPlayerData.m_TutorialDataList.Count; i++)
			{
				if (CPlayerData.m_TutorialDataList[i].tutorialTaskCondition == ETutorialTaskCondition.UnlockBasicCardBox)
				{
					flag = true;
					CPlayerData.m_TutorialDataList[i].value = 1f;
					break;
				}
			}
			if (!flag)
			{
				TutorialData tutorialData = new TutorialData();
				tutorialData.tutorialTaskCondition = ETutorialTaskCondition.UnlockBasicCardBox;
				tutorialData.value = 1f;
				CPlayerData.m_TutorialDataList.Add(tutorialData);
			}
		}
		this.m_TutorialTargetIndicator.gameObject.SetActive(false);
		for (int j = 0; j < CPlayerData.m_TutorialDataList.Count; j++)
		{
			for (int k = 0; k < CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList.Count; k++)
			{
				CSingleton<TutorialManager>.Instance.m_TutorialSubGroupList[k].AddTaskValue(CPlayerData.m_TutorialDataList[j].value, CPlayerData.m_TutorialDataList[j].tutorialTaskCondition);
			}
		}
		this.EvaluateTaskVisibility();
	}

	// Token: 0x040004A6 RID: 1190
	public ShopRenamer m_ShopRenamer;

	// Token: 0x040004A7 RID: 1191
	public GameObject m_TutorialTargetIndicator;

	// Token: 0x040004A8 RID: 1192
	public List<TutorialSubGroup> m_TutorialSubGroupList;

	// Token: 0x040004A9 RID: 1193
	public int m_TempShowTutorialIndex;

	// Token: 0x040004AA RID: 1194
	public List<TutorialData> m_TutorialDataList = new List<TutorialData>();

	// Token: 0x040004AB RID: 1195
	public CanvasGroup m_CanvasGrp;

	// Token: 0x040004AC RID: 1196
	private bool m_IsShowingCanvasGrpAlpha;

	// Token: 0x040004AD RID: 1197
	private bool m_IsHidingCanvasGrpAlpha;

	// Token: 0x040004AE RID: 1198
	private bool m_FinishedTutorial;

	// Token: 0x040004AF RID: 1199
	private float m_CanvasGrpAlphaLerpTimer;
}
