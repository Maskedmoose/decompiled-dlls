﻿using System;
using UnityEngine;

// Token: 0x02000082 RID: 130
public class UIScreenBase : MonoBehaviour
{
	// Token: 0x0600051C RID: 1308 RVA: 0x0002BAE2 File Offset: 0x00029CE2
	protected virtual void Awake()
	{
		this.m_ControllerScreenUIExtension = base.GetComponent<ControllerScreenUIExtension>();
	}

	// Token: 0x0600051D RID: 1309 RVA: 0x0002BAF0 File Offset: 0x00029CF0
	protected virtual void Start()
	{
		this.m_ScreenGroup.SetActive(false);
	}

	// Token: 0x0600051E RID: 1310 RVA: 0x0002BAFE File Offset: 0x00029CFE
	protected void Update()
	{
		if (!this.m_FinishLoading)
		{
			return;
		}
		if (this.m_CurrentChildScreen)
		{
			return;
		}
		if (this.m_IsScreenOpen)
		{
			this.RunUpdate();
		}
	}

	// Token: 0x0600051F RID: 1311 RVA: 0x0002BB25 File Offset: 0x00029D25
	protected virtual void RunUpdate()
	{
	}

	// Token: 0x06000520 RID: 1312 RVA: 0x0002BB27 File Offset: 0x00029D27
	protected virtual void Init()
	{
		this.m_FinishLoading = true;
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x0002BB30 File Offset: 0x00029D30
	public void SetParentScreen(UIScreenBase parentScreen)
	{
		this.m_ParentScreen = parentScreen;
	}

	// Token: 0x06000522 RID: 1314 RVA: 0x0002BB39 File Offset: 0x00029D39
	protected void OpenChildScreen(UIScreenBase childScreen)
	{
		this.m_CurrentChildScreen = childScreen;
		this.m_CurrentChildScreen.SetParentScreen(this);
		childScreen.OpenScreen();
	}

	// Token: 0x06000523 RID: 1315 RVA: 0x0002BB54 File Offset: 0x00029D54
	protected void CloseChildScreen(UIScreenBase childScreen)
	{
		if (this.m_CurrentChildScreen == childScreen)
		{
			this.m_CurrentChildScreen = null;
			this.OnChildScreenClosed(childScreen);
		}
	}

	// Token: 0x06000524 RID: 1316 RVA: 0x0002BB72 File Offset: 0x00029D72
	protected virtual void OnChildScreenClosed(UIScreenBase childScreen)
	{
	}

	// Token: 0x06000525 RID: 1317 RVA: 0x0002BB74 File Offset: 0x00029D74
	public void OpenScreen()
	{
		if (this.m_CloseIfScreenOpened && this.m_IsScreenOpen)
		{
			this.CloseScreen();
			return;
		}
		this.OnOpenScreen();
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x06000526 RID: 1318 RVA: 0x0002BB9E File Offset: 0x00029D9E
	protected virtual void OnOpenScreen()
	{
		this.m_IsScreenOpen = true;
		this.m_ScreenGroup.SetActive(true);
	}

	// Token: 0x06000527 RID: 1319 RVA: 0x0002BBB3 File Offset: 0x00029DB3
	public void CloseScreen()
	{
		if (!CSingleton<TouchManager>.Instance.m_AllowButtonPress)
		{
			return;
		}
		if (!this.m_IsScreenOpen)
		{
			return;
		}
		this.OnCloseScreen();
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x06000528 RID: 1320 RVA: 0x0002BBDC File Offset: 0x00029DDC
	protected virtual void OnCloseScreen()
	{
		this.m_IsScreenOpen = false;
		this.m_ScreenGroup.SetActive(false);
		if (this.m_ParentScreen)
		{
			this.m_ParentScreen.CloseChildScreen(this);
			this.m_ParentScreen = null;
		}
	}

	// Token: 0x06000529 RID: 1321 RVA: 0x0002BC11 File Offset: 0x00029E11
	public void OnPressBack()
	{
		if (this.m_CurrentChildScreen)
		{
			this.m_CurrentChildScreen.OnPressBack();
			return;
		}
		this.CloseScreen();
	}

	// Token: 0x0600052A RID: 1322 RVA: 0x0002BC32 File Offset: 0x00029E32
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
		}
	}

	// Token: 0x0600052B RID: 1323 RVA: 0x0002BC66 File Offset: 0x00029E66
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
		}
	}

	// Token: 0x0600052C RID: 1324 RVA: 0x0002BC9A File Offset: 0x00029E9A
	protected virtual void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
	}

	// Token: 0x0600052D RID: 1325 RVA: 0x0002BCA2 File Offset: 0x00029EA2
	protected virtual void OnFinishHideLoadingScreen(CEventPlayer_FinishHideLoadingScreen evt)
	{
		this.m_FinishHideLoadingScreen = true;
		if (this.m_FinishLoading)
		{
			return;
		}
		this.Init();
	}

	// Token: 0x040006C1 RID: 1729
	public GameObject m_ScreenGroup;

	// Token: 0x040006C2 RID: 1730
	public bool m_CloseIfScreenOpened = true;

	// Token: 0x040006C3 RID: 1731
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040006C4 RID: 1732
	protected UIScreenBase m_ParentScreen;

	// Token: 0x040006C5 RID: 1733
	protected bool m_IsScreenOpen;

	// Token: 0x040006C6 RID: 1734
	protected bool m_FinishLoading;

	// Token: 0x040006C7 RID: 1735
	protected bool m_FinishHideLoadingScreen;

	// Token: 0x040006C8 RID: 1736
	protected UIScreenBase m_CurrentChildScreen;
}
