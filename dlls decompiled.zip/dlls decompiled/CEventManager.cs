﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000A7 RID: 167
public class CEventManager : CSingleton<CEventManager>
{
	// Token: 0x060006B2 RID: 1714 RVA: 0x0003750D File Offset: 0x0003570D
	protected CEventManager()
	{
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x00037538 File Offset: 0x00035738
	private void Update()
	{
		float num = 0f;
		while (this.m_queueEvent.Count > 0)
		{
			if (this.m_limitQueueProcessing && num > this.m_queueProcessTime)
			{
				return;
			}
			CEvent evt = this.m_queueEvent.Dequeue() as CEvent;
			this.OnNotify(evt);
			if (this.m_limitQueueProcessing)
			{
				num += Time.deltaTime;
			}
		}
	}

	// Token: 0x060006B4 RID: 1716 RVA: 0x00037595 File Offset: 0x00035795
	public static void QueueEvent(CEvent evt)
	{
		if ((Application.isPlaying || Application.isMobilePlatform) && !CSingleton<CEventManager>.IsQuitting)
		{
			CSingleton<CEventManager>.Instance.QueueEventPrivate(evt);
		}
	}

	// Token: 0x060006B5 RID: 1717 RVA: 0x000375B8 File Offset: 0x000357B8
	public static void AddListener<T>(CEventManager.EventDelegate<T> listener) where T : CEvent
	{
		if ((Application.isPlaying || Application.isMobilePlatform) && !CSingleton<CEventManager>.IsQuitting)
		{
			CSingleton<CEventManager>.Instance.AddListenerPrivate<T>(listener);
		}
	}

	// Token: 0x060006B6 RID: 1718 RVA: 0x000375DA File Offset: 0x000357DA
	public static void RemoveListener<T>(CEventManager.EventDelegate<T> listener) where T : CEvent
	{
		if ((Application.isPlaying || Application.isMobilePlatform) && !CSingleton<CEventManager>.IsQuitting)
		{
			CSingleton<CEventManager>.Instance.RemoveListenerPrivate<T>(listener);
		}
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x000375FC File Offset: 0x000357FC
	private void AddListenerPrivate<T>(CEventManager.EventDelegate<T> listener) where T : CEvent
	{
		if (this.m_listenerLookup.ContainsKey(listener))
		{
			return;
		}
		CEventManager.EventDelegate eventDelegate = delegate(CEvent e)
		{
			listener((T)((object)e));
		};
		this.m_listenerLookup[listener] = eventDelegate;
		CEventManager.EventDelegate a;
		if (this.m_listeners.TryGetValue(typeof(T), out a))
		{
			a = (this.m_listeners[typeof(T)] = (CEventManager.EventDelegate)Delegate.Combine(a, eventDelegate));
			return;
		}
		this.m_listeners[typeof(T)] = eventDelegate;
	}

	// Token: 0x060006B8 RID: 1720 RVA: 0x0003769C File Offset: 0x0003589C
	public void RemoveListenerPrivate<T>(CEventManager.EventDelegate<T> listener) where T : CEvent
	{
		CEventManager.EventDelegate value;
		if (this.m_listenerLookup.TryGetValue(listener, out value))
		{
			CEventManager.EventDelegate eventDelegate;
			if (this.m_listeners.TryGetValue(typeof(T), out eventDelegate))
			{
				eventDelegate = (CEventManager.EventDelegate)Delegate.Remove(eventDelegate, value);
				if (eventDelegate == null)
				{
					this.m_listeners.Remove(typeof(T));
				}
				else
				{
					this.m_listeners[typeof(T)] = eventDelegate;
				}
			}
			this.m_listenerLookup.Remove(listener);
		}
	}

	// Token: 0x060006B9 RID: 1721 RVA: 0x0003771D File Offset: 0x0003591D
	public bool HasListener<T>(CEventManager.EventDelegate<T> listener) where T : CEvent
	{
		return this.m_listenerLookup.ContainsKey(listener);
	}

	// Token: 0x060006BA RID: 1722 RVA: 0x0003772C File Offset: 0x0003592C
	private void OnNotify(CEvent evt)
	{
		CEventManager.EventDelegate eventDelegate;
		if (this.m_listeners.TryGetValue(evt.GetType(), out eventDelegate) && eventDelegate != null)
		{
			eventDelegate(evt);
		}
	}

	// Token: 0x060006BB RID: 1723 RVA: 0x00037758 File Offset: 0x00035958
	private bool QueueEventPrivate(CEvent evt)
	{
		if (!this.m_listeners.ContainsKey(evt.GetType()))
		{
			return false;
		}
		this.m_queueEvent.Enqueue(evt);
		return true;
	}

	// Token: 0x060006BC RID: 1724 RVA: 0x0003777C File Offset: 0x0003597C
	private void RemoveAll()
	{
		this.m_listeners.Clear();
		this.m_listenerLookup.Clear();
	}

	// Token: 0x040008ED RID: 2285
	public bool m_limitQueueProcessing;

	// Token: 0x040008EE RID: 2286
	public float m_queueProcessTime;

	// Token: 0x040008EF RID: 2287
	private Queue m_queueEvent = new Queue();

	// Token: 0x040008F0 RID: 2288
	private Dictionary<Type, CEventManager.EventDelegate> m_listeners = new Dictionary<Type, CEventManager.EventDelegate>();

	// Token: 0x040008F1 RID: 2289
	private Dictionary<Delegate, CEventManager.EventDelegate> m_listenerLookup = new Dictionary<Delegate, CEventManager.EventDelegate>();

	// Token: 0x02000226 RID: 550
	// (Invoke) Token: 0x06000EF7 RID: 3831
	public delegate void EventDelegate<T>(T e) where T : CEvent;

	// Token: 0x02000227 RID: 551
	// (Invoke) Token: 0x06000EFB RID: 3835
	private delegate void EventDelegate(CEvent e);
}
