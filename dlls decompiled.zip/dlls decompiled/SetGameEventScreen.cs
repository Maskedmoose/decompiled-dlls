﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x0200007F RID: 127
public class SetGameEventScreen : UIScreenBase
{
	// Token: 0x06000501 RID: 1281 RVA: 0x0002AF20 File Offset: 0x00029120
	protected override void OnOpenScreen()
	{
		this.m_LastSetFee = PriceChangeManager.GetGameEventPrice(CPlayerData.m_GameEventFormat, true);
		base.OnOpenScreen();
		this.m_ShopNameText.text = CPlayerData.PlayerName;
		this.EvaluateText();
	}

	// Token: 0x06000502 RID: 1282 RVA: 0x0002AF4F File Offset: 0x0002914F
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x0002AF57 File Offset: 0x00029157
	public void OnPressSetPrice()
	{
		base.OpenChildScreen(this.m_SetPriceScreen);
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x0002AF74 File Offset: 0x00029174
	public void OnPressSetFormat()
	{
		base.OpenChildScreen(this.m_SetFormatScreen);
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x0002AF91 File Offset: 0x00029191
	public void OnPressReset()
	{
		CPlayerData.m_PendingGameEventFormat = EGameEventFormat.None;
		CPlayerData.m_PendingGameEventExpansionType = CPlayerData.m_GameEventExpansionType;
		PriceChangeManager.SetGameEventPrice(CPlayerData.m_GameEventFormat, this.m_LastSetFee);
		this.EvaluateText();
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x06000506 RID: 1286 RVA: 0x0002AFC8 File Offset: 0x000291C8
	protected override void OnChildScreenClosed(UIScreenBase childScreen)
	{
		base.OnChildScreenClosed(childScreen);
		this.EvaluateText();
	}

	// Token: 0x06000507 RID: 1287 RVA: 0x0002AFD8 File Offset: 0x000291D8
	private void EvaluateText()
	{
		if (CPlayerData.m_PendingGameEventFormat != EGameEventFormat.None)
		{
			GameEventData gameEventData = InventoryBase.GetGameEventData(CPlayerData.m_PendingGameEventFormat);
			this.m_FormatText.text = LocalizationManager.GetTranslation(this.m_FormatPrefix, true, 0, true, false, null, null, true) + " : " + gameEventData.GetName();
			this.m_CostText.text = string.Concat(new string[]
			{
				LocalizationManager.GetTranslation(this.m_CostPrefix, true, 0, true, false, null, null, true),
				" : ",
				GameInstance.GetPriceString((float)gameEventData.hostEventCost, false, true, false, "F2"),
				"/",
				LocalizationManager.GetTranslation(this.m_CostSuffix, true, 0, true, false, null, null, true)
			});
			this.m_FeeText.text = LocalizationManager.GetTranslation(this.m_FeePrefix, true, 0, true, false, null, null, true) + " : " + GameInstance.GetPriceString(PriceChangeManager.GetGameEventPrice(CPlayerData.m_PendingGameEventFormat, true), false, true, false, "F2") + LocalizationManager.GetTranslation(this.m_FeeSuffix, true, 0, true, false, null, null, true);
			this.m_PositiveEffectText.text = "(+) " + InventoryBase.GetPriceChangeTypeText(gameEventData.positivePriceChangeType, true);
			this.m_NegativeEffectText.text = "(-) " + InventoryBase.GetPriceChangeTypeText(gameEventData.negativePriceChangeType, false);
			this.m_CurrentGameEventText.gameObject.SetActive(false);
			this.m_NextGameEventText.gameObject.SetActive(true);
		}
		else
		{
			GameEventData gameEventData2 = InventoryBase.GetGameEventData(CPlayerData.m_GameEventFormat);
			this.m_FormatText.text = LocalizationManager.GetTranslation(this.m_FormatPrefix, true, 0, true, false, null, null, true) + " : " + gameEventData2.GetName();
			this.m_CostText.text = string.Concat(new string[]
			{
				LocalizationManager.GetTranslation(this.m_CostPrefix, true, 0, true, false, null, null, true),
				" : ",
				GameInstance.GetPriceString((float)gameEventData2.hostEventCost, false, true, false, "F2"),
				"/",
				LocalizationManager.GetTranslation(this.m_CostSuffix, true, 0, true, false, null, null, true)
			});
			this.m_FeeText.text = LocalizationManager.GetTranslation(this.m_FeePrefix, true, 0, true, false, null, null, true) + " : " + GameInstance.GetPriceString(PriceChangeManager.GetGameEventPrice(CPlayerData.m_GameEventFormat, true), false, true, false, "F2") + LocalizationManager.GetTranslation(this.m_FeeSuffix, true, 0, true, false, null, null, true);
			this.m_PositiveEffectText.text = "(+) " + InventoryBase.GetPriceChangeTypeText(gameEventData2.positivePriceChangeType, true);
			this.m_NegativeEffectText.text = "(-) " + InventoryBase.GetPriceChangeTypeText(gameEventData2.negativePriceChangeType, false);
			this.m_CurrentGameEventText.gameObject.SetActive(true);
			this.m_NextGameEventText.gameObject.SetActive(false);
		}
		if (CPlayerData.m_GameEventExpansionType != CPlayerData.m_PendingGameEventExpansionType)
		{
			this.m_CurrentGameEventText.gameObject.SetActive(false);
			this.m_NextGameEventText.gameObject.SetActive(true);
		}
	}

	// Token: 0x0400069D RID: 1693
	public SetGameEventPriceScreen m_SetPriceScreen;

	// Token: 0x0400069E RID: 1694
	public SetGameEventFormatScreen m_SetFormatScreen;

	// Token: 0x0400069F RID: 1695
	public GameObject m_CurrentGameEventText;

	// Token: 0x040006A0 RID: 1696
	public GameObject m_NextGameEventText;

	// Token: 0x040006A1 RID: 1697
	public TextMeshProUGUI m_ShopNameText;

	// Token: 0x040006A2 RID: 1698
	public TextMeshProUGUI m_FeeText;

	// Token: 0x040006A3 RID: 1699
	public TextMeshProUGUI m_FormatText;

	// Token: 0x040006A4 RID: 1700
	public TextMeshProUGUI m_CostText;

	// Token: 0x040006A5 RID: 1701
	public TextMeshProUGUI m_PositiveEffectText;

	// Token: 0x040006A6 RID: 1702
	public TextMeshProUGUI m_NegativeEffectText;

	// Token: 0x040006A7 RID: 1703
	private string m_FeePrefix = "Fee";

	// Token: 0x040006A8 RID: 1704
	private string m_FormatPrefix = "Format";

	// Token: 0x040006A9 RID: 1705
	private string m_CostPrefix = "Cost";

	// Token: 0x040006AA RID: 1706
	private string m_FeeSuffix = "hr";

	// Token: 0x040006AB RID: 1707
	private string m_CostSuffix = "day";

	// Token: 0x040006AC RID: 1708
	private float m_LastSetFee;
}
