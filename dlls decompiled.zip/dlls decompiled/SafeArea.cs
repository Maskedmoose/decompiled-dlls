﻿using System;
using UnityEngine;

// Token: 0x02000120 RID: 288
public class SafeArea : MonoBehaviour
{
	// Token: 0x06000865 RID: 2149 RVA: 0x0003EB20 File Offset: 0x0003CD20
	private void Awake()
	{
		this.Panel = base.GetComponent<RectTransform>();
		if (!this.m_IsManual)
		{
			this.Refresh();
		}
	}

	// Token: 0x06000866 RID: 2150 RVA: 0x0003EB3C File Offset: 0x0003CD3C
	private void Update()
	{
		if (this.m_IsManual)
		{
			return;
		}
		this.Refresh();
	}

	// Token: 0x06000867 RID: 2151 RVA: 0x0003EB50 File Offset: 0x0003CD50
	public void Refresh()
	{
		if (!base.enabled)
		{
			return;
		}
		Rect safeArea = this.GetSafeArea();
		if (safeArea != this.LastSafeArea)
		{
			this.ApplySafeArea(safeArea);
		}
	}

	// Token: 0x06000868 RID: 2152 RVA: 0x0003EB82 File Offset: 0x0003CD82
	private Rect GetSafeArea()
	{
		bool debugTestArea = this.m_DebugTestArea;
		return Screen.safeArea;
	}

	// Token: 0x06000869 RID: 2153 RVA: 0x0003EB90 File Offset: 0x0003CD90
	private void ApplySafeArea(Rect r)
	{
		this.LastSafeArea = r;
		Vector2 position = r.position;
		Vector2 anchorMax = r.position + r.size;
		position.x /= (float)Screen.width;
		position.y /= (float)Screen.height;
		anchorMax.x /= (float)Screen.width;
		anchorMax.y /= (float)Screen.height;
		position.x = this.Panel.anchorMin.x;
		anchorMax.x = this.Panel.anchorMax.x;
		this.Panel.anchorMin = position;
		this.Panel.anchorMax = anchorMax;
		Debug.LogFormat("New safe area applied to {0}: x={1}, y={2}, w={3}, h={4} on full extents w={5}, h={6}", new object[]
		{
			base.name,
			r.x,
			r.y,
			r.width,
			r.height,
			Screen.width,
			Screen.height
		});
	}

	// Token: 0x04001028 RID: 4136
	private RectTransform Panel;

	// Token: 0x04001029 RID: 4137
	private Rect LastSafeArea = new Rect(0f, 0f, 0f, 0f);

	// Token: 0x0400102A RID: 4138
	public Rect m_Test;

	// Token: 0x0400102B RID: 4139
	private Rect m_OffsetUI;

	// Token: 0x0400102C RID: 4140
	public bool m_DebugTestArea;

	// Token: 0x0400102D RID: 4141
	public bool m_IsManual;
}
