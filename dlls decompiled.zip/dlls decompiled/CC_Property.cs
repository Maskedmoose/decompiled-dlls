﻿using System;

namespace CC
{
	// Token: 0x020001AF RID: 431
	[Serializable]
	public class CC_Property
	{
		// Token: 0x0400133C RID: 4924
		public string propertyName = "";

		// Token: 0x0400133D RID: 4925
		public string stringValue = "";

		// Token: 0x0400133E RID: 4926
		public float floatValue;

		// Token: 0x0400133F RID: 4927
		public int materialIndex = -1;

		// Token: 0x04001340 RID: 4928
		public string meshTag = "";
	}
}
