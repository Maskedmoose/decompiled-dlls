﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000077 RID: 119
public class RestockItemCheckoutScreen : GenericSliderScreen
{
	// Token: 0x060004CB RID: 1227 RVA: 0x000295C0 File Offset: 0x000277C0
	public void UpdateData(RestockItemScreen restockItemScreen, Dictionary<int, int> cartItemList, bool hasItemRemoved)
	{
		this.m_RestockItemScreen = restockItemScreen;
		for (int i = 0; i < this.m_RestockCheckoutItemBarUIList.Count; i++)
		{
			this.m_RestockCheckoutItemBarUIList[i].Init(this.m_RestockItemScreen);
			this.m_RestockCheckoutItemBarUIList[i].SetActive(false);
		}
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		int num = 0;
		foreach (KeyValuePair<int, int> keyValuePair in cartItemList)
		{
			list.Add(keyValuePair.Key);
			list2.Add(keyValuePair.Value);
			num += keyValuePair.Value;
		}
		float num2 = 0f;
		for (int j = 0; j < list.Count; j++)
		{
			this.m_RestockCheckoutItemBarUIList[j].UpdateData(list[j], list2[j]);
			this.m_RestockCheckoutItemBarUIList[j].SetActive(true);
			this.m_ScrollEndPosParent = this.m_RestockCheckoutItemBarUIList[j].gameObject;
			num2 += this.m_RestockCheckoutItemBarUIList[j].GetTotalPrice();
		}
		float num3 = (float)Mathf.Clamp(10 * num / 5, 5, 1000);
		if (num == 0)
		{
			num3 = 0f;
		}
		this.m_TotalCost = num2 + num3;
		this.m_SubtotalText.text = GameInstance.GetPriceString(num2, false, true, false, "F2");
		this.m_DeliveryFeeText.text = GameInstance.GetPriceString(num3, false, true, false, "F2");
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_TotalCost, false, true, false, "F2");
		this.m_RestockItemScreen.UpdateCartTotalCost(num2, num);
		if (hasItemRemoved && this.m_ControllerScreenUIExtension)
		{
			this.m_ControllerScreenUIExtension.EvaluateCtrlBtnActiveChanged();
		}
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x000297A8 File Offset: 0x000279A8
	public void OnPressConfirmCheckout()
	{
		if (this.m_TotalCost <= 0f)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.NothingInCart);
			return;
		}
		if (CPlayerData.m_CoinAmount >= this.m_TotalCost)
		{
			for (int i = 0; i < this.m_RestockCheckoutItemBarUIList.Count; i++)
			{
				if (this.m_RestockCheckoutItemBarUIList[i].IsActive())
				{
					EItemType itemType = this.m_RestockCheckoutItemBarUIList[i].GetItemType();
					int totalUnit = this.m_RestockCheckoutItemBarUIList[i].GetTotalUnit();
					float unitPrice = this.m_RestockCheckoutItemBarUIList[i].GetUnitPrice();
					CPlayerData.UpdateAverageItemCost(itemType, totalUnit, unitPrice);
				}
			}
			this.m_RestockItemScreen.EvaluateCartCheckout(this.m_TotalCost);
			base.CloseScreen();
			return;
		}
		NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
	}

	// Token: 0x04000640 RID: 1600
	public List<RestockCheckoutItemBar> m_RestockCheckoutItemBarUIList;

	// Token: 0x04000641 RID: 1601
	public TextMeshProUGUI m_SubtotalText;

	// Token: 0x04000642 RID: 1602
	public TextMeshProUGUI m_DeliveryFeeText;

	// Token: 0x04000643 RID: 1603
	public TextMeshProUGUI m_TotalPriceText;

	// Token: 0x04000644 RID: 1604
	private RestockItemScreen m_RestockItemScreen;

	// Token: 0x04000645 RID: 1605
	private float m_TotalCost;

	// Token: 0x04000646 RID: 1606
	public List<float> m_TotalItemCostList = new List<float>();
}
