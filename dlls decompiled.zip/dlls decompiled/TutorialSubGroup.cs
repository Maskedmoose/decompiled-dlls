﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000056 RID: 86
public class TutorialSubGroup : MonoBehaviour
{
	// Token: 0x060003EA RID: 1002 RVA: 0x00022FC0 File Offset: 0x000211C0
	public void AddTaskValue(float currentValue, ETutorialTaskCondition tutorialTaskCondition)
	{
		if (this.m_TutorialData.tutorialTaskCondition == tutorialTaskCondition)
		{
			this.m_TutorialData.value = this.m_TutorialData.value + currentValue;
			this.m_CurrentValue += currentValue;
			this.EvaluateValueText();
			if (this.m_CurrentValue >= this.m_MaxValue)
			{
				this.m_IsTaskFinish = true;
			}
		}
	}

	// Token: 0x060003EB RID: 1003 RVA: 0x0002301C File Offset: 0x0002121C
	public bool IsTaskFinish()
	{
		return this.m_IsTaskFinish;
	}

	// Token: 0x060003EC RID: 1004 RVA: 0x00023024 File Offset: 0x00021224
	public void OpenScreen()
	{
		this.EvaluateValueText();
		base.gameObject.SetActive(true);
	}

	// Token: 0x060003ED RID: 1005 RVA: 0x00023038 File Offset: 0x00021238
	public void CloseScreen()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x060003EE RID: 1006 RVA: 0x00023048 File Offset: 0x00021248
	private void EvaluateValueText()
	{
		if (this.m_IsInt)
		{
			this.m_NumberText.text = Mathf.RoundToInt(this.m_CurrentValue).ToString() + "/" + Mathf.RoundToInt(this.m_MaxValue).ToString();
		}
		else
		{
			this.m_NumberText.text = this.m_CurrentValue.ToString() + "/" + this.m_MaxValue.ToString();
		}
		this.m_NumberText.enabled = this.m_ShowValue;
	}

	// Token: 0x040004B0 RID: 1200
	public GameObject m_ScreenGrp;

	// Token: 0x040004B1 RID: 1201
	public TextMeshProUGUI m_NumberText;

	// Token: 0x040004B2 RID: 1202
	public TutorialData m_TutorialData;

	// Token: 0x040004B3 RID: 1203
	public bool m_ShowValue = true;

	// Token: 0x040004B4 RID: 1204
	public bool m_IsInt;

	// Token: 0x040004B5 RID: 1205
	public bool m_IsPrice;

	// Token: 0x040004B6 RID: 1206
	private bool m_IsTaskFinish;

	// Token: 0x040004B7 RID: 1207
	private float m_CurrentValue;

	// Token: 0x040004B8 RID: 1208
	public float m_MaxValue;
}
