﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200010F RID: 271
public class ControllerSelectorUIGrp : MonoBehaviour
{
	// Token: 0x060007F3 RID: 2035 RVA: 0x0003B324 File Offset: 0x00039524
	private void Start()
	{
		this.m_TopUIGrp.SetActive(false);
	}

	// Token: 0x060007F4 RID: 2036 RVA: 0x0003B334 File Offset: 0x00039534
	public void SetActive(bool isActive)
	{
		if (Time.timeScale <= 0f)
		{
			this.m_PopupAnim.enabled = false;
			this.m_TopUIGrp.transform.localScale = Vector3.one;
		}
		else
		{
			this.m_PopupAnim.enabled = true;
		}
		this.m_TopUIGrp.SetActive(isActive);
	}

	// Token: 0x060007F5 RID: 2037 RVA: 0x0003B388 File Offset: 0x00039588
	public void SetSpriteGrpScale(float scale)
	{
		if (Time.timeScale <= 0f)
		{
			this.m_PopupAnim.enabled = false;
			this.m_TopUIGrp.transform.localScale = Vector3.one;
		}
		else
		{
			this.m_PopupAnim.enabled = true;
		}
		for (int i = 0; i < this.m_SpriteGrp.Count; i++)
		{
			this.m_SpriteGrp[i].localScale = Vector3.one * scale;
		}
	}

	// Token: 0x04000F2F RID: 3887
	public RectTransform m_Rect;

	// Token: 0x04000F30 RID: 3888
	public GameObject m_TopUIGrp;

	// Token: 0x04000F31 RID: 3889
	public List<Transform> m_SpriteGrp;

	// Token: 0x04000F32 RID: 3890
	public Animation m_PopupAnim;
}
