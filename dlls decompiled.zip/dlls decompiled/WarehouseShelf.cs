﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200008C RID: 140
public class WarehouseShelf : InteractableObject
{
	// Token: 0x06000584 RID: 1412 RVA: 0x0002D8AE File Offset: 0x0002BAAE
	protected override void Awake()
	{
		base.Awake();
		ShelfManager.InitWarehouseShelf(this);
	}

	// Token: 0x06000585 RID: 1413 RVA: 0x0002D8BC File Offset: 0x0002BABC
	public override void Init()
	{
		if (this.m_HasInit)
		{
			return;
		}
		base.Init();
		for (int i = 0; i < this.m_ShelfCompartmentGrpList.Count; i++)
		{
			for (int j = 0; j < this.m_ShelfCompartmentGrpList[i].childCount; j++)
			{
				this.m_ItemCompartmentList.Add(this.m_ShelfCompartmentGrpList[i].GetChild(j).GetComponent<ShelfCompartment>());
				this.m_StorageCompartmentList.Add(this.m_ShelfCompartmentGrpList[i].GetChild(j).GetComponent<InteractableStorageCompartment>());
			}
		}
		this.m_Shelf_WorldUIGrp = PriceTagUISpawner.SpawnShelfWorldUIGrp(base.transform);
		for (int k = 0; k < this.m_StorageCompartmentList.Count; k++)
		{
			this.m_StorageCompartmentList[k].InitWarehouseShelf(this, this.m_ItemCompartmentList[k], k);
			for (int l = 0; l < this.m_ItemCompartmentList[k].m_InteractablePriceTagList.Count; l++)
			{
				UI_PriceTag ui_PriceTag = PriceTagUISpawner.SpawnPriceTagWarehouseRakWorldUIGrp(this.m_Shelf_WorldUIGrp, this.m_ItemCompartmentList[k].m_InteractablePriceTagList[l].transform);
				this.m_UIPriceTagList.Add(ui_PriceTag);
				this.m_ItemCompartmentList[k].m_InteractablePriceTagList[l].SetPriceTagUI(ui_PriceTag);
				this.m_ItemCompartmentList[k].m_InteractablePriceTagList[l].SetVisibility(false);
			}
		}
	}

	// Token: 0x06000586 RID: 1414 RVA: 0x0002DA30 File Offset: 0x0002BC30
	protected override void LateUpdate()
	{
		base.LateUpdate();
		if (this.m_IsMovingObject && this.m_Shelf_WorldUIGrp)
		{
			this.m_Shelf_WorldUIGrp.transform.position = base.transform.position;
			this.m_Shelf_WorldUIGrp.transform.rotation = base.transform.rotation;
		}
	}

	// Token: 0x06000587 RID: 1415 RVA: 0x0002DA8E File Offset: 0x0002BC8E
	protected override void OnPlacedMovedObject()
	{
		base.OnPlacedMovedObject();
	}

	// Token: 0x06000588 RID: 1416 RVA: 0x0002DA96 File Offset: 0x0002BC96
	public override void BoxUpObject(bool holdBox)
	{
		base.BoxUpObject(holdBox);
	}

	// Token: 0x06000589 RID: 1417 RVA: 0x0002DAA0 File Offset: 0x0002BCA0
	public override void OnDestroyed()
	{
		ShelfManager.RemoveWarehouseShelf(this);
		for (int i = 0; i < this.m_StorageCompartmentList.Count; i++)
		{
			if (this.m_StorageCompartmentList[i])
			{
				this.m_StorageCompartmentList[i].DisableAllItem();
			}
		}
		base.OnDestroyed();
	}

	// Token: 0x0600058A RID: 1418 RVA: 0x0002DAF3 File Offset: 0x0002BCF3
	public ShelfCompartment GetWarehouseCompartment(int index)
	{
		if (index >= this.m_StorageCompartmentList.Count)
		{
			return null;
		}
		return this.m_StorageCompartmentList[index].GetShelfCompartment();
	}

	// Token: 0x0600058B RID: 1419 RVA: 0x0002DB16 File Offset: 0x0002BD16
	public void SetIndex(int index)
	{
		this.m_Index = index;
	}

	// Token: 0x0600058C RID: 1420 RVA: 0x0002DB1F File Offset: 0x0002BD1F
	public int GetIndex()
	{
		return this.m_Index;
	}

	// Token: 0x0600058D RID: 1421 RVA: 0x0002DB27 File Offset: 0x0002BD27
	public List<InteractableStorageCompartment> GetStorageCompartmentList()
	{
		return this.m_StorageCompartmentList;
	}

	// Token: 0x0600058E RID: 1422 RVA: 0x0002DB30 File Offset: 0x0002BD30
	public ShelfCompartment GetNonFullItemCompartment(EItemType itemType, bool isBigBox, bool ignoreNoneType = false)
	{
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (!ignoreNoneType && (this.m_ItemCompartmentList[i].GetItemType() == EItemType.None || this.m_ItemCompartmentList[i].GetItemCount() == 0))
			{
				return this.m_ItemCompartmentList[i];
			}
			if (this.m_ItemCompartmentList[i].GetItemType() == itemType && this.m_ItemCompartmentList[i].CheckBoxType(isBigBox) == isBigBox && this.m_ItemCompartmentList[i].GetItemCount() < this.m_ItemCompartmentList[i].GetMaxItemCount())
			{
				return this.m_ItemCompartmentList[i];
			}
		}
		return null;
	}

	// Token: 0x0600058F RID: 1423 RVA: 0x0002DBEC File Offset: 0x0002BDEC
	public List<ShelfCompartment> GetNonFullItemCompartmentList(EItemType itemType, bool isBigBox, bool ignoreNoneType = false)
	{
		List<ShelfCompartment> list = new List<ShelfCompartment>();
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (!ignoreNoneType && (this.m_ItemCompartmentList[i].GetItemType() == EItemType.None || this.m_ItemCompartmentList[i].GetItemCount() == 0))
			{
				list.Add(this.m_ItemCompartmentList[i]);
			}
			else if (this.m_ItemCompartmentList[i].GetItemType() == itemType && this.m_ItemCompartmentList[i].CheckBoxType(isBigBox) == isBigBox && this.m_ItemCompartmentList[i].GetItemCount() < this.m_ItemCompartmentList[i].GetMaxItemCount())
			{
				list.Add(this.m_ItemCompartmentList[i]);
			}
		}
		return list;
	}

	// Token: 0x04000724 RID: 1828
	public List<Transform> m_ShelfCompartmentGrpList;

	// Token: 0x04000725 RID: 1829
	private List<InteractableStorageCompartment> m_StorageCompartmentList = new List<InteractableStorageCompartment>();

	// Token: 0x04000726 RID: 1830
	private List<UI_PriceTag> m_UIPriceTagList = new List<UI_PriceTag>();

	// Token: 0x04000727 RID: 1831
	private int m_Index;
}
