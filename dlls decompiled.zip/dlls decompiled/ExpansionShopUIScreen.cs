﻿using System;
using System.Collections;
using System.Collections.Generic;
using I2.Loc;
using TMPro;
using UnityEngine;

// Token: 0x02000065 RID: 101
public class ExpansionShopUIScreen : GenericSliderScreen
{
	// Token: 0x06000450 RID: 1104 RVA: 0x00025C03 File Offset: 0x00023E03
	protected override void Init()
	{
		this.EvaluateShopPanelUI();
		base.Init();
	}

	// Token: 0x06000451 RID: 1105 RVA: 0x00025C11 File Offset: 0x00023E11
	protected override void OnOpenScreen()
	{
		this.Init();
		base.OnOpenScreen();
	}

	// Token: 0x06000452 RID: 1106 RVA: 0x00025C20 File Offset: 0x00023E20
	private void EvaluateShopPanelUI()
	{
		for (int i = 0; i < this.m_ExpansionShopPanelUIList.Count; i++)
		{
			this.m_ExpansionShopPanelUIList[i].SetActive(false);
		}
		this.m_ShopA_HighlightBtn.SetActive(!this.m_IsShopB);
		this.m_ShopB_HighlightBtn.SetActive(this.m_IsShopB);
		if (this.m_IsShopB)
		{
			if (this.m_LevelRequirementString == "")
			{
				this.m_LevelRequirementString = this.m_ShopB_LevelRequirementText.text;
			}
			this.m_ShopB_PriceText.text = GameInstance.GetPriceString(this.m_ShopB_UnlockPrice, false, true, false, "F2");
			this.m_ShopB_LevelRequirementText.text = LocalizationManager.GetTranslation(this.m_LevelRequirementString, true, 0, true, false, null, null, true).Replace("XXX", this.m_ShopB_UnlockLevelRequired.ToString());
			this.m_ShopB_UnlockGrp.SetActive(!CPlayerData.m_IsWarehouseRoomUnlocked);
			if (CSingleton<CGameManager>.Instance.m_IsPrologue)
			{
				this.m_ShopB_UnlockGrpPrologue.SetActive(true);
			}
			if (CPlayerData.m_ShopLevel + 1 >= this.m_ShopB_UnlockLevelRequired)
			{
				this.m_ShopB_LevelRequirementText.enabled = false;
				this.m_ShopB_LockPurchaseBtn.SetActive(false);
			}
			else
			{
				this.m_ShopB_LevelRequirementText.enabled = true;
				this.m_ShopB_LockPurchaseBtn.SetActive(true);
			}
			if (!CPlayerData.m_IsWarehouseRoomUnlocked)
			{
				return;
			}
		}
		else
		{
			this.m_ShopB_UnlockGrp.SetActive(false);
		}
		int num = 20;
		if (this.m_IsShopB)
		{
			num = 8;
		}
		for (int j = 0; j < num; j++)
		{
			this.m_ExpansionShopPanelUIList[j].Init(this, j, this.m_IsShopB);
			this.m_ExpansionShopPanelUIList[j].SetActive(true);
			this.m_ScrollEndPosParent = this.m_ExpansionShopPanelUIList[j].gameObject;
		}
	}

	// Token: 0x06000453 RID: 1107 RVA: 0x00025DD3 File Offset: 0x00023FD3
	public void OnPressPanelUIButton(int index)
	{
	}

	// Token: 0x06000454 RID: 1108 RVA: 0x00025DD5 File Offset: 0x00023FD5
	public void OnPressShopSubButton(bool isShopB)
	{
		this.m_IsShopB = isShopB;
		this.EvaluateShopPanelUI();
		base.StartCoroutine(base.EvaluateActiveRestockUIScroller());
		this.m_PosX = 0f;
		this.m_LerpPosX = 0f;
	}

	// Token: 0x06000455 RID: 1109 RVA: 0x00025E08 File Offset: 0x00024008
	public void OnPressUnlockShopB()
	{
		if (CSingleton<CGameManager>.Instance.m_IsPrologue)
		{
			return;
		}
		if (CPlayerData.m_IsWarehouseRoomUnlocked)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AlreadyPurchased);
			return;
		}
		if (CPlayerData.m_ShopLevel + 1 < this.m_ShopB_UnlockLevelRequired)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShopLevelNotEnough);
			return;
		}
		if (CPlayerData.m_CoinAmount >= this.m_ShopB_UnlockPrice)
		{
			CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(this.m_ShopB_UnlockPrice, false));
			CSingleton<UnlockRoomManager>.Instance.SetUnlockWarehouseRoom(true);
			AchievementManager.OnShopLotBUnlocked();
			CEventManager.QueueEvent(new CEventPlayer_AddShopExp(Mathf.Clamp(Mathf.RoundToInt(this.m_ShopB_UnlockPrice / 100f), 5, 100), false));
			base.StartCoroutine(this.DelaySaveShelfData());
			this.m_ShopB_UnlockGrp.SetActive(false);
			this.OnPressShopSubButton(true);
			CPlayerData.m_GameReportDataCollect.upgradeCost = CPlayerData.m_GameReportDataCollect.upgradeCost - this.m_ShopB_UnlockPrice;
			CPlayerData.m_GameReportDataCollectPermanent.upgradeCost = CPlayerData.m_GameReportDataCollectPermanent.upgradeCost - this.m_ShopB_UnlockPrice;
			SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
			return;
		}
		NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
	}

	// Token: 0x06000456 RID: 1110 RVA: 0x00025F00 File Offset: 0x00024100
	public void EvaluateCartCheckout(float totalCost, int index, bool isShopB)
	{
		if (this.m_IsShopB != isShopB)
		{
			return;
		}
		CPlayerData.GetUnlockShopRoomCost(CPlayerData.m_UnlockRoomCount);
		if (isShopB)
		{
			CPlayerData.GetUnlockWarehouseRoomCost(CPlayerData.m_UnlockWarehouseRoomCount);
		}
		CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(totalCost, false));
		if (isShopB)
		{
			CSingleton<UnlockRoomManager>.Instance.StartUnlockNextWarehouseRoom();
		}
		else
		{
			CSingleton<UnlockRoomManager>.Instance.StartUnlockNextRoom();
		}
		CEventManager.QueueEvent(new CEventPlayer_AddShopExp(Mathf.Clamp(Mathf.RoundToInt(totalCost / 100f), 5, 100), false));
		base.StartCoroutine(this.DelaySaveShelfData());
		for (int i = 0; i < this.m_ExpansionShopPanelUIList.Count; i++)
		{
			this.m_ExpansionShopPanelUIList[i].Init(this, i, this.m_IsShopB);
		}
		CPlayerData.m_GameReportDataCollect.upgradeCost = CPlayerData.m_GameReportDataCollect.upgradeCost - totalCost;
		CPlayerData.m_GameReportDataCollectPermanent.upgradeCost = CPlayerData.m_GameReportDataCollectPermanent.upgradeCost - totalCost;
		SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
	}

	// Token: 0x06000457 RID: 1111 RVA: 0x00025FE2 File Offset: 0x000241E2
	private IEnumerator DelaySaveShelfData()
	{
		yield return new WaitForSeconds(1f);
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		yield break;
	}

	// Token: 0x0400054E RID: 1358
	public List<ExpansionShopPanelUI> m_ExpansionShopPanelUIList;

	// Token: 0x0400054F RID: 1359
	public int m_ShopB_UnlockLevelRequired = 15;

	// Token: 0x04000550 RID: 1360
	public float m_ShopB_UnlockPrice = 5000f;

	// Token: 0x04000551 RID: 1361
	public TextMeshProUGUI m_ShopB_PriceText;

	// Token: 0x04000552 RID: 1362
	public TextMeshProUGUI m_ShopB_LevelRequirementText;

	// Token: 0x04000553 RID: 1363
	public GameObject m_ShopB_LockPurchaseBtn;

	// Token: 0x04000554 RID: 1364
	public GameObject m_ShopB_UnlockGrp;

	// Token: 0x04000555 RID: 1365
	public GameObject m_ShopB_UnlockGrpPrologue;

	// Token: 0x04000556 RID: 1366
	public GameObject m_ShopA_HighlightBtn;

	// Token: 0x04000557 RID: 1367
	public GameObject m_ShopB_HighlightBtn;

	// Token: 0x04000558 RID: 1368
	private bool m_IsShopB;

	// Token: 0x04000559 RID: 1369
	private string m_LevelRequirementString = "";
}
