﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DB RID: 475
	public class Mover : MonoBehaviour
	{
		// Token: 0x06000D4E RID: 3406 RVA: 0x0005B9D2 File Offset: 0x00059BD2
		private void Awake()
		{
			this.Setup();
			this.sensor = new Sensor(this.tr, this.col);
			this.RecalculateColliderDimensions();
			this.RecalibrateSensor();
		}

		// Token: 0x06000D4F RID: 3407 RVA: 0x0005B9FD File Offset: 0x00059BFD
		private void Reset()
		{
			this.Setup();
		}

		// Token: 0x06000D50 RID: 3408 RVA: 0x0005BA05 File Offset: 0x00059C05
		private void OnValidate()
		{
			if (base.gameObject.activeInHierarchy)
			{
				this.RecalculateColliderDimensions();
			}
			if (this.sensorType == Sensor.CastType.RaycastArray)
			{
				this.raycastArrayPreviewPositions = Sensor.GetRaycastStartPositions(this.sensorArrayRows, this.sensorArrayRayCount, this.sensorArrayRowsAreOffset, 1f);
			}
		}

		// Token: 0x06000D51 RID: 3409 RVA: 0x0005BA48 File Offset: 0x00059C48
		private void Setup()
		{
			this.tr = base.transform;
			this.col = base.GetComponent<Collider>();
			if (this.col == null)
			{
				this.tr.gameObject.AddComponent<CapsuleCollider>();
				this.col = base.GetComponent<Collider>();
			}
			this.rig = base.GetComponent<Rigidbody>();
			if (this.rig == null)
			{
				this.tr.gameObject.AddComponent<Rigidbody>();
				this.rig = base.GetComponent<Rigidbody>();
			}
			this.boxCollider = base.GetComponent<BoxCollider>();
			this.sphereCollider = base.GetComponent<SphereCollider>();
			this.capsuleCollider = base.GetComponent<CapsuleCollider>();
			this.rig.freezeRotation = true;
			this.rig.useGravity = false;
		}

		// Token: 0x06000D52 RID: 3410 RVA: 0x0005BB0B File Offset: 0x00059D0B
		private void LateUpdate()
		{
			if (this.isInDebugMode)
			{
				this.sensor.DrawDebug();
			}
		}

		// Token: 0x06000D53 RID: 3411 RVA: 0x0005BB20 File Offset: 0x00059D20
		public void RecalculateColliderDimensions()
		{
			if (this.col == null)
			{
				this.Setup();
				if (this.col == null)
				{
					Debug.LogWarning("There is no collider attached to " + base.gameObject.name + "!");
					return;
				}
			}
			if (this.boxCollider)
			{
				Vector3 zero = Vector3.zero;
				zero.x = this.colliderThickness;
				zero.z = this.colliderThickness;
				this.boxCollider.center = this.colliderOffset * this.colliderHeight;
				zero.y = this.colliderHeight * (1f - this.stepHeightRatio);
				this.boxCollider.size = zero;
				this.boxCollider.center = this.boxCollider.center + new Vector3(0f, this.stepHeightRatio * this.colliderHeight / 2f, 0f);
			}
			else if (this.sphereCollider)
			{
				this.sphereCollider.radius = this.colliderHeight / 2f;
				this.sphereCollider.center = this.colliderOffset * this.colliderHeight;
				this.sphereCollider.center = this.sphereCollider.center + new Vector3(0f, this.stepHeightRatio * this.sphereCollider.radius, 0f);
				this.sphereCollider.radius *= 1f - this.stepHeightRatio;
			}
			else if (this.capsuleCollider)
			{
				this.capsuleCollider.height = this.colliderHeight;
				this.capsuleCollider.center = this.colliderOffset * this.colliderHeight;
				this.capsuleCollider.radius = this.colliderThickness / 2f;
				this.capsuleCollider.center = this.capsuleCollider.center + new Vector3(0f, this.stepHeightRatio * this.capsuleCollider.height / 2f, 0f);
				this.capsuleCollider.height *= 1f - this.stepHeightRatio;
				if (this.capsuleCollider.height / 2f < this.capsuleCollider.radius)
				{
					this.capsuleCollider.radius = this.capsuleCollider.height / 2f;
				}
			}
			if (this.sensor != null)
			{
				this.RecalibrateSensor();
			}
		}

		// Token: 0x06000D54 RID: 3412 RVA: 0x0005BDC4 File Offset: 0x00059FC4
		private void RecalibrateSensor()
		{
			this.sensor.SetCastOrigin(this.GetColliderCenter());
			this.sensor.SetCastDirection(Sensor.CastDirection.Down);
			this.RecalculateSensorLayerMask();
			this.sensor.castType = this.sensorType;
			float num = this.colliderThickness / 2f * this.sensorRadiusModifier;
			float num2 = 0.001f;
			if (this.boxCollider)
			{
				num = Mathf.Clamp(num, num2, this.boxCollider.size.y / 2f * (1f - num2));
			}
			else if (this.sphereCollider)
			{
				num = Mathf.Clamp(num, num2, this.sphereCollider.radius * (1f - num2));
			}
			else if (this.capsuleCollider)
			{
				num = Mathf.Clamp(num, num2, this.capsuleCollider.height / 2f * (1f - num2));
			}
			this.sensor.sphereCastRadius = num * this.tr.localScale.x;
			float num3 = 0f;
			num3 += this.colliderHeight * (1f - this.stepHeightRatio) * 0.5f;
			num3 += this.colliderHeight * this.stepHeightRatio;
			this.baseSensorRange = num3 * (1f + num2) * this.tr.localScale.x;
			this.sensor.castLength = num3 * this.tr.localScale.x;
			this.sensor.ArrayRows = this.sensorArrayRows;
			this.sensor.arrayRayCount = this.sensorArrayRayCount;
			this.sensor.offsetArrayRows = this.sensorArrayRowsAreOffset;
			this.sensor.isInDebugMode = this.isInDebugMode;
			this.sensor.calculateRealDistance = true;
			this.sensor.calculateRealSurfaceNormal = true;
			this.sensor.RecalibrateRaycastArrayPositions();
		}

		// Token: 0x06000D55 RID: 3413 RVA: 0x0005BFA0 File Offset: 0x0005A1A0
		private void RecalculateSensorLayerMask()
		{
			int num = 0;
			int layer = base.gameObject.layer;
			for (int i = 0; i < 32; i++)
			{
				if (!Physics.GetIgnoreLayerCollision(layer, i))
				{
					num |= 1 << i;
				}
			}
			if (num == (num | 1 << LayerMask.NameToLayer("Ignore Raycast")))
			{
				num ^= 1 << LayerMask.NameToLayer("Ignore Raycast");
			}
			this.sensor.layermask = num;
			this.currentLayer = layer;
		}

		// Token: 0x06000D56 RID: 3414 RVA: 0x0005C018 File Offset: 0x0005A218
		private Vector3 GetColliderCenter()
		{
			if (this.col == null)
			{
				this.Setup();
			}
			return this.col.bounds.center;
		}

		// Token: 0x06000D57 RID: 3415 RVA: 0x0005C04C File Offset: 0x0005A24C
		private void Check()
		{
			this.currentGroundAdjustmentVelocity = Vector3.zero;
			if (this.IsUsingExtendedSensorRange)
			{
				this.sensor.castLength = this.baseSensorRange + this.colliderHeight * this.tr.localScale.x * this.stepHeightRatio;
			}
			else
			{
				this.sensor.castLength = this.baseSensorRange;
			}
			this.sensor.Cast();
			if (!this.sensor.HasDetectedHit())
			{
				this.isGrounded = false;
				return;
			}
			this.isGrounded = true;
			float distance = this.sensor.GetDistance();
			float num = this.colliderHeight * this.tr.localScale.x * (1f - this.stepHeightRatio) * 0.5f + this.colliderHeight * this.tr.localScale.x * this.stepHeightRatio - distance;
			this.currentGroundAdjustmentVelocity = this.tr.up * (num / Time.fixedDeltaTime);
		}

		// Token: 0x06000D58 RID: 3416 RVA: 0x0005C14B File Offset: 0x0005A34B
		public void CheckForGround()
		{
			if (this.currentLayer != base.gameObject.layer)
			{
				this.RecalculateSensorLayerMask();
			}
			this.Check();
		}

		// Token: 0x06000D59 RID: 3417 RVA: 0x0005C16C File Offset: 0x0005A36C
		public void SetVelocity(Vector3 _velocity)
		{
			this.rig.velocity = _velocity + this.currentGroundAdjustmentVelocity;
		}

		// Token: 0x06000D5A RID: 3418 RVA: 0x0005C185 File Offset: 0x0005A385
		public bool IsGrounded()
		{
			return this.isGrounded;
		}

		// Token: 0x06000D5B RID: 3419 RVA: 0x0005C18D File Offset: 0x0005A38D
		public void SetExtendSensorRange(bool _isExtended)
		{
			this.IsUsingExtendedSensorRange = _isExtended;
		}

		// Token: 0x06000D5C RID: 3420 RVA: 0x0005C196 File Offset: 0x0005A396
		public void SetColliderHeight(float _newColliderHeight)
		{
			if (this.colliderHeight == _newColliderHeight)
			{
				return;
			}
			this.colliderHeight = _newColliderHeight;
			this.RecalculateColliderDimensions();
		}

		// Token: 0x06000D5D RID: 3421 RVA: 0x0005C1AF File Offset: 0x0005A3AF
		public void SetColliderThickness(float _newColliderThickness)
		{
			if (this.colliderThickness == _newColliderThickness)
			{
				return;
			}
			if (_newColliderThickness < 0f)
			{
				_newColliderThickness = 0f;
			}
			this.colliderThickness = _newColliderThickness;
			this.RecalculateColliderDimensions();
		}

		// Token: 0x06000D5E RID: 3422 RVA: 0x0005C1D7 File Offset: 0x0005A3D7
		public void SetStepHeightRatio(float _newStepHeightRatio)
		{
			_newStepHeightRatio = Mathf.Clamp(_newStepHeightRatio, 0f, 1f);
			this.stepHeightRatio = _newStepHeightRatio;
			this.RecalculateColliderDimensions();
		}

		// Token: 0x06000D5F RID: 3423 RVA: 0x0005C1F8 File Offset: 0x0005A3F8
		public Vector3 GetGroundNormal()
		{
			return this.sensor.GetNormal();
		}

		// Token: 0x06000D60 RID: 3424 RVA: 0x0005C205 File Offset: 0x0005A405
		public Vector3 GetGroundPoint()
		{
			return this.sensor.GetPosition();
		}

		// Token: 0x06000D61 RID: 3425 RVA: 0x0005C212 File Offset: 0x0005A412
		public Collider GetGroundCollider()
		{
			return this.sensor.GetCollider();
		}

		// Token: 0x04001440 RID: 5184
		[Header("Mover Options :")]
		[Range(0f, 1f)]
		[SerializeField]
		private float stepHeightRatio = 0.25f;

		// Token: 0x04001441 RID: 5185
		[Header("Collider Options :")]
		[SerializeField]
		private float colliderHeight = 2f;

		// Token: 0x04001442 RID: 5186
		[SerializeField]
		private float colliderThickness = 1f;

		// Token: 0x04001443 RID: 5187
		[SerializeField]
		private Vector3 colliderOffset = Vector3.zero;

		// Token: 0x04001444 RID: 5188
		private BoxCollider boxCollider;

		// Token: 0x04001445 RID: 5189
		private SphereCollider sphereCollider;

		// Token: 0x04001446 RID: 5190
		private CapsuleCollider capsuleCollider;

		// Token: 0x04001447 RID: 5191
		[Header("Sensor Options :")]
		[SerializeField]
		public Sensor.CastType sensorType;

		// Token: 0x04001448 RID: 5192
		private float sensorRadiusModifier = 0.8f;

		// Token: 0x04001449 RID: 5193
		private int currentLayer;

		// Token: 0x0400144A RID: 5194
		[SerializeField]
		private bool isInDebugMode;

		// Token: 0x0400144B RID: 5195
		[Header("Sensor Array Options :")]
		[SerializeField]
		[Range(1f, 5f)]
		private int sensorArrayRows = 1;

		// Token: 0x0400144C RID: 5196
		[SerializeField]
		[Range(3f, 10f)]
		private int sensorArrayRayCount = 6;

		// Token: 0x0400144D RID: 5197
		[SerializeField]
		private bool sensorArrayRowsAreOffset;

		// Token: 0x0400144E RID: 5198
		[HideInInspector]
		public Vector3[] raycastArrayPreviewPositions;

		// Token: 0x0400144F RID: 5199
		private bool isGrounded;

		// Token: 0x04001450 RID: 5200
		private bool IsUsingExtendedSensorRange = true;

		// Token: 0x04001451 RID: 5201
		private float baseSensorRange;

		// Token: 0x04001452 RID: 5202
		private Vector3 currentGroundAdjustmentVelocity = Vector3.zero;

		// Token: 0x04001453 RID: 5203
		private Collider col;

		// Token: 0x04001454 RID: 5204
		private Rigidbody rig;

		// Token: 0x04001455 RID: 5205
		private Transform tr;

		// Token: 0x04001456 RID: 5206
		private Sensor sensor;
	}
}
