﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D4 RID: 468
	public class CameraController : MonoBehaviour
	{
		// Token: 0x06000D07 RID: 3335 RVA: 0x00059F80 File Offset: 0x00058180
		private void Awake()
		{
			this.tr = base.transform;
			this.cam = base.GetComponent<Camera>();
			this.cameraInput = base.GetComponent<CameraInput>();
			if (this.cameraInput == null)
			{
				Debug.LogWarning("No camera input script has been attached to this gameobject", base.gameObject);
			}
			if (this.cam == null)
			{
				this.cam = base.GetComponentInChildren<Camera>();
			}
			this.currentXAngle = this.tr.localRotation.eulerAngles.x;
			this.currentYAngle = this.tr.localRotation.eulerAngles.y;
			this.RotateCamera(0f, 0f);
			this.Setup();
		}

		// Token: 0x06000D08 RID: 3336 RVA: 0x0005A03B File Offset: 0x0005823B
		protected virtual void Setup()
		{
		}

		// Token: 0x06000D09 RID: 3337 RVA: 0x0005A03D File Offset: 0x0005823D
		private void Update()
		{
			this.HandleCameraRotation();
		}

		// Token: 0x06000D0A RID: 3338 RVA: 0x0005A048 File Offset: 0x00058248
		protected virtual void HandleCameraRotation()
		{
			if (this.cameraInput == null)
			{
				return;
			}
			float horizontalCameraInput = this.cameraInput.GetHorizontalCameraInput();
			float verticalCameraInput = this.cameraInput.GetVerticalCameraInput();
			this.RotateCamera(horizontalCameraInput, verticalCameraInput);
		}

		// Token: 0x06000D0B RID: 3339 RVA: 0x0005A084 File Offset: 0x00058284
		protected void RotateCamera(float _newHorizontalInput, float _newVerticalInput)
		{
			if (this.smoothCameraRotation)
			{
				this.oldHorizontalInput = Mathf.Lerp(this.oldHorizontalInput, _newHorizontalInput, Time.deltaTime * this.cameraSmoothingFactor);
				this.oldVerticalInput = Mathf.Lerp(this.oldVerticalInput, _newVerticalInput, Time.deltaTime * this.cameraSmoothingFactor);
			}
			else
			{
				this.oldHorizontalInput = _newHorizontalInput;
				this.oldVerticalInput = _newVerticalInput;
			}
			this.currentXAngle += this.oldVerticalInput * this.cameraSpeed * Time.deltaTime * CSingleton<CGameManager>.Instance.m_MouseSensitivityLerp;
			this.currentYAngle += this.oldHorizontalInput * this.cameraSpeed * Time.deltaTime * CSingleton<CGameManager>.Instance.m_MouseSensitivityLerp;
			this.currentXAngle = Mathf.Clamp(this.currentXAngle, -this.upperVerticalLimit, this.lowerVerticalLimit);
			if (this.isViewCardAlbumMode)
			{
				this.currentYAngle = Mathf.Clamp(this.currentYAngle, this.viewCardAlbumYAngle - 34f - 33f * this.viewCardAlbumAngleOffsetMultiplier, this.viewCardAlbumYAngle + 34f + 33f * this.viewCardAlbumAngleOffsetMultiplier);
				this.currentXAngle = Mathf.Clamp(this.currentXAngle, this.viewCardAlbumXAngle - 10f - 15f * this.viewCardAlbumAngleOffsetMultiplier, this.viewCardAlbumXAngle + 10f + 15f * this.viewCardAlbumAngleOffsetMultiplier);
			}
			this.UpdateRotation();
		}

		// Token: 0x06000D0C RID: 3340 RVA: 0x0005A1F0 File Offset: 0x000583F0
		protected void UpdateRotation()
		{
			this.tr.localRotation = Quaternion.Euler(new Vector3(0f, this.currentYAngle, 0f));
			this.facingDirection = this.tr.forward;
			this.upwardsDirection = this.tr.up;
			this.tr.localRotation = Quaternion.Euler(new Vector3(this.currentXAngle, this.currentYAngle, 0f));
		}

		// Token: 0x06000D0D RID: 3341 RVA: 0x0005A26A File Offset: 0x0005846A
		public void SetFOV(float _fov)
		{
			if (this.cam)
			{
				this.cam.fieldOfView = _fov;
			}
		}

		// Token: 0x06000D0E RID: 3342 RVA: 0x0005A285 File Offset: 0x00058485
		public void SetRotationAngles(float _xAngle, float _yAngle)
		{
			this.currentXAngle = _xAngle;
			this.currentYAngle = _yAngle;
			this.UpdateRotation();
		}

		// Token: 0x06000D0F RID: 3343 RVA: 0x0005A29C File Offset: 0x0005849C
		public void RotateTowardPosition(Vector3 _position, float _lookSpeed)
		{
			Vector3 direction = _position - this.tr.position;
			this.RotateTowardDirection(direction, _lookSpeed);
		}

		// Token: 0x06000D10 RID: 3344 RVA: 0x0005A2C4 File Offset: 0x000584C4
		public void RotateTowardDirection(Vector3 _direction, float _lookSpeed)
		{
			_direction.Normalize();
			_direction = this.tr.parent.InverseTransformDirection(_direction);
			Vector3 vector = this.GetAimingDirection();
			vector = this.tr.parent.InverseTransformDirection(vector);
			float angle = VectorMath.GetAngle(new Vector3(0f, vector.y, 1f), new Vector3(0f, _direction.y, 1f), Vector3.right);
			vector.y = 0f;
			_direction.y = 0f;
			float angle2 = VectorMath.GetAngle(vector, _direction, Vector3.up);
			Vector2 vector2 = new Vector2(this.currentXAngle, this.currentYAngle);
			Vector2 a = new Vector2(angle, angle2);
			float magnitude = a.magnitude;
			if (magnitude == 0f)
			{
				return;
			}
			Vector2 a2 = a / magnitude;
			if (_lookSpeed * Time.deltaTime > magnitude)
			{
				vector2 += a2 * magnitude;
			}
			else
			{
				vector2 += a2 * _lookSpeed * Time.deltaTime;
			}
			this.currentYAngle = vector2.y;
			this.currentXAngle = Mathf.Clamp(vector2.x, -this.upperVerticalLimit, this.lowerVerticalLimit);
			this.UpdateRotation();
		}

		// Token: 0x06000D11 RID: 3345 RVA: 0x0005A3FE File Offset: 0x000585FE
		public void EnterViewCardAlbumMode()
		{
			this.isViewCardAlbumMode = true;
			this.viewCardAlbumXAngle = this.currentXAngle;
			this.viewCardAlbumYAngle = this.currentYAngle;
			this.viewCardAlbumAngleOffsetMultiplier = Mathf.Abs(this.currentXAngle) / this.upperVerticalLimit;
		}

		// Token: 0x06000D12 RID: 3346 RVA: 0x0005A437 File Offset: 0x00058637
		public float GetViewCardDeltaAngleX()
		{
			return this.currentXAngle - this.viewCardAlbumXAngle;
		}

		// Token: 0x06000D13 RID: 3347 RVA: 0x0005A446 File Offset: 0x00058646
		public float GetViewCardDeltaAngleY()
		{
			return this.currentYAngle - this.viewCardAlbumYAngle;
		}

		// Token: 0x06000D14 RID: 3348 RVA: 0x0005A455 File Offset: 0x00058655
		public void ExitViewCardAlbumMode()
		{
			this.isViewCardAlbumMode = false;
		}

		// Token: 0x06000D15 RID: 3349 RVA: 0x0005A45E File Offset: 0x0005865E
		public float GetCurrentXAngle()
		{
			return this.currentXAngle;
		}

		// Token: 0x06000D16 RID: 3350 RVA: 0x0005A466 File Offset: 0x00058666
		public float GetCurrentYAngle()
		{
			return this.currentYAngle;
		}

		// Token: 0x06000D17 RID: 3351 RVA: 0x0005A46E File Offset: 0x0005866E
		public Vector3 GetFacingDirection()
		{
			return this.facingDirection;
		}

		// Token: 0x06000D18 RID: 3352 RVA: 0x0005A476 File Offset: 0x00058676
		public Vector3 GetAimingDirection()
		{
			return this.tr.forward;
		}

		// Token: 0x06000D19 RID: 3353 RVA: 0x0005A483 File Offset: 0x00058683
		public Vector3 GetStrafeDirection()
		{
			return this.tr.right;
		}

		// Token: 0x06000D1A RID: 3354 RVA: 0x0005A490 File Offset: 0x00058690
		public Vector3 GetUpDirection()
		{
			return this.upwardsDirection;
		}

		// Token: 0x040013F6 RID: 5110
		public float currentXAngle;

		// Token: 0x040013F7 RID: 5111
		public float currentYAngle;

		// Token: 0x040013F8 RID: 5112
		[Range(0f, 90f)]
		public float upperVerticalLimit = 60f;

		// Token: 0x040013F9 RID: 5113
		[Range(0f, 90f)]
		public float lowerVerticalLimit = 60f;

		// Token: 0x040013FA RID: 5114
		public float oldHorizontalInput;

		// Token: 0x040013FB RID: 5115
		public float oldVerticalInput;

		// Token: 0x040013FC RID: 5116
		public float cameraSpeed = 250f;

		// Token: 0x040013FD RID: 5117
		public bool smoothCameraRotation;

		// Token: 0x040013FE RID: 5118
		[Range(1f, 50f)]
		public float cameraSmoothingFactor = 25f;

		// Token: 0x040013FF RID: 5119
		private Vector3 facingDirection;

		// Token: 0x04001400 RID: 5120
		private Vector3 upwardsDirection;

		// Token: 0x04001401 RID: 5121
		protected Transform tr;

		// Token: 0x04001402 RID: 5122
		protected Camera cam;

		// Token: 0x04001403 RID: 5123
		protected CameraInput cameraInput;

		// Token: 0x04001404 RID: 5124
		protected bool isViewCardAlbumMode;

		// Token: 0x04001405 RID: 5125
		protected float viewCardAlbumXAngle;

		// Token: 0x04001406 RID: 5126
		protected float viewCardAlbumYAngle;

		// Token: 0x04001407 RID: 5127
		protected float viewCardAlbumAngleOffsetMultiplier;
	}
}
