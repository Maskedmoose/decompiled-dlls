﻿using System;
using UnityEngine;

// Token: 0x02000142 RID: 322
public class ButtonAnimation : MonoBehaviour
{
	// Token: 0x06000927 RID: 2343 RVA: 0x000423F4 File Offset: 0x000405F4
	private void Awake()
	{
		this.initial_size_x = base.transform.localScale.x;
		this.initial_size_y = base.transform.localScale.y;
	}

	// Token: 0x06000928 RID: 2344 RVA: 0x00042424 File Offset: 0x00040624
	private void FixedUpdate()
	{
		if (this.GO)
		{
			float num = base.transform.localScale.x;
			float num2 = base.transform.localScale.y;
			if (base.transform.localScale.y < this.initial_size_y)
			{
				num *= this.speed;
				num2 *= this.speed;
				base.transform.localScale = new Vector3(num, num2, 1f);
				return;
			}
			num = this.initial_size_x;
			num2 = this.initial_size_y;
			base.transform.localScale = new Vector3(num, num2, 1f);
			this.GO = false;
		}
	}

	// Token: 0x06000929 RID: 2345 RVA: 0x000424CC File Offset: 0x000406CC
	private void Go()
	{
		this.GO = true;
		base.transform.localScale = new Vector3(this.initial_size_x * this.factor, this.initial_size_y * this.factor, 1f);
	}

	// Token: 0x04001133 RID: 4403
	private float initial_size_x;

	// Token: 0x04001134 RID: 4404
	private float initial_size_y;

	// Token: 0x04001135 RID: 4405
	public float factor = 0.5f;

	// Token: 0x04001136 RID: 4406
	public float speed = 1.15f;

	// Token: 0x04001137 RID: 4407
	private bool GO;
}
