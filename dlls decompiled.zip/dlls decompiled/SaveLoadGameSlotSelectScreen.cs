﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200007B RID: 123
public class SaveLoadGameSlotSelectScreen : CSingleton<SaveLoadGameSlotSelectScreen>
{
	// Token: 0x060004E5 RID: 1253 RVA: 0x0002A340 File Offset: 0x00028540
	public static void OpenScreen(bool isSaveState)
	{
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsSavingGame)
		{
			return;
		}
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsSaveState = isSaveState;
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_LoadGameText.SetActive(!isSaveState);
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SaveGameText.SetActive(isSaveState);
		if (!isSaveState && CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Count >= 4)
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsDataLoaded = true;
		}
		if (!CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsDataLoaded)
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Clear();
			if (CSaveLoad.LoadSavedSlotData(0))
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(CGameData.instance.GetLoadSavedSlotData(CSaveLoad.m_SavedGameBackup));
			}
			else
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(default(LoadSavedSlotData));
			}
			if (CSaveLoad.LoadSavedSlotData(1))
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(CGameData.instance.GetLoadSavedSlotData(CSaveLoad.m_SavedGameBackup));
			}
			else
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(default(LoadSavedSlotData));
			}
			if (CSaveLoad.LoadSavedSlotData(2))
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(CGameData.instance.GetLoadSavedSlotData(CSaveLoad.m_SavedGameBackup));
			}
			else
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(default(LoadSavedSlotData));
			}
			if (CSaveLoad.LoadSavedSlotData(3))
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(CGameData.instance.GetLoadSavedSlotData(CSaveLoad.m_SavedGameBackup));
			}
			else
			{
				CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Add(default(LoadSavedSlotData));
			}
		}
		for (int i = 0; i < CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList.Count; i++)
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SaveLoadSlotPanelUIList[i].LoadSlotData(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList[i]);
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SaveLoadSlotPanelUIList[i].SetSaveOrLoadState(isSaveState);
		}
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ScreenGrp.SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x0002A54C File Offset: 0x0002874C
	public static void CloseScreen()
	{
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsSavingGame)
		{
			return;
		}
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteSaveFileScreenGrp.activeSelf)
		{
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.CloseConfirmOverwriteSaveScreen();
			return;
		}
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ScreenGrp.SetActive(false);
		SoundManager.GenericMenuClose(1f, 1f);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x060004E7 RID: 1255 RVA: 0x0002A5B0 File Offset: 0x000287B0
	public void OnPressLoadGame(int slotIndex)
	{
		if (this.m_IsSavingGame)
		{
			return;
		}
		if (this.m_IsOpeningLevel)
		{
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		this.m_IsOpeningLevel = true;
		CSingleton<CGameManager>.Instance.m_CurrentSaveLoadSlotSelectedIndex = slotIndex;
		CSingleton<CGameManager>.Instance.m_IsManualSaveLoad = true;
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Start", 0);
	}

	// Token: 0x060004E8 RID: 1256 RVA: 0x0002A60C File Offset: 0x0002880C
	public void OnPressSaveGame(int slotIndex)
	{
		if (this.m_IsSavingGame)
		{
			return;
		}
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList[slotIndex].hasSaveData && CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_SavedDataList[slotIndex].name != CPlayerData.PlayerName)
		{
			SoundManager.GenericMenuOpen(1f, 1f);
			this.m_CurrentSaveSlotIndex = slotIndex;
			CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteSaveFileScreenGrp.SetActive(true);
			ControllerScreenUIExtManager.OnOpenScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension_OverwriteSaveFileScreen);
			return;
		}
		this.m_CurrentSaveSlotIndex = slotIndex;
		SoundManager.GenericLightTap(1f, 1f);
		CSingleton<CGameManager>.Instance.m_CurrentSaveLoadSlotSelectedIndex = slotIndex;
		CSingleton<CGameManager>.Instance.m_IsManualSaveLoad = true;
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		CSingleton<CGameManager>.Instance.SaveGame(true);
		this.m_IsSavingGame = true;
		this.m_SavingGameScreen.gameObject.SetActive(true);
		base.StartCoroutine(this.DelaySavingGame());
	}

	// Token: 0x060004E9 RID: 1257 RVA: 0x0002A6F8 File Offset: 0x000288F8
	public void OnPressConfirmOverwriteSave()
	{
		if (this.m_IsSavingGame)
		{
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		CSingleton<CGameManager>.Instance.m_CurrentSaveLoadSlotSelectedIndex = this.m_CurrentSaveSlotIndex;
		CSingleton<CGameManager>.Instance.m_IsManualSaveLoad = true;
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		CSingleton<CGameManager>.Instance.SaveGame(true);
		this.m_IsSavingGame = true;
		this.m_SavingGameScreen.gameObject.SetActive(true);
		base.StartCoroutine(this.DelaySavingGame());
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteSaveFileScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension_OverwriteSaveFileScreen);
	}

	// Token: 0x060004EA RID: 1258 RVA: 0x0002A792 File Offset: 0x00028992
	public void CloseConfirmOverwriteSaveScreen()
	{
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_IsSavingGame)
		{
			return;
		}
		CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_OverwriteSaveFileScreenGrp.SetActive(false);
		SoundManager.GenericMenuClose(1f, 1f);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ControllerScreenUIExtension_OverwriteSaveFileScreen);
	}

	// Token: 0x060004EB RID: 1259 RVA: 0x0002A7CF File Offset: 0x000289CF
	private IEnumerator DelaySavingGame()
	{
		yield return new WaitForSecondsRealtime(2f);
		this.m_SavingGameScreen.gameObject.SetActive(false);
		this.m_IsSavingGame = false;
		SaveLoadGameSlotSelectScreen.CloseScreen();
		yield break;
	}

	// Token: 0x0400066F RID: 1647
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x04000670 RID: 1648
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_OverwriteSaveFileScreen;

	// Token: 0x04000671 RID: 1649
	public GameObject m_ScreenGrp;

	// Token: 0x04000672 RID: 1650
	public GameObject m_OverwriteSaveFileScreenGrp;

	// Token: 0x04000673 RID: 1651
	public GameObject m_LoadGameText;

	// Token: 0x04000674 RID: 1652
	public GameObject m_SaveGameText;

	// Token: 0x04000675 RID: 1653
	public GameObject m_SavingGameScreen;

	// Token: 0x04000676 RID: 1654
	public List<SaveLoadSlotPanelUI> m_SaveLoadSlotPanelUIList;

	// Token: 0x04000677 RID: 1655
	public List<LoadSavedSlotData> m_SavedDataList = new List<LoadSavedSlotData>();

	// Token: 0x04000678 RID: 1656
	private bool m_IsOpeningLevel;

	// Token: 0x04000679 RID: 1657
	private bool m_IsSavingGame;

	// Token: 0x0400067A RID: 1658
	private bool m_IsSaveState;

	// Token: 0x0400067B RID: 1659
	private bool m_IsDataLoaded;

	// Token: 0x0400067C RID: 1660
	private int m_CurrentSaveSlotIndex;
}
