﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;

// Token: 0x0200003C RID: 60
[Serializable]
public class MonsterData
{
	// Token: 0x060002FB RID: 763 RVA: 0x0001BF34 File Offset: 0x0001A134
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.Name, true, 0, true, false, null, null, true);
	}

	// Token: 0x060002FC RID: 764 RVA: 0x0001BF48 File Offset: 0x0001A148
	public string GetArtistName()
	{
		return "Illus. " + this.ArtistName;
	}

	// Token: 0x060002FD RID: 765 RVA: 0x0001BF5C File Offset: 0x0001A15C
	public string GetDescription()
	{
		if (this.Description == "")
		{
			return LocalizationManager.GetTranslation("No effect", true, 0, true, false, null, null, true);
		}
		return LocalizationManager.GetTranslation(this.Description, true, 0, true, false, null, null, true).Replace("XXX", this.EffectAmount.x.ToString()).Replace("YYY", this.EffectAmount.y.ToString()).Replace("ZZZ", this.EffectAmount.z.ToString());
	}

	// Token: 0x060002FE RID: 766 RVA: 0x0001BFED File Offset: 0x0001A1ED
	public string GetRarityName()
	{
		return LocalizationManager.GetTranslation(this.Rarity.ToString(), true, 0, true, false, null, null, true);
	}

	// Token: 0x060002FF RID: 767 RVA: 0x0001C00C File Offset: 0x0001A20C
	public string GetElementName()
	{
		return LocalizationManager.GetTranslation(this.ElementIndex.ToString(), true, 0, true, false, null, null, true);
	}

	// Token: 0x06000300 RID: 768 RVA: 0x0001C02C File Offset: 0x0001A22C
	public string GetRoleName()
	{
		string text = "";
		string result = "";
		for (int i = 0; i < this.Roles.Count; i++)
		{
			if (i > 0)
			{
				text += ", ";
			}
			string translation = LocalizationManager.GetTranslation(this.Roles[i].ToString(), true, 0, true, false, null, null, true);
			if (this.Roles[i] == EMonsterRole.AllRounder)
			{
				translation = LocalizationManager.GetTranslation("All Rounder", true, 0, true, false, null, null, true);
			}
			else if (this.Roles[i] == EMonsterRole.MagicalAttacker)
			{
				translation = LocalizationManager.GetTranslation("Magical Attacker", true, 0, true, false, null, null, true);
			}
			else if (this.Roles[i] == EMonsterRole.PhysicalAttacker)
			{
				translation = LocalizationManager.GetTranslation("Physical Attacker", true, 0, true, false, null, null, true);
			}
			text += translation;
			if (i == 0)
			{
				result = translation;
			}
		}
		if (text.Length > 27)
		{
			return result;
		}
		return text;
	}

	// Token: 0x06000301 RID: 769 RVA: 0x0001C11C File Offset: 0x0001A31C
	public Sprite GetIcon(ECardExpansionType cardExpansionType)
	{
		if (cardExpansionType == ECardExpansionType.Ghost)
		{
			return this.GhostIcon;
		}
		if (!(this.Icon == null))
		{
			return this.Icon;
		}
		if (cardExpansionType == ECardExpansionType.None)
		{
			return LoadStreamTexture.GetImage("Special_" + this.MonsterType.ToString());
		}
		return LoadStreamTexture.GetImage(cardExpansionType.ToString() + "_" + this.MonsterType.ToString());
	}

	// Token: 0x040003A3 RID: 931
	public string Name;

	// Token: 0x040003A4 RID: 932
	public string ArtistName;

	// Token: 0x040003A5 RID: 933
	public string Description;

	// Token: 0x040003A6 RID: 934
	public Vector3 EffectAmount;

	// Token: 0x040003A7 RID: 935
	public EElementIndex ElementIndex;

	// Token: 0x040003A8 RID: 936
	public ERarity Rarity;

	// Token: 0x040003A9 RID: 937
	public EMonsterType MonsterType;

	// Token: 0x040003AA RID: 938
	public EMonsterType NextEvolution;

	// Token: 0x040003AB RID: 939
	public EMonsterType PreviousEvolution;

	// Token: 0x040003AC RID: 940
	public List<EMonsterRole> Roles;

	// Token: 0x040003AD RID: 941
	public Stats BaseStats;

	// Token: 0x040003AE RID: 942
	public List<ESkill> SkillList;

	// Token: 0x040003AF RID: 943
	public Sprite Icon;

	// Token: 0x040003B0 RID: 944
	public Sprite GhostIcon;
}
