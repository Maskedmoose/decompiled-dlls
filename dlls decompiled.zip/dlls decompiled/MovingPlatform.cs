﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DF RID: 479
	public class MovingPlatform : MonoBehaviour
	{
		// Token: 0x06000D7F RID: 3455 RVA: 0x0005CE0C File Offset: 0x0005B00C
		private void Start()
		{
			this.r = base.GetComponent<Rigidbody>();
			this.triggerArea = base.GetComponentInChildren<TriggerArea>();
			this.r.freezeRotation = true;
			this.r.useGravity = false;
			this.r.isKinematic = true;
			if (this.waypoints.Count <= 0)
			{
				Debug.LogWarning("No waypoints have been assigned to 'MovingPlatform'!");
			}
			else
			{
				this.currentWaypoint = this.waypoints[this.currentWaypointIndex];
			}
			base.StartCoroutine(this.WaitRoutine());
			base.StartCoroutine(this.LateFixedUpdate());
		}

		// Token: 0x06000D80 RID: 3456 RVA: 0x0005CEA0 File Offset: 0x0005B0A0
		private IEnumerator LateFixedUpdate()
		{
			WaitForFixedUpdate _instruction = new WaitForFixedUpdate();
			for (;;)
			{
				yield return _instruction;
				this.MovePlatform();
			}
			yield break;
		}

		// Token: 0x06000D81 RID: 3457 RVA: 0x0005CEB0 File Offset: 0x0005B0B0
		private void MovePlatform()
		{
			if (this.waypoints.Count <= 0)
			{
				return;
			}
			if (this.isWaiting)
			{
				return;
			}
			Vector3 vector = this.currentWaypoint.position - base.transform.position;
			Vector3 vector2 = vector.normalized;
			vector2 *= this.movementSpeed * Time.deltaTime;
			if (vector2.magnitude >= vector.magnitude || vector2.magnitude == 0f)
			{
				this.r.transform.position = this.currentWaypoint.position;
				this.UpdateWaypoint();
			}
			else
			{
				this.r.transform.position += vector2;
			}
			if (this.triggerArea == null)
			{
				return;
			}
			for (int i = 0; i < this.triggerArea.rigidbodiesInTriggerArea.Count; i++)
			{
				this.triggerArea.rigidbodiesInTriggerArea[i].MovePosition(this.triggerArea.rigidbodiesInTriggerArea[i].position + vector2);
			}
		}

		// Token: 0x06000D82 RID: 3458 RVA: 0x0005CFC8 File Offset: 0x0005B1C8
		private void UpdateWaypoint()
		{
			if (this.reverseDirection)
			{
				this.currentWaypointIndex--;
			}
			else
			{
				this.currentWaypointIndex++;
			}
			if (this.currentWaypointIndex >= this.waypoints.Count)
			{
				this.currentWaypointIndex = 0;
			}
			if (this.currentWaypointIndex < 0)
			{
				this.currentWaypointIndex = this.waypoints.Count - 1;
			}
			this.currentWaypoint = this.waypoints[this.currentWaypointIndex];
			this.isWaiting = true;
		}

		// Token: 0x06000D83 RID: 3459 RVA: 0x0005D04F File Offset: 0x0005B24F
		private IEnumerator WaitRoutine()
		{
			WaitForSeconds _waitInstruction = new WaitForSeconds(this.waitTime);
			for (;;)
			{
				if (this.isWaiting)
				{
					yield return _waitInstruction;
					this.isWaiting = false;
				}
				yield return null;
			}
			yield break;
		}

		// Token: 0x04001475 RID: 5237
		public float movementSpeed = 10f;

		// Token: 0x04001476 RID: 5238
		public bool reverseDirection;

		// Token: 0x04001477 RID: 5239
		public float waitTime = 1f;

		// Token: 0x04001478 RID: 5240
		private bool isWaiting;

		// Token: 0x04001479 RID: 5241
		private Rigidbody r;

		// Token: 0x0400147A RID: 5242
		private TriggerArea triggerArea;

		// Token: 0x0400147B RID: 5243
		public List<Transform> waypoints = new List<Transform>();

		// Token: 0x0400147C RID: 5244
		private int currentWaypointIndex;

		// Token: 0x0400147D RID: 5245
		private Transform currentWaypoint;
	}
}
