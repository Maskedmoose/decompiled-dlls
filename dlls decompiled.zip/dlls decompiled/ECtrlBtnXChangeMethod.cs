﻿using System;

// Token: 0x0200010C RID: 268
public enum ECtrlBtnXChangeMethod
{
	// Token: 0x04000F08 RID: 3848
	Normal,
	// Token: 0x04000F09 RID: 3849
	AlwaysZeroifGoDown,
	// Token: 0x04000F0A RID: 3850
	RememberIndexX,
	// Token: 0x04000F0B RID: 3851
	AlwaysGoIndexYOne,
	// Token: 0x04000F0C RID: 3852
	SettingScreenSkipSideButtonIndexY
}
