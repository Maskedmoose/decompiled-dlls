﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001C3 RID: 451
	public class Option_Grid_Picker : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CB2 RID: 3250 RVA: 0x00058520 File Offset: 0x00056720
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util parentUI)
		{
			this.customizer = customizerScript;
			Option_Grid_Picker.Type customizationType = this.CustomizationType;
			if (customizationType != Option_Grid_Picker.Type.Blendshape)
			{
			}
		}

		// Token: 0x06000CB3 RID: 3251 RVA: 0x00058542 File Offset: 0x00056742
		public void RefreshUIElement()
		{
		}

		// Token: 0x06000CB4 RID: 3252 RVA: 0x00058544 File Offset: 0x00056744
		public void updateValue(Vector2 coords)
		{
			Option_Grid_Picker.Type customizationType = this.CustomizationType;
			if (customizationType == Option_Grid_Picker.Type.Blendshape)
			{
				Vector2 vector = new Vector2(coords.x * 2f - 1f, coords.y * 2f - 1f);
				foreach (string name in this.ShapesYNeg)
				{
					this.customizer.setBlendshapeByName(name, Mathf.Abs(Mathf.Clamp(vector.y, -1f, 0f)), this.save);
				}
				foreach (string name2 in this.ShapesYPos)
				{
					this.customizer.setBlendshapeByName(name2, Mathf.Clamp(vector.y, 0f, 1f), this.save);
				}
				foreach (string name3 in this.ShapesXPos)
				{
					this.customizer.setBlendshapeByName(name3, Mathf.Clamp(vector.x, 0f, 1f), this.save);
				}
				foreach (string name4 in this.ShapesXNeg)
				{
					this.customizer.setBlendshapeByName(name4, Mathf.Abs(Mathf.Clamp(vector.x, -1f, 0f)), this.save);
				}
				return;
			}
			if (customizationType != Option_Grid_Picker.Type.Color)
			{
				return;
			}
			int x = Mathf.RoundToInt((float)this.colorTexture.width * coords.x);
			int y = Mathf.RoundToInt((float)this.colorTexture.height * coords.y);
			Color pixel = this.colorTexture.GetPixel(x, y);
			this.customizer.setColorProperty(this.ColorProperty, pixel, true);
		}

		// Token: 0x04001390 RID: 5008
		private CharacterCustomization customizer;

		// Token: 0x04001391 RID: 5009
		public string[] ShapesYNeg;

		// Token: 0x04001392 RID: 5010
		public string[] ShapesYPos;

		// Token: 0x04001393 RID: 5011
		public string[] ShapesXNeg;

		// Token: 0x04001394 RID: 5012
		public string[] ShapesXPos;

		// Token: 0x04001395 RID: 5013
		public bool save;

		// Token: 0x04001396 RID: 5014
		public Texture2D colorTexture;

		// Token: 0x04001397 RID: 5015
		public Option_Grid_Picker.Type CustomizationType;

		// Token: 0x04001398 RID: 5016
		public CC_Property ColorProperty;

		// Token: 0x02000273 RID: 627
		public enum Type
		{
			// Token: 0x04001677 RID: 5751
			Blendshape,
			// Token: 0x04001678 RID: 5752
			Color
		}
	}
}
