﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200011F RID: 287
public class RaycasterManager : CSingleton<RaycasterManager>
{
	// Token: 0x06000861 RID: 2145 RVA: 0x0003E9C0 File Offset: 0x0003CBC0
	private void Start()
	{
		GraphicRaycaster[] componentsInChildren = base.gameObject.GetComponentsInChildren<GraphicRaycaster>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			this.m_RaycasterList.Add(componentsInChildren[i]);
		}
		for (int j = 0; j < this.m_CustomRaycasterList.Count; j++)
		{
			this.m_RaycasterList.Add(this.m_CustomRaycasterList[j]);
		}
		HorizontalLayoutGroup[] componentsInChildren2 = base.gameObject.GetComponentsInChildren<HorizontalLayoutGroup>();
		for (int k = 0; k < componentsInChildren2.Length; k++)
		{
			if (!this.m_HLayoutGrpExceptionList.Contains(componentsInChildren2[k]))
			{
				this.m_HLayoutGrpList.Add(componentsInChildren2[k]);
			}
		}
		VerticalLayoutGroup[] componentsInChildren3 = base.gameObject.GetComponentsInChildren<VerticalLayoutGroup>();
		for (int l = 0; l < componentsInChildren3.Length; l++)
		{
			this.m_VLayoutGrpList.Add(componentsInChildren3[l]);
		}
	}

	// Token: 0x06000862 RID: 2146 RVA: 0x0003EA92 File Offset: 0x0003CC92
	private IEnumerator DisableLayoutGrp()
	{
		yield return new WaitForSeconds(1f);
		for (int i = 0; i < this.m_HLayoutGrpList.Count; i++)
		{
			this.m_HLayoutGrpList[i].enabled = false;
		}
		for (int j = 0; j < this.m_VLayoutGrpList.Count; j++)
		{
			this.m_VLayoutGrpList[j].enabled = false;
		}
		yield break;
	}

	// Token: 0x06000863 RID: 2147 RVA: 0x0003EAA4 File Offset: 0x0003CCA4
	public static void SetUIRaycastEnabled(bool isEnabled)
	{
		for (int i = 0; i < CSingleton<RaycasterManager>.Instance.m_RaycasterList.Count; i++)
		{
			CSingleton<RaycasterManager>.Instance.m_RaycasterList[i].enabled = isEnabled;
		}
	}

	// Token: 0x04001023 RID: 4131
	public List<GraphicRaycaster> m_RaycasterList = new List<GraphicRaycaster>();

	// Token: 0x04001024 RID: 4132
	public List<GraphicRaycaster> m_CustomRaycasterList = new List<GraphicRaycaster>();

	// Token: 0x04001025 RID: 4133
	public List<HorizontalLayoutGroup> m_HLayoutGrpList = new List<HorizontalLayoutGroup>();

	// Token: 0x04001026 RID: 4134
	public List<VerticalLayoutGroup> m_VLayoutGrpList = new List<VerticalLayoutGroup>();

	// Token: 0x04001027 RID: 4135
	public List<HorizontalLayoutGroup> m_HLayoutGrpExceptionList = new List<HorizontalLayoutGroup>();
}
