﻿using System;

// Token: 0x02000029 RID: 41
public class InteractableStorageCompartment : InteractableObject
{
	// Token: 0x06000224 RID: 548 RVA: 0x00014EB9 File Offset: 0x000130B9
	public void InitWarehouseShelf(WarehouseShelf warehouseShelf, ShelfCompartment shelfCompartment, int index)
	{
		this.m_WarehouseShelf = warehouseShelf;
		this.m_ShelfCompartment = shelfCompartment;
		this.m_ShelfCompartment.SetIndex(index);
		this.m_ShelfCompartment.SetWarehouseShelf(this.m_WarehouseShelf);
	}

	// Token: 0x06000225 RID: 549 RVA: 0x00014EE8 File Offset: 0x000130E8
	public override void OnMouseButtonUp()
	{
		if (this.m_ShelfCompartment.GetInteractablePackagingBoxList().Count > 0)
		{
			InteractablePackagingBox_Item lastInteractablePackagingBox = this.m_ShelfCompartment.GetLastInteractablePackagingBox();
			if (lastInteractablePackagingBox.CanPickup())
			{
				lastInteractablePackagingBox.StartHoldBox(true, CSingleton<InteractionPlayerController>.Instance.m_HoldItemPos);
				this.m_ShelfCompartment.RemoveBox(lastInteractablePackagingBox);
			}
		}
	}

	// Token: 0x06000226 RID: 550 RVA: 0x00014F3C File Offset: 0x0001313C
	public void DisableAllItem()
	{
		for (int i = 0; i < this.m_ShelfCompartment.GetInteractablePackagingBoxList().Count; i++)
		{
			if (this.m_ShelfCompartment.GetInteractablePackagingBoxList()[i])
			{
				this.m_ShelfCompartment.GetInteractablePackagingBoxList()[i].m_ItemCompartment.DisableAllItem();
			}
			RestockManager.RemoveItemPackageBox(this.m_ShelfCompartment.GetInteractablePackagingBoxList()[i]);
		}
	}

	// Token: 0x06000227 RID: 551 RVA: 0x00014FAD File Offset: 0x000131AD
	public ShelfCompartment GetShelfCompartment()
	{
		return this.m_ShelfCompartment;
	}

	// Token: 0x04000267 RID: 615
	private WarehouseShelf m_WarehouseShelf;

	// Token: 0x04000268 RID: 616
	private ShelfCompartment m_ShelfCompartment;
}
