﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000112 RID: 274
public class InputTooltipUI : MonoBehaviour
{
	// Token: 0x0600080C RID: 2060 RVA: 0x0003BE5F File Offset: 0x0003A05F
	public void SetActive(bool isActive)
	{
		this.m_IsActive = isActive;
		base.gameObject.SetActive(isActive);
	}

	// Token: 0x0600080D RID: 2061 RVA: 0x0003BE74 File Offset: 0x0003A074
	public void SetGamepadInputTooltip(EGameAction gameAction, EGamepadControlBtn gamepadControlBtn, string actionName, bool isHold)
	{
		this.m_CurrentGameAction = gameAction;
		this.m_ActionText.text = actionName;
		this.m_GamepadControlBtn = gamepadControlBtn;
		this.m_IsHold = isHold;
		this.m_KeycodeText.text = "";
		if (CSingleton<InputManager>.Instance.m_IsPSController)
		{
			this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_PSCtrlBtnSpriteList[(int)this.m_GamepadControlBtn];
			return;
		}
		this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_XBoxCtrlBtnSpriteList[(int)this.m_GamepadControlBtn];
	}

	// Token: 0x0600080E RID: 2062 RVA: 0x0003BF10 File Offset: 0x0003A110
	public void SetInputTooltip(EGameAction gameAction, KeyCode keycode, string actionName, bool isHold)
	{
		this.m_CurrentGameAction = gameAction;
		this.m_KeycodeText.text = keycode.ToString();
		this.m_ActionText.text = actionName;
		this.m_KeyCode = keycode;
		this.m_ActionName = actionName;
		this.m_IsHold = isHold;
		if (keycode == KeyCode.Mouse0)
		{
			this.m_KeycodeText.text = "";
			if (isHold)
			{
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_LeftMouseHoldImage;
				return;
			}
			this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_LeftMouseClickImage;
			return;
		}
		else if (keycode == KeyCode.Mouse1)
		{
			this.m_KeycodeText.text = "";
			if (isHold)
			{
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_RightMouseHoldImage;
				return;
			}
			this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_RightMouseClickImage;
			return;
		}
		else
		{
			if (keycode == KeyCode.Mouse2)
			{
				this.m_ActionText.text = this.m_ActionText.text;
				this.m_KeycodeText.text = "";
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_MiddleMouseScrollImage;
				return;
			}
			if (keycode == KeyCode.Return)
			{
				this.m_KeycodeText.text = "";
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_EnterImage;
				return;
			}
			if (keycode == KeyCode.Space)
			{
				this.m_KeycodeText.text = "";
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_SpacebarImage;
				return;
			}
			if (keycode == KeyCode.Tab)
			{
				this.m_KeycodeText.text = "";
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_TabImage;
				return;
			}
			if (keycode == KeyCode.LeftShift || keycode == KeyCode.RightShift)
			{
				this.m_KeycodeText.text = "";
				this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_ShiftImage;
				return;
			}
			if (keycode == KeyCode.Escape)
			{
				this.m_KeycodeText.text = "Esc";
			}
			else if (keycode == KeyCode.Backspace)
			{
				this.m_KeycodeText.text = "BSpace";
			}
			this.m_KeyImage.sprite = CSingleton<CGameManager>.Instance.m_TextSO.m_KeyboardBtnImage;
			return;
		}
	}

	// Token: 0x04000F43 RID: 3907
	public Image m_KeyImage;

	// Token: 0x04000F44 RID: 3908
	public TextMeshProUGUI m_KeycodeText;

	// Token: 0x04000F45 RID: 3909
	public TextMeshProUGUI m_ActionText;

	// Token: 0x04000F46 RID: 3910
	public bool m_IsActive;

	// Token: 0x04000F47 RID: 3911
	public Transform m_Transform;

	// Token: 0x04000F48 RID: 3912
	public EGameAction m_CurrentGameAction;

	// Token: 0x04000F49 RID: 3913
	private bool m_IsHold;

	// Token: 0x04000F4A RID: 3914
	private KeyCode m_KeyCode;

	// Token: 0x04000F4B RID: 3915
	private EGamepadControlBtn m_GamepadControlBtn = EGamepadControlBtn.Start;

	// Token: 0x04000F4C RID: 3916
	private string m_ActionName = "";
}
