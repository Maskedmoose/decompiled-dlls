﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CC
{
	// Token: 0x020001BB RID: 443
	public class CC_UI_Manager : MonoBehaviour
	{
		// Token: 0x06000C8D RID: 3213 RVA: 0x00057BEC File Offset: 0x00055DEC
		private void Awake()
		{
			if (CC_UI_Manager.instance == null)
			{
				CC_UI_Manager.instance = this;
				return;
			}
			Object.Destroy(base.gameObject);
		}

		// Token: 0x06000C8E RID: 3214 RVA: 0x00057C0D File Offset: 0x00055E0D
		public void Start()
		{
			this.SetActiveCharacter(0);
		}

		// Token: 0x06000C8F RID: 3215 RVA: 0x00057C18 File Offset: 0x00055E18
		public void playUIAudio(int Index)
		{
			AudioSource component = base.gameObject.GetComponent<AudioSource>();
			if (component && this.UISounds.Count > Index)
			{
				component.clip = this.UISounds[Index];
			}
			component.Play();
		}

		// Token: 0x06000C90 RID: 3216 RVA: 0x00057C60 File Offset: 0x00055E60
		public void SetActiveCharacter(int i)
		{
			this.characterIndex = i;
			for (int j = 0; j < this.CharacterParent.transform.childCount; j++)
			{
				this.CharacterParent.transform.GetChild(j).gameObject.SetActive(i == j);
				this.CharacterParent.transform.GetChild(j).GetComponent<CharacterCustomization>().UI.SetActive(i == j);
			}
		}

		// Token: 0x06000C91 RID: 3217 RVA: 0x00057CD2 File Offset: 0x00055ED2
		public void characterNext()
		{
			this.SetActiveCharacter((this.characterIndex == this.CharacterParent.transform.childCount - 1) ? 0 : (this.characterIndex + 1));
		}

		// Token: 0x06000C92 RID: 3218 RVA: 0x00057CFF File Offset: 0x00055EFF
		public void characterPrev()
		{
			this.SetActiveCharacter((this.characterIndex == 0) ? (this.CharacterParent.transform.childCount - 1) : (this.characterIndex - 1));
		}

		// Token: 0x0400136C RID: 4972
		public static CC_UI_Manager instance;

		// Token: 0x0400136D RID: 4973
		[Tooltip("The parent object of your customizable characters")]
		public GameObject CharacterParent;

		// Token: 0x0400136E RID: 4974
		public List<AudioClip> UISounds = new List<AudioClip>();

		// Token: 0x0400136F RID: 4975
		private int characterIndex;
	}
}
