﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200007E RID: 126
public class SetGameEventPriceScreen : UIScreenBase
{
	// Token: 0x060004FA RID: 1274 RVA: 0x0002AC40 File Offset: 0x00028E40
	protected override void OnOpenScreen()
	{
		EGameEventFormat egameEventFormat = CPlayerData.m_GameEventFormat;
		if (CPlayerData.m_PendingGameEventFormat != EGameEventFormat.None)
		{
			egameEventFormat = CPlayerData.m_PendingGameEventFormat;
		}
		if (egameEventFormat == EGameEventFormat.None)
		{
			Debug.LogError("Event type cannot be none");
			return;
		}
		this.m_GameEventFormat = egameEventFormat;
		this.m_PriceSet = PriceChangeManager.GetGameEventPrice(this.m_GameEventFormat, false);
		this.m_MarketPrice = PriceChangeManager.GetGameEventMarketPrice(this.m_GameEventFormat);
		this.m_SetPrice.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_SetPriceInputDisplay.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_MarketPriceText.text = GameInstance.GetPriceString(this.m_MarketPrice, false, true, false, "F2");
		this.m_SetPriceInputDisplay.gameObject.SetActive(false);
		base.OnOpenScreen();
	}

	// Token: 0x060004FB RID: 1275 RVA: 0x0002AD0B File Offset: 0x00028F0B
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
	}

	// Token: 0x060004FC RID: 1276 RVA: 0x0002AD13 File Offset: 0x00028F13
	public void OnPressConfirm()
	{
		PriceChangeManager.SetGameEventPrice(this.m_GameEventFormat, this.m_PriceSet);
		base.CloseScreen();
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x060004FD RID: 1277 RVA: 0x0002AD3C File Offset: 0x00028F3C
	public void OnInputChanged(string text)
	{
		float num = GameInstance.GetInvariantCultureDecimal(text) / GameInstance.GetCurrencyConversionRate();
		num = (float)Mathf.RoundToInt(num * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		this.m_SetPriceInputDisplay.text = GameInstance.GetPriceString(num, false, true, false, "F2");
		this.m_SetPriceInputDisplay.gameObject.SetActive(true);
		this.m_SetPrice.gameObject.SetActive(false);
	}

	// Token: 0x060004FE RID: 1278 RVA: 0x0002ADA8 File Offset: 0x00028FA8
	public void OnInputTextSelected(string text)
	{
		this.m_SetPriceInputDisplay.gameObject.SetActive(true);
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F0");
		}
		else
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F2");
		}
		this.m_SetPrice.gameObject.SetActive(false);
	}

	// Token: 0x060004FF RID: 1279 RVA: 0x0002AE24 File Offset: 0x00029024
	public void OnInputTextUpdated(string text)
	{
		float num = GameInstance.GetInvariantCultureDecimal(text) / GameInstance.GetCurrencyConversionRate();
		this.m_PriceSet = (float)Mathf.RoundToInt(num * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		if (this.m_PriceSet < 0f)
		{
			this.m_PriceSet = 0f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F0");
		}
		else
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F2");
		}
		this.m_SetPriceInputDisplay.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_SetPrice.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_SetPriceInputDisplay.gameObject.SetActive(false);
		this.m_SetPrice.gameObject.SetActive(true);
	}

	// Token: 0x04000696 RID: 1686
	public TextMeshProUGUI m_MarketPriceText;

	// Token: 0x04000697 RID: 1687
	public TMP_InputField m_SetPriceInput;

	// Token: 0x04000698 RID: 1688
	public TextMeshProUGUI m_SetPriceInputDisplay;

	// Token: 0x04000699 RID: 1689
	public TextMeshProUGUI m_SetPrice;

	// Token: 0x0400069A RID: 1690
	private float m_PriceSet;

	// Token: 0x0400069B RID: 1691
	private float m_MarketPrice;

	// Token: 0x0400069C RID: 1692
	private EGameEventFormat m_GameEventFormat;
}
