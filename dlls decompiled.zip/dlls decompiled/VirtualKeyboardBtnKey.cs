﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000113 RID: 275
public class VirtualKeyboardBtnKey : MonoBehaviour
{
	// Token: 0x06000810 RID: 2064 RVA: 0x0003C179 File Offset: 0x0003A379
	public void Init(VirtualKeyboardScreenUI virtualKeyboardScreenUI)
	{
		this.m_VirtualKeyboardScreenUI = virtualKeyboardScreenUI;
		this.EvaluateKey();
	}

	// Token: 0x06000811 RID: 2065 RVA: 0x0003C188 File Offset: 0x0003A388
	public void EvaluateKey()
	{
		if (this.m_IsCapital || this.m_IsBack || this.m_IsSpacebar || this.m_IsDone)
		{
			return;
		}
		if (!this.m_VirtualKeyboardScreenUI.m_IsAltActive)
		{
			this.m_KeyText.text = this.m_String.ToLower();
			return;
		}
		if (this.m_AltString != null && this.m_AltString != "")
		{
			this.m_KeyText.text = this.m_AltString;
			return;
		}
		this.m_KeyText.text = this.m_String.ToUpper();
	}

	// Token: 0x06000812 RID: 2066 RVA: 0x0003C21C File Offset: 0x0003A41C
	public void OnPressButton()
	{
		if (this.m_IsCapital)
		{
			this.m_VirtualKeyboardScreenUI.OnPressCapitalKey();
		}
		else if (this.m_IsBack)
		{
			this.m_VirtualKeyboardScreenUI.OnPressBackKey();
		}
		else if (this.m_IsSpacebar)
		{
			this.m_VirtualKeyboardScreenUI.OnPressSpaceKey();
		}
		else if (this.m_IsDone)
		{
			this.m_VirtualKeyboardScreenUI.OnPressDoneKey();
		}
		else
		{
			this.m_VirtualKeyboardScreenUI.OnPressButton(this.m_KeyText.text);
		}
		SoundManager.GenericLightTap(0.4f, 1f);
	}

	// Token: 0x04000F4D RID: 3917
	public TextMeshProUGUI m_KeyText;

	// Token: 0x04000F4E RID: 3918
	public string m_String;

	// Token: 0x04000F4F RID: 3919
	public string m_AltString;

	// Token: 0x04000F50 RID: 3920
	public bool m_IsSpacebar;

	// Token: 0x04000F51 RID: 3921
	public bool m_IsBack;

	// Token: 0x04000F52 RID: 3922
	public bool m_IsCapital;

	// Token: 0x04000F53 RID: 3923
	public bool m_IsDone;

	// Token: 0x04000F54 RID: 3924
	private VirtualKeyboardScreenUI m_VirtualKeyboardScreenUI;
}
