﻿using System;

// Token: 0x020000C9 RID: 201
public class CEventPlayer_VolumeChanged : CEvent
{
}
