﻿using System;
using TMPro;
using UnityEngine.UI;

// Token: 0x02000066 RID: 102
public class FurnitureShopConfirmPurchaseScreen : UIScreenBase
{
	// Token: 0x06000459 RID: 1113 RVA: 0x00026010 File Offset: 0x00024210
	public void UpdateData(FurnitureShopUIScreen furnitureShopUIScreen, int index)
	{
		this.m_FurnitureShopUIScreen = furnitureShopUIScreen;
		this.m_Index = index;
		FurniturePurchaseData furniturePurchaseData = InventoryBase.GetFurniturePurchaseData(index);
		this.m_TotalCost = furniturePurchaseData.price;
		this.m_Image.sprite = furniturePurchaseData.icon;
		this.m_NameText.text = furniturePurchaseData.GetName();
		this.m_DescriptionText.text = furniturePurchaseData.GetDescription();
		this.m_PriceText.text = GameInstance.GetPriceString(this.m_TotalCost, false, true, false, "F2");
	}

	// Token: 0x0600045A RID: 1114 RVA: 0x00026090 File Offset: 0x00024290
	public void OnPressConfirmCheckout()
	{
		if (this.m_TotalCost <= 0f)
		{
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.NothingInCart);
			return;
		}
		if (CPlayerData.m_CoinAmount >= this.m_TotalCost)
		{
			this.m_FurnitureShopUIScreen.EvaluateCartCheckout(this.m_TotalCost, this.m_Index);
			base.CloseScreen();
			return;
		}
		NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.Money);
	}

	// Token: 0x0400055A RID: 1370
	public Image m_Image;

	// Token: 0x0400055B RID: 1371
	public TextMeshProUGUI m_NameText;

	// Token: 0x0400055C RID: 1372
	public TextMeshProUGUI m_DescriptionText;

	// Token: 0x0400055D RID: 1373
	public TextMeshProUGUI m_PriceText;

	// Token: 0x0400055E RID: 1374
	private FurnitureShopUIScreen m_FurnitureShopUIScreen;

	// Token: 0x0400055F RID: 1375
	private int m_Index;

	// Token: 0x04000560 RID: 1376
	private float m_TotalCost;
}
