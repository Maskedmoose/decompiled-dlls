﻿using System;

namespace CC
{
	// Token: 0x020001B6 RID: 438
	[Serializable]
	public class FootOffset
	{
		// Token: 0x04001359 RID: 4953
		public float HeightOffset = -1f;

		// Token: 0x0400135A RID: 4954
		public float FootRotation;

		// Token: 0x0400135B RID: 4955
		public float BallRotation;
	}
}
