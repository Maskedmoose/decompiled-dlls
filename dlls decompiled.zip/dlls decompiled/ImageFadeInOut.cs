﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000105 RID: 261
public class ImageFadeInOut : MonoBehaviour
{
	// Token: 0x060007A6 RID: 1958 RVA: 0x0003960C File Offset: 0x0003780C
	private void Awake()
	{
		this.m_DefaultFadeAlpha = this.m_Image.color.a;
		this.m_Color = this.m_Image.color;
		if (this.m_FadeOutOnStart)
		{
			this.m_Color.a = 0f;
			this.m_Image.color = this.m_Color;
		}
		this.m_Image.enabled = true;
	}

	// Token: 0x060007A7 RID: 1959 RVA: 0x00039675 File Offset: 0x00037875
	public void SetFadeIn(float fadeSpeed = 1f, float delay = 0f)
	{
		this.m_IsFadingIn = true;
		this.m_IsFadingOut = false;
		this.m_FadeSpeed = fadeSpeed;
		this.m_Delay = delay;
	}

	// Token: 0x060007A8 RID: 1960 RVA: 0x00039693 File Offset: 0x00037893
	public void SetFadeOut(float fadeSpeed = 1f, float delay = 0f)
	{
		this.m_IsFadingIn = false;
		this.m_IsFadingOut = true;
		this.m_FadeSpeed = fadeSpeed;
		this.m_Delay = delay;
	}

	// Token: 0x060007A9 RID: 1961 RVA: 0x000396B4 File Offset: 0x000378B4
	private void Update()
	{
		if (this.m_Delay > 0f)
		{
			this.m_Delay -= Time.deltaTime;
			return;
		}
		if (this.m_IsFadingIn)
		{
			this.m_Timer += Time.deltaTime * this.m_FadeSpeed;
			if (this.m_Timer >= 1f)
			{
				this.m_Timer = 1f;
				this.m_IsFadingIn = false;
			}
			this.m_Color.a = Mathf.Lerp(0f, this.m_DefaultFadeAlpha, this.m_Timer);
			this.m_Image.color = this.m_Color;
			return;
		}
		if (this.m_IsFadingOut)
		{
			this.m_Timer -= Time.deltaTime * this.m_FadeSpeed;
			if (this.m_Timer <= 0f)
			{
				this.m_Timer = 0f;
				this.m_IsFadingOut = false;
			}
			this.m_Color.a = Mathf.Lerp(0f, this.m_DefaultFadeAlpha, this.m_Timer);
			this.m_Image.color = this.m_Color;
		}
	}

	// Token: 0x04000EDA RID: 3802
	public Image m_Image;

	// Token: 0x04000EDB RID: 3803
	public bool m_FadeOutOnStart = true;

	// Token: 0x04000EDC RID: 3804
	private bool m_IsFadingIn;

	// Token: 0x04000EDD RID: 3805
	private bool m_IsFadingOut;

	// Token: 0x04000EDE RID: 3806
	private float m_DefaultFadeAlpha;

	// Token: 0x04000EDF RID: 3807
	private float m_Timer;

	// Token: 0x04000EE0 RID: 3808
	private float m_FadeSpeed = 1f;

	// Token: 0x04000EE1 RID: 3809
	private float m_Delay;

	// Token: 0x04000EE2 RID: 3810
	private Color m_Color;
}
