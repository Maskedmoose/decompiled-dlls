﻿using System;

// Token: 0x020000DF RID: 223
public enum ECustomerType
{
	// Token: 0x04000A89 RID: 2697
	None = -1,
	// Token: 0x04000A8A RID: 2698
	Peasant,
	// Token: 0x04000A8B RID: 2699
	AverageJoe,
	// Token: 0x04000A8C RID: 2700
	Shark,
	// Token: 0x04000A8D RID: 2701
	Whale,
	// Token: 0x04000A8E RID: 2702
	Collector,
	// Token: 0x04000A8F RID: 2703
	SuperCollector,
	// Token: 0x04000A90 RID: 2704
	UltimateCollector,
	// Token: 0x04000A91 RID: 2705
	LegendCollector,
	// Token: 0x04000A92 RID: 2706
	MAX
}
