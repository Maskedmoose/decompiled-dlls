﻿using System;
using UnityEngine;

// Token: 0x0200013E RID: 318
public class PEDestoryTimed : MonoBehaviour
{
	// Token: 0x06000908 RID: 2312 RVA: 0x00041F07 File Offset: 0x00040107
	private void Start()
	{
	}

	// Token: 0x06000909 RID: 2313 RVA: 0x00041F09 File Offset: 0x00040109
	private void Update()
	{
	}
}
