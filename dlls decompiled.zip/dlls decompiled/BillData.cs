﻿using System;

// Token: 0x02000072 RID: 114
[Serializable]
public class BillData
{
	// Token: 0x04000616 RID: 1558
	public EBillType billType;

	// Token: 0x04000617 RID: 1559
	public int billDayPassed;

	// Token: 0x04000618 RID: 1560
	public float amountToPay;
}
