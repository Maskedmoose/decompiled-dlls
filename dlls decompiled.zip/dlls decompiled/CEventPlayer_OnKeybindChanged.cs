﻿using System;

// Token: 0x020000CF RID: 207
public class CEventPlayer_OnKeybindChanged : CEvent
{
}
