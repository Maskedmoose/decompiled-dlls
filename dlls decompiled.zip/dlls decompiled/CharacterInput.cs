﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E5 RID: 485
	public abstract class CharacterInput : MonoBehaviour
	{
		// Token: 0x06000D98 RID: 3480
		public abstract float GetHorizontalMovementInput();

		// Token: 0x06000D99 RID: 3481
		public abstract float GetVerticalMovementInput();

		// Token: 0x06000D9A RID: 3482
		public abstract bool IsJumpKeyPressed();
	}
}
