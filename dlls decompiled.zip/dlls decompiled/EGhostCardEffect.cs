﻿using System;

// Token: 0x02000101 RID: 257
public enum EGhostCardEffect
{
	// Token: 0x04000EBA RID: 3770
	None,
	// Token: 0x04000EBB RID: 3771
	MoreMoney,
	// Token: 0x04000EBC RID: 3772
	MoreFame,
	// Token: 0x04000EBD RID: 3773
	MoreDP,
	// Token: 0x04000EBE RID: 3774
	ReducePlayTableTime,
	// Token: 0x04000EBF RID: 3775
	CustomerDoubleChance,
	// Token: 0x04000EC0 RID: 3776
	FoilChance,
	// Token: 0x04000EC1 RID: 3777
	CustomerSpendingPower,
	// Token: 0x04000EC2 RID: 3778
	CollectorChance,
	// Token: 0x04000EC3 RID: 3779
	SuperCollectorChance,
	// Token: 0x04000EC4 RID: 3780
	UltimateCollectorChance,
	// Token: 0x04000EC5 RID: 3781
	LegendaryCollectorChance,
	// Token: 0x04000EC6 RID: 3782
	CommonPackOverCharge,
	// Token: 0x04000EC7 RID: 3783
	CommonBoxOverCharge,
	// Token: 0x04000EC8 RID: 3784
	RarePackOverCharge,
	// Token: 0x04000EC9 RID: 3785
	RareBoxOverCharge,
	// Token: 0x04000ECA RID: 3786
	EpicPackOverCharge,
	// Token: 0x04000ECB RID: 3787
	EpicBoxOverCharge,
	// Token: 0x04000ECC RID: 3788
	LegendaryPackOverCharge,
	// Token: 0x04000ECD RID: 3789
	LegendaryBoxOverCharge,
	// Token: 0x04000ECE RID: 3790
	MAX
}
