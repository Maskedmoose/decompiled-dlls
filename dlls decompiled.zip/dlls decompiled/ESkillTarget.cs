﻿using System;

// Token: 0x020000F0 RID: 240
public enum ESkillTarget
{
	// Token: 0x04000D52 RID: 3410
	None,
	// Token: 0x04000D53 RID: 3411
	Single,
	// Token: 0x04000D54 RID: 3412
	AllActive,
	// Token: 0x04000D55 RID: 3413
	All,
	// Token: 0x04000D56 RID: 3414
	Team
}
