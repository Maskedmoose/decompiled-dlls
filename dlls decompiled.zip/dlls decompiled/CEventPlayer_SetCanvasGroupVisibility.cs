﻿using System;

// Token: 0x020000C4 RID: 196
public class CEventPlayer_SetCanvasGroupVisibility : CEvent
{
	// Token: 0x17000022 RID: 34
	// (get) Token: 0x0600072F RID: 1839 RVA: 0x00038207 File Offset: 0x00036407
	// (set) Token: 0x06000730 RID: 1840 RVA: 0x0003820F File Offset: 0x0003640F
	public bool m_IsVisible { get; private set; }

	// Token: 0x06000731 RID: 1841 RVA: 0x00038218 File Offset: 0x00036418
	public CEventPlayer_SetCanvasGroupVisibility(bool isVisible)
	{
		this.m_IsVisible = isVisible;
	}
}
