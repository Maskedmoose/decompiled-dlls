﻿using System;
using System.Collections;
using TMPro;
using UnityEngine;

// Token: 0x0200009B RID: 155
public class LoadingScreen : CSingleton<LoadingScreen>
{
	// Token: 0x06000612 RID: 1554 RVA: 0x00031F43 File Offset: 0x00030143
	private void Awake()
	{
		if (LoadingScreen.m_Instance == null)
		{
			LoadingScreen.m_Instance = this;
		}
		else if (LoadingScreen.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x06000613 RID: 1555 RVA: 0x00031F78 File Offset: 0x00030178
	public static void OpenScreen()
	{
		CSingleton<LoadingScreen>.Instance.m_PercentText.text = "0%";
		CSingleton<LoadingScreen>.Instance.m_ScreenGrp.SetActive(true);
		CSingleton<LoadingScreen>.Instance.m_ScreenAnim.Play("Loading_FadeIn");
		GameInstance.m_HasFinishHideLoadingScreen = false;
	}

	// Token: 0x06000614 RID: 1556 RVA: 0x00031FC4 File Offset: 0x000301C4
	public static void CloseScreen()
	{
		CSingleton<LoadingScreen>.Instance.HideLoadingScreen();
	}

	// Token: 0x06000615 RID: 1557 RVA: 0x00031FD0 File Offset: 0x000301D0
	public static void SetPercentDone(int percent)
	{
		CSingleton<LoadingScreen>.Instance.m_PercentText.text = percent.ToString() + "%";
	}

	// Token: 0x06000616 RID: 1558 RVA: 0x00031FF2 File Offset: 0x000301F2
	private void HideLoadingScreen()
	{
		this.m_ScreenGrp.SetActive(true);
		this.m_PercentText.text = "100%";
	}

	// Token: 0x06000617 RID: 1559 RVA: 0x00032010 File Offset: 0x00030210
	public void FinishLoading()
	{
		if (this.m_DelayHide != null)
		{
			base.StopCoroutine(this.m_DelayHide);
		}
		this.m_DelayHide = base.StartCoroutine(this.DelayHide(0.1f));
	}

	// Token: 0x06000618 RID: 1560 RVA: 0x0003203D File Offset: 0x0003023D
	private IEnumerator DelayHide(float delayTime)
	{
		yield return new WaitForSeconds(delayTime);
		this.m_ScreenAnim.Play("Loading_FadeOut");
		yield return new WaitForSeconds(1f);
		CEventManager.QueueEvent(new CEventPlayer_FinishHideLoadingScreen());
		this.m_ScreenGrp.SetActive(false);
		GameInstance.m_HasFinishHideLoadingScreen = true;
		yield break;
	}

	// Token: 0x040007E2 RID: 2018
	public static LoadingScreen m_Instance;

	// Token: 0x040007E3 RID: 2019
	public GameObject m_ScreenGrp;

	// Token: 0x040007E4 RID: 2020
	public Animation m_ScreenAnim;

	// Token: 0x040007E5 RID: 2021
	public TextMeshProUGUI m_PercentText;

	// Token: 0x040007E6 RID: 2022
	private Coroutine m_DelayHide;
}
