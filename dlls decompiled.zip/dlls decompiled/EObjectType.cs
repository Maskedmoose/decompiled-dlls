﻿using System;

// Token: 0x020000E5 RID: 229
public enum EObjectType
{
	// Token: 0x04000AEF RID: 2799
	None = -1,
	// Token: 0x04000AF0 RID: 2800
	CashCounter,
	// Token: 0x04000AF1 RID: 2801
	Trashbin,
	// Token: 0x04000AF2 RID: 2802
	PersonalStash,
	// Token: 0x04000AF3 RID: 2803
	PackageBoxBig,
	// Token: 0x04000AF4 RID: 2804
	PackageBoxSmall,
	// Token: 0x04000AF5 RID: 2805
	PackageBoxShelf,
	// Token: 0x04000AF6 RID: 2806
	Shelf,
	// Token: 0x04000AF7 RID: 2807
	ShelfSmall,
	// Token: 0x04000AF8 RID: 2808
	WarehouseShelf,
	// Token: 0x04000AF9 RID: 2809
	Card3d,
	// Token: 0x04000AFA RID: 2810
	CardShelf,
	// Token: 0x04000AFB RID: 2811
	PlayTable,
	// Token: 0x04000AFC RID: 2812
	ShelfSmallB,
	// Token: 0x04000AFD RID: 2813
	PersonalShelfA,
	// Token: 0x04000AFE RID: 2814
	PersonalShelfB,
	// Token: 0x04000AFF RID: 2815
	PersonalShelfC,
	// Token: 0x04000B00 RID: 2816
	FancyShelfA,
	// Token: 0x04000B01 RID: 2817
	FancyShelfB,
	// Token: 0x04000B02 RID: 2818
	HugeShelfA,
	// Token: 0x04000B03 RID: 2819
	HugeShelfB,
	// Token: 0x04000B04 RID: 2820
	CabinetA,
	// Token: 0x04000B05 RID: 2821
	LongShelfA,
	// Token: 0x04000B06 RID: 2822
	RusticShelfA,
	// Token: 0x04000B07 RID: 2823
	VintageCardTable,
	// Token: 0x04000B08 RID: 2824
	DisplayCardTableA,
	// Token: 0x04000B09 RID: 2825
	DisplayCardShelfA,
	// Token: 0x04000B0A RID: 2826
	DisplayCardShelfB,
	// Token: 0x04000B0B RID: 2827
	WarehouseShelfA,
	// Token: 0x04000B0C RID: 2828
	WarehouseShelfB,
	// Token: 0x04000B0D RID: 2829
	WarehouseShelfC,
	// Token: 0x04000B0E RID: 2830
	Workbench,
	// Token: 0x04000B0F RID: 2831
	AutoCleanser1,
	// Token: 0x04000B10 RID: 2832
	AutoCleanser2,
	// Token: 0x04000B11 RID: 2833
	AutoCleanser3,
	// Token: 0x04000B12 RID: 2834
	MAX
}
