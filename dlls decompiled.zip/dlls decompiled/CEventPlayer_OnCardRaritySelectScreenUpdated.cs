﻿using System;

// Token: 0x020000C3 RID: 195
public class CEventPlayer_OnCardRaritySelectScreenUpdated : CEvent
{
	// Token: 0x17000021 RID: 33
	// (get) Token: 0x0600072C RID: 1836 RVA: 0x000381E7 File Offset: 0x000363E7
	// (set) Token: 0x0600072D RID: 1837 RVA: 0x000381EF File Offset: 0x000363EF
	public int m_CardRarityIndex { get; private set; }

	// Token: 0x0600072E RID: 1838 RVA: 0x000381F8 File Offset: 0x000363F8
	public CEventPlayer_OnCardRaritySelectScreenUpdated(int cardRarityIndex)
	{
		this.m_CardRarityIndex = cardRarityIndex;
	}
}
