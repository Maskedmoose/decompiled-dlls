﻿using System;
using UnityEngine;

namespace CC
{
	// Token: 0x020001BC RID: 444
	public class CC_UI_Util : MonoBehaviour
	{
		// Token: 0x06000C94 RID: 3220 RVA: 0x00057D40 File Offset: 0x00055F40
		public void Initialize(CharacterCustomization customizerScript)
		{
			this.customizer = customizerScript;
			ICustomizerUI[] componentsInChildren = base.gameObject.GetComponentsInChildren<ICustomizerUI>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].InitializeUIElement(customizerScript, this);
			}
		}

		// Token: 0x06000C95 RID: 3221 RVA: 0x00057D7C File Offset: 0x00055F7C
		public void refreshUI()
		{
			ICustomizerUI[] componentsInChildren = base.gameObject.GetComponentsInChildren<ICustomizerUI>(true);
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].RefreshUIElement();
			}
		}

		// Token: 0x06000C96 RID: 3222 RVA: 0x00057DAC File Offset: 0x00055FAC
		public void characterNext()
		{
			CC_UI_Manager.instance.characterNext();
		}

		// Token: 0x06000C97 RID: 3223 RVA: 0x00057DB8 File Offset: 0x00055FB8
		public void characterPrev()
		{
			CC_UI_Manager.instance.characterPrev();
		}

		// Token: 0x06000C98 RID: 3224 RVA: 0x00057DC4 File Offset: 0x00055FC4
		public void saveCharacter()
		{
			this.customizer.SaveToJSON();
		}

		// Token: 0x06000C99 RID: 3225 RVA: 0x00057DD1 File Offset: 0x00055FD1
		public void loadCharacter()
		{
			this.customizer.LoadFromJSON();
			this.refreshUI();
		}

		// Token: 0x06000C9A RID: 3226 RVA: 0x00057DE4 File Offset: 0x00055FE4
		public void setCharacterName(string newName)
		{
			this.customizer.setCharacterName(newName);
		}

		// Token: 0x04001370 RID: 4976
		private CharacterCustomization customizer;
	}
}
