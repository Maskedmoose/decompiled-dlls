﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E9 RID: 489
	public class DisableShadows : MonoBehaviour
	{
		// Token: 0x06000DAD RID: 3501 RVA: 0x0005D8D1 File Offset: 0x0005BAD1
		private void Start()
		{
			this.sceneLight = base.GetComponent<Light>();
		}

		// Token: 0x06000DAE RID: 3502 RVA: 0x0005D8DF File Offset: 0x0005BADF
		public void SetShadows(bool _isActivated)
		{
			this.shadowsAreActive = _isActivated;
			if (!this.shadowsAreActive)
			{
				this.sceneLight.shadows = LightShadows.None;
				return;
			}
			this.sceneLight.shadows = LightShadows.Hard;
		}

		// Token: 0x040014A2 RID: 5282
		private bool shadowsAreActive = true;

		// Token: 0x040014A3 RID: 5283
		public Light sceneLight;
	}
}
