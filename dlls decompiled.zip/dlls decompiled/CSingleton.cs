﻿using System;
using UnityEngine;

// Token: 0x0200009F RID: 159
[Serializable]
public class CSingleton<T> : MonoBehaviour where T : Component
{
	// Token: 0x17000001 RID: 1
	// (get) Token: 0x0600063F RID: 1599 RVA: 0x00032A63 File Offset: 0x00030C63
	public static bool IsQuitting
	{
		get
		{
			return CSingleton<T>.isQuitting;
		}
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000640 RID: 1600 RVA: 0x00032A6C File Offset: 0x00030C6C
	public static T Instance
	{
		get
		{
			object obj = CSingleton<T>.padlock;
			T t;
			lock (obj)
			{
				if (CSingleton<T>.isQuitting)
				{
					string str = "[Singleton] Cancel creating '";
					Type typeFromHandle = typeof(T);
					Debug.LogWarning(str + ((typeFromHandle != null) ? typeFromHandle.ToString() : null) + "' , application is closing.");
					t = default(T);
					t = t;
				}
				else
				{
					if (CSingleton<T>.instance == null)
					{
						CSingleton<T>.instance = Object.FindObjectOfType<T>();
						if (Object.FindObjectsOfType(typeof(T)).Length > 1)
						{
							string str2 = "[Singleton] More than 1 ";
							Type typeFromHandle2 = typeof(T);
							Debug.LogWarning(str2 + ((typeFromHandle2 != null) ? typeFromHandle2.ToString() : null) + " in the game");
							return CSingleton<T>.instance;
						}
						if (CSingleton<T>.instance == null)
						{
							GameObject gameObject = new GameObject();
							gameObject.name = "(singleton)" + typeof(T).ToString();
							CSingleton<T>.instance = gameObject.AddComponent<T>();
							Object.DontDestroyOnLoad(gameObject);
						}
					}
					t = CSingleton<T>.instance;
				}
			}
			return t;
		}
	}

	// Token: 0x06000641 RID: 1601 RVA: 0x00032B98 File Offset: 0x00030D98
	public virtual void OnApplicationQuit()
	{
		CSingleton<T>.isQuitting = true;
	}

	// Token: 0x040007F9 RID: 2041
	private static T instance;

	// Token: 0x040007FA RID: 2042
	private static object padlock = new object();

	// Token: 0x040007FB RID: 2043
	private static bool isQuitting = false;
}
