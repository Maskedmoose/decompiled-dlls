﻿using System;

// Token: 0x020000E9 RID: 233
public enum ECardBorderType
{
	// Token: 0x04000B57 RID: 2903
	Base,
	// Token: 0x04000B58 RID: 2904
	FirstEdition,
	// Token: 0x04000B59 RID: 2905
	Silver,
	// Token: 0x04000B5A RID: 2906
	Gold,
	// Token: 0x04000B5B RID: 2907
	EX,
	// Token: 0x04000B5C RID: 2908
	FullArt
}
