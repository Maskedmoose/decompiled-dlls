﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;
using UniversalSettings;

// Token: 0x0200009A RID: 154
public class SettingScreen : CSingleton<SettingScreen>
{
	// Token: 0x060005FB RID: 1531 RVA: 0x00031568 File Offset: 0x0002F768
	public static void OpenScreen(bool isTitleScreen)
	{
		CSingleton<SettingScreen>.Instance.m_IsTitleScreen = isTitleScreen;
		CSingleton<SettingScreen>.Instance.m_GameSettingScreen.SetActive(true);
		CSingleton<SettingScreen>.Instance.m_DisplaySettingScreen.SetActive(false);
		CSingleton<SettingScreen>.Instance.m_LanguageScreen.SetActive(false);
		CSingleton<SettingScreen>.Instance.m_KeybindScreen.SetActive(false);
		CSingleton<SettingScreen>.Instance.ShowSubSettingBtnHighlight(0);
		CSingleton<SettingScreen>.Instance.m_IsChangingKeybind = false;
		CSingleton<SettingScreen>.Instance.m_CurrentCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
		if (CSingleton<SettingScreen>.Instance.m_ScreenGrp.activeSelf)
		{
			SettingScreen.CloseScreen();
			return;
		}
		CSingleton<SettingScreen>.Instance.m_ScreenGrp.SetActive(true);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<SettingScreen>.Instance.m_ControllerScreenUIExtension);
		SoundManager.GenericMenuOpen(1f, 1f);
	}

	// Token: 0x060005FC RID: 1532 RVA: 0x00031630 File Offset: 0x0002F830
	public static void CloseScreen()
	{
		if (CSingleton<SettingScreen>.Instance.m_IsChangingKeybind)
		{
			return;
		}
		if (SettingScreen.CheckKeybindChangesConfirmScreenPopup())
		{
			return;
		}
		CSingleton<SettingScreen>.Instance.m_ScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SettingScreen>.Instance.m_ControllerScreenUIExtension);
		CSettingData.instance.SaveSettingData();
		SoundManager.GenericMenuClose(1f, 1f);
		if (CSingleton<SettingScreen>.Instance.m_CurrentCurrencyType != CSingleton<CGameManager>.Instance.m_CurrencyType)
		{
			CSingleton<SettingScreen>.Instance.m_CurrentCurrencyType = CSingleton<CGameManager>.Instance.m_CurrencyType;
			CEventManager.QueueEvent(new CEventPlayer_OnMoneyCurrencyUpdated());
		}
	}

	// Token: 0x060005FD RID: 1533 RVA: 0x000316BE File Offset: 0x0002F8BE
	private static bool CheckKeybindChangesConfirmScreenPopup()
	{
		if (InputManager.HasKeybindChanges())
		{
			ControllerScreenUIExtManager.OnOpenScreen(CSingleton<SettingScreen>.Instance.m_KeybindChangesConfirmScreenUIExtension);
			CSingleton<SettingScreen>.Instance.m_KeybindChangesConfirmScreen.SetActive(true);
			return true;
		}
		return false;
	}

	// Token: 0x060005FE RID: 1534 RVA: 0x000316E9 File Offset: 0x0002F8E9
	public void OnPressConfirmKeybindChange()
	{
		this.m_KeybindChangesConfirmScreen.SetActive(false);
		this.m_IsChangingKeybind = false;
		this.OnPressSaveKeybind();
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SettingScreen>.Instance.m_KeybindChangesConfirmScreenUIExtension);
	}

	// Token: 0x060005FF RID: 1535 RVA: 0x00031713 File Offset: 0x0002F913
	public void OnPressCancelKeybindChange()
	{
		this.m_KeybindChangesConfirmScreen.SetActive(false);
		this.m_IsChangingKeybind = false;
		this.OnPressUndoKeybind();
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<SettingScreen>.Instance.m_KeybindChangesConfirmScreenUIExtension);
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x00031740 File Offset: 0x0002F940
	private void Start()
	{
		UniversalSettingsRunner.Instance.onApplySettings += delegate()
		{
			CSingleton<CGameManager>.Instance.m_EnableTooltip = UniversalSettingsRunner.Instance.GetCustomBoolean(0);
			CSingleton<CGameManager>.Instance.m_InvertedMouse = UniversalSettingsRunner.Instance.GetCustomBoolean(1);
			CSingleton<CGameManager>.Instance.m_InvertedMouse = UniversalSettingsRunner.Instance.GetCustomBoolean(1);
			CSingleton<CGameManager>.Instance.m_CashierLockMovement = UniversalSettingsRunner.Instance.GetCustomBoolean(2);
			CSingleton<CGameManager>.Instance.m_KeyboardTypeIndex = UniversalSettingsRunner.Instance.GetCustomInteger(1);
			InputManager.OnKeyboardTypeUpdated(CSingleton<CGameManager>.Instance.m_KeyboardTypeIndex);
			CSingleton<CGameManager>.Instance.m_QualitySettingIndex = UniversalSettingsRunner.Instance.GetCustomInteger(2);
			CSingleton<CGameManager>.Instance.m_MouseSensitivity = UniversalSettingsRunner.Instance.GetCustomFloat(0);
			SoundManager.MusicVolume = UniversalSettingsRunner.Instance.GetCustomFloat(1);
			SoundManager.SFXVolume = UniversalSettingsRunner.Instance.GetCustomFloat(2);
			CSingleton<CGameManager>.Instance.m_CameraFOVSlider = UniversalSettingsRunner.Instance.GetCustomFloat(3);
			CSingleton<CGameManager>.Instance.m_CenterDotSizeSlider = UniversalSettingsRunner.Instance.GetCustomFloat(4);
			CSingleton<CGameManager>.Instance.m_OpenPackSpeedSlider = UniversalSettingsRunner.Instance.GetCustomFloat(5);
			CSingleton<CGameManager>.Instance.m_CenterDotColorIndex = UniversalSettingsRunner.Instance.GetCustomInteger(3);
			CSingleton<CGameManager>.Instance.m_CenterDotSpriteTypeIndex = UniversalSettingsRunner.Instance.GetCustomInteger(4);
			CSingleton<CGameManager>.Instance.m_CurrencyType = (EMoneyCurrencyType)UniversalSettingsRunner.Instance.GetCustomInteger(5);
			CSingleton<CGameManager>.Instance.m_CenterDotHasOutline = UniversalSettingsRunner.Instance.GetCustomBoolean(3);
			CSingleton<CGameManager>.Instance.m_OpenPackShowNewCard = UniversalSettingsRunner.Instance.GetCustomBoolean(4);
			CSingleton<CGameManager>.Instance.m_OpenPacAutoNextCard = UniversalSettingsRunner.Instance.GetCustomBoolean(5);
			CSingleton<CGameManager>.Instance.m_DisableController = UniversalSettingsRunner.Instance.GetCustomBoolean(6);
			CSingleton<CGameManager>.Instance.m_IsTurnVSyncOff = UniversalSettingsRunner.Instance.GetCustomBoolean(7);
			if (CSingleton<CGameManager>.Instance.m_IsTurnVSyncOff)
			{
				QualitySettings.vSyncCount = 0;
			}
			else
			{
				QualitySettings.vSyncCount = 1;
			}
			CSingleton<InputManager>.Instance.SetIsControllerDisabledSetting(CSingleton<CGameManager>.Instance.m_DisableController);
			CSingleton<SoundManager>.Instance.EvaluateSoundVolume();
			CSingleton<CGameManager>.Instance.m_MouseSensitivityLerp = Mathf.Lerp(0.2f, 1.8f, CSingleton<CGameManager>.Instance.m_MouseSensitivity);
			CEventManager.QueueEvent(new CEventPlayer_OnSettingUpdated());
		};
		CSingleton<CGameManager>.Instance.m_EnableTooltip = UniversalSettingsRunner.Instance.GetCustomBoolean(0);
		CSingleton<CGameManager>.Instance.m_InvertedMouse = UniversalSettingsRunner.Instance.GetCustomBoolean(1);
		CSingleton<CGameManager>.Instance.m_CashierLockMovement = UniversalSettingsRunner.Instance.GetCustomBoolean(2);
		CSingleton<CGameManager>.Instance.m_KeyboardTypeIndex = UniversalSettingsRunner.Instance.GetCustomInteger(1);
		InputManager.OnKeyboardTypeUpdated(CSingleton<CGameManager>.Instance.m_KeyboardTypeIndex);
		CSingleton<CGameManager>.Instance.m_QualitySettingIndex = UniversalSettingsRunner.Instance.GetCustomInteger(2);
		CSingleton<CGameManager>.Instance.m_MouseSensitivity = UniversalSettingsRunner.Instance.GetCustomFloat(0);
		SoundManager.MusicVolume = UniversalSettingsRunner.Instance.GetCustomFloat(1);
		SoundManager.SFXVolume = UniversalSettingsRunner.Instance.GetCustomFloat(2);
		CSingleton<CGameManager>.Instance.m_CameraFOVSlider = UniversalSettingsRunner.Instance.GetCustomFloat(3);
		CSingleton<CGameManager>.Instance.m_CenterDotSizeSlider = UniversalSettingsRunner.Instance.GetCustomFloat(4);
		CSingleton<CGameManager>.Instance.m_OpenPackSpeedSlider = UniversalSettingsRunner.Instance.GetCustomFloat(5);
		CSingleton<CGameManager>.Instance.m_CenterDotColorIndex = UniversalSettingsRunner.Instance.GetCustomInteger(3);
		CSingleton<CGameManager>.Instance.m_CenterDotSpriteTypeIndex = UniversalSettingsRunner.Instance.GetCustomInteger(4);
		CSingleton<CGameManager>.Instance.m_CurrencyType = (EMoneyCurrencyType)UniversalSettingsRunner.Instance.GetCustomInteger(5);
		CSingleton<CGameManager>.Instance.m_CenterDotHasOutline = UniversalSettingsRunner.Instance.GetCustomBoolean(3);
		CSingleton<CGameManager>.Instance.m_OpenPackShowNewCard = UniversalSettingsRunner.Instance.GetCustomBoolean(4);
		CSingleton<CGameManager>.Instance.m_OpenPacAutoNextCard = UniversalSettingsRunner.Instance.GetCustomBoolean(5);
		CSingleton<CGameManager>.Instance.m_DisableController = UniversalSettingsRunner.Instance.GetCustomBoolean(6);
		CSingleton<CGameManager>.Instance.m_IsTurnVSyncOff = UniversalSettingsRunner.Instance.GetCustomBoolean(7);
		if (CSingleton<CGameManager>.Instance.m_IsTurnVSyncOff)
		{
			QualitySettings.vSyncCount = 0;
		}
		else
		{
			QualitySettings.vSyncCount = 1;
		}
		CSingleton<InputManager>.Instance.SetIsControllerDisabledSetting(CSingleton<CGameManager>.Instance.m_DisableController);
		CSingleton<CGameManager>.Instance.m_MouseSensitivityLerp = Mathf.Lerp(0.2f, 1.8f, CSingleton<CGameManager>.Instance.m_MouseSensitivity);
		CEventManager.QueueEvent(new CEventPlayer_OnSettingUpdated());
	}

	// Token: 0x06000601 RID: 1537 RVA: 0x00031965 File Offset: 0x0002FB65
	public void ManualUpdate()
	{
		if (!this.m_IsChangingKeybind && CSingleton<SettingScreen>.Instance.m_ScreenGrp.activeSelf && (Input.GetKeyUp(KeyCode.Escape) || InputManager.GetKeyUpAction(EGameAction.ClosePhone)))
		{
			SettingScreen.CloseScreen();
		}
	}

	// Token: 0x06000602 RID: 1538 RVA: 0x00031997 File Offset: 0x0002FB97
	public void OnSettingUpdated(float amount)
	{
	}

	// Token: 0x06000603 RID: 1539 RVA: 0x0003199C File Offset: 0x0002FB9C
	public void OnPressGameSetting()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		if (SettingScreen.CheckKeybindChangesConfirmScreenPopup())
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_GameSettingScreen.SetActive(true);
		this.m_DisplaySettingScreen.SetActive(false);
		this.m_LanguageScreen.SetActive(false);
		this.m_KeybindScreen.SetActive(false);
		this.ShowSubSettingBtnHighlight(0);
	}

	// Token: 0x06000604 RID: 1540 RVA: 0x00031A00 File Offset: 0x0002FC00
	public void OnPressDisplaySetting()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		if (SettingScreen.CheckKeybindChangesConfirmScreenPopup())
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_GameSettingScreen.SetActive(false);
		this.m_DisplaySettingScreen.SetActive(true);
		this.m_LanguageScreen.SetActive(false);
		this.m_KeybindScreen.SetActive(false);
		this.ShowSubSettingBtnHighlight(1);
	}

	// Token: 0x06000605 RID: 1541 RVA: 0x00031A64 File Offset: 0x0002FC64
	public void OnPressLanguage()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		if (SettingScreen.CheckKeybindChangesConfirmScreenPopup())
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_GameSettingScreen.SetActive(false);
		this.m_DisplaySettingScreen.SetActive(false);
		this.m_LanguageScreen.SetActive(true);
		this.m_KeybindScreen.SetActive(false);
		this.ShowSubSettingBtnHighlight(2);
	}

	// Token: 0x06000606 RID: 1542 RVA: 0x00031AC8 File Offset: 0x0002FCC8
	public void OnPressKeybindSetting()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_GameSettingScreen.SetActive(false);
		this.m_DisplaySettingScreen.SetActive(false);
		this.m_LanguageScreen.SetActive(false);
		this.m_KeybindScreen.SetActive(true);
		this.m_KeybindKeyboardHighlight.SetActive(true);
		this.m_KeybindControllerHighlight.SetActive(false);
		if (CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			this.m_KeybindKeyboardScreen.SetActive(false);
			this.m_KeybindControllerScreen.SetActive(true);
			this.m_KeybindKeyboardHighlight.SetActive(false);
			this.m_KeybindControllerHighlight.SetActive(true);
		}
		else
		{
			this.m_KeybindKeyboardScreen.SetActive(true);
			this.m_KeybindControllerScreen.SetActive(false);
			this.m_KeybindKeyboardHighlight.SetActive(true);
			this.m_KeybindControllerHighlight.SetActive(false);
		}
		this.ShowSubSettingBtnHighlight(3);
		this.EvaluateKeybindSettingUI();
	}

	// Token: 0x06000607 RID: 1543 RVA: 0x00031BB0 File Offset: 0x0002FDB0
	public void OnPressKeybindKeyboard()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_KeybindKeyboardHighlight.SetActive(true);
		this.m_KeybindControllerHighlight.SetActive(false);
		this.m_KeybindKeyboardScreen.SetActive(true);
		this.m_KeybindControllerScreen.SetActive(false);
		this.EvaluateKeybindSettingUI();
	}

	// Token: 0x06000608 RID: 1544 RVA: 0x00031C0C File Offset: 0x0002FE0C
	public void OnPressKeybindController()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		this.m_KeybindKeyboardHighlight.SetActive(false);
		this.m_KeybindControllerHighlight.SetActive(true);
		this.m_KeybindKeyboardScreen.SetActive(false);
		this.m_KeybindControllerScreen.SetActive(true);
		this.EvaluateKeybindSettingUI();
	}

	// Token: 0x06000609 RID: 1545 RVA: 0x00031C67 File Offset: 0x0002FE67
	public void OnPressResetKeybind()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		CSingleton<InputManager>.Instance.ResetToDefaultKeybind();
		CSettingData.instance.SaveSettingData();
		this.EvaluateKeybindSettingUI();
	}

	// Token: 0x0600060A RID: 1546 RVA: 0x00031C9B File Offset: 0x0002FE9B
	public void OnPressUndoKeybind()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		CSingleton<InputManager>.Instance.UndoKeybind();
		this.EvaluateKeybindSettingUI();
	}

	// Token: 0x0600060B RID: 1547 RVA: 0x00031CC5 File Offset: 0x0002FEC5
	public void OnPressSaveKeybind()
	{
		if (this.m_IsChangingKeybind)
		{
			return;
		}
		SoundManager.GenericConfirm(1f, 1f);
		CSettingData.instance.SaveSettingData();
		CEventManager.QueueEvent(new CEventPlayer_OnKeybindChanged());
	}

	// Token: 0x0600060C RID: 1548 RVA: 0x00031CF4 File Offset: 0x0002FEF4
	private void EvaluateKeybindSettingUI()
	{
		for (int i = 0; i < this.m_KeybindSettingList.Count; i++)
		{
			this.m_KeybindSettingList[i].UpdateInputUI();
		}
	}

	// Token: 0x0600060D RID: 1549 RVA: 0x00031D28 File Offset: 0x0002FF28
	public void OnPressLanguageSelect(string language)
	{
		if (language == "English")
		{
			LocalizationManager.CurrentLanguageCode = "en";
		}
		else if (language == "France")
		{
			LocalizationManager.CurrentLanguageCode = "fr";
		}
		else if (language == "Germany")
		{
			LocalizationManager.CurrentLanguageCode = "de";
		}
		else if (language == "Spanish")
		{
			LocalizationManager.CurrentLanguageCode = "es";
		}
		else if (language == "ChineseT")
		{
			LocalizationManager.CurrentLanguageCode = "zh-TW";
		}
		else if (language == "ChineseS")
		{
			LocalizationManager.CurrentLanguageCode = "zh-CN";
		}
		else if (language == "Korean")
		{
			LocalizationManager.CurrentLanguageCode = "ko";
		}
		else if (language == "Japanese")
		{
			LocalizationManager.CurrentLanguageCode = "ja";
		}
		else if (language == "Portuguese")
		{
			LocalizationManager.CurrentLanguageCode = "pt";
		}
		else if (language == "Italian")
		{
			LocalizationManager.CurrentLanguageCode = "it";
		}
		else if (language == "Russian")
		{
			LocalizationManager.CurrentLanguageCode = "ru";
		}
		else if (language == "Hindi")
		{
			LocalizationManager.CurrentLanguageCode = "hi";
		}
		else if (language == "Thai")
		{
			LocalizationManager.CurrentLanguageCode = "th";
		}
		else if (language == "Arabic")
		{
			LocalizationManager.CurrentLanguageCode = "ar";
			LocalizationManager.IsRight2Left = false;
		}
		else if (language == "Dutch")
		{
			LocalizationManager.CurrentLanguageCode = "nl";
		}
		CEventManager.QueueEvent(new CEventPlayer_OnLanguageChanged());
	}

	// Token: 0x0600060E RID: 1550 RVA: 0x00031ED8 File Offset: 0x000300D8
	private void ShowSubSettingBtnHighlight(int index)
	{
		for (int i = 0; i < this.m_SubSettingBtnHighlight.Count; i++)
		{
			this.m_SubSettingBtnHighlight[i].SetActive(false);
		}
		this.m_SubSettingBtnHighlight[index].SetActive(true);
	}

	// Token: 0x0600060F RID: 1551 RVA: 0x00031F1F File Offset: 0x0003011F
	public void SetIsChangingKeybind(bool isChangingKeybind)
	{
		this.m_IsChangingKeybind = isChangingKeybind;
	}

	// Token: 0x06000610 RID: 1552 RVA: 0x00031F28 File Offset: 0x00030128
	public static bool IsChangingKeybind()
	{
		return CSingleton<SettingScreen>.Instance.m_IsChangingKeybind;
	}

	// Token: 0x040007D0 RID: 2000
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040007D1 RID: 2001
	public ControllerScreenUIExtension m_KeybindChangesConfirmScreenUIExtension;

	// Token: 0x040007D2 RID: 2002
	public GameObject m_ScreenGrp;

	// Token: 0x040007D3 RID: 2003
	public GameObject m_GameSettingScreen;

	// Token: 0x040007D4 RID: 2004
	public GameObject m_DisplaySettingScreen;

	// Token: 0x040007D5 RID: 2005
	public GameObject m_LanguageScreen;

	// Token: 0x040007D6 RID: 2006
	public GameObject m_KeybindScreen;

	// Token: 0x040007D7 RID: 2007
	public GameObject m_KeybindKeyboardHighlight;

	// Token: 0x040007D8 RID: 2008
	public GameObject m_KeybindControllerHighlight;

	// Token: 0x040007D9 RID: 2009
	public GameObject m_KeybindKeyboardScreen;

	// Token: 0x040007DA RID: 2010
	public GameObject m_KeybindControllerScreen;

	// Token: 0x040007DB RID: 2011
	public GameObject m_KeybindChangesConfirmScreen;

	// Token: 0x040007DC RID: 2012
	public List<GameObject> m_SubSettingBtnHighlight;

	// Token: 0x040007DD RID: 2013
	public List<KeybindSetting> m_KeybindSettingList;

	// Token: 0x040007DE RID: 2014
	private bool m_IsCursorVisible;

	// Token: 0x040007DF RID: 2015
	private bool m_IsTitleScreen = true;

	// Token: 0x040007E0 RID: 2016
	private bool m_IsChangingKeybind;

	// Token: 0x040007E1 RID: 2017
	private EMoneyCurrencyType m_CurrentCurrencyType;
}
