﻿using System;

// Token: 0x020000E1 RID: 225
public enum ERestockerType
{
	// Token: 0x04000A9C RID: 2716
	None,
	// Token: 0x04000A9D RID: 2717
	Bike,
	// Token: 0x04000A9E RID: 2718
	Van,
	// Token: 0x04000A9F RID: 2719
	Truck,
	// Token: 0x04000AA0 RID: 2720
	BigTruck,
	// Token: 0x04000AA1 RID: 2721
	Helicopter,
	// Token: 0x04000AA2 RID: 2722
	Max
}
