﻿using System;

// Token: 0x020000E7 RID: 231
public enum EQuestType
{
	// Token: 0x04000B1B RID: 2843
	None = -1,
	// Token: 0x04000B1C RID: 2844
	MainCounterLevel,
	// Token: 0x04000B1D RID: 2845
	TetramonCardCollected,
	// Token: 0x04000B1E RID: 2846
	UnlockTetramonBasicBox,
	// Token: 0x04000B1F RID: 2847
	UnlockTetramonLegendPack,
	// Token: 0x04000B20 RID: 2848
	SellTetramonBasicPack,
	// Token: 0x04000B21 RID: 2849
	SellTetramonRareBox,
	// Token: 0x04000B22 RID: 2850
	SellTetramonEpicPack,
	// Token: 0x04000B23 RID: 2851
	SellTetramonLegendBox,
	// Token: 0x04000B24 RID: 2852
	CustomerVisit,
	// Token: 0x04000B25 RID: 2853
	EarnGlobalShopPoint,
	// Token: 0x04000B26 RID: 2854
	UnlockMediumShelf,
	// Token: 0x04000B27 RID: 2855
	UnlockLargeShelf,
	// Token: 0x04000B28 RID: 2856
	UnlockGiantShelf,
	// Token: 0x04000B29 RID: 2857
	UnlockPiggyAStatue,
	// Token: 0x04000B2A RID: 2858
	UnlockPiggyBStatue,
	// Token: 0x04000B2B RID: 2859
	UnlockPiggyCStatue,
	// Token: 0x04000B2C RID: 2860
	UnlockPiggyDStatue,
	// Token: 0x04000B2D RID: 2861
	UpgradeSmallShelf,
	// Token: 0x04000B2E RID: 2862
	UpgradeSmallTable,
	// Token: 0x04000B2F RID: 2863
	UpgradeMediumTable,
	// Token: 0x04000B30 RID: 2864
	UpgradeLongTable,
	// Token: 0x04000B31 RID: 2865
	UpgradeATMLevel,
	// Token: 0x04000B32 RID: 2866
	UpgradeLoudspeakerLevel,
	// Token: 0x04000B33 RID: 2867
	UpgradeTrolleyLevel,
	// Token: 0x04000B34 RID: 2868
	UpgradePackStorageLevel,
	// Token: 0x04000B35 RID: 2869
	UpgradePigniStatueLevel,
	// Token: 0x04000B36 RID: 2870
	UpgradeTrickstarStatueLevel,
	// Token: 0x04000B37 RID: 2871
	UpgradeMeganiteStatueLevel,
	// Token: 0x04000B38 RID: 2872
	UpgradeDracunixStatueLevel,
	// Token: 0x04000B39 RID: 2873
	UnlockVehicleVan,
	// Token: 0x04000B3A RID: 2874
	UnlockVehicleTruck,
	// Token: 0x04000B3B RID: 2875
	UnlockVehicleTrailer,
	// Token: 0x04000B3C RID: 2876
	UpgradeBike,
	// Token: 0x04000B3D RID: 2877
	UpgradeVan,
	// Token: 0x04000B3E RID: 2878
	UpgradeHelicopter,
	// Token: 0x04000B3F RID: 2879
	DestinyCardCollected,
	// Token: 0x04000B40 RID: 2880
	SellDestinyBasicPack,
	// Token: 0x04000B41 RID: 2881
	SellDestinyRarePack,
	// Token: 0x04000B42 RID: 2882
	SellDestinyEpicPack,
	// Token: 0x04000B43 RID: 2883
	SellDestinyLegendPack,
	// Token: 0x04000B44 RID: 2884
	GhostCardCollected,
	// Token: 0x04000B45 RID: 2885
	SellGhostPack
}
