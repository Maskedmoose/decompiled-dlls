﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B1 RID: 433
	public class CharacterCustomization : MonoBehaviour
	{
		// Token: 0x06000C5C RID: 3164 RVA: 0x000560A6 File Offset: 0x000542A6
		private void Start()
		{
			this.SavePath = Application.dataPath + "/CharacterCustomizer.json";
			if (this.Autoload)
			{
				this.Initialize();
			}
		}

		// Token: 0x06000C5D RID: 3165 RVA: 0x000560CC File Offset: 0x000542CC
		public void Initialize()
		{
			if (this.m_HasInit)
			{
				this.LoadFromJSON();
				return;
			}
			this.m_HasInit = true;
			this.SavePath = Application.dataPath + "/CharacterCustomizer.json";
			SkinnedMeshRenderer[] componentsInChildren = base.gameObject.GetComponentsInChildren<SkinnedMeshRenderer>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].gameObject.AddComponent<BlendshapeManager>().parseBlendshapes();
			}
			for (int j = 0; j < this.HairTables.Count; j++)
			{
				GameObject gameObject = new GameObject();
				this.HairObjects.Add(gameObject);
				Object.Destroy(gameObject);
			}
			for (int k = 0; k < this.ApparelTables.Count; k++)
			{
				GameObject gameObject2 = new GameObject();
				this.ApparelObjects.Add(gameObject2);
				Object.Destroy(gameObject2);
			}
			this.LoadFromJSON();
			if (this.UI != null)
			{
				this.UI.GetComponent<CC_UI_Util>().Initialize(this);
			}
		}

		// Token: 0x06000C5E RID: 3166 RVA: 0x000561B8 File Offset: 0x000543B8
		public void SaveToJSON()
		{
			if (File.Exists(this.SavePath))
			{
				if (this.CharacterName != "")
				{
					CC_SaveData cc_SaveData = JsonUtility.FromJson<CC_SaveData>(File.ReadAllText(this.SavePath));
					this.StoredCharacterData.CharacterPrefab = base.gameObject.name;
					int num = cc_SaveData.SavedCharacters.FindIndex((CC_CharacterData t) => t.CharacterName == this.CharacterName);
					if (num != -1)
					{
						cc_SaveData.SavedCharacters[num] = this.StoredCharacterData;
					}
					else
					{
						cc_SaveData.SavedCharacters.Add(this.StoredCharacterData);
					}
					string contents = JsonUtility.ToJson(cc_SaveData, true);
					File.WriteAllText(this.SavePath, contents);
					return;
				}
			}
			else
			{
				this.createSaveFile();
				this.SaveToJSON();
			}
		}

		// Token: 0x06000C5F RID: 3167 RVA: 0x00056274 File Offset: 0x00054474
		public void InstantiateCharacter(string name, Transform _transform)
		{
			if (File.Exists(this.SavePath))
			{
				CC_SaveData cc_SaveData = JsonUtility.FromJson<CC_SaveData>(File.ReadAllText(this.SavePath));
				int num = cc_SaveData.SavedCharacters.FindIndex((CC_CharacterData t) => t.CharacterName == name);
				if (num != -1)
				{
					GameObject gameObject = (GameObject)Object.Instantiate(Resources.Load(cc_SaveData.SavedCharacters[num].CharacterPrefab), _transform);
					gameObject.GetComponent<CharacterCustomization>().CharacterName = name;
					gameObject.GetComponent<CharacterCustomization>().Initialize();
				}
			}
		}

		// Token: 0x06000C60 RID: 3168 RVA: 0x00056304 File Offset: 0x00054504
		public void LoadFromJSON()
		{
			if (File.Exists(this.SavePath))
			{
				if (this.CharacterName != "")
				{
					CC_SaveData cc_SaveData = JsonUtility.FromJson<CC_SaveData>(File.ReadAllText(this.SavePath));
					int num = cc_SaveData.SavedCharacters.FindIndex((CC_CharacterData t) => t.CharacterName == this.CharacterName);
					if (num != -1)
					{
						this.StoredCharacterData = cc_SaveData.SavedCharacters[num];
					}
					else if (this.Presets.Presets.Find((CC_CharacterData t) => t.CharacterName == this.CharacterName) != null)
					{
						this.StoredCharacterData = JsonUtility.FromJson<CC_CharacterData>(JsonUtility.ToJson(this.Presets.Presets.Find((CC_CharacterData t) => t.CharacterName == this.CharacterName)));
					}
					else
					{
						this.StoredCharacterData = JsonUtility.FromJson<CC_CharacterData>(JsonUtility.ToJson(this.Presets.Presets[0]));
						this.StoredCharacterData.CharacterName = this.CharacterName;
					}
					while (this.StoredCharacterData.HairNames.Count < this.HairObjects.Count)
					{
						this.StoredCharacterData.HairNames.Add("");
					}
					while (this.StoredCharacterData.HairColor.Count < this.HairObjects.Count)
					{
						this.StoredCharacterData.HairColor.Add(new CC_Property());
					}
					while (this.StoredCharacterData.ApparelNames.Count < this.ApparelObjects.Count)
					{
						this.StoredCharacterData.ApparelNames.Add("");
					}
					while (this.StoredCharacterData.ApparelMaterials.Count < this.ApparelObjects.Count)
					{
						this.StoredCharacterData.ApparelMaterials.Add(0);
					}
					this.ApplyCharacterVars(this.StoredCharacterData);
					return;
				}
			}
			else
			{
				this.createSaveFile();
				this.LoadFromJSON();
			}
		}

		// Token: 0x06000C61 RID: 3169 RVA: 0x000564E0 File Offset: 0x000546E0
		public void ApplyCharacterVars(CC_CharacterData characterData)
		{
			for (int i = 0; i < characterData.Blendshapes.Count; i++)
			{
				this.setBlendshapeByName(characterData.Blendshapes[i].propertyName, characterData.Blendshapes[i].floatValue, false);
			}
			for (int j = 0; j < characterData.HairNames.Count; j++)
			{
				this.setHairByName(characterData.HairNames[j], j);
			}
			for (int k = 0; k < characterData.ApparelNames.Count; k++)
			{
				this.setApparelByName(characterData.ApparelNames[k], k, characterData.ApparelMaterials[k]);
			}
			foreach (CC_Property p in characterData.TextureProperties)
			{
				this.setTextureProperty(p, false, null);
			}
			foreach (CC_Property p2 in characterData.FloatProperties)
			{
				this.setFloatProperty(p2, false);
			}
			foreach (CC_Property cc_Property in characterData.ColorProperties)
			{
				Color c;
				if (ColorUtility.TryParseHtmlString("#" + cc_Property.stringValue, out c))
				{
					this.setColorProperty(cc_Property, c, false);
				}
			}
		}

		// Token: 0x06000C62 RID: 3170 RVA: 0x0005667C File Offset: 0x0005487C
		public void createSaveFile()
		{
			string contents = JsonUtility.ToJson(new CC_SaveData(), true);
			File.WriteAllText(this.SavePath, contents);
		}

		// Token: 0x06000C63 RID: 3171 RVA: 0x000566A1 File Offset: 0x000548A1
		public void setCharacterName(string newName)
		{
			this.CharacterName = newName;
			this.StoredCharacterData.CharacterName = newName;
		}

		// Token: 0x06000C64 RID: 3172 RVA: 0x000566B8 File Offset: 0x000548B8
		public void setHair(int selection, int slot)
		{
			if (this.HairTables[slot].Hairstyles.Count > selection)
			{
				scrObj_Hair.Hairstyle hairstyle = this.HairTables[slot].Hairstyles[selection];
				if (this.HairObjects[slot] != null)
				{
					Object.Destroy(this.HairObjects[slot]);
				}
				if (this.HairTables[slot].Hairstyles[selection].Mesh != null)
				{
					this.HairObjects[slot] = Object.Instantiate<GameObject>(hairstyle.Mesh, base.gameObject.transform);
					GameObject gameObject = this.HairObjects[slot];
					foreach (SkinnedMeshRenderer skinnedMeshRenderer in gameObject.GetComponentsInChildren<SkinnedMeshRenderer>())
					{
						BlendshapeManager blendshapeManager = skinnedMeshRenderer.gameObject.AddComponent<BlendshapeManager>();
						blendshapeManager.parseBlendshapes();
						foreach (CC_Property cc_Property in this.StoredCharacterData.Blendshapes)
						{
							blendshapeManager.setBlendshape(cc_Property.propertyName, cc_Property.floatValue);
						}
						skinnedMeshRenderer.gameObject.layer = LayerMask.NameToLayer("Customer");
					}
					if (hairstyle.AddCopyPoseScript)
					{
						gameObject.AddComponent<CopyPose>();
					}
					else
					{
						foreach (SkinnedMeshRenderer skinnedMeshRenderer2 in gameObject.GetComponentsInChildren<SkinnedMeshRenderer>())
						{
							Transform[] array = new Transform[skinnedMeshRenderer2.bones.Length];
							for (int j = 0; j < skinnedMeshRenderer2.bones.Length; j++)
							{
								if (!(skinnedMeshRenderer2.bones[j] == null))
								{
									array[j] = this.FindChildByName(skinnedMeshRenderer2.bones[j].name, this.MainMesh.rootBone);
								}
							}
							skinnedMeshRenderer2.bones = array;
							skinnedMeshRenderer2.gameObject.layer = LayerMask.NameToLayer("Customer");
						}
					}
				}
				this.setTextureProperty(new CC_Property
				{
					propertyName = this.HairTables[slot].ShadowMapProperty
				}, false, hairstyle.ShadowMap);
				CC_Property cc_Property2 = this.StoredCharacterData.HairColor[slot];
				Color color;
				if (ColorUtility.TryParseHtmlString("#" + cc_Property2.stringValue, out color))
				{
					this.setHairColor(cc_Property2, color, slot, false);
				}
				this.StoredCharacterData.HairNames[slot] = hairstyle.Name;
			}
		}

		// Token: 0x06000C65 RID: 3173 RVA: 0x00056954 File Offset: 0x00054B54
		public void setHairByName(string name, int slot)
		{
			int num = this.HairTables[slot].Hairstyles.FindIndex((scrObj_Hair.Hairstyle t) => t.Name == name);
			if (num != -1)
			{
				this.setHair(num, slot);
			}
		}

		// Token: 0x06000C66 RID: 3174 RVA: 0x000569A0 File Offset: 0x00054BA0
		public void setApparel(int selection, int slot, int materialSelection)
		{
			if (this.ApparelTables[slot].Items.Count > selection)
			{
				scrObj_Apparel.Apparel apparel = this.ApparelTables[slot].Items[selection];
				if (this.ApparelObjects[slot] != null)
				{
					Object.Destroy(this.ApparelObjects[slot]);
				}
				if (this.ApparelTables[slot].Items[selection].Mesh != null)
				{
					this.ApparelObjects[slot] = Object.Instantiate<GameObject>(apparel.Mesh, base.gameObject.transform);
					GameObject gameObject = this.ApparelObjects[slot];
					foreach (SkinnedMeshRenderer skinnedMeshRenderer in gameObject.GetComponentsInChildren<SkinnedMeshRenderer>())
					{
						BlendshapeManager blendshapeManager = skinnedMeshRenderer.gameObject.AddComponent<BlendshapeManager>();
						blendshapeManager.parseBlendshapes();
						foreach (CC_Property cc_Property in this.StoredCharacterData.Blendshapes)
						{
							blendshapeManager.setBlendshape(cc_Property.propertyName, cc_Property.floatValue);
						}
						skinnedMeshRenderer.gameObject.layer = LayerMask.NameToLayer("Customer");
					}
					foreach (SkinnedMeshRenderer skinnedMeshRenderer2 in gameObject.GetComponentsInChildren<SkinnedMeshRenderer>())
					{
						for (int j = 0; j < skinnedMeshRenderer2.materials.Length; j++)
						{
							if (apparel.Materials.Count != 0 && apparel.Materials[0].MaterialDefinitions.Count - 1 >= j)
							{
								List<CC_Apparel_Material_Definition> materialDefinitions = apparel.Materials[materialSelection].MaterialDefinitions;
								skinnedMeshRenderer2.materials[j].SetColor("_Tint", materialDefinitions[j].MainTint);
								skinnedMeshRenderer2.materials[j].SetColor("_Tint_R", materialDefinitions[j].TintR);
								skinnedMeshRenderer2.materials[j].SetColor("_Tint_G", materialDefinitions[j].TintG);
								skinnedMeshRenderer2.materials[j].SetColor("_Tint_B", materialDefinitions[j].TintB);
								if (materialDefinitions[j].Print)
								{
									skinnedMeshRenderer2.materials[j].SetTexture("_Print", materialDefinitions[j].Print);
								}
								else
								{
									skinnedMeshRenderer2.materials[j].SetTexture("_Print", Resources.Load<Texture2D>("T_Transparent"));
								}
							}
						}
					}
					if (apparel.AddCopyPoseScript)
					{
						gameObject.AddComponent<CopyPose>();
					}
					else
					{
						foreach (SkinnedMeshRenderer skinnedMeshRenderer3 in gameObject.GetComponentsInChildren<SkinnedMeshRenderer>())
						{
							Transform[] array = new Transform[skinnedMeshRenderer3.bones.Length];
							for (int k = 0; k < skinnedMeshRenderer3.bones.Length; k++)
							{
								if (!(skinnedMeshRenderer3.bones[k] == null))
								{
									array[k] = this.FindChildByName(skinnedMeshRenderer3.bones[k].name, this.MainMesh.rootBone);
								}
							}
							skinnedMeshRenderer3.bones = array;
							skinnedMeshRenderer3.gameObject.layer = LayerMask.NameToLayer("Customer");
						}
					}
				}
				if (apparel.FootOffset.HeightOffset >= 0f)
				{
					TransformBone[] componentsInChildren2 = base.gameObject.GetComponentsInChildren<TransformBone>();
					for (int i = 0; i < componentsInChildren2.Length; i++)
					{
						componentsInChildren2[i].SetOffset(apparel.FootOffset);
					}
				}
				this.setTextureProperty(new CC_Property
				{
					propertyName = this.ApparelTables[slot].MaskProperty
				}, false, apparel.Mask);
				this.StoredCharacterData.ApparelNames[slot] = apparel.Name;
				this.StoredCharacterData.ApparelMaterials[slot] = materialSelection;
			}
		}

		// Token: 0x06000C67 RID: 3175 RVA: 0x00056DA0 File Offset: 0x00054FA0
		public void setApparelByName(string name, int slot, int materialSelection)
		{
			int num = this.ApparelTables[slot].Items.FindIndex((scrObj_Apparel.Apparel t) => t.Name == name);
			if (num != -1)
			{
				this.setApparel(num, slot, materialSelection);
			}
		}

		// Token: 0x06000C68 RID: 3176 RVA: 0x00056DEC File Offset: 0x00054FEC
		private Transform FindChildByName(string name, Transform parentObj)
		{
			if (parentObj.name == name)
			{
				return parentObj.transform;
			}
			foreach (object obj in parentObj)
			{
				Transform parentObj2 = (Transform)obj;
				Transform transform = this.FindChildByName(name, parentObj2);
				if (transform)
				{
					return transform;
				}
			}
			return null;
		}

		// Token: 0x06000C69 RID: 3177 RVA: 0x00056E6C File Offset: 0x0005506C
		public void setBlendshapeByName(string name, float value, bool save = true)
		{
			if (name != "")
			{
				BlendshapeManager[] componentsInChildren = base.gameObject.GetComponentsInChildren<BlendshapeManager>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					componentsInChildren[i].setBlendshape(name, value);
				}
				if (save)
				{
					this.saveProperty(ref this.StoredCharacterData.Blendshapes, new CC_Property
					{
						propertyName = name,
						floatValue = value
					});
				}
			}
		}

		// Token: 0x06000C6A RID: 3178 RVA: 0x00056ED4 File Offset: 0x000550D4
		public List<Material> getRelevantMaterials(int materialIndex, string meshTag)
		{
			List<Material> list = new List<Material>();
			if (materialIndex != -1)
			{
				if (meshTag != "")
				{
					using (List<SkinnedMeshRenderer>.Enumerator enumerator = this.getMeshByTag(meshTag).GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							SkinnedMeshRenderer skinnedMeshRenderer = enumerator.Current;
							if (skinnedMeshRenderer.materials.Length > materialIndex)
							{
								list.Add(skinnedMeshRenderer.materials[materialIndex]);
							}
						}
						return list;
					}
				}
				foreach (SkinnedMeshRenderer skinnedMeshRenderer2 in base.gameObject.GetComponentsInChildren<SkinnedMeshRenderer>())
				{
					if (skinnedMeshRenderer2.materials.Length > materialIndex)
					{
						list.Add(skinnedMeshRenderer2.materials[materialIndex]);
					}
				}
			}
			else
			{
				if (meshTag != "")
				{
					using (List<SkinnedMeshRenderer>.Enumerator enumerator = this.getMeshByTag(meshTag).GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							SkinnedMeshRenderer skinnedMeshRenderer3 = enumerator.Current;
							foreach (Material item in skinnedMeshRenderer3.materials)
							{
								list.Add(item);
							}
						}
						return list;
					}
				}
				SkinnedMeshRenderer[] componentsInChildren = base.gameObject.GetComponentsInChildren<SkinnedMeshRenderer>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					foreach (Material item2 in componentsInChildren[i].materials)
					{
						list.Add(item2);
					}
				}
			}
			return list;
		}

		// Token: 0x06000C6B RID: 3179 RVA: 0x00057058 File Offset: 0x00055258
		public List<SkinnedMeshRenderer> getMeshByTag(string tag)
		{
			List<SkinnedMeshRenderer> list = new List<SkinnedMeshRenderer>();
			foreach (Transform transform in base.transform.GetComponentsInChildren<Transform>())
			{
				if (transform.tag == tag)
				{
					foreach (SkinnedMeshRenderer item in transform.GetComponentsInChildren<SkinnedMeshRenderer>())
					{
						list.Add(item);
					}
				}
			}
			return list;
		}

		// Token: 0x06000C6C RID: 3180 RVA: 0x000570C4 File Offset: 0x000552C4
		public void setTextureProperty(CC_Property p, bool save = false, Texture2D t = null)
		{
			foreach (Material material in this.getRelevantMaterials(p.materialIndex, p.meshTag))
			{
				material.SetTexture(p.propertyName, (t != null) ? t : ((Texture2D)Resources.Load(p.stringValue)));
			}
			if (save)
			{
				this.saveProperty(ref this.StoredCharacterData.TextureProperties, p);
			}
		}

		// Token: 0x06000C6D RID: 3181 RVA: 0x00057158 File Offset: 0x00055358
		public void setFloatProperty(CC_Property p, bool save = false)
		{
			foreach (Material material in this.getRelevantMaterials(p.materialIndex, p.meshTag))
			{
				material.SetFloat(p.propertyName, p.floatValue);
			}
			if (p.propertyName == "Height")
			{
				ScaleCharacter[] componentsInChildren = base.gameObject.GetComponentsInChildren<ScaleCharacter>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					componentsInChildren[i].SetHeight(p.floatValue);
				}
			}
			if (p.propertyName == "Width")
			{
				ScaleCharacter[] componentsInChildren = base.gameObject.GetComponentsInChildren<ScaleCharacter>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					componentsInChildren[i].SetWidth(p.floatValue);
				}
			}
			if (save)
			{
				this.saveProperty(ref this.StoredCharacterData.FloatProperties, p);
			}
		}

		// Token: 0x06000C6E RID: 3182 RVA: 0x0005724C File Offset: 0x0005544C
		public void setColorProperty(CC_Property p, Color c, bool save = false)
		{
			foreach (Material material in this.getRelevantMaterials(p.materialIndex, p.meshTag))
			{
				if (p.propertyName == "_Hair_Color")
				{
					material.SetColor("_BaseColor", c);
				}
				material.SetColor(p.propertyName, c);
			}
			p.stringValue = ColorUtility.ToHtmlStringRGBA(c);
			if (save)
			{
				this.saveProperty(ref this.StoredCharacterData.ColorProperties, p);
			}
		}

		// Token: 0x06000C6F RID: 3183 RVA: 0x000572F0 File Offset: 0x000554F0
		public void setHairColor(CC_Property p, Color color, int slot, bool save = false)
		{
			this.setColorProperty(p, color, false);
			this.setColorProperty(new CC_Property
			{
				propertyName = this.HairTables[(slot == -1) ? 0 : slot].TintProperty
			}, color, false);
			if (save)
			{
				if (slot == -1)
				{
					for (int i = 0; i < this.StoredCharacterData.HairColor.Count; i++)
					{
						this.StoredCharacterData.HairColor[i] = p;
					}
					return;
				}
				this.StoredCharacterData.HairColor[slot] = p;
			}
		}

		// Token: 0x06000C70 RID: 3184 RVA: 0x0005737C File Offset: 0x0005557C
		public void saveProperty(ref List<CC_Property> properties, CC_Property p)
		{
			int num = properties.FindIndex((CC_Property t) => t.materialIndex == p.materialIndex && t.propertyName == p.propertyName && t.meshTag == p.meshTag);
			if (num == -1)
			{
				properties.Add(p);
				return;
			}
			properties[num] = p;
		}

		// Token: 0x04001342 RID: 4930
		public SkinnedMeshRenderer MainMesh;

		// Token: 0x04001343 RID: 4931
		public GameObject UI;

		// Token: 0x04001344 RID: 4932
		public string CharacterName;

		// Token: 0x04001345 RID: 4933
		public bool Autoload;

		// Token: 0x04001346 RID: 4934
		public List<scrObj_Hair> HairTables = new List<scrObj_Hair>();

		// Token: 0x04001347 RID: 4935
		private List<GameObject> HairObjects = new List<GameObject>();

		// Token: 0x04001348 RID: 4936
		public List<scrObj_Apparel> ApparelTables = new List<scrObj_Apparel>();

		// Token: 0x04001349 RID: 4937
		private List<GameObject> ApparelObjects = new List<GameObject>();

		// Token: 0x0400134A RID: 4938
		public scrObj_Presets Presets;

		// Token: 0x0400134B RID: 4939
		public CC_CharacterData StoredCharacterData;

		// Token: 0x0400134C RID: 4940
		private string SavePath;

		// Token: 0x0400134D RID: 4941
		public bool m_HasInit;
	}
}
