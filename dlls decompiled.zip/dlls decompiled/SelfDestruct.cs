﻿using System;
using UnityEngine;

// Token: 0x02000144 RID: 324
public class SelfDestruct : MonoBehaviour
{
	// Token: 0x0600092E RID: 2350 RVA: 0x000428E9 File Offset: 0x00040AE9
	private void Start()
	{
		float num = this.selfdestruct_in;
	}

	// Token: 0x0400113D RID: 4413
	public float selfdestruct_in = 4f;
}
