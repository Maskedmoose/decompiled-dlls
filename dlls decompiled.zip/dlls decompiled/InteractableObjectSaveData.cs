﻿using System;

// Token: 0x02000048 RID: 72
[Serializable]
public class InteractableObjectSaveData
{
	// Token: 0x0400042F RID: 1071
	public Vector3Serializer pos;

	// Token: 0x04000430 RID: 1072
	public QuaternionSerializer rot;

	// Token: 0x04000431 RID: 1073
	public bool isBoxed;

	// Token: 0x04000432 RID: 1074
	public Vector3Serializer boxedPackagePos;

	// Token: 0x04000433 RID: 1075
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x04000434 RID: 1076
	public EObjectType objectType;
}
