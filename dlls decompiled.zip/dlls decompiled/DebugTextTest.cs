﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200011D RID: 285
public class DebugTextTest : CSingleton<DebugTextTest>
{
	// Token: 0x06000856 RID: 2134 RVA: 0x0003E698 File Offset: 0x0003C898
	private void Awake()
	{
		if (DebugTextTest.m_Instance == null)
		{
			DebugTextTest.m_Instance = this;
		}
		else if (DebugTextTest.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		if (base.transform.root == base.transform)
		{
			Object.DontDestroyOnLoad(this);
		}
	}

	// Token: 0x06000857 RID: 2135 RVA: 0x0003E6F0 File Offset: 0x0003C8F0
	public static void PrintText2(string text)
	{
	}

	// Token: 0x06000858 RID: 2136 RVA: 0x0003E6F2 File Offset: 0x0003C8F2
	public static void PrintText(string text)
	{
	}

	// Token: 0x04001018 RID: 4120
	public static DebugTextTest m_Instance;

	// Token: 0x04001019 RID: 4121
	public TextMeshProUGUI m_Text;

	// Token: 0x0400101A RID: 4122
	public TextMeshProUGUI m_Text2;

	// Token: 0x0400101B RID: 4123
	private static string m_CurrentString;

	// Token: 0x0400101C RID: 4124
	private static int m_StringCount;
}
