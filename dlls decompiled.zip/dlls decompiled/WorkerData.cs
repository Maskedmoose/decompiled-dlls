﻿using System;
using I2.Loc;
using UnityEngine;

// Token: 0x02000091 RID: 145
[Serializable]
public class WorkerData
{
	// Token: 0x060005C0 RID: 1472 RVA: 0x0003065F File Offset: 0x0002E85F
	public string GetName()
	{
		return this.name;
	}

	// Token: 0x060005C1 RID: 1473 RVA: 0x00030667 File Offset: 0x0002E867
	public string GetDescription()
	{
		return LocalizationManager.GetTranslation(this.description, true, 0, true, false, null, null, true);
	}

	// Token: 0x060005C2 RID: 1474 RVA: 0x0003067C File Offset: 0x0002E87C
	public string GetRestockSpeedText()
	{
		if (this.restockSpeed < 1f)
		{
			return LocalizationManager.GetTranslation("Very Fast", true, 0, true, false, null, null, true);
		}
		if (this.restockSpeed < 1.75f)
		{
			return LocalizationManager.GetTranslation("Fast", true, 0, true, false, null, null, true);
		}
		if (this.restockSpeed < 2.5f)
		{
			return LocalizationManager.GetTranslation("Normal", true, 0, true, false, null, null, true);
		}
		if (this.restockSpeed < 3f)
		{
			return LocalizationManager.GetTranslation("Slow", true, 0, true, false, null, null, true);
		}
		return LocalizationManager.GetTranslation("Very Slow", true, 0, true, false, null, null, true);
	}

	// Token: 0x060005C3 RID: 1475 RVA: 0x00030718 File Offset: 0x0002E918
	public string GetCheckoutSpeedText()
	{
		if (this.checkoutSpeed < 1f)
		{
			return LocalizationManager.GetTranslation("Very Fast", true, 0, true, false, null, null, true);
		}
		if (this.checkoutSpeed < 1.75f)
		{
			return LocalizationManager.GetTranslation("Fast", true, 0, true, false, null, null, true);
		}
		if (this.checkoutSpeed < 2.5f)
		{
			return LocalizationManager.GetTranslation("Normal", true, 0, true, false, null, null, true);
		}
		if (this.checkoutSpeed < 3f)
		{
			return LocalizationManager.GetTranslation("Slow", true, 0, true, false, null, null, true);
		}
		return LocalizationManager.GetTranslation("Very Slow", true, 0, true, false, null, null, true);
	}

	// Token: 0x060005C4 RID: 1476 RVA: 0x000307B4 File Offset: 0x0002E9B4
	public string GetSalaryCostText()
	{
		return GameInstance.GetPriceString(this.costPerDay, false, true, false, "F2") + "/" + LocalizationManager.GetTranslation("day", true, 0, true, false, null, null, true);
	}

	// Token: 0x04000782 RID: 1922
	public string name;

	// Token: 0x04000783 RID: 1923
	public Sprite icon;

	// Token: 0x04000784 RID: 1924
	public float restockSpeed;

	// Token: 0x04000785 RID: 1925
	public float checkoutSpeed;

	// Token: 0x04000786 RID: 1926
	public float walkSpeedMultiplier;

	// Token: 0x04000787 RID: 1927
	public float costPerDay;

	// Token: 0x04000788 RID: 1928
	public float hiringCost;

	// Token: 0x04000789 RID: 1929
	public float arriveEarlySpeedMin;

	// Token: 0x0400078A RID: 1930
	public float arriveEarlySpeedMax;

	// Token: 0x0400078B RID: 1931
	public int shopLevelRequired;

	// Token: 0x0400078C RID: 1932
	public string description;

	// Token: 0x0400078D RID: 1933
	public bool goBackOnTime;

	// Token: 0x0400078E RID: 1934
	public bool prologueShow;
}
