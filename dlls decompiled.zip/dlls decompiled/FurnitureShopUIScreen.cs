﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000068 RID: 104
public class FurnitureShopUIScreen : GenericSliderScreen
{
	// Token: 0x0600045F RID: 1119 RVA: 0x00026284 File Offset: 0x00024484
	protected override void Init()
	{
		for (int i = 0; i < this.m_FurnitureShopPanelUIList.Count; i++)
		{
			this.m_FurnitureShopPanelUIList[i].SetActive(false);
		}
		int count = CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_FurniturePurchaseDataList.Count;
		for (int j = 0; j < count; j++)
		{
			this.m_FurnitureShopPanelUIList[j].Init(this, j);
			this.m_FurnitureShopPanelUIList[j].SetActive(true);
			this.m_ScrollEndPosParent = this.m_FurnitureShopPanelUIList[j].gameObject;
		}
		base.Init();
	}

	// Token: 0x06000460 RID: 1120 RVA: 0x0002631C File Offset: 0x0002451C
	protected override void OnOpenScreen()
	{
		this.Init();
		base.OnOpenScreen();
	}

	// Token: 0x06000461 RID: 1121 RVA: 0x0002632A File Offset: 0x0002452A
	public void OnPressPanelUIButton(int index)
	{
		this.m_ConfirmPurchaseScreen.UpdateData(this, index);
		base.OpenChildScreen(this.m_ConfirmPurchaseScreen);
	}

	// Token: 0x06000462 RID: 1122 RVA: 0x00026348 File Offset: 0x00024548
	private void SpawnPackageItemBox(EObjectType objectType)
	{
		Transform randomPackageSpawnPos = RestockManager.GetRandomPackageSpawnPos();
		ShelfManager.SpawnInteractableObjectInPackageBox(objectType, randomPackageSpawnPos.position, randomPackageSpawnPos.rotation);
	}

	// Token: 0x06000463 RID: 1123 RVA: 0x00026370 File Offset: 0x00024570
	public void EvaluateCartCheckout(float totalCost, int index)
	{
		CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(totalCost, false));
		FurniturePurchaseData furniturePurchaseData = InventoryBase.GetFurniturePurchaseData(index);
		this.SpawnPackageItemBox(furniturePurchaseData.objectType);
		base.StartCoroutine(this.DelaySaveShelfData());
		CEventManager.QueueEvent(new CEventPlayer_AddShopExp(Mathf.Clamp(Mathf.RoundToInt(totalCost / 100f), 5, 100), false));
		CPlayerData.m_GameReportDataCollect.upgradeCost = CPlayerData.m_GameReportDataCollect.upgradeCost - totalCost;
		CPlayerData.m_GameReportDataCollectPermanent.upgradeCost = CPlayerData.m_GameReportDataCollectPermanent.upgradeCost - totalCost;
		SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
	}

	// Token: 0x06000464 RID: 1124 RVA: 0x000263FA File Offset: 0x000245FA
	private IEnumerator DelaySaveShelfData()
	{
		yield return new WaitForSeconds(1f);
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		yield break;
	}

	// Token: 0x0400056C RID: 1388
	public List<FurnitureShopPanelUI> m_FurnitureShopPanelUIList;

	// Token: 0x0400056D RID: 1389
	public FurnitureShopConfirmPurchaseScreen m_ConfirmPurchaseScreen;
}
