﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000043 RID: 67
public class PriceTagUISpawner : CSingleton<PriceTagUISpawner>
{
	// Token: 0x0600032A RID: 810 RVA: 0x0001D16D File Offset: 0x0001B36D
	private void Awake()
	{
		if (PriceTagUISpawner.m_Instance == null)
		{
			PriceTagUISpawner.m_Instance = this;
		}
		else if (PriceTagUISpawner.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x0600032B RID: 811 RVA: 0x0001D1A4 File Offset: 0x0001B3A4
	private void Update()
	{
		this.m_CullLoopCount = 0;
		for (int i = 0; i < this.m_UI_PriceTagList.Count; i++)
		{
			if (this.m_UI_PriceTagList[this.m_CullIndex] && !this.m_UI_PriceTagList[this.m_CullIndex].m_IgnoreCull)
			{
				float num = Vector3.Dot((this.m_UI_PriceTagList[this.m_CullIndex].m_UIGrp.position - CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.position).normalized, CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.forward);
				float magnitude = (this.m_UI_PriceTagList[this.m_CullIndex].m_UIGrp.position - CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.transform.position).magnitude;
				float num2 = Vector3.Angle(this.m_UI_PriceTagList[this.m_CullIndex].m_UIGrp.TransformDirection(Vector3.forward), CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.TransformDirection(Vector3.forward));
				if (magnitude > 6f || (magnitude > 1f && num < this.m_DotCullLimit) || num2 > 110f)
				{
					this.m_UI_PriceTagList[this.m_CullIndex].m_UIGrp.gameObject.SetActive(false);
				}
				else
				{
					this.m_UI_PriceTagList[this.m_CullIndex].m_UIGrp.gameObject.SetActive(true);
				}
			}
			this.m_CullIndex++;
			if (this.m_CullIndex >= this.m_UI_PriceTagList.Count)
			{
				this.m_CullIndex = 0;
			}
			this.m_CullLoopCount++;
			if (this.m_CullLoopCount >= this.m_CullLoopCountMaxPerFrame)
			{
				this.m_CullLoopCount = 0;
				return;
			}
		}
	}

	// Token: 0x0600032C RID: 812 RVA: 0x0001D390 File Offset: 0x0001B590
	public static Transform SpawnShelfWorldUIGrp(Transform shelf)
	{
		Transform transform = Object.Instantiate<Transform>(CSingleton<PriceTagUISpawner>.Instance.m_Shelf_WorldUIGrpPrefab, shelf.position, shelf.rotation, CSingleton<PriceTagUISpawner>.Instance.transform);
		CSingleton<PriceTagUISpawner>.Instance.m_WorldUIGrpList.Add(transform);
		return transform;
	}

	// Token: 0x0600032D RID: 813 RVA: 0x0001D3D4 File Offset: 0x0001B5D4
	public static UI_PriceTag SpawnPriceTagWorldUIGrp(Transform parent, Transform priceTagLoc)
	{
		UI_PriceTag ui_PriceTag = Object.Instantiate<UI_PriceTag>(CSingleton<PriceTagUISpawner>.Instance.m_UIPriceTagPrefab, priceTagLoc.position, priceTagLoc.rotation, parent);
		CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Add(ui_PriceTag);
		return ui_PriceTag;
	}

	// Token: 0x0600032E RID: 814 RVA: 0x0001D410 File Offset: 0x0001B610
	public static UI_PriceTag SpawnPriceTagItemBoxWorldUIGrp(Transform parent, Transform priceTagLoc)
	{
		UI_PriceTag ui_PriceTag = Object.Instantiate<UI_PriceTag>(CSingleton<PriceTagUISpawner>.Instance.m_UIPriceTagItemBoxPrefab, priceTagLoc.position, priceTagLoc.rotation, parent);
		CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Add(ui_PriceTag);
		return ui_PriceTag;
	}

	// Token: 0x0600032F RID: 815 RVA: 0x0001D44C File Offset: 0x0001B64C
	public static UI_PriceTag SpawnPriceTagPackageBoxWorldUIGrp(Transform parent, Transform priceTagLoc)
	{
		UI_PriceTag ui_PriceTag = Object.Instantiate<UI_PriceTag>(CSingleton<PriceTagUISpawner>.Instance.m_UIPriceTagPackageBoxPrefab, priceTagLoc.position, priceTagLoc.rotation, parent);
		CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Add(ui_PriceTag);
		return ui_PriceTag;
	}

	// Token: 0x06000330 RID: 816 RVA: 0x0001D488 File Offset: 0x0001B688
	public static UI_PriceTag SpawnPriceTagWarehouseRakWorldUIGrp(Transform parent, Transform priceTagLoc)
	{
		UI_PriceTag ui_PriceTag = Object.Instantiate<UI_PriceTag>(CSingleton<PriceTagUISpawner>.Instance.m_UIPriceTagWarehouseRackPrefab, priceTagLoc.position, priceTagLoc.rotation, parent);
		CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Add(ui_PriceTag);
		return ui_PriceTag;
	}

	// Token: 0x06000331 RID: 817 RVA: 0x0001D4C4 File Offset: 0x0001B6C4
	public static UI_PriceTag SpawnPriceTagCardWorldUIGrp(Transform parent, Transform priceTagLoc)
	{
		UI_PriceTag ui_PriceTag = Object.Instantiate<UI_PriceTag>(CSingleton<PriceTagUISpawner>.Instance.m_UIPriceTagCardPrefab, priceTagLoc.position, priceTagLoc.rotation, parent);
		CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Add(ui_PriceTag);
		return ui_PriceTag;
	}

	// Token: 0x06000332 RID: 818 RVA: 0x0001D500 File Offset: 0x0001B700
	public static void SetAllPriceTagUIBrightness(float brightness)
	{
		for (int i = 0; i < CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList.Count; i++)
		{
			if (CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList[i])
			{
				CSingleton<PriceTagUISpawner>.Instance.m_UI_PriceTagList[i].SetBrightness(brightness);
			}
		}
	}

	// Token: 0x06000333 RID: 819 RVA: 0x0001D554 File Offset: 0x0001B754
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x06000334 RID: 820 RVA: 0x0001D575 File Offset: 0x0001B775
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x06000335 RID: 821 RVA: 0x0001D596 File Offset: 0x0001B796
	protected void OnSettingUpdated(CEventPlayer_OnSettingUpdated evt)
	{
		this.m_DotCullLimit = Mathf.Lerp(0.75f, 0.35f, CSingleton<CGameManager>.Instance.m_CameraFOVSlider);
	}

	// Token: 0x040003D5 RID: 981
	public static PriceTagUISpawner m_Instance;

	// Token: 0x040003D6 RID: 982
	public Transform m_Shelf_WorldUIGrpPrefab;

	// Token: 0x040003D7 RID: 983
	public UI_PriceTag m_UIPriceTagPrefab;

	// Token: 0x040003D8 RID: 984
	public UI_PriceTag m_UIPriceTagItemBoxPrefab;

	// Token: 0x040003D9 RID: 985
	public UI_PriceTag m_UIPriceTagPackageBoxPrefab;

	// Token: 0x040003DA RID: 986
	public UI_PriceTag m_UIPriceTagWarehouseRackPrefab;

	// Token: 0x040003DB RID: 987
	public UI_PriceTag m_UIPriceTagCardPrefab;

	// Token: 0x040003DC RID: 988
	private List<Transform> m_WorldUIGrpList = new List<Transform>();

	// Token: 0x040003DD RID: 989
	private List<UI_PriceTag> m_UI_PriceTagList = new List<UI_PriceTag>();

	// Token: 0x040003DE RID: 990
	private int m_CullIndex;

	// Token: 0x040003DF RID: 991
	private int m_CullLoopCount;

	// Token: 0x040003E0 RID: 992
	private int m_CullLoopCountMaxPerFrame = 100;

	// Token: 0x040003E1 RID: 993
	private float m_DotCullLimit = 0.65f;
}
