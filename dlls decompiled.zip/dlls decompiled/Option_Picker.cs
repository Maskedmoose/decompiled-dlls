﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CC
{
	// Token: 0x020001C9 RID: 457
	public class Option_Picker : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CD0 RID: 3280 RVA: 0x00058DAF File Offset: 0x00056FAF
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util ParentUI)
		{
			this.customizer = customizerScript;
			this.RefreshUIElement();
		}

		// Token: 0x06000CD1 RID: 3281 RVA: 0x00058DC0 File Offset: 0x00056FC0
		public void RefreshUIElement()
		{
			switch (this.CustomizationType)
			{
			case Option_Picker.Type.Blendshape:
			{
				this.optionsCount = this.Options.Count;
				this.updateOptionText();
				int j;
				int i;
				for (i = 0; i < this.customizer.StoredCharacterData.Blendshapes.Count; i = j + 1)
				{
					int num = this.Options.FindIndex((CC_Property t) => t.propertyName == this.customizer.StoredCharacterData.Blendshapes[i].propertyName);
					if (num != -1)
					{
						this.navIndex = num;
						this.updateOptionText();
						return;
					}
					j = i;
				}
				return;
			}
			case Option_Picker.Type.Texture:
			{
				this.optionsCount = this.Options.Count;
				int savedIndex = this.customizer.StoredCharacterData.TextureProperties.FindIndex((CC_Property t) => t.propertyName == this.Property.propertyName && t.materialIndex == this.Property.materialIndex && t.meshTag == this.Property.meshTag);
				if (savedIndex != -1)
				{
					this.navIndex = this.Options.FindIndex((CC_Property t) => t.stringValue == this.customizer.StoredCharacterData.TextureProperties[savedIndex].stringValue);
				}
				else
				{
					this.navIndex = 0;
				}
				this.updateOptionText();
				return;
			}
			case Option_Picker.Type.Hair:
				this.optionsCount = this.customizer.HairTables[this.Slot].Hairstyles.Count;
				this.navIndex = this.customizer.HairTables[this.Slot].Hairstyles.FindIndex((scrObj_Hair.Hairstyle t) => t.Name == this.customizer.StoredCharacterData.HairNames[this.Slot]);
				if (this.navIndex == -1)
				{
					this.navIndex = 0;
				}
				this.updateOptionText();
				return;
			default:
				return;
			}
		}

		// Token: 0x06000CD2 RID: 3282 RVA: 0x00058F5C File Offset: 0x0005715C
		public void updateOptionText()
		{
			this.OptionText.SetText((this.navIndex + 1).ToString() + "/" + this.optionsCount.ToString(), true);
		}

		// Token: 0x06000CD3 RID: 3283 RVA: 0x00058F9C File Offset: 0x0005719C
		public void setOption(int i)
		{
			this.navIndex = i;
			this.updateOptionText();
			switch (this.CustomizationType)
			{
			case Option_Picker.Type.Blendshape:
				foreach (CC_Property cc_Property in this.Options)
				{
					this.customizer.setBlendshapeByName(base.name, 0f, true);
				}
				this.customizer.setBlendshapeByName(this.Options[i].propertyName, 1f, true);
				return;
			case Option_Picker.Type.Texture:
				this.customizer.setTextureProperty(this.Options[i], true, null);
				return;
			case Option_Picker.Type.Hair:
				this.customizer.setHair(i, this.Slot);
				return;
			default:
				return;
			}
		}

		// Token: 0x06000CD4 RID: 3284 RVA: 0x00059078 File Offset: 0x00057278
		public void navLeft()
		{
			this.setOption((this.navIndex == 0) ? (this.optionsCount - 1) : (this.navIndex - 1));
		}

		// Token: 0x06000CD5 RID: 3285 RVA: 0x0005909A File Offset: 0x0005729A
		public void navRight()
		{
			this.setOption((this.navIndex == this.optionsCount - 1) ? 0 : (this.navIndex + 1));
		}

		// Token: 0x06000CD6 RID: 3286 RVA: 0x000590BD File Offset: 0x000572BD
		public void randomize()
		{
			this.setOption(Random.Range(0, this.optionsCount));
		}

		// Token: 0x040013B3 RID: 5043
		private CharacterCustomization customizer;

		// Token: 0x040013B4 RID: 5044
		public Option_Picker.Type CustomizationType;

		// Token: 0x040013B5 RID: 5045
		public CC_Property Property;

		// Token: 0x040013B6 RID: 5046
		public List<CC_Property> Options = new List<CC_Property>();

		// Token: 0x040013B7 RID: 5047
		public int Slot;

		// Token: 0x040013B8 RID: 5048
		public TextMeshProUGUI OptionText;

		// Token: 0x040013B9 RID: 5049
		private int navIndex;

		// Token: 0x040013BA RID: 5050
		private int optionsCount;

		// Token: 0x02000276 RID: 630
		public enum Type
		{
			// Token: 0x0400167F RID: 5759
			Blendshape,
			// Token: 0x04001680 RID: 5760
			Texture,
			// Token: 0x04001681 RID: 5761
			Hair
		}
	}
}
