﻿using System;

// Token: 0x020000B2 RID: 178
public class CEventPlayer_AddShopExp : CEvent
{
	// Token: 0x17000015 RID: 21
	// (get) Token: 0x06000703 RID: 1795 RVA: 0x0003803F File Offset: 0x0003623F
	// (set) Token: 0x06000704 RID: 1796 RVA: 0x00038047 File Offset: 0x00036247
	public int m_ExpValue { get; private set; }

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x06000705 RID: 1797 RVA: 0x00038050 File Offset: 0x00036250
	// (set) Token: 0x06000706 RID: 1798 RVA: 0x00038058 File Offset: 0x00036258
	public bool m_NoLerp { get; private set; }

	// Token: 0x06000707 RID: 1799 RVA: 0x00038061 File Offset: 0x00036261
	public CEventPlayer_AddShopExp(int ExpValue, bool noLerp = false)
	{
		this.m_ExpValue = ExpValue;
		this.m_NoLerp = noLerp;
	}
}
