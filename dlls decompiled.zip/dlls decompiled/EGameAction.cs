﻿using System;

// Token: 0x0200011A RID: 282
public enum EGameAction
{
	// Token: 0x04000FAA RID: 4010
	None,
	// Token: 0x04000FAB RID: 4011
	Interact,
	// Token: 0x04000FAC RID: 4012
	Back,
	// Token: 0x04000FAD RID: 4013
	Cancel,
	// Token: 0x04000FAE RID: 4014
	PutItem,
	// Token: 0x04000FAF RID: 4015
	TakeItem,
	// Token: 0x04000FB0 RID: 4016
	PutCard,
	// Token: 0x04000FB1 RID: 4017
	TakeCard,
	// Token: 0x04000FB2 RID: 4018
	TakeBox,
	// Token: 0x04000FB3 RID: 4019
	OpenBox,
	// Token: 0x04000FB4 RID: 4020
	CloseBox,
	// Token: 0x04000FB5 RID: 4021
	OpenPhone,
	// Token: 0x04000FB6 RID: 4022
	ClosePhone,
	// Token: 0x04000FB7 RID: 4023
	Scroll,
	// Token: 0x04000FB8 RID: 4024
	StartMoveObject,
	// Token: 0x04000FB9 RID: 4025
	PlaceMoveObject,
	// Token: 0x04000FBA RID: 4026
	Throw,
	// Token: 0x04000FBB RID: 4027
	Rotate,
	// Token: 0x04000FBC RID: 4028
	OpenCardAlbum,
	// Token: 0x04000FBD RID: 4029
	CloseCardAlbum,
	// Token: 0x04000FBE RID: 4030
	TakeAlbumCard,
	// Token: 0x04000FBF RID: 4031
	FlipNextPage,
	// Token: 0x04000FC0 RID: 4032
	FlipPreviousPage,
	// Token: 0x04000FC1 RID: 4033
	FlipNextPage10,
	// Token: 0x04000FC2 RID: 4034
	FlipPreviousPage10,
	// Token: 0x04000FC3 RID: 4035
	GoNextDay,
	// Token: 0x04000FC4 RID: 4036
	Jump,
	// Token: 0x04000FC5 RID: 4037
	PauseGame,
	// Token: 0x04000FC6 RID: 4038
	InitiateOpenPack,
	// Token: 0x04000FC7 RID: 4039
	CancelOpenPack,
	// Token: 0x04000FC8 RID: 4040
	OpenPack,
	// Token: 0x04000FC9 RID: 4041
	BoxUpShelf,
	// Token: 0x04000FCA RID: 4042
	StartCounter,
	// Token: 0x04000FCB RID: 4043
	ExitCounter,
	// Token: 0x04000FCC RID: 4044
	ScanCounter,
	// Token: 0x04000FCD RID: 4045
	DoneCounter,
	// Token: 0x04000FCE RID: 4046
	SortAlbum,
	// Token: 0x04000FCF RID: 4047
	InteractLeft,
	// Token: 0x04000FD0 RID: 4048
	InteractRight,
	// Token: 0x04000FD1 RID: 4049
	TrashDispose,
	// Token: 0x04000FD2 RID: 4050
	BackF,
	// Token: 0x04000FD3 RID: 4051
	SetPrice,
	// Token: 0x04000FD4 RID: 4052
	AddChange,
	// Token: 0x04000FD5 RID: 4053
	RemoveChange,
	// Token: 0x04000FD6 RID: 4054
	StoreBox,
	// Token: 0x04000FD7 RID: 4055
	MoveForward,
	// Token: 0x04000FD8 RID: 4056
	MoveBackward,
	// Token: 0x04000FD9 RID: 4057
	MoveLeft,
	// Token: 0x04000FDA RID: 4058
	MoveRight,
	// Token: 0x04000FDB RID: 4059
	LookAround,
	// Token: 0x04000FDC RID: 4060
	InitiateSpray,
	// Token: 0x04000FDD RID: 4061
	CancelSpray,
	// Token: 0x04000FDE RID: 4062
	Spray,
	// Token: 0x04000FDF RID: 4063
	ManageEvent,
	// Token: 0x04000FE0 RID: 4064
	Sprint,
	// Token: 0x04000FE1 RID: 4065
	MoveForwardAlt,
	// Token: 0x04000FE2 RID: 4066
	MoveBackwardAlt,
	// Token: 0x04000FE3 RID: 4067
	MoveLeftAlt,
	// Token: 0x04000FE4 RID: 4068
	MoveRightAlt,
	// Token: 0x04000FE5 RID: 4069
	PlaceBox,
	// Token: 0x04000FE6 RID: 4070
	MenuConfirm,
	// Token: 0x04000FE7 RID: 4071
	MenuBack,
	// Token: 0x04000FE8 RID: 4072
	RotateB,
	// Token: 0x04000FE9 RID: 4073
	RemoveLabel,
	// Token: 0x04000FEA RID: 4074
	Refill,
	// Token: 0x04000FEB RID: 4075
	TurnOn,
	// Token: 0x04000FEC RID: 4076
	TurnOff,
	// Token: 0x04000FED RID: 4077
	OpenCardBox,
	// Token: 0x04000FEE RID: 4078
	ViewAlbumCard,
	// Token: 0x04000FEF RID: 4079
	SellBoxedUpShelf
}
