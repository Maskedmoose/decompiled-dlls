﻿using System;
using UnityEngine;

// Token: 0x02000122 RID: 290
public class TouchScrollHorizontal : MonoBehaviour
{
	// Token: 0x06000871 RID: 2161 RVA: 0x0003EE1B File Offset: 0x0003D01B
	private void Start()
	{
		this.m_RectTransform = base.GetComponent<RectTransform>();
		this.m_ScrollIndicatorStartPos = this.m_ScrollIndicator.transform.position;
		this.m_ScrollIndicatorEndPos = this.m_ScrollIndicatorEnd.transform.position;
	}

	// Token: 0x06000872 RID: 2162 RVA: 0x0003EE55 File Offset: 0x0003D055
	private void Update()
	{
		this.SwipeDetection();
		this.EvaluateScrollIndicator();
	}

	// Token: 0x06000873 RID: 2163 RVA: 0x0003EE63 File Offset: 0x0003D063
	public void SetScrollingNormal()
	{
		this.m_IsScrollingInverse = false;
	}

	// Token: 0x06000874 RID: 2164 RVA: 0x0003EE6C File Offset: 0x0003D06C
	public void SetScrollingInverse()
	{
		this.m_IsScrollingInverse = true;
	}

	// Token: 0x06000875 RID: 2165 RVA: 0x0003EE78 File Offset: 0x0003D078
	private void EvaluateScrollIndicator()
	{
		this.m_ScrollIndicatorLerpAlpha = this.m_RectTransform.localPosition.x / this.m_ScrollLimitMaxX;
		this.m_ScrollIndicator.transform.position = Vector3.Lerp(this.m_ScrollIndicatorStartPos, this.m_ScrollIndicatorEndPos, this.m_ScrollIndicatorLerpAlpha);
	}

	// Token: 0x06000876 RID: 2166 RVA: 0x0003EEC9 File Offset: 0x0003D0C9
	public void IsMouseDown()
	{
	}

	// Token: 0x06000877 RID: 2167 RVA: 0x0003EECB File Offset: 0x0003D0CB
	public void IsMouseUp()
	{
	}

	// Token: 0x06000878 RID: 2168 RVA: 0x0003EECD File Offset: 0x0003D0CD
	public void SetScrollLerpPos(float posX)
	{
		this.m_ScrollerLerpPos = new Vector3(posX, 0f, 0f);
	}

	// Token: 0x06000879 RID: 2169 RVA: 0x0003EEE8 File Offset: 0x0003D0E8
	private void SwipeDetection()
	{
		this.m_RectTransform.localPosition = Vector3.Lerp(this.m_RectTransform.localPosition, this.m_ScrollerLerpPos, Time.deltaTime * this.m_ScrollerLerpSpeed);
		if (InputManager.GetKeyDownAction(EGameAction.InteractLeft))
		{
			this.mStartPosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
			this.mSwipeStartTime = Time.time;
			this.m_FingerTouched = true;
		}
		if (this.m_FingerTouched)
		{
			this.m_FingerTouchTime += Time.deltaTime;
		}
		Vector2 vector = new Vector2(Input.mousePosition.x, Input.mousePosition.y) - this.mStartPosition;
		float num = Time.time - this.mSwipeStartTime;
		float num2 = vector.magnitude / num;
		if (this.m_FingerTouchTime > 0.001f && this.m_RectTransform.localPosition.x <= this.m_ScrollLimitMinX && this.m_RectTransform.localPosition.x >= this.m_ScrollLimitMaxX)
		{
			float x;
			if (this.m_IsScrollingInverse)
			{
				x = vector.x * this.m_ScrollSensitivity;
			}
			else
			{
				x = vector.x * this.m_ScrollSensitivity * -1f * 2f;
			}
			this.m_ScrollerLerpPos += new Vector3(x, 0f, 0f);
			this.mStartPosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
			if (this.m_ScrollerLerpPos.x > this.m_ScrollLimitMinX)
			{
				this.m_ScrollerLerpPos = new Vector3(this.m_ScrollLimitMinX, 0f, 0f);
			}
			else if (this.m_ScrollerLerpPos.x < this.m_ScrollLimitMaxX)
			{
				this.m_ScrollerLerpPos = new Vector3(this.m_ScrollLimitMaxX, 0f, 0f);
			}
			if (this.m_RectTransform.localPosition.x > this.m_ScrollLimitMinX)
			{
				this.m_RectTransform.localPosition = new Vector3(this.m_ScrollLimitMinX, 0f, 0f);
			}
			else if (this.m_RectTransform.localPosition.x < this.m_ScrollLimitMaxX)
			{
				this.m_RectTransform.localPosition = new Vector3(this.m_ScrollLimitMaxX, 0f, 0f);
			}
		}
		if (Input.GetMouseButtonUp(0) && this.m_FingerTouched)
		{
			this.m_FingerTouched = false;
			this.m_FingerTouchTime = 0f;
			num = Time.time - this.mSwipeStartTime;
			vector = new Vector2(Input.mousePosition.x, Input.mousePosition.y) - this.mStartPosition;
			if (vector.magnitude / num > 0.1f && vector.magnitude > 0.1f)
			{
				vector.Normalize();
				float num3 = Vector2.Dot(vector, this.mXAxis);
				num3 = Mathf.Acos(num3) * 57.29578f;
				if (num3 < 44f)
				{
					this.OnSwipeRight();
					return;
				}
				if (180f - num3 < 44f)
				{
					this.OnSwipeLeft();
					return;
				}
				num3 = Vector2.Dot(vector, this.mYAxis);
				num3 = Mathf.Acos(num3) * 57.29578f;
				if (num3 < 44f)
				{
					this.OnSwipeTop();
					return;
				}
				if (180f - num3 < 44f)
				{
					this.OnSwipeBottom();
					return;
				}
			}
			else
			{
				this.OnTapDetection();
			}
		}
	}

	// Token: 0x0600087A RID: 2170 RVA: 0x0003F247 File Offset: 0x0003D447
	private void ResetTouch()
	{
		this.m_FingerTouched = false;
		this.m_FingerTouchTime = 0f;
	}

	// Token: 0x0600087B RID: 2171 RVA: 0x0003F25B File Offset: 0x0003D45B
	private void OnTapDetection()
	{
	}

	// Token: 0x0600087C RID: 2172 RVA: 0x0003F25D File Offset: 0x0003D45D
	private void OnSwipeLeft()
	{
	}

	// Token: 0x0600087D RID: 2173 RVA: 0x0003F25F File Offset: 0x0003D45F
	private void OnSwipeRight()
	{
	}

	// Token: 0x0600087E RID: 2174 RVA: 0x0003F261 File Offset: 0x0003D461
	private void OnSwipeTop()
	{
	}

	// Token: 0x0600087F RID: 2175 RVA: 0x0003F263 File Offset: 0x0003D463
	private void OnSwipeBottom()
	{
	}

	// Token: 0x04001030 RID: 4144
	public float m_ScrollLimitMinX = 60f;

	// Token: 0x04001031 RID: 4145
	public float m_ScrollLimitMaxX = -500f;

	// Token: 0x04001032 RID: 4146
	public float m_ScrollerLerpSpeed = 5f;

	// Token: 0x04001033 RID: 4147
	public float m_ScrollSensitivity = 0.4f;

	// Token: 0x04001034 RID: 4148
	public GameObject m_ScrollIndicator;

	// Token: 0x04001035 RID: 4149
	public GameObject m_ScrollIndicatorEnd;

	// Token: 0x04001036 RID: 4150
	private Vector3 m_ScrollIndicatorStartPos;

	// Token: 0x04001037 RID: 4151
	private Vector3 m_ScrollIndicatorEndPos;

	// Token: 0x04001038 RID: 4152
	private float m_ScrollIndicatorLerpAlpha;

	// Token: 0x04001039 RID: 4153
	private bool m_IsScrollingInverse = true;

	// Token: 0x0400103A RID: 4154
	private RectTransform m_RectTransform;

	// Token: 0x0400103B RID: 4155
	private Vector3 m_ScrollerLerpPos;

	// Token: 0x0400103C RID: 4156
	private bool m_FingerTouched;

	// Token: 0x0400103D RID: 4157
	private float m_FingerTouchTime;

	// Token: 0x0400103E RID: 4158
	private readonly Vector2 mXAxis = new Vector2(1f, 0f);

	// Token: 0x0400103F RID: 4159
	private readonly Vector2 mYAxis = new Vector2(0f, 1f);

	// Token: 0x04001040 RID: 4160
	private const float mAngleRange = 44f;

	// Token: 0x04001041 RID: 4161
	private const float mMinSwipeDist = 0.1f;

	// Token: 0x04001042 RID: 4162
	private const float mMinVelocity = 0.1f;

	// Token: 0x04001043 RID: 4163
	private Vector2 mStartPosition;

	// Token: 0x04001044 RID: 4164
	private float mSwipeStartTime;
}
