﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E4 RID: 484
	public class CameraMouseInput : CameraInput
	{
		// Token: 0x06000D95 RID: 3477 RVA: 0x0005D2AC File Offset: 0x0005B4AC
		public unsafe override float GetHorizontalCameraInput()
		{
			float num = Input.GetAxisRaw(this.joystickHorizontalAxis);
			if (CSingleton<InputManager>.Instance.m_CurrentGamepad != null && CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				num = *CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStick.x.value;
			}
			bool flag = false;
			if (Mathf.Abs(num) > 0f && CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				flag = true;
			}
			else
			{
				num = Input.GetAxisRaw(this.mouseHorizontalAxis);
			}
			if (Time.timeScale > 0f && Time.deltaTime > 0f)
			{
				num /= Time.deltaTime;
				num *= Time.timeScale;
			}
			else
			{
				num = 0f;
			}
			if (flag)
			{
				num *= this.joystickInputMultiplier;
			}
			else
			{
				num *= this.mouseInputMultiplier;
			}
			if (this.invertHorizontalInput)
			{
				num *= -1f;
			}
			return num;
		}

		// Token: 0x06000D96 RID: 3478 RVA: 0x0005D37C File Offset: 0x0005B57C
		public unsafe override float GetVerticalCameraInput()
		{
			float num = -Input.GetAxisRaw(this.joystickVerticalAxis);
			if (CSingleton<InputManager>.Instance.m_CurrentGamepad != null && CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				num = -(*CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStick.y.value);
			}
			bool flag = false;
			if (Mathf.Abs(num) > 0f && CSingleton<InputManager>.Instance.m_IsControllerActive)
			{
				flag = true;
			}
			else
			{
				num = -Input.GetAxisRaw(this.mouseVerticalAxis);
			}
			if (Time.timeScale > 0f && Time.deltaTime > 0f)
			{
				num /= Time.deltaTime;
				num *= Time.timeScale;
			}
			else
			{
				num = 0f;
			}
			if (flag)
			{
				num *= this.joystickInputMultiplier;
			}
			else
			{
				num *= this.mouseInputMultiplier;
			}
			if (this.invertVerticalInput)
			{
				num *= -1f;
			}
			return num;
		}

		// Token: 0x04001484 RID: 5252
		public string mouseHorizontalAxis = "Mouse X";

		// Token: 0x04001485 RID: 5253
		public string mouseVerticalAxis = "Mouse Y";

		// Token: 0x04001486 RID: 5254
		public string joystickHorizontalAxis = "RJoystick X";

		// Token: 0x04001487 RID: 5255
		public string joystickVerticalAxis = "RJoystick Y";

		// Token: 0x04001488 RID: 5256
		public string joystickHorizontalAxisPS = "RJoystick X PS";

		// Token: 0x04001489 RID: 5257
		public string joystickVerticalAxisPS = "RJoystick Y PS";

		// Token: 0x0400148A RID: 5258
		public bool invertHorizontalInput;

		// Token: 0x0400148B RID: 5259
		public bool invertVerticalInput;

		// Token: 0x0400148C RID: 5260
		public float mouseInputMultiplier = 0.01f;

		// Token: 0x0400148D RID: 5261
		public float joystickInputMultiplier = 1f;
	}
}
