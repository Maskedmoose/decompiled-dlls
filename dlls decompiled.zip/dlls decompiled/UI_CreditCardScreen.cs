﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000088 RID: 136
public class UI_CreditCardScreen : MonoBehaviour
{
	// Token: 0x0600055A RID: 1370 RVA: 0x0002CEC4 File Offset: 0x0002B0C4
	private void Awake()
	{
		this.ResetCounter();
	}

	// Token: 0x0600055B RID: 1371 RVA: 0x0002CECC File Offset: 0x0002B0CC
	public void Update()
	{
		if (!this.m_IsCreditCardMode)
		{
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha1) || Input.GetKeyUp(KeyCode.Keypad1))
		{
			this.OnPressNumber(1);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha2) || Input.GetKeyUp(KeyCode.Keypad2))
		{
			this.OnPressNumber(2);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha3) || Input.GetKeyUp(KeyCode.Keypad3))
		{
			this.OnPressNumber(3);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha4) || Input.GetKeyUp(KeyCode.Keypad4))
		{
			this.OnPressNumber(4);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha5) || Input.GetKeyUp(KeyCode.Keypad5))
		{
			this.OnPressNumber(5);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha6) || Input.GetKeyUp(KeyCode.Keypad6))
		{
			this.OnPressNumber(6);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha7) || Input.GetKeyUp(KeyCode.Keypad7))
		{
			this.OnPressNumber(7);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha8) || Input.GetKeyUp(KeyCode.Keypad8))
		{
			this.OnPressNumber(8);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha9) || Input.GetKeyUp(KeyCode.Keypad9))
		{
			this.OnPressNumber(9);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Alpha0) || Input.GetKeyUp(KeyCode.Keypad0))
		{
			this.OnPressNumber(0);
			return;
		}
		if (Input.GetKeyUp(KeyCode.Period) || Input.GetKeyUp(KeyCode.KeypadPeriod) || Input.GetKeyUp(KeyCode.Comma))
		{
			this.OnPressDecimalBtn();
			return;
		}
		if (Input.GetKeyUp(KeyCode.Backspace))
		{
			this.OnPressBackBtn();
			return;
		}
		if (Input.GetKeyUp(KeyCode.KeypadEnter) || Input.GetKeyUp(KeyCode.Return) || InputManager.GetKeyUpAction(EGameAction.DoneCounter))
		{
			this.OnPressConfirmBtn();
		}
	}

	// Token: 0x0600055C RID: 1372 RVA: 0x0002D060 File Offset: 0x0002B260
	public void OnPressNumber(int number)
	{
		if (!this.m_IsCreditCardMode)
		{
			return;
		}
		if (!this.m_HasPressedDecimal && this.m_CurrentNumberValue > 100000f)
		{
			return;
		}
		if (!this.m_HasPressedDecimal)
		{
			this.m_CurrentNumberValue = this.m_CurrentNumberValue * 10f + (float)number;
		}
		else if (this.m_CurrentDecimalPoint == 0)
		{
			this.m_CurrentNumberValue += (float)number * 0.1f;
			this.m_CurrentDecimalPoint++;
		}
		else if (this.m_CurrentDecimalPoint == 1)
		{
			this.m_CurrentNumberValue += (float)number * 0.01f;
			this.m_CurrentDecimalPoint++;
		}
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_CurrentNumberValue / GameInstance.GetCurrencyConversionRate(), false, true, false, "F2");
		SoundManager.PlayAudio("SFX_CheckoutCardPress", 0.2f, 1f);
	}

	// Token: 0x0600055D RID: 1373 RVA: 0x0002D13C File Offset: 0x0002B33C
	public void OnPressDecimalBtn()
	{
		if (!this.m_IsCreditCardMode)
		{
			return;
		}
		if (!GameInstance.GetCurrencyHasDecimal(CSingleton<CGameManager>.Instance.m_CurrencyType))
		{
			return;
		}
		if (!this.m_HasPressedDecimal)
		{
			this.m_HasPressedDecimal = true;
		}
		SoundManager.PlayAudio("SFX_CheckoutCardPress", 0.2f, 1f);
	}

	// Token: 0x0600055E RID: 1374 RVA: 0x0002D17C File Offset: 0x0002B37C
	public void OnPressBackBtn()
	{
		if (!this.m_IsCreditCardMode)
		{
			return;
		}
		if (!this.m_HasPressedDecimal || this.m_CurrentDecimalPoint == 0)
		{
			this.m_HasPressedDecimal = false;
			this.m_CurrentNumberValue = (float)Mathf.FloorToInt(this.m_CurrentNumberValue / 10f);
		}
		else if (this.m_CurrentDecimalPoint == 0)
		{
			this.m_HasPressedDecimal = false;
			this.m_CurrentDecimalPoint = 0;
		}
		else if (this.m_CurrentDecimalPoint == 1)
		{
			this.m_CurrentNumberValue = (float)Mathf.FloorToInt(this.m_CurrentNumberValue);
			this.m_CurrentDecimalPoint--;
		}
		else if (this.m_CurrentDecimalPoint == 2)
		{
			this.m_CurrentNumberValue = (float)Mathf.FloorToInt(this.m_CurrentNumberValue * 10f) / 10f;
			this.m_CurrentDecimalPoint--;
		}
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_CurrentNumberValue / GameInstance.GetCurrencyConversionRate(), false, true, false, "F2");
		SoundManager.PlayAudio("SFX_CheckoutCardPress", 0.2f, 1f);
	}

	// Token: 0x0600055F RID: 1375 RVA: 0x0002D273 File Offset: 0x0002B473
	public void OnPressConfirmBtn()
	{
		if (!this.m_IsCreditCardMode)
		{
			return;
		}
		this.m_CashierCounter.EvaluateCreditCard(this.m_CurrentNumberValue / GameInstance.GetCurrencyConversionRate());
		SoundManager.PlayAudio("SFX_CheckoutCardPress", 0.2f, 1f);
	}

	// Token: 0x06000560 RID: 1376 RVA: 0x0002D2A9 File Offset: 0x0002B4A9
	public void SetCashierCounter(InteractableCashierCounter cashierCounter)
	{
		this.m_CashierCounter = cashierCounter;
	}

	// Token: 0x06000561 RID: 1377 RVA: 0x0002D2B2 File Offset: 0x0002B4B2
	public void EnableCreditCardMode(bool isPlayer)
	{
		this.m_IsCreditCardMode = isPlayer;
		if (isPlayer)
		{
			ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension);
			this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_CurrentNumberValue, false, true, false, "F2");
		}
	}

	// Token: 0x06000562 RID: 1378 RVA: 0x0002D2E8 File Offset: 0x0002B4E8
	public void ResetCounter()
	{
		if (this.m_IsCreditCardMode)
		{
			ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
		}
		this.m_IsCreditCardMode = false;
		this.m_HasPressedDecimal = false;
		this.m_CurrentDecimalPoint = 0;
		this.m_CurrentNumberValue = 0f;
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_CurrentNumberValue, false, true, false, "F2");
	}

	// Token: 0x0400070B RID: 1803
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x0400070C RID: 1804
	public FollowObject m_FollowObject;

	// Token: 0x0400070D RID: 1805
	public TextMeshProUGUI m_TotalPriceText;

	// Token: 0x0400070E RID: 1806
	private int m_CurrentDecimalPoint;

	// Token: 0x0400070F RID: 1807
	private float m_CurrentNumberValue;

	// Token: 0x04000710 RID: 1808
	private bool m_HasPressedDecimal;

	// Token: 0x04000711 RID: 1809
	private bool m_IsCreditCardMode;

	// Token: 0x04000712 RID: 1810
	private InteractableCashierCounter m_CashierCounter;
}
