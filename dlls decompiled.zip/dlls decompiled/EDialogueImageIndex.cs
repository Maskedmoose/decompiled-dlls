﻿using System;

// Token: 0x020000F8 RID: 248
public enum EDialogueImageIndex
{
	// Token: 0x04000D9A RID: 3482
	None,
	// Token: 0x04000D9B RID: 3483
	RobotProxy
}
