﻿using System;
using UnityEngine;

// Token: 0x02000081 RID: 129
public class UIElementBase : MonoBehaviour
{
	// Token: 0x06000518 RID: 1304 RVA: 0x0002BAB4 File Offset: 0x00029CB4
	public void SetActive(bool isActive)
	{
		this.m_IsActive = isActive;
		this.m_TopUIGrp.SetActive(isActive);
	}

	// Token: 0x06000519 RID: 1305 RVA: 0x0002BAC9 File Offset: 0x00029CC9
	public virtual void OnPressButton()
	{
	}

	// Token: 0x0600051A RID: 1306 RVA: 0x0002BACB File Offset: 0x00029CCB
	public bool IsActive()
	{
		return this.m_IsActive;
	}

	// Token: 0x040006BE RID: 1726
	public GameObject m_TopUIGrp;

	// Token: 0x040006BF RID: 1727
	public GameObject m_UIGrp;

	// Token: 0x040006C0 RID: 1728
	protected bool m_IsActive = true;
}
