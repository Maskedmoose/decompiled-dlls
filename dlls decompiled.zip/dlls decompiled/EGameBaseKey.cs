﻿using System;

// Token: 0x02000119 RID: 281
public enum EGameBaseKey
{
	// Token: 0x04000F80 RID: 3968
	None,
	// Token: 0x04000F81 RID: 3969
	LeftMouseClick,
	// Token: 0x04000F82 RID: 3970
	LeftMouseHold,
	// Token: 0x04000F83 RID: 3971
	RightMouseClick,
	// Token: 0x04000F84 RID: 3972
	RightMouseHold,
	// Token: 0x04000F85 RID: 3973
	MiddleMouseScroll,
	// Token: 0x04000F86 RID: 3974
	MiddleMouseClick,
	// Token: 0x04000F87 RID: 3975
	MiddleMouseHold,
	// Token: 0x04000F88 RID: 3976
	F,
	// Token: 0x04000F89 RID: 3977
	R,
	// Token: 0x04000F8A RID: 3978
	Q,
	// Token: 0x04000F8B RID: 3979
	E,
	// Token: 0x04000F8C RID: 3980
	Escape,
	// Token: 0x04000F8D RID: 3981
	Enter,
	// Token: 0x04000F8E RID: 3982
	Spacebar,
	// Token: 0x04000F8F RID: 3983
	A,
	// Token: 0x04000F90 RID: 3984
	W,
	// Token: 0x04000F91 RID: 3985
	S,
	// Token: 0x04000F92 RID: 3986
	D,
	// Token: 0x04000F93 RID: 3987
	Backspace,
	// Token: 0x04000F94 RID: 3988
	C,
	// Token: 0x04000F95 RID: 3989
	Tab,
	// Token: 0x04000F96 RID: 3990
	Shift,
	// Token: 0x04000F97 RID: 3991
	UpArrow,
	// Token: 0x04000F98 RID: 3992
	DownArrow,
	// Token: 0x04000F99 RID: 3993
	LeftArrow,
	// Token: 0x04000F9A RID: 3994
	RightArrow,
	// Token: 0x04000F9B RID: 3995
	JStick_Confirm,
	// Token: 0x04000F9C RID: 3996
	JStick_Cancel,
	// Token: 0x04000F9D RID: 3997
	JStick_Square,
	// Token: 0x04000F9E RID: 3998
	JStick_Triangle,
	// Token: 0x04000F9F RID: 3999
	JStick_L1,
	// Token: 0x04000FA0 RID: 4000
	JStick_R1,
	// Token: 0x04000FA1 RID: 4001
	JStick_L2,
	// Token: 0x04000FA2 RID: 4002
	JStick_R2,
	// Token: 0x04000FA3 RID: 4003
	JStick_DPad_L,
	// Token: 0x04000FA4 RID: 4004
	JStick_DPad_R,
	// Token: 0x04000FA5 RID: 4005
	JStick_DPad_Up,
	// Token: 0x04000FA6 RID: 4006
	JStick_DPad_Down,
	// Token: 0x04000FA7 RID: 4007
	RotateL,
	// Token: 0x04000FA8 RID: 4008
	RotateR
}
