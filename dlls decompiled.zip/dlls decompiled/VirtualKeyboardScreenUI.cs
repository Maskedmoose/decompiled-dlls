﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000114 RID: 276
public class VirtualKeyboardScreenUI : UIScreenBase
{
	// Token: 0x06000814 RID: 2068 RVA: 0x0003C2AC File Offset: 0x0003A4AC
	protected override void Awake()
	{
		base.Awake();
		for (int i = 0; i < this.m_VirtualKeyboardBtnKeyList.Count; i++)
		{
			this.m_VirtualKeyboardBtnKeyList[i].Init(this);
		}
	}

	// Token: 0x06000815 RID: 2069 RVA: 0x0003C2E8 File Offset: 0x0003A4E8
	protected override void RunUpdate()
	{
		base.RunUpdate();
		this.m_Timer += Time.deltaTime;
		if (this.m_Timer >= 1f)
		{
			this.m_Timer = 0f;
			this.m_ShowLineCursor = !this.m_ShowLineCursor;
			this.UpdateOutputText();
		}
	}

	// Token: 0x06000816 RID: 2070 RVA: 0x0003C33C File Offset: 0x0003A53C
	private void UpdateOutputText()
	{
		if (this.m_ShowLineCursor)
		{
			this.m_OutputShowText.text = this.m_CurrentString + "|";
			return;
		}
		this.m_OutputShowText.text = this.m_CurrentString + "<alpha=#00>|</color>";
	}

	// Token: 0x06000817 RID: 2071 RVA: 0x0003C388 File Offset: 0x0003A588
	public void SetInitialText(string text, TMP_InputField inputText)
	{
		this.m_InputText = inputText;
		this.m_CurrentString = text;
		this.UpdateOutputText();
	}

	// Token: 0x06000818 RID: 2072 RVA: 0x0003C39E File Offset: 0x0003A59E
	public void OnPressButton(string text)
	{
		if (this.m_CurrentString.Length >= this.m_MaxLength)
		{
			return;
		}
		this.m_CurrentString += text;
		this.UpdateOutputText();
	}

	// Token: 0x06000819 RID: 2073 RVA: 0x0003C3CC File Offset: 0x0003A5CC
	public void OnPressBackKey()
	{
		if (this.m_CurrentString.Length > 0)
		{
			this.m_CurrentString = this.m_CurrentString.Remove(this.m_CurrentString.Length - 1, 1);
			this.UpdateOutputText();
		}
	}

	// Token: 0x0600081A RID: 2074 RVA: 0x0003C401 File Offset: 0x0003A601
	public void OnPressCapitalKey()
	{
		this.ToggleAltActive();
	}

	// Token: 0x0600081B RID: 2075 RVA: 0x0003C409 File Offset: 0x0003A609
	public void OnPressDoneKey()
	{
		this.m_InputText.text = this.m_CurrentString;
		this.m_InputText.onEndEdit.Invoke(this.m_CurrentString);
		base.CloseScreen();
	}

	// Token: 0x0600081C RID: 2076 RVA: 0x0003C438 File Offset: 0x0003A638
	public void OnPressSpaceKey()
	{
		if (this.m_CurrentString.Length >= this.m_MaxLength)
		{
			return;
		}
		this.m_CurrentString += " ";
		this.UpdateOutputText();
	}

	// Token: 0x0600081D RID: 2077 RVA: 0x0003C46C File Offset: 0x0003A66C
	public void ToggleAltActive()
	{
		this.m_IsAltActive = !this.m_IsAltActive;
		for (int i = 0; i < this.m_VirtualKeyboardBtnKeyList.Count; i++)
		{
			this.m_VirtualKeyboardBtnKeyList[i].EvaluateKey();
		}
	}

	// Token: 0x04000F55 RID: 3925
	public TextMeshProUGUI m_OutputShowText;

	// Token: 0x04000F56 RID: 3926
	private TMP_InputField m_InputText;

	// Token: 0x04000F57 RID: 3927
	public List<VirtualKeyboardBtnKey> m_VirtualKeyboardBtnKeyList;

	// Token: 0x04000F58 RID: 3928
	public bool m_IsAltActive;

	// Token: 0x04000F59 RID: 3929
	private bool m_ShowLineCursor;

	// Token: 0x04000F5A RID: 3930
	private int m_MaxLength = 30;

	// Token: 0x04000F5B RID: 3931
	private float m_Timer;

	// Token: 0x04000F5C RID: 3932
	private string m_CurrentString = "";
}
