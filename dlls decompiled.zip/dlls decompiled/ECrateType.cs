﻿using System;

// Token: 0x020000F3 RID: 243
public enum ECrateType
{
	// Token: 0x04000D6D RID: 3437
	None,
	// Token: 0x04000D6E RID: 3438
	Training,
	// Token: 0x04000D6F RID: 3439
	Normal,
	// Token: 0x04000D70 RID: 3440
	Super,
	// Token: 0x04000D71 RID: 3441
	SuperL,
	// Token: 0x04000D72 RID: 3442
	Mega,
	// Token: 0x04000D73 RID: 3443
	Legendary,
	// Token: 0x04000D74 RID: 3444
	Ultra,
	// Token: 0x04000D75 RID: 3445
	DailyKO
}
