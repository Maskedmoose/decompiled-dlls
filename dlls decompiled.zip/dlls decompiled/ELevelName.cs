﻿using System;

// Token: 0x020000D6 RID: 214
public enum ELevelName
{
	// Token: 0x04000984 RID: 2436
	Start
}
