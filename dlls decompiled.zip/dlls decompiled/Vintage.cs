﻿using System;
using UnityEngine;

// Token: 0x0200014E RID: 334
[ExecuteInEditMode]
public class Vintage : MonoBehaviour
{
	// Token: 0x17000035 RID: 53
	// (get) Token: 0x06000973 RID: 2419 RVA: 0x00044B45 File Offset: 0x00042D45
	private Material material
	{
		get
		{
			if (this.curMaterial == null)
			{
				this.curMaterial = new Material(this.curShader);
				this.curMaterial.hideFlags = HideFlags.HideAndDontSave;
			}
			return this.curMaterial;
		}
	}

	// Token: 0x06000974 RID: 2420 RVA: 0x00044B79 File Offset: 0x00042D79
	private void Start()
	{
		if (!SystemInfo.supportsImageEffects)
		{
			base.enabled = false;
			return;
		}
		this.curShader = Shader.Find("Custom/Vintage");
	}

	// Token: 0x06000975 RID: 2421 RVA: 0x00044B9C File Offset: 0x00042D9C
	private void OnRenderImage(RenderTexture sourceTexture, RenderTexture destTexture)
	{
		if (this.curShader != null)
		{
			this.material.SetFloat("_YellowLevel", this.YellowLevel);
			this.material.SetFloat("_CyanLevel", this.CyanLevel);
			this.material.SetFloat("_MagentaLevel", this.MagentaLevel);
			this.material.SetColor("_Yellow", this.Yellow);
			this.material.SetColor("_Cyan", this.Cyan);
			this.material.SetColor("_Magenta", this.Magenta);
			Graphics.Blit(sourceTexture, destTexture, this.material);
			return;
		}
		Graphics.Blit(sourceTexture, destTexture);
	}

	// Token: 0x06000976 RID: 2422 RVA: 0x00044C53 File Offset: 0x00042E53
	private void Update()
	{
	}

	// Token: 0x06000977 RID: 2423 RVA: 0x00044C55 File Offset: 0x00042E55
	private void OnDisable()
	{
		if (this.curMaterial)
		{
			Object.DestroyImmediate(this.curMaterial);
		}
	}

	// Token: 0x040011B9 RID: 4537
	private Shader curShader;

	// Token: 0x040011BA RID: 4538
	private Color Yellow = Color.yellow;

	// Token: 0x040011BB RID: 4539
	private Color Cyan = Color.cyan;

	// Token: 0x040011BC RID: 4540
	private Color Magenta = Color.magenta;

	// Token: 0x040011BD RID: 4541
	public float YellowLevel = 0.01f;

	// Token: 0x040011BE RID: 4542
	public float CyanLevel = 0.03f;

	// Token: 0x040011BF RID: 4543
	public float MagentaLevel = 0.04f;

	// Token: 0x040011C0 RID: 4544
	private Material curMaterial;
}
