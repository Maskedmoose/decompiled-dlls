﻿using System;

// Token: 0x020000EC RID: 236
public enum EMonsterRole
{
	// Token: 0x04000D28 RID: 3368
	PhysicalAttacker,
	// Token: 0x04000D29 RID: 3369
	Defender,
	// Token: 0x04000D2A RID: 3370
	Support,
	// Token: 0x04000D2B RID: 3371
	Healer,
	// Token: 0x04000D2C RID: 3372
	MagicalAttacker,
	// Token: 0x04000D2D RID: 3373
	AllRounder,
	// Token: 0x04000D2E RID: 3374
	Disruptor
}
