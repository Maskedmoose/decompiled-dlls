﻿using System;
using System.Collections.Generic;

// Token: 0x0200004E RID: 78
[Serializable]
public class AutoCleanserSaveData
{
	// Token: 0x04000459 RID: 1113
	public bool isNeedRefill;

	// Token: 0x0400045A RID: 1114
	public bool isTurnedOn;

	// Token: 0x0400045B RID: 1115
	public int itemAmount;

	// Token: 0x0400045C RID: 1116
	public List<float> contentFillList;

	// Token: 0x0400045D RID: 1117
	public Vector3Serializer pos;

	// Token: 0x0400045E RID: 1118
	public QuaternionSerializer rot;

	// Token: 0x0400045F RID: 1119
	public bool isBoxed;

	// Token: 0x04000460 RID: 1120
	public Vector3Serializer boxedPackagePos;

	// Token: 0x04000461 RID: 1121
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x04000462 RID: 1122
	public EObjectType objectType;
}
