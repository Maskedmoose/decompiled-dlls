﻿using System;

namespace CMF
{
	// Token: 0x020001EC RID: 492
	public static class PlayerData
	{
		// Token: 0x040014AC RID: 5292
		public static int controllerIndex = 0;

		// Token: 0x040014AD RID: 5293
		public static bool enableShadows = true;
	}
}
