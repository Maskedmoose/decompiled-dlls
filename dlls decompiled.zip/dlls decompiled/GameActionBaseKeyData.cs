﻿using System;
using I2.Loc;

// Token: 0x02000118 RID: 280
[Serializable]
public class GameActionBaseKeyData
{
	// Token: 0x06000821 RID: 2081 RVA: 0x0003C4DA File Offset: 0x0003A6DA
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.actionName, true, 0, true, false, null, null, true);
	}

	// Token: 0x04000F7C RID: 3964
	public string actionName;

	// Token: 0x04000F7D RID: 3965
	public EGameAction gameAction;

	// Token: 0x04000F7E RID: 3966
	public EGameBaseKey baseKey;
}
