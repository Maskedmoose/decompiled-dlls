﻿using System;

// Token: 0x020000EB RID: 235
public enum EMonsterType
{
	// Token: 0x04000BDA RID: 3034
	EarlyPlayer = -1,
	// Token: 0x04000BDB RID: 3035
	None,
	// Token: 0x04000BDC RID: 3036
	PiggyA,
	// Token: 0x04000BDD RID: 3037
	PiggyB,
	// Token: 0x04000BDE RID: 3038
	PiggyC,
	// Token: 0x04000BDF RID: 3039
	PiggyD,
	// Token: 0x04000BE0 RID: 3040
	FoxA,
	// Token: 0x04000BE1 RID: 3041
	FoxB,
	// Token: 0x04000BE2 RID: 3042
	FoxC,
	// Token: 0x04000BE3 RID: 3043
	FoxD,
	// Token: 0x04000BE4 RID: 3044
	GolemA,
	// Token: 0x04000BE5 RID: 3045
	GolemB,
	// Token: 0x04000BE6 RID: 3046
	GolemC,
	// Token: 0x04000BE7 RID: 3047
	GolemD,
	// Token: 0x04000BE8 RID: 3048
	TreeA,
	// Token: 0x04000BE9 RID: 3049
	TreeB,
	// Token: 0x04000BEA RID: 3050
	TreeC,
	// Token: 0x04000BEB RID: 3051
	TreeD,
	// Token: 0x04000BEC RID: 3052
	StarfishA,
	// Token: 0x04000BED RID: 3053
	StarfishB,
	// Token: 0x04000BEE RID: 3054
	StarfishC,
	// Token: 0x04000BEF RID: 3055
	StarfishD,
	// Token: 0x04000BF0 RID: 3056
	ShellyA,
	// Token: 0x04000BF1 RID: 3057
	ShellyB,
	// Token: 0x04000BF2 RID: 3058
	ShellyC,
	// Token: 0x04000BF3 RID: 3059
	ShellyD,
	// Token: 0x04000BF4 RID: 3060
	BugA,
	// Token: 0x04000BF5 RID: 3061
	BugB,
	// Token: 0x04000BF6 RID: 3062
	BugC,
	// Token: 0x04000BF7 RID: 3063
	BugD,
	// Token: 0x04000BF8 RID: 3064
	BatA,
	// Token: 0x04000BF9 RID: 3065
	BatB,
	// Token: 0x04000BFA RID: 3066
	BatC,
	// Token: 0x04000BFB RID: 3067
	BatD,
	// Token: 0x04000BFC RID: 3068
	Skull,
	// Token: 0x04000BFD RID: 3069
	Beetle,
	// Token: 0x04000BFE RID: 3070
	Bear,
	// Token: 0x04000BFF RID: 3071
	Jellyfish,
	// Token: 0x04000C00 RID: 3072
	Wisp,
	// Token: 0x04000C01 RID: 3073
	MummyMan,
	// Token: 0x04000C02 RID: 3074
	FlowerA,
	// Token: 0x04000C03 RID: 3075
	FlowerB,
	// Token: 0x04000C04 RID: 3076
	FlowerC,
	// Token: 0x04000C05 RID: 3077
	FlowerD,
	// Token: 0x04000C06 RID: 3078
	WeirdBirdA,
	// Token: 0x04000C07 RID: 3079
	FireSpirit,
	// Token: 0x04000C08 RID: 3080
	Angez,
	// Token: 0x04000C09 RID: 3081
	Mosquito,
	// Token: 0x04000C0A RID: 3082
	HydraA,
	// Token: 0x04000C0B RID: 3083
	HydraB,
	// Token: 0x04000C0C RID: 3084
	HydraC,
	// Token: 0x04000C0D RID: 3085
	HydraD,
	// Token: 0x04000C0E RID: 3086
	DragonFire,
	// Token: 0x04000C0F RID: 3087
	DragonEarth,
	// Token: 0x04000C10 RID: 3088
	DragonWater,
	// Token: 0x04000C11 RID: 3089
	DragonThunder,
	// Token: 0x04000C12 RID: 3090
	Turtle,
	// Token: 0x04000C13 RID: 3091
	FireWolfA,
	// Token: 0x04000C14 RID: 3092
	FireWolfB,
	// Token: 0x04000C15 RID: 3093
	FireWolfC,
	// Token: 0x04000C16 RID: 3094
	FireWolfD,
	// Token: 0x04000C17 RID: 3095
	FishA,
	// Token: 0x04000C18 RID: 3096
	FishB,
	// Token: 0x04000C19 RID: 3097
	FishC,
	// Token: 0x04000C1A RID: 3098
	FishD,
	// Token: 0x04000C1B RID: 3099
	HalloweenA,
	// Token: 0x04000C1C RID: 3100
	HalloweenB,
	// Token: 0x04000C1D RID: 3101
	HalloweenC,
	// Token: 0x04000C1E RID: 3102
	HalloweenD,
	// Token: 0x04000C1F RID: 3103
	TronA,
	// Token: 0x04000C20 RID: 3104
	TronB,
	// Token: 0x04000C21 RID: 3105
	TronC,
	// Token: 0x04000C22 RID: 3106
	TronD,
	// Token: 0x04000C23 RID: 3107
	LobsterA,
	// Token: 0x04000C24 RID: 3108
	LobsterB,
	// Token: 0x04000C25 RID: 3109
	LobsterC,
	// Token: 0x04000C26 RID: 3110
	LobsterD,
	// Token: 0x04000C27 RID: 3111
	FireBirdA,
	// Token: 0x04000C28 RID: 3112
	FireBirdB,
	// Token: 0x04000C29 RID: 3113
	FireBirdC,
	// Token: 0x04000C2A RID: 3114
	SerpentA,
	// Token: 0x04000C2B RID: 3115
	SerpentB,
	// Token: 0x04000C2C RID: 3116
	SerpentC,
	// Token: 0x04000C2D RID: 3117
	CloudA,
	// Token: 0x04000C2E RID: 3118
	CloudB,
	// Token: 0x04000C2F RID: 3119
	CloudC,
	// Token: 0x04000C30 RID: 3120
	EmeraldA,
	// Token: 0x04000C31 RID: 3121
	EmeraldB,
	// Token: 0x04000C32 RID: 3122
	EmeraldC,
	// Token: 0x04000C33 RID: 3123
	Crystalmon,
	// Token: 0x04000C34 RID: 3124
	ElecDragon,
	// Token: 0x04000C35 RID: 3125
	CrabA,
	// Token: 0x04000C36 RID: 3126
	CrabB,
	// Token: 0x04000C37 RID: 3127
	FireUmbrellaDragon,
	// Token: 0x04000C38 RID: 3128
	Lanternmon,
	// Token: 0x04000C39 RID: 3129
	SeedBugA,
	// Token: 0x04000C3A RID: 3130
	SeedBugB,
	// Token: 0x04000C3B RID: 3131
	SeedBugC,
	// Token: 0x04000C3C RID: 3132
	NinjaBirdA,
	// Token: 0x04000C3D RID: 3133
	NinjaBirdB,
	// Token: 0x04000C3E RID: 3134
	NinjaBirdC,
	// Token: 0x04000C3F RID: 3135
	NinjaBirdD,
	// Token: 0x04000C40 RID: 3136
	NinjaCrowC,
	// Token: 0x04000C41 RID: 3137
	NinjaCrowD,
	// Token: 0x04000C42 RID: 3138
	MuffinTreeA,
	// Token: 0x04000C43 RID: 3139
	MuffinTreeB,
	// Token: 0x04000C44 RID: 3140
	MuffinTreeC,
	// Token: 0x04000C45 RID: 3141
	SharkFishA,
	// Token: 0x04000C46 RID: 3142
	SharkFishB,
	// Token: 0x04000C47 RID: 3143
	SharkFishC,
	// Token: 0x04000C48 RID: 3144
	FireGeckoA,
	// Token: 0x04000C49 RID: 3145
	FireGeckoB,
	// Token: 0x04000C4A RID: 3146
	EarthDino,
	// Token: 0x04000C4B RID: 3147
	SlimeA,
	// Token: 0x04000C4C RID: 3148
	SlimeB,
	// Token: 0x04000C4D RID: 3149
	SlimeC,
	// Token: 0x04000C4E RID: 3150
	SlimeD,
	// Token: 0x04000C4F RID: 3151
	SeahorseA,
	// Token: 0x04000C50 RID: 3152
	SeahorseB,
	// Token: 0x04000C51 RID: 3153
	SeahorseC,
	// Token: 0x04000C52 RID: 3154
	SeahorseD,
	// Token: 0x04000C53 RID: 3155
	FireChickenA,
	// Token: 0x04000C54 RID: 3156
	FireChickenB,
	// Token: 0x04000C55 RID: 3157
	MAX,
	// Token: 0x04000C56 RID: 3158
	START_MEGABOT = -1000,
	// Token: 0x04000C57 RID: 3159
	Alpha = 1000,
	// Token: 0x04000C58 RID: 3160
	Beta,
	// Token: 0x04000C59 RID: 3161
	Gamma,
	// Token: 0x04000C5A RID: 3162
	Ronin,
	// Token: 0x04000C5B RID: 3163
	Bumblebee,
	// Token: 0x04000C5C RID: 3164
	Orca,
	// Token: 0x04000C5D RID: 3165
	Garuda,
	// Token: 0x04000C5E RID: 3166
	Viper,
	// Token: 0x04000C5F RID: 3167
	Blitz,
	// Token: 0x04000C60 RID: 3168
	Cylops,
	// Token: 0x04000C61 RID: 3169
	Kabuto,
	// Token: 0x04000C62 RID: 3170
	Minotaur,
	// Token: 0x04000C63 RID: 3171
	Spectre,
	// Token: 0x04000C64 RID: 3172
	Wolf,
	// Token: 0x04000C65 RID: 3173
	Bolt,
	// Token: 0x04000C66 RID: 3174
	Hawk,
	// Token: 0x04000C67 RID: 3175
	Cyber,
	// Token: 0x04000C68 RID: 3176
	Space,
	// Token: 0x04000C69 RID: 3177
	Hangar,
	// Token: 0x04000C6A RID: 3178
	Arena,
	// Token: 0x04000C6B RID: 3179
	UndergroundDark,
	// Token: 0x04000C6C RID: 3180
	UndergroundLight,
	// Token: 0x04000C6D RID: 3181
	RoninBoss,
	// Token: 0x04000C6E RID: 3182
	OrcaBoss,
	// Token: 0x04000C6F RID: 3183
	GarudaBoss,
	// Token: 0x04000C70 RID: 3184
	ViperBoss,
	// Token: 0x04000C71 RID: 3185
	Max,
	// Token: 0x04000C72 RID: 3186
	Shockwave,
	// Token: 0x04000C73 RID: 3187
	Tremor,
	// Token: 0x04000C74 RID: 3188
	Rhino,
	// Token: 0x04000C75 RID: 3189
	RoninArt,
	// Token: 0x04000C76 RID: 3190
	GarudaArt,
	// Token: 0x04000C77 RID: 3191
	MaxArt,
	// Token: 0x04000C78 RID: 3192
	MinotaurArt,
	// Token: 0x04000C79 RID: 3193
	WolfArt,
	// Token: 0x04000C7A RID: 3194
	SkullArt,
	// Token: 0x04000C7B RID: 3195
	OrcaAlt,
	// Token: 0x04000C7C RID: 3196
	GarudaAlt,
	// Token: 0x04000C7D RID: 3197
	ViperAlt,
	// Token: 0x04000C7E RID: 3198
	KabutoAlt,
	// Token: 0x04000C7F RID: 3199
	Neon,
	// Token: 0x04000C80 RID: 3200
	Pulse,
	// Token: 0x04000C81 RID: 3201
	Raptor,
	// Token: 0x04000C82 RID: 3202
	AncientHammer,
	// Token: 0x04000C83 RID: 3203
	ArcMissile,
	// Token: 0x04000C84 RID: 3204
	Axe,
	// Token: 0x04000C85 RID: 3205
	BarrageMissle,
	// Token: 0x04000C86 RID: 3206
	BarrelHammer,
	// Token: 0x04000C87 RID: 3207
	BattleChip,
	// Token: 0x04000C88 RID: 3208
	BoxingGlove,
	// Token: 0x04000C89 RID: 3209
	ChainGun,
	// Token: 0x04000C8A RID: 3210
	ChillMissile,
	// Token: 0x04000C8B RID: 3211
	ColdShoulder,
	// Token: 0x04000C8C RID: 3212
	CrescentClaw,
	// Token: 0x04000C8D RID: 3213
	CrescentMachete,
	// Token: 0x04000C8E RID: 3214
	CrimsonWheel,
	// Token: 0x04000C8F RID: 3215
	CryoBlaster,
	// Token: 0x04000C90 RID: 3216
	Drill,
	// Token: 0x04000C91 RID: 3217
	DualMissile,
	// Token: 0x04000C92 RID: 3218
	ElecBroadsword,
	// Token: 0x04000C93 RID: 3219
	ElectricChainsaw,
	// Token: 0x04000C94 RID: 3220
	ElectricSpike,
	// Token: 0x04000C95 RID: 3221
	EnergyShield,
	// Token: 0x04000C96 RID: 3222
	FanBlade,
	// Token: 0x04000C97 RID: 3223
	FeatherBlade,
	// Token: 0x04000C98 RID: 3224
	FireAxe,
	// Token: 0x04000C99 RID: 3225
	FireBroadsword,
	// Token: 0x04000C9A RID: 3226
	FireKatana,
	// Token: 0x04000C9B RID: 3227
	FireRocket,
	// Token: 0x04000C9C RID: 3228
	FireShield,
	// Token: 0x04000C9D RID: 3229
	FireTwinAxe,
	// Token: 0x04000C9E RID: 3230
	Flamethrower,
	// Token: 0x04000C9F RID: 3231
	FreezeBomb,
	// Token: 0x04000CA0 RID: 3232
	GigaBlade,
	// Token: 0x04000CA1 RID: 3233
	GigaCannon,
	// Token: 0x04000CA2 RID: 3234
	GreatCleaver,
	// Token: 0x04000CA3 RID: 3235
	HeatKnife,
	// Token: 0x04000CA4 RID: 3236
	HeatMissile,
	// Token: 0x04000CA5 RID: 3237
	IceBroadsword,
	// Token: 0x04000CA6 RID: 3238
	IceMortar,
	// Token: 0x04000CA7 RID: 3239
	IcePike,
	// Token: 0x04000CA8 RID: 3240
	IceSpinner,
	// Token: 0x04000CA9 RID: 3241
	IceTwinSpear,
	// Token: 0x04000CAA RID: 3242
	InfernoBoost,
	// Token: 0x04000CAB RID: 3243
	IronBall,
	// Token: 0x04000CAC RID: 3244
	JetBurner,
	// Token: 0x04000CAD RID: 3245
	Katana,
	// Token: 0x04000CAE RID: 3246
	KnightShield,
	// Token: 0x04000CAF RID: 3247
	KnightSword,
	// Token: 0x04000CB0 RID: 3248
	LightSaber,
	// Token: 0x04000CB1 RID: 3249
	LionShield,
	// Token: 0x04000CB2 RID: 3250
	MagneticCoil,
	// Token: 0x04000CB3 RID: 3251
	MaulerMace,
	// Token: 0x04000CB4 RID: 3252
	MegavoltBeam,
	// Token: 0x04000CB5 RID: 3253
	MiniMissile,
	// Token: 0x04000CB6 RID: 3254
	MissileCannon,
	// Token: 0x04000CB7 RID: 3255
	MoonlightBlade,
	// Token: 0x04000CB8 RID: 3256
	MorningStar,
	// Token: 0x04000CB9 RID: 3257
	Mortar,
	// Token: 0x04000CBA RID: 3258
	PulseCannon,
	// Token: 0x04000CBB RID: 3259
	RailCannon,
	// Token: 0x04000CBC RID: 3260
	Ravager,
	// Token: 0x04000CBD RID: 3261
	RocketMissile,
	// Token: 0x04000CBE RID: 3262
	RollerSpike,
	// Token: 0x04000CBF RID: 3263
	ShurikenBlade,
	// Token: 0x04000CC0 RID: 3264
	SonicBlaster,
	// Token: 0x04000CC1 RID: 3265
	SpikeBall,
	// Token: 0x04000CC2 RID: 3266
	SpikedWarhammer,
	// Token: 0x04000CC3 RID: 3267
	Sword,
	// Token: 0x04000CC4 RID: 3268
	ThorHammer,
	// Token: 0x04000CC5 RID: 3269
	Thunderblade,
	// Token: 0x04000CC6 RID: 3270
	ThunderTwinBlade,
	// Token: 0x04000CC7 RID: 3271
	WingBooster,
	// Token: 0x04000CC8 RID: 3272
	MAX_MEGABOT,
	// Token: 0x04000CC9 RID: 3273
	START_FANTASYRPG = -2000,
	// Token: 0x04000CCA RID: 3274
	Archer = 2000,
	// Token: 0x04000CCB RID: 3275
	ArmoredSlime,
	// Token: 0x04000CCC RID: 3276
	AxeWarrior,
	// Token: 0x04000CCD RID: 3277
	Basilisk,
	// Token: 0x04000CCE RID: 3278
	Blacksmith,
	// Token: 0x04000CCF RID: 3279
	CatMage,
	// Token: 0x04000CD0 RID: 3280
	CatPirate1,
	// Token: 0x04000CD1 RID: 3281
	CatThief,
	// Token: 0x04000CD2 RID: 3282
	Cook,
	// Token: 0x04000CD3 RID: 3283
	DarkKnight,
	// Token: 0x04000CD4 RID: 3284
	Dragon,
	// Token: 0x04000CD5 RID: 3285
	DragonKnight,
	// Token: 0x04000CD6 RID: 3286
	EldritchCreature,
	// Token: 0x04000CD7 RID: 3287
	Farmer,
	// Token: 0x04000CD8 RID: 3288
	Fencer,
	// Token: 0x04000CD9 RID: 3289
	Florist,
	// Token: 0x04000CDA RID: 3290
	GoblinMage,
	// Token: 0x04000CDB RID: 3291
	GoblinThief,
	// Token: 0x04000CDC RID: 3292
	GoblinWarrior,
	// Token: 0x04000CDD RID: 3293
	Golem,
	// Token: 0x04000CDE RID: 3294
	Grandma,
	// Token: 0x04000CDF RID: 3295
	Harpy1,
	// Token: 0x04000CE0 RID: 3296
	Harpy2,
	// Token: 0x04000CE1 RID: 3297
	InkKnight,
	// Token: 0x04000CE2 RID: 3298
	Jester1,
	// Token: 0x04000CE3 RID: 3299
	Jester2,
	// Token: 0x04000CE4 RID: 3300
	King,
	// Token: 0x04000CE5 RID: 3301
	Knight,
	// Token: 0x04000CE6 RID: 3302
	Lamia,
	// Token: 0x04000CE7 RID: 3303
	Mage,
	// Token: 0x04000CE8 RID: 3304
	Mimic1,
	// Token: 0x04000CE9 RID: 3305
	Mimic2,
	// Token: 0x04000CEA RID: 3306
	MushroomMonster,
	// Token: 0x04000CEB RID: 3307
	Noble1,
	// Token: 0x04000CEC RID: 3308
	Noble2,
	// Token: 0x04000CED RID: 3309
	Peasant1,
	// Token: 0x04000CEE RID: 3310
	Peasant2,
	// Token: 0x04000CEF RID: 3311
	Phoenix,
	// Token: 0x04000CF0 RID: 3312
	Queen,
	// Token: 0x04000CF1 RID: 3313
	Reaper,
	// Token: 0x04000CF2 RID: 3314
	Schoolboy1,
	// Token: 0x04000CF3 RID: 3315
	SchoolBoy2,
	// Token: 0x04000CF4 RID: 3316
	Slime,
	// Token: 0x04000CF5 RID: 3317
	Snake,
	// Token: 0x04000CF6 RID: 3318
	Traveller,
	// Token: 0x04000CF7 RID: 3319
	TreeMonster,
	// Token: 0x04000CF8 RID: 3320
	Vampire,
	// Token: 0x04000CF9 RID: 3321
	Witch,
	// Token: 0x04000CFA RID: 3322
	Wizard,
	// Token: 0x04000CFB RID: 3323
	WolfFantasy,
	// Token: 0x04000CFC RID: 3324
	MAX_FANTASYRPG,
	// Token: 0x04000CFD RID: 3325
	START_CATJOB = -3000,
	// Token: 0x04000CFE RID: 3326
	EX0Teacher = 3000,
	// Token: 0x04000CFF RID: 3327
	EX0Detective,
	// Token: 0x04000D00 RID: 3328
	EX0Woodworker,
	// Token: 0x04000D01 RID: 3329
	EX0Plumber,
	// Token: 0x04000D02 RID: 3330
	EX0Electrician,
	// Token: 0x04000D03 RID: 3331
	EX0Soldier,
	// Token: 0x04000D04 RID: 3332
	EX0General,
	// Token: 0x04000D05 RID: 3333
	EX0Police,
	// Token: 0x04000D06 RID: 3334
	EX0Fireman,
	// Token: 0x04000D07 RID: 3335
	EX0Farmer,
	// Token: 0x04000D08 RID: 3336
	EX0Architect,
	// Token: 0x04000D09 RID: 3337
	EX0Construction,
	// Token: 0x04000D0A RID: 3338
	EX0Bodybuilder,
	// Token: 0x04000D0B RID: 3339
	EX0Archer,
	// Token: 0x04000D0C RID: 3340
	EX0Explorer,
	// Token: 0x04000D0D RID: 3341
	EX0Hiker,
	// Token: 0x04000D0E RID: 3342
	EX0Programmer,
	// Token: 0x04000D0F RID: 3343
	EX0Librarian,
	// Token: 0x04000D10 RID: 3344
	EX0Laundry,
	// Token: 0x04000D11 RID: 3345
	EX0Racer,
	// Token: 0x04000D12 RID: 3346
	EX0Florist,
	// Token: 0x04000D13 RID: 3347
	EX0Geologist,
	// Token: 0x04000D14 RID: 3348
	EX0Gamer,
	// Token: 0x04000D15 RID: 3349
	EX0Maid,
	// Token: 0x04000D16 RID: 3350
	EX0Barber,
	// Token: 0x04000D17 RID: 3351
	EX0Bartender,
	// Token: 0x04000D18 RID: 3352
	EX0Bouncer,
	// Token: 0x04000D19 RID: 3353
	EX0Composer,
	// Token: 0x04000D1A RID: 3354
	EX0Director,
	// Token: 0x04000D1B RID: 3355
	EX0Investor,
	// Token: 0x04000D1C RID: 3356
	EX0Singer,
	// Token: 0x04000D1D RID: 3357
	EX0Musician,
	// Token: 0x04000D1E RID: 3358
	EX0Artist,
	// Token: 0x04000D1F RID: 3359
	EX0Photographer,
	// Token: 0x04000D20 RID: 3360
	EX0Lawyer,
	// Token: 0x04000D21 RID: 3361
	EX0Janitor,
	// Token: 0x04000D22 RID: 3362
	EX0Psychic,
	// Token: 0x04000D23 RID: 3363
	EX0Astronaut,
	// Token: 0x04000D24 RID: 3364
	EX0Scout,
	// Token: 0x04000D25 RID: 3365
	EX0Pirate,
	// Token: 0x04000D26 RID: 3366
	MAX_CATJOB
}
