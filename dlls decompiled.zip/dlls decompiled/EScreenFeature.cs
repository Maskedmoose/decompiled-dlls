﻿using System;

// Token: 0x020000F5 RID: 245
public enum EScreenFeature
{
	// Token: 0x04000D7E RID: 3454
	None,
	// Token: 0x04000D7F RID: 3455
	OpenScreen,
	// Token: 0x04000D80 RID: 3456
	CloseScreen,
	// Token: 0x04000D81 RID: 3457
	MainFeature1,
	// Token: 0x04000D82 RID: 3458
	MainFeature2,
	// Token: 0x04000D83 RID: 3459
	SideFeature1,
	// Token: 0x04000D84 RID: 3460
	SideFeature2,
	// Token: 0x04000D85 RID: 3461
	SideFeature3
}
