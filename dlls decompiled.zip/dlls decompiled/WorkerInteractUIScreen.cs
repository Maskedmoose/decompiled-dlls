﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000084 RID: 132
public class WorkerInteractUIScreen : CSingleton<WorkerInteractUIScreen>
{
	// Token: 0x0600053C RID: 1340 RVA: 0x0002C514 File Offset: 0x0002A714
	public static void OpenScreen(Worker worker)
	{
		CSingleton<WorkerInteractUIScreen>.Instance.m_Worker = worker;
		CSingleton<WorkerInteractUIScreen>.Instance.m_CurrentTaskText.text = WorkerManager.GetTaskName(CSingleton<WorkerInteractUIScreen>.Instance.m_Worker.m_WorkerTask);
		CSingleton<WorkerInteractUIScreen>.Instance.m_CheckoutSpeedText.text = CSingleton<WorkerInteractUIScreen>.Instance.m_Worker.GetWorkerData().GetCheckoutSpeedText();
		CSingleton<WorkerInteractUIScreen>.Instance.m_RestockSpeedText.text = CSingleton<WorkerInteractUIScreen>.Instance.m_Worker.GetWorkerData().GetRestockSpeedText();
		CSingleton<WorkerInteractUIScreen>.Instance.m_SalaryCostText.text = CSingleton<WorkerInteractUIScreen>.Instance.m_Worker.GetWorkerData().GetSalaryCostText();
		CSingleton<WorkerInteractUIScreen>.Instance.m_ScreenGrp.SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<WorkerInteractUIScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x0600053D RID: 1341 RVA: 0x0002C5E6 File Offset: 0x0002A7E6
	public void CloseScreen()
	{
		this.m_ScreenGrp.SetActive(false);
		SoundManager.GenericMenuClose(1f, 1f);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<WorkerInteractUIScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x0600053E RID: 1342 RVA: 0x0002C614 File Offset: 0x0002A814
	public void OnPressAssignTask(int taskIndex)
	{
		if (taskIndex == 2)
		{
			this.m_WorkerOptionUIScreen.OpenScreen(this.m_Worker, taskIndex);
			this.CloseScreen();
			return;
		}
		this.m_Worker.SetTask((EWorkerTask)taskIndex);
		this.m_Worker.SetLastTask((EWorkerTask)taskIndex);
		SoundManager.GenericConfirm(1f, 1f);
		this.m_Worker.OnPressStopInteract();
		this.CloseScreen();
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x0002C676 File Offset: 0x0002A876
	public void OnPressFire()
	{
		this.m_Worker.FireWorker();
		SoundManager.GenericConfirm(1f, 1f);
		this.m_Worker.OnPressStopInteract();
		this.CloseScreen();
	}

	// Token: 0x06000540 RID: 1344 RVA: 0x0002C6A3 File Offset: 0x0002A8A3
	public void OnPressCancel()
	{
		this.m_Worker.OnPressStopInteract();
		SoundManager.GenericCancel(1f, 1f);
		this.CloseScreen();
	}

	// Token: 0x040006DF RID: 1759
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040006E0 RID: 1760
	public GameObject m_ScreenGrp;

	// Token: 0x040006E1 RID: 1761
	public WorkerOptionUIScreen m_WorkerOptionUIScreen;

	// Token: 0x040006E2 RID: 1762
	public TextMeshProUGUI m_CurrentTaskText;

	// Token: 0x040006E3 RID: 1763
	public TextMeshProUGUI m_CheckoutSpeedText;

	// Token: 0x040006E4 RID: 1764
	public TextMeshProUGUI m_RestockSpeedText;

	// Token: 0x040006E5 RID: 1765
	public TextMeshProUGUI m_SalaryCostText;

	// Token: 0x040006E6 RID: 1766
	private Worker m_Worker;
}
