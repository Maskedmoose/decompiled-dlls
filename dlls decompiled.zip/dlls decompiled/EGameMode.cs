﻿using System;

// Token: 0x020000FA RID: 250
public enum EGameMode
{
	// Token: 0x04000E0F RID: 3599
	Base,
	// Token: 0x04000E10 RID: 3600
	ManaFlux,
	// Token: 0x04000E11 RID: 3601
	ManaRamp,
	// Token: 0x04000E12 RID: 3602
	DoubleDamage,
	// Token: 0x04000E13 RID: 3603
	DoubleMana,
	// Token: 0x04000E14 RID: 3604
	TripleMana,
	// Token: 0x04000E15 RID: 3605
	Draft,
	// Token: 0x04000E16 RID: 3606
	AllAttackIsPoison,
	// Token: 0x04000E17 RID: 3607
	PowerSurge,
	// Token: 0x04000E18 RID: 3608
	DrilcerosBattle,
	// Token: 0x04000E19 RID: 3609
	SlumberParty,
	// Token: 0x04000E1A RID: 3610
	PreMadeTeam
}
