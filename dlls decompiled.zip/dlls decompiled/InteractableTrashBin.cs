﻿using System;

// Token: 0x0200002A RID: 42
public class InteractableTrashBin : InteractableObject
{
	// Token: 0x06000229 RID: 553 RVA: 0x00014FBD File Offset: 0x000131BD
	public void DiscardBox(InteractablePackagingBox packagingBox, bool isPlayer)
	{
		packagingBox.OnDestroyed();
		if (isPlayer)
		{
			SoundManager.PlayAudio("SFX_Dispose", 0.6f, 1f);
			CSingleton<InteractionPlayerController>.Instance.OnExitHoldBoxMode();
		}
	}
}
