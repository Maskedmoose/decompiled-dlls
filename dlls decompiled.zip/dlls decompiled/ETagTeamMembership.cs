﻿using System;

// Token: 0x020000F6 RID: 246
public enum ETagTeamMembership
{
	// Token: 0x04000D87 RID: 3463
	None,
	// Token: 0x04000D88 RID: 3464
	Creator,
	// Token: 0x04000D89 RID: 3465
	Joiner,
	// Token: 0x04000D8A RID: 3466
	PendingCreator,
	// Token: 0x04000D8B RID: 3467
	PendingJoiner
}
