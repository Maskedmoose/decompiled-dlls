﻿using System;

// Token: 0x02000100 RID: 256
public enum EEmoteType
{
	// Token: 0x04000E9E RID: 3742
	Angry,
	// Token: 0x04000E9F RID: 3743
	BigSmile,
	// Token: 0x04000EA0 RID: 3744
	ClenchTeeth,
	// Token: 0x04000EA1 RID: 3745
	ClenchTeeth2,
	// Token: 0x04000EA2 RID: 3746
	Cool,
	// Token: 0x04000EA3 RID: 3747
	Cry,
	// Token: 0x04000EA4 RID: 3748
	Cute,
	// Token: 0x04000EA5 RID: 3749
	Derp,
	// Token: 0x04000EA6 RID: 3750
	Disappoint,
	// Token: 0x04000EA7 RID: 3751
	Disappoint2,
	// Token: 0x04000EA8 RID: 3752
	Drool,
	// Token: 0x04000EA9 RID: 3753
	Happy,
	// Token: 0x04000EAA RID: 3754
	Heart,
	// Token: 0x04000EAB RID: 3755
	Kiss,
	// Token: 0x04000EAC RID: 3756
	Laugh,
	// Token: 0x04000EAD RID: 3757
	LaughCry,
	// Token: 0x04000EAE RID: 3758
	LaughSweat,
	// Token: 0x04000EAF RID: 3759
	Poop,
	// Token: 0x04000EB0 RID: 3760
	Sad,
	// Token: 0x04000EB1 RID: 3761
	Shocked,
	// Token: 0x04000EB2 RID: 3762
	Sick1,
	// Token: 0x04000EB3 RID: 3763
	Sick2,
	// Token: 0x04000EB4 RID: 3764
	Sick3,
	// Token: 0x04000EB5 RID: 3765
	Silly,
	// Token: 0x04000EB6 RID: 3766
	TearyEye,
	// Token: 0x04000EB7 RID: 3767
	Silence,
	// Token: 0x04000EB8 RID: 3768
	Exclaimation
}
