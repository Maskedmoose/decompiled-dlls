﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000111 RID: 273
public class InputTooltipListDisplay : MonoBehaviour
{
	// Token: 0x060007FD RID: 2045 RVA: 0x0003B6C5 File Offset: 0x000398C5
	private void Awake()
	{
		this.ClearTooltip();
	}

	// Token: 0x060007FE RID: 2046 RVA: 0x0003B6CD File Offset: 0x000398CD
	private void Init()
	{
		this.UpdatePhoneAndAlbumTooltip();
		this.m_PhoneTooltipUI.SetActive(true);
		this.m_AlbumTooltipUI.SetActive(true);
	}

	// Token: 0x060007FF RID: 2047 RVA: 0x0003B6ED File Offset: 0x000398ED
	public void UpdatePhoneAndAlbumTooltip()
	{
		this.UpdateTooltip(this.m_PhoneTooltipUI, EGameAction.OpenPhone, false, true);
		this.UpdateTooltip(this.m_AlbumTooltipUI, EGameAction.OpenCardAlbum, false, true);
	}

	// Token: 0x06000800 RID: 2048 RVA: 0x0003B710 File Offset: 0x00039910
	public void RefreshActiveTooltip()
	{
		if (this.m_ActiveActionList.Count > 0)
		{
			List<EGameAction> list = new List<EGameAction>();
			List<bool> list2 = new List<bool>();
			List<bool> list3 = new List<bool>();
			for (int i = 0; i < this.m_ActiveActionList.Count; i++)
			{
				list.Add(this.m_ActiveActionList[i]);
				list2.Add(this.m_ActiveIsHoldList[i]);
				list3.Add(this.m_ActiveSingleKeyOnlyList[i]);
			}
			this.ClearTooltip();
			EGameAction egameAction = EGameAction.None;
			for (int j = 0; j < list.Count; j++)
			{
				if (egameAction != list[j])
				{
					egameAction = list[j];
					this.ShowTooltip(list[j], list2[j], list3[j]);
				}
			}
		}
	}

	// Token: 0x06000801 RID: 2049 RVA: 0x0003B7E4 File Offset: 0x000399E4
	public void SetCurrentGameState(EGameState state)
	{
		this.ClearTooltip();
		this.m_PhoneTooltipUI.SetActive(false);
		this.m_AlbumTooltipUI.SetActive(false);
		if (!CSingleton<CGameManager>.Instance.m_EnableTooltip)
		{
			this.m_ActiveLayoutParent.gameObject.SetActive(false);
			return;
		}
		switch (state)
		{
		case EGameState.DefaultState:
			this.m_PhoneTooltipUI.SetActive(true);
			this.m_AlbumTooltipUI.SetActive(true);
			break;
		case EGameState.HoldingBoxState:
			this.ShowTooltip(EGameAction.PlaceBox, false, false);
			this.ShowTooltip(EGameAction.Throw, false, false);
			break;
		case EGameState.HoldingCardState:
			this.ShowTooltip(EGameAction.OpenCardAlbum, false, false);
			break;
		case EGameState.HoldingItemState:
			if (CSingleton<InteractionPlayerController>.Instance.CanOpenPack())
			{
				this.ShowTooltip(EGameAction.InitiateOpenPack, false, false);
			}
			else if (CSingleton<InteractionPlayerController>.Instance.CanOpenCardBox())
			{
				this.ShowTooltip(EGameAction.OpenCardBox, false, false);
			}
			else if (CSingleton<InteractionPlayerController>.Instance.IsHoldingSpray())
			{
				this.ShowTooltip(EGameAction.InitiateSpray, false, false);
			}
			break;
		case EGameState.ViewAlbumState:
			this.ShowTooltip(EGameAction.CloseCardAlbum, false, false);
			this.ShowTooltip(EGameAction.ViewAlbumCard, false, true);
			this.ShowTooltip(EGameAction.TakeCard, false, true);
			this.ShowTooltip(EGameAction.SortAlbum, false, false);
			this.ShowTooltip(EGameAction.FlipNextPage, false, false);
			this.ShowTooltip(EGameAction.FlipPreviousPage, false, false);
			this.ShowTooltip(EGameAction.FlipNextPage10, false, false);
			this.ShowTooltip(EGameAction.FlipPreviousPage10, false, false);
			break;
		case EGameState.MovingObjectState:
			this.ShowTooltip(EGameAction.PlaceMoveObject, false, false);
			this.ShowTooltip(EGameAction.Rotate, false, false);
			this.ShowTooltip(EGameAction.RotateB, false, false);
			this.ShowTooltip(EGameAction.BoxUpShelf, false, false);
			break;
		case EGameState.CashCounterState:
			this.ShowTooltip(EGameAction.ExitCounter, false, false);
			this.ShowTooltip(EGameAction.ScanCounter, true, false);
			break;
		case EGameState.PhoneState:
			this.ShowTooltip(EGameAction.ClosePhone, false, false);
			break;
		case EGameState.HoldSprayState:
			this.ShowTooltip(EGameAction.Spray, false, false);
			this.ShowTooltip(EGameAction.CancelSpray, false, false);
			break;
		case EGameState.MovingBoxState:
			this.ShowTooltip(EGameAction.PlaceMoveObject, false, false);
			this.ShowTooltip(EGameAction.Rotate, false, false);
			this.ShowTooltip(EGameAction.RotateB, false, false);
			break;
		}
		this.m_ActiveLayoutParent.gameObject.SetActive(true);
	}

	// Token: 0x06000802 RID: 2050 RVA: 0x0003B9EC File Offset: 0x00039BEC
	public void ClearTooltip()
	{
		this.m_ActiveActionList.Clear();
		this.m_ActiveIsHoldList.Clear();
		this.m_ActiveSingleKeyOnlyList.Clear();
		this.m_ActiveInputTooltipUIList.Clear();
		for (int i = 0; i < this.m_InputTooltipUIPool.Count; i++)
		{
			this.m_InputTooltipUIPool[i].SetActive(false);
			this.m_InputTooltipUIPool[i].m_Transform.parent = this.m_PoolParent;
		}
	}

	// Token: 0x06000803 RID: 2051 RVA: 0x0003BA6C File Offset: 0x00039C6C
	public void ShowTooltip(EGameAction action, bool isHold = false, bool singleKeyOnly = false)
	{
		string actionName = InputManager.GetActionName(action);
		if (CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			List<EGamepadControlBtn> actionBindedGamepadBtnList = InputManager.GetActionBindedGamepadBtnList(action);
			for (int i = 0; i < actionBindedGamepadBtnList.Count; i++)
			{
				for (int j = 0; j < this.m_InputTooltipUIPool.Count; j++)
				{
					if (!this.m_InputTooltipUIPool[j].m_IsActive)
					{
						this.m_InputTooltipUIPool[j].m_Transform.parent = this.m_ActiveLayoutParent;
						this.m_InputTooltipUIPool[j].SetGamepadInputTooltip(action, actionBindedGamepadBtnList[i], actionName, isHold);
						this.m_InputTooltipUIPool[j].SetActive(true);
						this.m_ActiveInputTooltipUIList.Add(this.m_InputTooltipUIPool[j]);
						this.m_ActiveActionList.Add(action);
						this.m_ActiveIsHoldList.Add(isHold);
						this.m_ActiveSingleKeyOnlyList.Add(singleKeyOnly);
						break;
					}
				}
				if (singleKeyOnly)
				{
					break;
				}
			}
			return;
		}
		List<KeyCode> actionBindedKeyList = InputManager.GetActionBindedKeyList(action);
		for (int k = 0; k < actionBindedKeyList.Count; k++)
		{
			for (int l = 0; l < this.m_InputTooltipUIPool.Count; l++)
			{
				if (!this.m_InputTooltipUIPool[l].m_IsActive)
				{
					this.m_InputTooltipUIPool[l].m_Transform.parent = this.m_ActiveLayoutParent;
					this.m_InputTooltipUIPool[l].SetInputTooltip(action, actionBindedKeyList[k], actionName, isHold);
					this.m_InputTooltipUIPool[l].SetActive(true);
					this.m_ActiveInputTooltipUIList.Add(this.m_InputTooltipUIPool[l]);
					this.m_ActiveActionList.Add(action);
					this.m_ActiveIsHoldList.Add(isHold);
					this.m_ActiveSingleKeyOnlyList.Add(singleKeyOnly);
					break;
				}
			}
			if (singleKeyOnly)
			{
				break;
			}
		}
	}

	// Token: 0x06000804 RID: 2052 RVA: 0x0003BC5C File Offset: 0x00039E5C
	public void RemoveTooltip(EGameAction action)
	{
		InputManager.GetActionBindedKeyList(action);
		InputManager.GetActionName(action);
		for (int i = this.m_ActiveInputTooltipUIList.Count - 1; i >= 0; i--)
		{
			if (this.m_ActiveInputTooltipUIList[i].m_CurrentGameAction == action)
			{
				this.m_ActiveInputTooltipUIList[i].m_Transform.parent = this.m_PoolParent;
				this.m_ActiveInputTooltipUIList[i].SetActive(false);
				this.m_ActiveInputTooltipUIList.RemoveAt(i);
				this.m_ActiveActionList.RemoveAt(i);
				this.m_ActiveIsHoldList.RemoveAt(i);
				this.m_ActiveSingleKeyOnlyList.RemoveAt(i);
			}
		}
	}

	// Token: 0x06000805 RID: 2053 RVA: 0x0003BD04 File Offset: 0x00039F04
	public void UpdateTooltip(InputTooltipUI tooltipUI, EGameAction action, bool isHold = false, bool singleKeyOnly = false)
	{
		string actionName = InputManager.GetActionName(action);
		if (CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			List<EGamepadControlBtn> actionBindedGamepadBtnList = InputManager.GetActionBindedGamepadBtnList(action);
			int num = 0;
			if (num >= actionBindedGamepadBtnList.Count)
			{
				return;
			}
			tooltipUI.SetGamepadInputTooltip(action, actionBindedGamepadBtnList[num], actionName, isHold);
			return;
		}
		else
		{
			List<KeyCode> actionBindedKeyList = InputManager.GetActionBindedKeyList(action);
			int num2 = 0;
			if (num2 >= actionBindedKeyList.Count)
			{
				return;
			}
			tooltipUI.SetInputTooltip(action, actionBindedKeyList[num2], actionName, isHold);
			return;
		}
	}

	// Token: 0x06000806 RID: 2054 RVA: 0x0003BD74 File Offset: 0x00039F74
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_OnLanguageChanged>(new CEventManager.EventDelegate<CEventPlayer_OnLanguageChanged>(this.OnLanguageChanged));
			CEventManager.AddListener<CEventPlayer_OnKeybindChanged>(new CEventManager.EventDelegate<CEventPlayer_OnKeybindChanged>(this.OnKeybindChanged));
		}
	}

	// Token: 0x06000807 RID: 2055 RVA: 0x0003BDC4 File Offset: 0x00039FC4
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_OnLanguageChanged>(new CEventManager.EventDelegate<CEventPlayer_OnLanguageChanged>(this.OnLanguageChanged));
			CEventManager.RemoveListener<CEventPlayer_OnKeybindChanged>(new CEventManager.EventDelegate<CEventPlayer_OnKeybindChanged>(this.OnKeybindChanged));
		}
	}

	// Token: 0x06000808 RID: 2056 RVA: 0x0003BE12 File Offset: 0x0003A012
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
	}

	// Token: 0x06000809 RID: 2057 RVA: 0x0003BE1A File Offset: 0x0003A01A
	protected void OnLanguageChanged(CEventPlayer_OnLanguageChanged evt)
	{
		this.UpdatePhoneAndAlbumTooltip();
		this.RefreshActiveTooltip();
	}

	// Token: 0x0600080A RID: 2058 RVA: 0x0003BE28 File Offset: 0x0003A028
	protected void OnKeybindChanged(CEventPlayer_OnKeybindChanged evt)
	{
		this.UpdatePhoneAndAlbumTooltip();
		this.RefreshActiveTooltip();
	}

	// Token: 0x04000F3A RID: 3898
	public List<InputTooltipUI> m_InputTooltipUIPool;

	// Token: 0x04000F3B RID: 3899
	public List<InputTooltipUI> m_ActiveInputTooltipUIList;

	// Token: 0x04000F3C RID: 3900
	public InputTooltipUI m_PhoneTooltipUI;

	// Token: 0x04000F3D RID: 3901
	public InputTooltipUI m_AlbumTooltipUI;

	// Token: 0x04000F3E RID: 3902
	public Transform m_PoolParent;

	// Token: 0x04000F3F RID: 3903
	public Transform m_ActiveLayoutParent;

	// Token: 0x04000F40 RID: 3904
	private List<EGameAction> m_ActiveActionList = new List<EGameAction>();

	// Token: 0x04000F41 RID: 3905
	private List<bool> m_ActiveIsHoldList = new List<bool>();

	// Token: 0x04000F42 RID: 3906
	private List<bool> m_ActiveSingleKeyOnlyList = new List<bool>();
}
