﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DC RID: 476
	[Serializable]
	public class Sensor
	{
		// Token: 0x06000D63 RID: 3427 RVA: 0x0005C28C File Offset: 0x0005A48C
		public Sensor(Transform _transform, Collider _collider)
		{
			this.tr = _transform;
			if (_collider == null)
			{
				return;
			}
			this.ignoreList = new Collider[1];
			this.ignoreList[0] = _collider;
			this.ignoreRaycastLayer = LayerMask.NameToLayer("Ignore Raycast");
			this.ignoreListLayers = new int[this.ignoreList.Length];
		}

		// Token: 0x06000D64 RID: 3428 RVA: 0x0005C354 File Offset: 0x0005A554
		private void ResetFlags()
		{
			this.hasDetectedHit = false;
			this.hitPosition = Vector3.zero;
			this.hitNormal = -this.GetCastDirection();
			this.hitDistance = 0f;
			if (this.hitColliders.Count > 0)
			{
				this.hitColliders.Clear();
			}
			if (this.hitTransforms.Count > 0)
			{
				this.hitTransforms.Clear();
			}
		}

		// Token: 0x06000D65 RID: 3429 RVA: 0x0005C3C4 File Offset: 0x0005A5C4
		public static Vector3[] GetRaycastStartPositions(int sensorRows, int sensorRayCount, bool offsetRows, float sensorRadius)
		{
			List<Vector3> list = new List<Vector3>();
			Vector3 zero = Vector3.zero;
			list.Add(zero);
			for (int i = 0; i < sensorRows; i++)
			{
				float num = (float)(i + 1) / (float)sensorRows;
				for (int j = 0; j < sensorRayCount * (i + 1); j++)
				{
					float num2 = 360f / (float)(sensorRayCount * (i + 1)) * (float)j;
					if (offsetRows && i % 2 == 0)
					{
						num2 += 360f / (float)(sensorRayCount * (i + 1)) / 2f;
					}
					float x = num * Mathf.Cos(0.017453292f * num2);
					float z = num * Mathf.Sin(0.017453292f * num2);
					list.Add(new Vector3(x, 0f, z) * sensorRadius);
				}
			}
			return list.ToArray();
		}

		// Token: 0x06000D66 RID: 3430 RVA: 0x0005C488 File Offset: 0x0005A688
		public void Cast()
		{
			this.ResetFlags();
			Vector3 direction = this.GetCastDirection();
			Vector3 vector = this.tr.TransformPoint(this.origin);
			if (this.ignoreListLayers.Length != this.ignoreList.Length)
			{
				this.ignoreListLayers = new int[this.ignoreList.Length];
			}
			for (int i = 0; i < this.ignoreList.Length; i++)
			{
				this.ignoreListLayers[i] = this.ignoreList[i].gameObject.layer;
				this.ignoreList[i].gameObject.layer = this.ignoreRaycastLayer;
			}
			switch (this.castType)
			{
			case Sensor.CastType.Raycast:
				this.CastRay(vector, direction);
				break;
			case Sensor.CastType.RaycastArray:
				this.CastRayArray(vector, direction);
				break;
			case Sensor.CastType.Spherecast:
				this.CastSphere(vector, direction);
				break;
			default:
				this.hasDetectedHit = false;
				break;
			}
			for (int j = 0; j < this.ignoreList.Length; j++)
			{
				this.ignoreList[j].gameObject.layer = this.ignoreListLayers[j];
			}
		}

		// Token: 0x06000D67 RID: 3431 RVA: 0x0005C594 File Offset: 0x0005A794
		private void CastRayArray(Vector3 _origin, Vector3 _direction)
		{
			Vector3 zero = Vector3.zero;
			Vector3 direction = this.GetCastDirection();
			this.arrayNormals.Clear();
			this.arrayPoints.Clear();
			for (int i = 0; i < this.raycastArrayStartPositions.Length; i++)
			{
				RaycastHit raycastHit;
				if (Physics.Raycast(_origin + this.tr.TransformDirection(this.raycastArrayStartPositions[i]), direction, out raycastHit, this.castLength, this.layermask, QueryTriggerInteraction.Ignore))
				{
					if (this.isInDebugMode)
					{
						Debug.DrawRay(raycastHit.point, raycastHit.normal, Color.red, Time.fixedDeltaTime * 1.01f);
					}
					this.hitColliders.Add(raycastHit.collider);
					this.hitTransforms.Add(raycastHit.transform);
					this.arrayNormals.Add(raycastHit.normal);
					this.arrayPoints.Add(raycastHit.point);
				}
			}
			this.hasDetectedHit = (this.arrayPoints.Count > 0);
			if (this.hasDetectedHit)
			{
				Vector3 a = Vector3.zero;
				for (int j = 0; j < this.arrayNormals.Count; j++)
				{
					a += this.arrayNormals[j];
				}
				a.Normalize();
				Vector3 a2 = Vector3.zero;
				for (int k = 0; k < this.arrayPoints.Count; k++)
				{
					a2 += this.arrayPoints[k];
				}
				a2 /= (float)this.arrayPoints.Count;
				this.hitPosition = a2;
				this.hitNormal = a;
				this.hitDistance = VectorMath.ExtractDotVector(_origin - this.hitPosition, _direction).magnitude;
			}
		}

		// Token: 0x06000D68 RID: 3432 RVA: 0x0005C760 File Offset: 0x0005A960
		private void CastRay(Vector3 _origin, Vector3 _direction)
		{
			RaycastHit raycastHit;
			this.hasDetectedHit = Physics.Raycast(_origin, _direction, out raycastHit, this.castLength, this.layermask, QueryTriggerInteraction.Ignore);
			if (this.hasDetectedHit)
			{
				this.hitPosition = raycastHit.point;
				this.hitNormal = raycastHit.normal;
				this.hitColliders.Add(raycastHit.collider);
				this.hitTransforms.Add(raycastHit.transform);
				this.hitDistance = raycastHit.distance;
			}
		}

		// Token: 0x06000D69 RID: 3433 RVA: 0x0005C7E4 File Offset: 0x0005A9E4
		private void CastSphere(Vector3 _origin, Vector3 _direction)
		{
			RaycastHit raycastHit;
			this.hasDetectedHit = Physics.SphereCast(_origin, this.sphereCastRadius, _direction, out raycastHit, this.castLength - this.sphereCastRadius, this.layermask, QueryTriggerInteraction.Ignore);
			if (this.hasDetectedHit)
			{
				this.hitPosition = raycastHit.point;
				this.hitNormal = raycastHit.normal;
				this.hitColliders.Add(raycastHit.collider);
				this.hitTransforms.Add(raycastHit.transform);
				this.hitDistance = raycastHit.distance;
				this.hitDistance += this.sphereCastRadius;
				if (this.calculateRealDistance)
				{
					this.hitDistance = VectorMath.ExtractDotVector(_origin - this.hitPosition, _direction).magnitude;
				}
				Collider collider = this.hitColliders[0];
				if (this.calculateRealSurfaceNormal)
				{
					if (collider.Raycast(new Ray(this.hitPosition - _direction, _direction), out raycastHit, 1.5f))
					{
						if (Vector3.Angle(raycastHit.normal, -_direction) >= 89f)
						{
							this.hitNormal = this.backupNormal;
						}
						else
						{
							this.hitNormal = raycastHit.normal;
						}
					}
					else
					{
						this.hitNormal = this.backupNormal;
					}
					this.backupNormal = this.hitNormal;
				}
			}
		}

		// Token: 0x06000D6A RID: 3434 RVA: 0x0005C934 File Offset: 0x0005AB34
		private Vector3 GetCastDirection()
		{
			switch (this.castDirection)
			{
			case Sensor.CastDirection.Forward:
				return this.tr.forward;
			case Sensor.CastDirection.Right:
				return this.tr.right;
			case Sensor.CastDirection.Up:
				return this.tr.up;
			case Sensor.CastDirection.Backward:
				return -this.tr.forward;
			case Sensor.CastDirection.Left:
				return -this.tr.right;
			case Sensor.CastDirection.Down:
				return -this.tr.up;
			default:
				return Vector3.one;
			}
		}

		// Token: 0x06000D6B RID: 3435 RVA: 0x0005C9C4 File Offset: 0x0005ABC4
		public void DrawDebug()
		{
			if (this.hasDetectedHit && this.isInDebugMode)
			{
				Debug.DrawRay(this.hitPosition, this.hitNormal, Color.red, Time.deltaTime);
				float d = 0.2f;
				Debug.DrawLine(this.hitPosition + Vector3.up * d, this.hitPosition - Vector3.up * d, Color.green, Time.deltaTime);
				Debug.DrawLine(this.hitPosition + Vector3.right * d, this.hitPosition - Vector3.right * d, Color.green, Time.deltaTime);
				Debug.DrawLine(this.hitPosition + Vector3.forward * d, this.hitPosition - Vector3.forward * d, Color.green, Time.deltaTime);
			}
		}

		// Token: 0x06000D6C RID: 3436 RVA: 0x0005CAB9 File Offset: 0x0005ACB9
		public bool HasDetectedHit()
		{
			return this.hasDetectedHit;
		}

		// Token: 0x06000D6D RID: 3437 RVA: 0x0005CAC1 File Offset: 0x0005ACC1
		public float GetDistance()
		{
			return this.hitDistance;
		}

		// Token: 0x06000D6E RID: 3438 RVA: 0x0005CAC9 File Offset: 0x0005ACC9
		public Vector3 GetNormal()
		{
			return this.hitNormal;
		}

		// Token: 0x06000D6F RID: 3439 RVA: 0x0005CAD1 File Offset: 0x0005ACD1
		public Vector3 GetPosition()
		{
			return this.hitPosition;
		}

		// Token: 0x06000D70 RID: 3440 RVA: 0x0005CAD9 File Offset: 0x0005ACD9
		public Collider GetCollider()
		{
			return this.hitColliders[0];
		}

		// Token: 0x06000D71 RID: 3441 RVA: 0x0005CAE7 File Offset: 0x0005ACE7
		public Transform GetTransform()
		{
			return this.hitTransforms[0];
		}

		// Token: 0x06000D72 RID: 3442 RVA: 0x0005CAF5 File Offset: 0x0005ACF5
		public void SetCastOrigin(Vector3 _origin)
		{
			if (this.tr == null)
			{
				return;
			}
			this.origin = this.tr.InverseTransformPoint(_origin);
		}

		// Token: 0x06000D73 RID: 3443 RVA: 0x0005CB18 File Offset: 0x0005AD18
		public void SetCastDirection(Sensor.CastDirection _direction)
		{
			if (this.tr == null)
			{
				return;
			}
			this.castDirection = _direction;
		}

		// Token: 0x06000D74 RID: 3444 RVA: 0x0005CB30 File Offset: 0x0005AD30
		public void RecalibrateRaycastArrayPositions()
		{
			this.raycastArrayStartPositions = Sensor.GetRaycastStartPositions(this.ArrayRows, this.arrayRayCount, this.offsetArrayRows, this.sphereCastRadius);
		}

		// Token: 0x04001457 RID: 5207
		public float castLength = 1f;

		// Token: 0x04001458 RID: 5208
		public float sphereCastRadius = 0.2f;

		// Token: 0x04001459 RID: 5209
		private Vector3 origin = Vector3.zero;

		// Token: 0x0400145A RID: 5210
		private Sensor.CastDirection castDirection;

		// Token: 0x0400145B RID: 5211
		private bool hasDetectedHit;

		// Token: 0x0400145C RID: 5212
		private Vector3 hitPosition;

		// Token: 0x0400145D RID: 5213
		private Vector3 hitNormal;

		// Token: 0x0400145E RID: 5214
		private float hitDistance;

		// Token: 0x0400145F RID: 5215
		private List<Collider> hitColliders = new List<Collider>();

		// Token: 0x04001460 RID: 5216
		private List<Transform> hitTransforms = new List<Transform>();

		// Token: 0x04001461 RID: 5217
		private Vector3 backupNormal;

		// Token: 0x04001462 RID: 5218
		private Transform tr;

		// Token: 0x04001463 RID: 5219
		private Collider col;

		// Token: 0x04001464 RID: 5220
		public Sensor.CastType castType;

		// Token: 0x04001465 RID: 5221
		public LayerMask layermask = 255;

		// Token: 0x04001466 RID: 5222
		private int ignoreRaycastLayer;

		// Token: 0x04001467 RID: 5223
		public bool calculateRealSurfaceNormal;

		// Token: 0x04001468 RID: 5224
		public bool calculateRealDistance;

		// Token: 0x04001469 RID: 5225
		public int arrayRayCount = 9;

		// Token: 0x0400146A RID: 5226
		public int ArrayRows = 3;

		// Token: 0x0400146B RID: 5227
		public bool offsetArrayRows;

		// Token: 0x0400146C RID: 5228
		private Vector3[] raycastArrayStartPositions;

		// Token: 0x0400146D RID: 5229
		private Collider[] ignoreList;

		// Token: 0x0400146E RID: 5230
		private int[] ignoreListLayers;

		// Token: 0x0400146F RID: 5231
		public bool isInDebugMode;

		// Token: 0x04001470 RID: 5232
		private List<Vector3> arrayNormals = new List<Vector3>();

		// Token: 0x04001471 RID: 5233
		private List<Vector3> arrayPoints = new List<Vector3>();

		// Token: 0x0200027F RID: 639
		public enum CastDirection
		{
			// Token: 0x04001697 RID: 5783
			Forward,
			// Token: 0x04001698 RID: 5784
			Right,
			// Token: 0x04001699 RID: 5785
			Up,
			// Token: 0x0400169A RID: 5786
			Backward,
			// Token: 0x0400169B RID: 5787
			Left,
			// Token: 0x0400169C RID: 5788
			Down
		}

		// Token: 0x02000280 RID: 640
		[SerializeField]
		public enum CastType
		{
			// Token: 0x0400169E RID: 5790
			Raycast,
			// Token: 0x0400169F RID: 5791
			RaycastArray,
			// Token: 0x040016A0 RID: 5792
			Spherecast
		}
	}
}
