﻿using System;

// Token: 0x020000DA RID: 218
public enum ECollectionPackType
{
	// Token: 0x04000A0A RID: 2570
	None = -1,
	// Token: 0x04000A0B RID: 2571
	BasicCardPack,
	// Token: 0x04000A0C RID: 2572
	RareCardPack,
	// Token: 0x04000A0D RID: 2573
	EpicCardPack,
	// Token: 0x04000A0E RID: 2574
	LegendaryCardPack,
	// Token: 0x04000A0F RID: 2575
	DestinyBasicCardPack,
	// Token: 0x04000A10 RID: 2576
	DestinyRareCardPack,
	// Token: 0x04000A11 RID: 2577
	DestinyEpicCardPack,
	// Token: 0x04000A12 RID: 2578
	DestinyLegendaryCardPack,
	// Token: 0x04000A13 RID: 2579
	GhostPack,
	// Token: 0x04000A14 RID: 2580
	MegabotPack,
	// Token: 0x04000A15 RID: 2581
	FantasyRPGPack,
	// Token: 0x04000A16 RID: 2582
	CatJobPack,
	// Token: 0x04000A17 RID: 2583
	FoodieGOPack,
	// Token: 0x04000A18 RID: 2584
	FoodieGOBWPack,
	// Token: 0x04000A19 RID: 2585
	FoodieGOJPPack,
	// Token: 0x04000A1A RID: 2586
	MAX
}
