﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001ED RID: 493
	public class RotateObject : MonoBehaviour
	{
		// Token: 0x06000DB7 RID: 3511 RVA: 0x0005DAC5 File Offset: 0x0005BCC5
		private void Start()
		{
			this.tr = base.transform;
		}

		// Token: 0x06000DB8 RID: 3512 RVA: 0x0005DAD3 File Offset: 0x0005BCD3
		private void Update()
		{
			this.tr.Rotate(this.rotationAxis * this.rotationSpeed * Time.deltaTime);
		}

		// Token: 0x040014AE RID: 5294
		private Transform tr;

		// Token: 0x040014AF RID: 5295
		public float rotationSpeed = 20f;

		// Token: 0x040014B0 RID: 5296
		public Vector3 rotationAxis = new Vector3(0f, 1f, 0f);
	}
}
