﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000087 RID: 135
public class UI_CheckoutItemBar : MonoBehaviour
{
	// Token: 0x06000554 RID: 1364 RVA: 0x0002CD80 File Offset: 0x0002AF80
	public void SetItemName(string name, float value)
	{
		this.m_NameText.text = name;
		this.m_UnitPrice = value;
		this.m_TotalPrice = value;
		this.m_UnitText.text = 1.ToString();
		this.m_PriceText.text = GameInstance.GetPriceString(this.m_UnitPrice, false, true, false, "F2");
		this.m_TotalText.text = this.m_PriceText.text;
	}

	// Token: 0x06000555 RID: 1365 RVA: 0x0002CDF0 File Offset: 0x0002AFF0
	public void AddScannedItem(int itemCount)
	{
		this.m_UnitText.text = itemCount.ToString();
		this.m_TotalPrice = this.m_UnitPrice * (float)itemCount;
		this.m_TotalText.text = GameInstance.GetPriceString(this.m_TotalPrice, false, true, false, "F2");
	}

	// Token: 0x06000556 RID: 1366 RVA: 0x0002CE3C File Offset: 0x0002B03C
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000557 RID: 1367 RVA: 0x0002CE5D File Offset: 0x0002B05D
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x06000558 RID: 1368 RVA: 0x0002CE7E File Offset: 0x0002B07E
	protected void OnMoneyCurrencyUpdated(CEventPlayer_OnMoneyCurrencyUpdated evt)
	{
		this.m_PriceText.text = GameInstance.GetPriceString(this.m_UnitPrice, false, true, false, "F2");
		this.m_TotalText.text = GameInstance.GetPriceString(this.m_TotalPrice, false, true, false, "F2");
	}

	// Token: 0x04000705 RID: 1797
	public TextMeshProUGUI m_NameText;

	// Token: 0x04000706 RID: 1798
	public TextMeshProUGUI m_PriceText;

	// Token: 0x04000707 RID: 1799
	public TextMeshProUGUI m_UnitText;

	// Token: 0x04000708 RID: 1800
	public TextMeshProUGUI m_TotalText;

	// Token: 0x04000709 RID: 1801
	private float m_UnitPrice;

	// Token: 0x0400070A RID: 1802
	private float m_TotalPrice;
}
