﻿using System;
using UnityEngine;

// Token: 0x02000147 RID: 327
public class EGA_EffectSound : MonoBehaviour
{
	// Token: 0x0600093B RID: 2363 RVA: 0x000430F8 File Offset: 0x000412F8
	private void Start()
	{
		this.soundComponent = base.GetComponent<AudioSource>();
		this.clip = this.soundComponent.clip;
		if (this.RandomVolume)
		{
			this.soundComponent.volume = Random.Range(this.minVolume, this.maxVolume);
			this.RepeatSound();
		}
		if (this.Repeating)
		{
			base.InvokeRepeating("RepeatSound", this.StartTime, this.RepeatTime);
		}
	}

	// Token: 0x0600093C RID: 2364 RVA: 0x0004316B File Offset: 0x0004136B
	private void RepeatSound()
	{
		this.soundComponent.PlayOneShot(this.clip);
	}

	// Token: 0x0400115A RID: 4442
	public bool Repeating = true;

	// Token: 0x0400115B RID: 4443
	public float RepeatTime = 2f;

	// Token: 0x0400115C RID: 4444
	public float StartTime;

	// Token: 0x0400115D RID: 4445
	public bool RandomVolume;

	// Token: 0x0400115E RID: 4446
	public float minVolume = 0.4f;

	// Token: 0x0400115F RID: 4447
	public float maxVolume = 1f;

	// Token: 0x04001160 RID: 4448
	private AudioClip clip;

	// Token: 0x04001161 RID: 4449
	private AudioSource soundComponent;
}
