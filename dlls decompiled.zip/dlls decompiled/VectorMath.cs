﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E1 RID: 481
	public static class VectorMath
	{
		// Token: 0x06000D88 RID: 3464 RVA: 0x0005D0FC File Offset: 0x0005B2FC
		public static float GetAngle(Vector3 _vector1, Vector3 _vector2, Vector3 _planeNormal)
		{
			float num = Vector3.Angle(_vector1, _vector2);
			float num2 = Mathf.Sign(Vector3.Dot(_planeNormal, Vector3.Cross(_vector1, _vector2)));
			return num * num2;
		}

		// Token: 0x06000D89 RID: 3465 RVA: 0x0005D125 File Offset: 0x0005B325
		public static float GetDotProduct(Vector3 _vector, Vector3 _direction)
		{
			if (_direction.sqrMagnitude != 1f)
			{
				_direction.Normalize();
			}
			return Vector3.Dot(_vector, _direction);
		}

		// Token: 0x06000D8A RID: 3466 RVA: 0x0005D144 File Offset: 0x0005B344
		public static Vector3 RemoveDotVector(Vector3 _vector, Vector3 _direction)
		{
			if (_direction.sqrMagnitude != 1f)
			{
				_direction.Normalize();
			}
			float d = Vector3.Dot(_vector, _direction);
			_vector -= _direction * d;
			return _vector;
		}

		// Token: 0x06000D8B RID: 3467 RVA: 0x0005D180 File Offset: 0x0005B380
		public static Vector3 ExtractDotVector(Vector3 _vector, Vector3 _direction)
		{
			if (_direction.sqrMagnitude != 1f)
			{
				_direction.Normalize();
			}
			float d = Vector3.Dot(_vector, _direction);
			return _direction * d;
		}

		// Token: 0x06000D8C RID: 3468 RVA: 0x0005D1B1 File Offset: 0x0005B3B1
		public static Vector3 RotateVectorOntoPlane(Vector3 _vector, Vector3 _planeNormal, Vector3 _upDirection)
		{
			_vector = Quaternion.FromToRotation(_upDirection, _planeNormal) * _vector;
			return _vector;
		}

		// Token: 0x06000D8D RID: 3469 RVA: 0x0005D1C4 File Offset: 0x0005B3C4
		public static Vector3 ProjectPointOntoLine(Vector3 _lineStartPosition, Vector3 _lineDirection, Vector3 _point)
		{
			float d = Vector3.Dot(_point - _lineStartPosition, _lineDirection);
			return _lineStartPosition + _lineDirection * d;
		}

		// Token: 0x06000D8E RID: 3470 RVA: 0x0005D1EC File Offset: 0x0005B3EC
		public static Vector3 IncrementVectorTowardTargetVector(Vector3 _currentVector, float _speed, float _deltaTime, Vector3 _targetVector)
		{
			return Vector3.MoveTowards(_currentVector, _targetVector, _speed * _deltaTime);
		}
	}
}
