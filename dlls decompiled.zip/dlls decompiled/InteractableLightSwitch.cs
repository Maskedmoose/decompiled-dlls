﻿using System;

// Token: 0x02000020 RID: 32
public class InteractableLightSwitch : InteractableObject
{
	// Token: 0x06000183 RID: 387 RVA: 0x000121FC File Offset: 0x000103FC
	public override void OnMouseButtonUp()
	{
		SoundManager.PlayAudio("SFX_ButtonLightTap", 0.6f, 0.5f);
		CSingleton<LightManager>.Instance.ToggleShopLight();
	}
}
