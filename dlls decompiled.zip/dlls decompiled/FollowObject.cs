﻿using System;
using UnityEngine;

// Token: 0x02000103 RID: 259
public class FollowObject : MonoBehaviour
{
	// Token: 0x0600079D RID: 1949 RVA: 0x000393AF File Offset: 0x000375AF
	private void Awake()
	{
		if (this.m_Target == null)
		{
			return;
		}
		this.m_PosOffset = this.m_Target.transform.position - base.transform.position;
	}

	// Token: 0x0600079E RID: 1950 RVA: 0x000393E8 File Offset: 0x000375E8
	private void LateUpdate()
	{
		if (this.m_Target == null)
		{
			return;
		}
		if (this.m_MaintainCurrentPos)
		{
			base.transform.position = this.m_Target.transform.position - this.m_PosOffset;
			return;
		}
		if (this.m_IgnoreY)
		{
			base.transform.position = new Vector3(this.m_Target.transform.position.x, base.transform.position.y, this.m_Target.transform.position.z);
			return;
		}
		base.transform.position = this.m_Target.transform.position;
		if (this.m_FollowRot)
		{
			base.transform.rotation = this.m_Target.transform.rotation;
		}
		if (this.m_FollowScale)
		{
			base.transform.localScale = this.m_Target.transform.lossyScale;
		}
	}

	// Token: 0x0600079F RID: 1951 RVA: 0x000394E7 File Offset: 0x000376E7
	public void SetFollowTarget(Transform followTarget)
	{
		this.m_Target = followTarget.gameObject;
	}

	// Token: 0x060007A0 RID: 1952 RVA: 0x000394F5 File Offset: 0x000376F5
	private void OnEnable()
	{
		if (this.m_Target == null)
		{
			this.m_Target = this.m_LastFollowTarget;
		}
	}

	// Token: 0x060007A1 RID: 1953 RVA: 0x00039511 File Offset: 0x00037711
	private void OnDisable()
	{
		if (this.m_IgnoreDisableTarget)
		{
			return;
		}
		this.m_LastFollowTarget = this.m_Target;
		this.m_Target = null;
	}

	// Token: 0x04000ED1 RID: 3793
	public GameObject m_Target;

	// Token: 0x04000ED2 RID: 3794
	public GameObject m_LastFollowTarget;

	// Token: 0x04000ED3 RID: 3795
	public bool m_MaintainCurrentPos;

	// Token: 0x04000ED4 RID: 3796
	public bool m_FollowRot;

	// Token: 0x04000ED5 RID: 3797
	public bool m_FollowScale;

	// Token: 0x04000ED6 RID: 3798
	private Vector3 m_PosOffset;

	// Token: 0x04000ED7 RID: 3799
	public bool m_IgnoreY;

	// Token: 0x04000ED8 RID: 3800
	public bool m_IgnoreDisableTarget;
}
