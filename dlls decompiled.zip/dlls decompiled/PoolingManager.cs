﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000D3 RID: 211
public class PoolingManager : CSingleton<PoolingManager>
{
	// Token: 0x06000757 RID: 1879 RVA: 0x000383AF File Offset: 0x000365AF
	protected PoolingManager()
	{
	}

	// Token: 0x06000758 RID: 1880 RVA: 0x000383C0 File Offset: 0x000365C0
	private void Start()
	{
		PoolingManager.m_SlashHitFXList = new List<GameObject>();
		PoolingManager.m_ExplosionFXList = new List<GameObject>();
		this.m_SlashHitFXPrefab = this.m_PoolFXScriptableObject.m_SlashHitFXPrefab;
		this.m_ExplosionFXPrefab = this.m_PoolFXScriptableObject.m_ExplosionFXPrefab;
		PoolingManager.m_DefaultPos = new Vector3(9999f, 9999f, 0f);
		base.StartCoroutine(this.SpawnInitialPool());
	}

	// Token: 0x06000759 RID: 1881 RVA: 0x00038429 File Offset: 0x00036629
	private void ParentObjectToGroup(GameObject poolObject)
	{
		poolObject.transform.SetParent(this.m_PoolingObjectGroup.transform);
	}

	// Token: 0x0600075A RID: 1882 RVA: 0x00038441 File Offset: 0x00036641
	private IEnumerator SpawnInitialPool()
	{
		float waitTime = 0.02f;
		this.m_PoolingObjectGroup = new GameObject("PoolingObject_Grp");
		Object.DontDestroyOnLoad(this.m_PoolingObjectGroup);
		yield return new WaitForSeconds(waitTime);
		for (int i = 0; i < this.m_SlashHitFXInitCount; i++)
		{
			this.objectInst = Object.Instantiate<GameObject>(this.m_SlashHitFXPrefab, PoolingManager.m_DefaultPos, base.transform.rotation);
			this.objectInst.SetActive(false);
			this.ParentObjectToGroup(this.objectInst);
			PoolingManager.m_SlashHitFXList.Add(this.objectInst);
		}
		yield return new WaitForSeconds(waitTime);
		for (int j = 0; j < this.m_ExplosionFXInitCount; j++)
		{
			this.objectInst = Object.Instantiate<GameObject>(this.m_ExplosionFXPrefab, PoolingManager.m_DefaultPos, base.transform.rotation);
			this.objectInst.SetActive(false);
			this.ParentObjectToGroup(this.objectInst);
			PoolingManager.m_ExplosionFXList.Add(this.objectInst);
		}
		yield break;
	}

	// Token: 0x0600075B RID: 1883 RVA: 0x00038450 File Offset: 0x00036650
	public static GameObject ActivateObject(PoolObjectType objectType, Vector3 position, Quaternion rotation, Transform followTarget = null)
	{
		List<GameObject> list = new List<GameObject>();
		List<FollowObject> list2 = new List<FollowObject>();
		if (objectType != PoolObjectType.slashHitFX)
		{
			if (objectType == PoolObjectType.explosionFX)
			{
				list = PoolingManager.m_ExplosionFXList;
			}
		}
		else
		{
			list = PoolingManager.m_SlashHitFXList;
		}
		for (int i = 0; i < list.Count; i++)
		{
			if (!list[i].activeSelf)
			{
				list[i].transform.position = position;
				list[i].transform.rotation = rotation;
				list[i].SetActive(true);
				if (followTarget)
				{
					list2[i].SetFollowTarget(followTarget);
				}
				return list[i];
			}
		}
		return null;
	}

	// Token: 0x0600075C RID: 1884 RVA: 0x000384EF File Offset: 0x000366EF
	public static void DeactivateObject(GameObject gameobject)
	{
		gameobject.transform.position = PoolingManager.m_DefaultPos;
		gameobject.SetActive(false);
	}

	// Token: 0x04000957 RID: 2391
	public PoolFX_ScriptableObject m_PoolFXScriptableObject;

	// Token: 0x04000958 RID: 2392
	private static Vector3 m_DefaultPos;

	// Token: 0x04000959 RID: 2393
	private GameObject m_PoolingObjectGroup;

	// Token: 0x0400095A RID: 2394
	private static List<GameObject> m_SlashHitFXList;

	// Token: 0x0400095B RID: 2395
	private static List<GameObject> m_ExplosionFXList;

	// Token: 0x0400095C RID: 2396
	private GameObject objectInst;

	// Token: 0x0400095D RID: 2397
	private int m_SlashHitFXInitCount;

	// Token: 0x0400095E RID: 2398
	private int m_ExplosionFXInitCount = 10;

	// Token: 0x0400095F RID: 2399
	private GameObject m_SlashHitFXPrefab;

	// Token: 0x04000960 RID: 2400
	private GameObject m_ExplosionFXPrefab;
}
