﻿using System;
using UnityEngine;

// Token: 0x02000129 RID: 297
public class TouchManager : CSingleton<TouchManager>
{
	// Token: 0x060008B6 RID: 2230 RVA: 0x00040012 File Offset: 0x0003E212
	private void Awake()
	{
		if (TouchManager.m_Instance == null)
		{
			TouchManager.m_Instance = this;
		}
		else if (TouchManager.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x060008B7 RID: 2231 RVA: 0x00040048 File Offset: 0x0003E248
	private void Update()
	{
		if (!this.m_IsEnabled)
		{
			return;
		}
		if (Input.touchSupported && Input.touchCount > 1)
		{
			this.ResetSwipe();
			return;
		}
		if (!this.m_IsPressed)
		{
			this.m_DragRatioX = Mathf.Lerp(this.m_DragRatioX, 0f, Time.deltaTime * 6f);
			this.m_DragRatioY = Mathf.Lerp(this.m_DragRatioY, 0f, Time.deltaTime * 6f);
			this.m_FreeDragRatioX = Mathf.Lerp(this.m_FreeDragRatioX, 0f, Time.deltaTime * 6f);
			this.m_FreeDragRatioY = Mathf.Lerp(this.m_FreeDragRatioY, 0f, Time.deltaTime * 6f);
			if (InputManager.GetKeyDownAction(EGameAction.InteractLeft))
			{
				this.m_AllowButtonPressTimer = 0f;
				this.m_AllowButtonPress = true;
				this.m_IsQuickSwipeX = false;
				this.m_IsQuickSwipeY = false;
				this.m_IsQuickSwipeXn = false;
				this.m_IsQuickSwipeYn = false;
				this.m_ScreenWidth = (float)Screen.width;
				this.m_ScreenHeight = (float)Screen.height;
				this.m_IsPressed = true;
				this.m_IsDragging = false;
				this.m_IsDraggingHorizontally = false;
				this.m_LastPosX = Input.mousePosition.x;
				this.m_FreeLastPosX = Input.mousePosition.x;
				this.m_StartPosX = this.m_LastPosX;
				this.m_LastPosY = Input.mousePosition.y;
				this.m_FreeLastPosY = Input.mousePosition.y;
				this.m_StartPosY = this.m_LastPosY;
				this.m_DragRatioX = 0f;
				this.m_DragRatioY = 0f;
				this.m_FreeDragRatioX = 0f;
				this.m_FreeDragRatioY = 0f;
				this.m_IsSnapping = true;
				this.m_IsSnappingHorizontally = true;
			}
		}
		else
		{
			this.m_QuickSwipeTimer += Time.deltaTime;
			if (!this.m_IsDraggingHorizontally && !this.m_IsDragging && Mathf.Abs(this.m_LastPosY - this.m_StartPosY) > 20f)
			{
				this.m_IsDragging = true;
				RaycasterManager.SetUIRaycastEnabled(false);
			}
			else if (!this.m_IsDraggingHorizontally && !this.m_IsDragging && Mathf.Abs(this.m_LastPosX - this.m_StartPosX) > 20f)
			{
				this.m_IsDraggingHorizontally = true;
				RaycasterManager.SetUIRaycastEnabled(false);
			}
			if ((this.m_IsDragging || this.m_IsDraggingHorizontally) && this.m_QuickSwipeTimer > 0.02f && this.m_TargetLerpSpeed != 100f)
			{
				this.m_DragRatioX = 0f;
				this.m_DragRatioY = 0f;
				this.m_TargetLerpSpeed = 100f;
				this.m_LerpSpeed = 100f;
				if (this.m_IsDragging)
				{
					this.m_IsSnapping = true;
				}
				else if (this.m_IsDraggingHorizontally)
				{
					this.m_IsSnappingHorizontally = true;
				}
			}
			if (this.m_IsDraggingHorizontally)
			{
				this.m_DragRatioX = (Input.mousePosition.x - this.m_LastPosX) / this.m_ScreenWidth;
			}
			else if (this.m_IsDragging)
			{
				this.m_DragRatioY = (Input.mousePosition.y - this.m_LastPosY) / this.m_ScreenHeight;
			}
			this.m_FreeDragRatioX = (Input.mousePosition.x - this.m_FreeLastPosX) / this.m_ScreenWidth;
			this.m_FreeDragRatioY = (Input.mousePosition.y - this.m_FreeLastPosY) / this.m_ScreenHeight;
			if (!this.m_IsDragging)
			{
				this.m_LastPosX = Input.mousePosition.x;
			}
			if (!this.m_IsDraggingHorizontally)
			{
				this.m_LastPosY = Input.mousePosition.y;
			}
			this.m_FreeLastPosX = Input.mousePosition.x;
			this.m_FreeLastPosY = Input.mousePosition.y;
			if (Input.GetMouseButtonUp(0))
			{
				if (this.m_QuickSwipeTimer < 0.4f)
				{
					if (this.m_LastPosX - this.m_StartPosX > 150f)
					{
						this.m_IsQuickSwipeX = true;
					}
					if (this.m_LastPosY - this.m_StartPosY > 150f)
					{
						this.m_IsQuickSwipeY = true;
					}
					if (this.m_LastPosX - this.m_StartPosX < -150f)
					{
						this.m_IsQuickSwipeXn = true;
					}
					if (this.m_LastPosY - this.m_StartPosY < -150f)
					{
						this.m_IsQuickSwipeYn = true;
					}
				}
				float num = Mathf.Clamp((0.5f - this.m_QuickSwipeTimer) * 0.15f, 0f, 0.1f);
				if (this.m_IsQuickSwipeX)
				{
					this.m_DragRatioX += num;
				}
				if (this.m_IsQuickSwipeXn)
				{
					this.m_DragRatioX -= num;
				}
				if (this.m_IsQuickSwipeY)
				{
					this.m_DragRatioY += num;
				}
				if (this.m_IsQuickSwipeYn)
				{
					this.m_DragRatioY -= num;
				}
				this.m_QuickSwipeTimer = 0f;
				this.m_IsDragging = false;
				this.m_IsDraggingHorizontally = false;
				this.m_IsPressed = false;
				this.m_ReleasePos = Input.mousePosition;
				this.m_TargetLerpSpeed = this.m_DefaultLerpSpeed;
				this.m_LerpSpeed = this.m_DefaultLerpSpeed;
				this.m_AllowButtonPress = true;
				RaycasterManager.SetUIRaycastEnabled(true);
			}
		}
		if (this.m_AllowButtonPress && (TouchManager.IsDragging() || TouchManager.IsDraggingHorizontally()))
		{
			this.m_AllowButtonPress = false;
		}
		if (!this.m_IsPressed && !this.m_AllowButtonPress)
		{
			this.m_AllowButtonPressTimer += Time.deltaTime;
			float allowButtonPressTimer = this.m_AllowButtonPressTimer;
		}
	}

	// Token: 0x060008B8 RID: 2232 RVA: 0x00040570 File Offset: 0x0003E770
	public void ResetSwipe()
	{
		this.m_AllowButtonPress = false;
		this.m_QuickSwipeTimer = 0f;
		this.m_IsDragging = false;
		this.m_IsDraggingHorizontally = false;
		this.m_IsSnapping = false;
		this.m_IsSnappingHorizontally = false;
		this.m_DragRatioX = 0f;
		this.m_DragRatioY = 0f;
		this.m_FreeDragRatioX = 0f;
		this.m_FreeDragRatioY = 0f;
		this.m_LastPosX = Input.mousePosition.x;
		this.m_LastPosY = Input.mousePosition.y;
		this.m_FreeLastPosX = Input.mousePosition.x;
		this.m_FreeLastPosY = Input.mousePosition.y;
		this.m_IsQuickSwipeX = false;
		this.m_IsQuickSwipeY = false;
		this.m_IsQuickSwipeXn = false;
		this.m_IsQuickSwipeYn = false;
		this.m_IsPressed = false;
		this.m_ReleasePos = Input.mousePosition;
		this.m_TargetLerpSpeed = this.m_DefaultLerpSpeed;
		this.m_LerpSpeed = this.m_DefaultLerpSpeed;
		RaycasterManager.SetUIRaycastEnabled(true);
	}

	// Token: 0x060008B9 RID: 2233 RVA: 0x00040668 File Offset: 0x0003E868
	public static bool IsDragging()
	{
		return CSingleton<TouchManager>.Instance.m_IsDragging;
	}

	// Token: 0x060008BA RID: 2234 RVA: 0x00040674 File Offset: 0x0003E874
	public static bool IsDraggingHorizontally()
	{
		return CSingleton<TouchManager>.Instance.m_IsDraggingHorizontally;
	}

	// Token: 0x060008BB RID: 2235 RVA: 0x00040680 File Offset: 0x0003E880
	public static int GetTouchFingerID()
	{
		if (Input.touchCount > 0)
		{
			return Input.GetTouch(Input.touchCount - 1).fingerId;
		}
		return -1;
	}

	// Token: 0x060008BC RID: 2236 RVA: 0x000406AB File Offset: 0x0003E8AB
	public static bool IsSnappingToFinger()
	{
		if (CSingleton<TouchManager>.Instance.m_IsSnapping)
		{
			CSingleton<TouchManager>.Instance.m_IsSnapping = false;
			return true;
		}
		return false;
	}

	// Token: 0x060008BD RID: 2237 RVA: 0x000406C7 File Offset: 0x0003E8C7
	public static bool IsSnappingToFingerHorizontally()
	{
		if (CSingleton<TouchManager>.Instance.m_IsSnappingHorizontally)
		{
			CSingleton<TouchManager>.Instance.m_IsSnappingHorizontally = false;
			return true;
		}
		return false;
	}

	// Token: 0x060008BE RID: 2238 RVA: 0x000406E3 File Offset: 0x0003E8E3
	public static void ResetFingerSnapping()
	{
		CSingleton<TouchManager>.Instance.m_IsSnapping = false;
		CSingleton<TouchManager>.Instance.m_IsSnappingHorizontally = false;
	}

	// Token: 0x060008BF RID: 2239 RVA: 0x000406FC File Offset: 0x0003E8FC
	public static Vector3 GetTouchPositionUsingID(int fingerID)
	{
		if ((!Input.touchSupported && !Input.multiTouchEnabled) || fingerID == -1)
		{
			return Input.mousePosition;
		}
		for (int i = 0; i < Input.touchCount; i++)
		{
			if (Input.GetTouch(i).fingerId == fingerID)
			{
				return Input.GetTouch(i).position;
			}
		}
		return Vector3.zero;
	}

	// Token: 0x04001081 RID: 4225
	public static TouchManager m_Instance;

	// Token: 0x04001082 RID: 4226
	public float m_ScrollSpeedMultiplier = 1f;

	// Token: 0x04001083 RID: 4227
	public bool m_IsEnabled = true;

	// Token: 0x04001084 RID: 4228
	public bool m_IsPressed;

	// Token: 0x04001085 RID: 4229
	public bool m_IsDragging;

	// Token: 0x04001086 RID: 4230
	public bool m_IsDraggingHorizontally;

	// Token: 0x04001087 RID: 4231
	public bool m_IsQuickSwipeX;

	// Token: 0x04001088 RID: 4232
	public bool m_IsQuickSwipeY;

	// Token: 0x04001089 RID: 4233
	public bool m_IsQuickSwipeXn;

	// Token: 0x0400108A RID: 4234
	public bool m_IsQuickSwipeYn;

	// Token: 0x0400108B RID: 4235
	public bool m_IsSnapping;

	// Token: 0x0400108C RID: 4236
	public bool m_IsSnappingHorizontally;

	// Token: 0x0400108D RID: 4237
	private float m_StartPosX;

	// Token: 0x0400108E RID: 4238
	private float m_LastPosX;

	// Token: 0x0400108F RID: 4239
	private float m_StartPosY;

	// Token: 0x04001090 RID: 4240
	private float m_LastPosY;

	// Token: 0x04001091 RID: 4241
	public float m_DragRatioX;

	// Token: 0x04001092 RID: 4242
	public float m_DragRatioY;

	// Token: 0x04001093 RID: 4243
	public float m_FreeDragRatioX;

	// Token: 0x04001094 RID: 4244
	public float m_FreeDragRatioY;

	// Token: 0x04001095 RID: 4245
	private float m_FreeLastPosX;

	// Token: 0x04001096 RID: 4246
	private float m_FreeLastPosY;

	// Token: 0x04001097 RID: 4247
	private float m_ScreenWidth;

	// Token: 0x04001098 RID: 4248
	private float m_ScreenHeight;

	// Token: 0x04001099 RID: 4249
	public Vector2 m_ReleasePos;

	// Token: 0x0400109A RID: 4250
	private float m_QuickSwipeTimer;

	// Token: 0x0400109B RID: 4251
	public float m_LerpSpeed = 5f;

	// Token: 0x0400109C RID: 4252
	public float m_TargetLerpSpeed = 5f;

	// Token: 0x0400109D RID: 4253
	public float m_DefaultLerpSpeed = 7f;

	// Token: 0x0400109E RID: 4254
	public bool m_AllowButtonPress = true;

	// Token: 0x0400109F RID: 4255
	private float m_AllowButtonPressTimer;
}
