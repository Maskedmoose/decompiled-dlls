﻿using System;
using I2.Loc;
using TMPro;

// Token: 0x0200005F RID: 95
public class ConfirmSellShelfScreen : UIScreenBase
{
	// Token: 0x06000432 RID: 1074 RVA: 0x00024A54 File Offset: 0x00022C54
	protected override void OnOpenScreen()
	{
		SoundManager.GenericMenuOpen(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(true);
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		base.OnOpenScreen();
	}

	// Token: 0x06000433 RID: 1075 RVA: 0x00024A85 File Offset: 0x00022C85
	protected override void OnCloseScreen()
	{
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(false);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
		SoundManager.GenericMenuClose(1f, 1f);
		base.OnCloseScreen();
	}

	// Token: 0x06000434 RID: 1076 RVA: 0x00024AB8 File Offset: 0x00022CB8
	public void SetFurnitureData(FurniturePurchaseData data)
	{
		string text = LocalizationManager.GetTranslation(this.m_Text, true, 0, true, false, null, null, true).Replace("XXX", data.GetName());
		text = text.Replace("YYY", GameInstance.GetPriceString(data.price / 2f, false, true, false, "F2"));
		this.m_DisplayText.text = text;
	}

	// Token: 0x06000435 RID: 1077 RVA: 0x00024B19 File Offset: 0x00022D19
	public void OnPressConfirmBtn()
	{
		SoundManager.GenericConfirm(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.ConfirmSellFurniture();
		base.CloseScreen();
	}

	// Token: 0x06000436 RID: 1078 RVA: 0x00024B3A File Offset: 0x00022D3A
	public void OnPressCancelBtn()
	{
		SoundManager.GenericCancel(1f, 1f);
		base.CloseScreen();
	}

	// Token: 0x0400050A RID: 1290
	public TextMeshProUGUI m_DisplayText;

	// Token: 0x0400050B RID: 1291
	public string m_Text = "Are you sure about selling XXX for YYY?";
}
