﻿using System;

// Token: 0x020000D0 RID: 208
public class CEventPlayer_OnOpenCardPack : CEvent
{
	// Token: 0x1700002B RID: 43
	// (get) Token: 0x0600074D RID: 1869 RVA: 0x0003833F File Offset: 0x0003653F
	// (set) Token: 0x0600074E RID: 1870 RVA: 0x00038347 File Offset: 0x00036547
	public int m_PackIndex { get; private set; }

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x0600074F RID: 1871 RVA: 0x00038350 File Offset: 0x00036550
	// (set) Token: 0x06000750 RID: 1872 RVA: 0x00038358 File Offset: 0x00036558
	public int m_Amount { get; private set; }

	// Token: 0x06000751 RID: 1873 RVA: 0x00038361 File Offset: 0x00036561
	public CEventPlayer_OnOpenCardPack(int packIndex, int amount)
	{
		this.m_PackIndex = packIndex;
		this.m_Amount = amount;
	}
}
