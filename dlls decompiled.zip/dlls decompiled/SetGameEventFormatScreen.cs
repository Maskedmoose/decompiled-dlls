﻿using System;
using I2.Loc;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200007D RID: 125
public class SetGameEventFormatScreen : UIScreenBase
{
	// Token: 0x060004F2 RID: 1266 RVA: 0x0002A967 File Offset: 0x00028B67
	protected override void OnOpenScreen()
	{
		base.OnOpenScreen();
		this.m_CurrentFormatIndex = (int)CPlayerData.m_GameEventFormat;
		if (CPlayerData.m_PendingGameEventFormat != EGameEventFormat.None)
		{
			this.m_CurrentFormatIndex = (int)CPlayerData.m_PendingGameEventFormat;
		}
		this.EvaluateText((EGameEventFormat)this.m_CurrentFormatIndex);
	}

	// Token: 0x060004F3 RID: 1267 RVA: 0x0002A999 File Offset: 0x00028B99
	protected override void OnCloseScreen()
	{
		base.OnCloseScreen();
	}

	// Token: 0x060004F4 RID: 1268 RVA: 0x0002A9A1 File Offset: 0x00028BA1
	public void OnPressConfirmBtn()
	{
		CPlayerData.m_PendingGameEventFormat = (EGameEventFormat)this.m_CurrentFormatIndex;
		SoundManager.GenericConfirm(1f, 1f);
		base.CloseScreen();
	}

	// Token: 0x060004F5 RID: 1269 RVA: 0x0002A9C3 File Offset: 0x00028BC3
	public void OnPressCancelBtn()
	{
		SoundManager.GenericCancel(1f, 1f);
		base.CloseScreen();
	}

	// Token: 0x060004F6 RID: 1270 RVA: 0x0002A9DA File Offset: 0x00028BDA
	public void OnPressNextEventSelect()
	{
		if (this.m_CurrentFormatIndex < 11)
		{
			SoundManager.GenericLightTap(1f, 1f);
			this.m_CurrentFormatIndex++;
			this.EvaluateText((EGameEventFormat)this.m_CurrentFormatIndex);
		}
	}

	// Token: 0x060004F7 RID: 1271 RVA: 0x0002AA0F File Offset: 0x00028C0F
	public void OnPressPreviousEventSelect()
	{
		if (this.m_CurrentFormatIndex > 0)
		{
			SoundManager.GenericLightTap(1f, 1f);
			this.m_CurrentFormatIndex--;
			this.EvaluateText((EGameEventFormat)this.m_CurrentFormatIndex);
		}
	}

	// Token: 0x060004F8 RID: 1272 RVA: 0x0002AA44 File Offset: 0x00028C44
	private void EvaluateText(EGameEventFormat gameEventFormat)
	{
		GameEventData gameEventData = InventoryBase.GetGameEventData(gameEventFormat);
		this.m_IsFormatUnlocked = false;
		int customerPlayed = CPlayerData.m_GameReportDataCollectPermanent.customerPlayed;
		int unlockPlayCountRequired = gameEventData.unlockPlayCountRequired;
		if (customerPlayed >= unlockPlayCountRequired)
		{
			this.m_IsFormatUnlocked = true;
			this.m_LockedGrp.SetActive(false);
			this.m_ConfirmButton.interactable = true;
		}
		else
		{
			this.m_PlayCountRequired.text = customerPlayed.ToString() + "/" + unlockPlayCountRequired.ToString();
			this.m_LockedGrp.SetActive(true);
			this.m_ConfirmButton.interactable = false;
		}
		this.m_FormatText.text = gameEventData.GetName();
		this.m_CostText.text = string.Concat(new string[]
		{
			LocalizationManager.GetTranslation(this.m_CostPrefix, true, 0, true, false, null, null, true),
			" : ",
			GameInstance.GetPriceString((float)gameEventData.hostEventCost, false, true, false, "F2"),
			"/",
			LocalizationManager.GetTranslation(this.m_CostSuffix, true, 0, true, false, null, null, true)
		});
		this.m_FeeText.text = LocalizationManager.GetTranslation(this.m_FeePrefix, true, 0, true, false, null, null, true) + " : " + GameInstance.GetPriceString(PriceChangeManager.GetGameEventPrice(gameEventFormat, true), false, true, false, "F2") + LocalizationManager.GetTranslation(this.m_FeeSuffix, true, 0, true, false, null, null, true);
		this.m_PositiveEffectText.text = "(+) " + InventoryBase.GetPriceChangeTypeText(gameEventData.positivePriceChangeType, true);
		this.m_NegativeEffectText.text = "(-) " + InventoryBase.GetPriceChangeTypeText(gameEventData.negativePriceChangeType, false);
		this.m_NextButton.interactable = (this.m_CurrentFormatIndex < 11);
		this.m_PreviousButton.interactable = (this.m_CurrentFormatIndex > 0);
	}

	// Token: 0x04000685 RID: 1669
	public GameObject m_LockedGrp;

	// Token: 0x04000686 RID: 1670
	public Button m_ConfirmButton;

	// Token: 0x04000687 RID: 1671
	public Button m_PreviousButton;

	// Token: 0x04000688 RID: 1672
	public Button m_NextButton;

	// Token: 0x04000689 RID: 1673
	public TextMeshProUGUI m_PlayCountRequired;

	// Token: 0x0400068A RID: 1674
	public TextMeshProUGUI m_FeeText;

	// Token: 0x0400068B RID: 1675
	public TextMeshProUGUI m_FormatText;

	// Token: 0x0400068C RID: 1676
	public TextMeshProUGUI m_CostText;

	// Token: 0x0400068D RID: 1677
	public TextMeshProUGUI m_PositiveEffectText;

	// Token: 0x0400068E RID: 1678
	public TextMeshProUGUI m_NegativeEffectText;

	// Token: 0x0400068F RID: 1679
	private string m_FeePrefix = "Market Fee";

	// Token: 0x04000690 RID: 1680
	private string m_FormatPrefix = "Format";

	// Token: 0x04000691 RID: 1681
	private string m_CostPrefix = "Cost";

	// Token: 0x04000692 RID: 1682
	private string m_FeeSuffix = "hr";

	// Token: 0x04000693 RID: 1683
	private string m_CostSuffix = "day";

	// Token: 0x04000694 RID: 1684
	private int m_CurrentFormatIndex;

	// Token: 0x04000695 RID: 1685
	private bool m_IsFormatUnlocked;
}
