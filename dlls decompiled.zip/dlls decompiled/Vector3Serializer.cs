﻿using System;
using UnityEngine;

// Token: 0x020000A2 RID: 162
[Serializable]
public struct Vector3Serializer
{
	// Token: 0x0600069B RID: 1691 RVA: 0x00036C7D File Offset: 0x00034E7D
	public void SetData(Vector3 v3)
	{
		this.x = v3.x;
		this.y = v3.y;
		this.z = v3.z;
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x0600069C RID: 1692 RVA: 0x00036CA3 File Offset: 0x00034EA3
	public Vector3 Data
	{
		get
		{
			return new Vector3(this.x, this.y, this.z);
		}
	}

	// Token: 0x040008CE RID: 2254
	public float x;

	// Token: 0x040008CF RID: 2255
	public float y;

	// Token: 0x040008D0 RID: 2256
	public float z;
}
