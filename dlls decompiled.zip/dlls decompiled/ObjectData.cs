﻿using System;
using I2.Loc;

// Token: 0x02000130 RID: 304
[Serializable]
public class ObjectData
{
	// Token: 0x060008E2 RID: 2274 RVA: 0x00041236 File Offset: 0x0003F436
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true);
	}

	// Token: 0x040010D4 RID: 4308
	public string name;

	// Token: 0x040010D5 RID: 4309
	public EObjectType objectType;

	// Token: 0x040010D6 RID: 4310
	public InteractableObject spawnPrefab;
}
