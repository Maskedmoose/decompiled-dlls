﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200011E RID: 286
public class TouchKeyboardManager : CSingleton<TouchKeyboardManager>
{
	// Token: 0x0600085A RID: 2138 RVA: 0x0003E6FC File Offset: 0x0003C8FC
	public static bool StartInput(string startText, int maxLength, bool IsHidden = false, bool doSpecialCharacterCheck = true)
	{
		if (TouchKeyboardManager.m_IsWaitingInput)
		{
			return false;
		}
		if (TouchKeyboardManager.gt == null)
		{
			TouchKeyboardManager.gt = CSingleton<TouchKeyboardManager>.Instance.gameObject.AddComponent<TextMeshProUGUI>();
		}
		TouchKeyboardManager.m_IsWaitingInput = true;
		TouchKeyboardManager.m_DoSpecialCharacterCheck = doSpecialCharacterCheck;
		if (startText == null)
		{
			startText = "";
		}
		TouchKeyboardManager.gt.text = startText;
		if (maxLength == 0)
		{
			TouchKeyboardManager.m_MaxLength = 1000;
		}
		else
		{
			TouchKeyboardManager.m_MaxLength = maxLength;
		}
		TouchKeyboardManager.inputText = startText;
		TouchKeyboardManager.touchScreenKeyboard = TouchScreenKeyboard.Open(TouchKeyboardManager.inputText, TouchScreenKeyboardType.ASCIICapable, false, false, IsHidden);
		return TouchKeyboardManager.touchScreenKeyboard != null;
	}

	// Token: 0x0600085B RID: 2139 RVA: 0x0003E78C File Offset: 0x0003C98C
	public static void CancelInput()
	{
		TouchKeyboardManager.touchScreenKeyboard = null;
		TouchKeyboardManager.m_IsWaitingInput = false;
	}

	// Token: 0x0600085C RID: 2140 RVA: 0x0003E79A File Offset: 0x0003C99A
	private void Update()
	{
		if (TouchKeyboardManager.touchScreenKeyboard == null)
		{
			return;
		}
		this.DetectPCInput();
		this.DetectMobileInput();
	}

	// Token: 0x0600085D RID: 2141 RVA: 0x0003E7B0 File Offset: 0x0003C9B0
	private void DetectMobileInput()
	{
		if (!Application.isMobilePlatform)
		{
			return;
		}
		TouchKeyboardManager.inputText = TouchKeyboardManager.touchScreenKeyboard.text;
		if (TouchKeyboardManager.inputText.Length > TouchKeyboardManager.m_MaxLength)
		{
			TouchKeyboardManager.inputText = TouchKeyboardManager.inputText.Substring(0, TouchKeyboardManager.m_MaxLength);
		}
		if (TouchKeyboardManager.touchScreenKeyboard.status == TouchScreenKeyboard.Status.Done || TouchKeyboardManager.touchScreenKeyboard.status == TouchScreenKeyboard.Status.LostFocus)
		{
			string text = TouchKeyboardManager.inputText;
			if (text != null && text != "" && TouchKeyboardManager.m_DoSpecialCharacterCheck)
			{
				text = text.Replace('_', ' ');
				text = text.Replace(',', ' ');
				text = text.Replace('`', ' ');
			}
			Debug.Log("User typed in " + text);
			CEventManager.QueueEvent(new CEventPlayer_WaitForKeyboardInput(text));
			TouchKeyboardManager.touchScreenKeyboard = null;
			TouchKeyboardManager.m_IsWaitingInput = false;
			return;
		}
		if (TouchKeyboardManager.touchScreenKeyboard.status == TouchScreenKeyboard.Status.Canceled)
		{
			CEventManager.QueueEvent(new CEventPlayer_WaitForKeyboardInput(""));
			TouchKeyboardManager.touchScreenKeyboard = null;
			TouchKeyboardManager.m_IsWaitingInput = false;
		}
	}

	// Token: 0x0600085E RID: 2142 RVA: 0x0003E8A4 File Offset: 0x0003CAA4
	private void DetectPCInput()
	{
		if (Application.isMobilePlatform)
		{
			return;
		}
		Debug.Log(TouchKeyboardManager.gt.text);
		foreach (char c in Input.inputString)
		{
			if (c == '\b')
			{
				if (TouchKeyboardManager.gt.text.Length != 0)
				{
				}
			}
			else if (c == '\n' || c == '\r')
			{
				string text = TouchKeyboardManager.gt.text;
				if (text != null && text != "" && TouchKeyboardManager.m_DoSpecialCharacterCheck)
				{
					text = text.Replace('_', ' ');
					text = text.Replace(',', ' ');
					text = text.Replace('`', ' ');
				}
				Debug.Log("User typed in " + text);
				CEventManager.QueueEvent(new CEventPlayer_WaitForKeyboardInput(text));
				TouchKeyboardManager.touchScreenKeyboard = null;
				TouchKeyboardManager.m_IsWaitingInput = false;
			}
			else
			{
				TextMeshProUGUI textMeshProUGUI = TouchKeyboardManager.gt;
				textMeshProUGUI.text += c.ToString();
			}
		}
	}

	// Token: 0x0400101D RID: 4125
	private static TouchScreenKeyboard touchScreenKeyboard;

	// Token: 0x0400101E RID: 4126
	private static string inputText = string.Empty;

	// Token: 0x0400101F RID: 4127
	private static int m_MaxLength = 1000;

	// Token: 0x04001020 RID: 4128
	private static TextMeshProUGUI gt;

	// Token: 0x04001021 RID: 4129
	private static bool m_IsWaitingInput;

	// Token: 0x04001022 RID: 4130
	private static bool m_DoSpecialCharacterCheck = true;
}
