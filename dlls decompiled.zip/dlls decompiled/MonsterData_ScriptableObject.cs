﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200012C RID: 300
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 5)]
public class MonsterData_ScriptableObject : ScriptableObject
{
	// Token: 0x060008D4 RID: 2260 RVA: 0x000410B0 File Offset: 0x0003F2B0
	public MonsterData GetMonsterData(string monsterType)
	{
		for (int i = 0; i < this.m_DataList.Count; i++)
		{
			if (this.m_DataList[i].MonsterType.ToString() == monsterType)
			{
				return this.m_DataList[i];
			}
		}
		return this.m_DataList[0];
	}

	// Token: 0x060008D5 RID: 2261 RVA: 0x00041110 File Offset: 0x0003F310
	public Color GetRarityColor(ERarity rarity)
	{
		return this.m_RarityColor[(int)rarity];
	}

	// Token: 0x060008D6 RID: 2262 RVA: 0x0004111E File Offset: 0x0003F31E
	public Sprite GetCardBorderSprite(ERarity rarity)
	{
		return this.m_CardBorderList[(int)rarity];
	}

	// Token: 0x060008D7 RID: 2263 RVA: 0x0004112C File Offset: 0x0003F32C
	public Sprite GetCardBGSprite(EElementIndex element)
	{
		if (element == EElementIndex.None)
		{
			return null;
		}
		return this.m_CardBGList[(int)element];
	}

	// Token: 0x060008D8 RID: 2264 RVA: 0x00041140 File Offset: 0x0003F340
	public Sprite GetCardFrontSprite(EElementIndex elementIndex)
	{
		return this.m_CardFrontImageList[(int)elementIndex];
	}

	// Token: 0x060008D9 RID: 2265 RVA: 0x0004114E File Offset: 0x0003F34E
	public Sprite GetCardBackSprite(ECardExpansionType cardExpansionType)
	{
		return this.m_CardBackImageList[(int)cardExpansionType];
	}

	// Token: 0x060008DA RID: 2266 RVA: 0x0004115C File Offset: 0x0003F35C
	public Sprite GetCardFoilMaskSprite(ECardExpansionType cardExpansionType)
	{
		return this.m_CardFoilMaskImageList[(int)cardExpansionType];
	}

	// Token: 0x040010AD RID: 4269
	public List<EMonsterType> m_ShownMonsterList;

	// Token: 0x040010AE RID: 4270
	public List<EMonsterType> m_ShownGhostMonsterList;

	// Token: 0x040010AF RID: 4271
	public List<EMonsterType> m_ShownMegabotList;

	// Token: 0x040010B0 RID: 4272
	public List<EMonsterType> m_ShownFantasyRPGList;

	// Token: 0x040010B1 RID: 4273
	public List<EMonsterType> m_ShownCatJobList;

	// Token: 0x040010B2 RID: 4274
	public List<MonsterData> m_DataList;

	// Token: 0x040010B3 RID: 4275
	public List<MonsterData> m_MegabotDataList;

	// Token: 0x040010B4 RID: 4276
	public List<MonsterData> m_FantasyRPGDataList;

	// Token: 0x040010B5 RID: 4277
	public List<MonsterData> m_CatJobDataList;

	// Token: 0x040010B6 RID: 4278
	public List<Color> m_RarityColor;

	// Token: 0x040010B7 RID: 4279
	public List<Sprite> m_CardBorderList;

	// Token: 0x040010B8 RID: 4280
	public List<Sprite> m_CardBGList;

	// Token: 0x040010B9 RID: 4281
	public List<Sprite> m_CardFrontImageList;

	// Token: 0x040010BA RID: 4282
	public List<Sprite> m_CardBackImageList;

	// Token: 0x040010BB RID: 4283
	public List<Sprite> m_CardFoilMaskImageList;

	// Token: 0x040010BC RID: 4284
	public List<CardUISetting> m_CardUISettingList;

	// Token: 0x040010BD RID: 4285
	public List<Sprite> m_TetramonImageList;

	// Token: 0x040010BE RID: 4286
	public List<MonsterData> m_SpecialCardImageList;
}
