﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000052 RID: 82
public class ShelfMoveStateValidArea : MonoBehaviour
{
	// Token: 0x04000495 RID: 1173
	public bool m_CanSnap = true;

	// Token: 0x04000496 RID: 1174
	public List<Transform> m_SnapLocList;
}
