﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000046 RID: 70
public class Shelf : InteractableObject
{
	// Token: 0x0600035F RID: 863 RVA: 0x0001E941 File Offset: 0x0001CB41
	protected override void Awake()
	{
		base.Awake();
		ShelfManager.InitShelf(this);
	}

	// Token: 0x06000360 RID: 864 RVA: 0x0001E950 File Offset: 0x0001CB50
	public override void Init()
	{
		if (this.m_HasInit)
		{
			return;
		}
		base.Init();
		for (int i = 0; i < this.m_ShelfCompartmentGrpList.Count; i++)
		{
			for (int j = 0; j < this.m_ShelfCompartmentGrpList[i].childCount; j++)
			{
				this.m_ItemCompartmentList.Add(this.m_ShelfCompartmentGrpList[i].GetChild(j).GetComponent<ShelfCompartment>());
			}
		}
		this.m_Shelf_WorldUIGrp = PriceTagUISpawner.SpawnShelfWorldUIGrp(base.transform);
		for (int k = 0; k < this.m_ItemCompartmentList.Count; k++)
		{
			this.m_ItemCompartmentList[k].m_ItemNotForSale = this.m_ItemNotForSale;
			this.m_ItemCompartmentList[k].InitShelf(this);
			if (!this.m_ItemNotForSale)
			{
				for (int l = 0; l < this.m_ItemCompartmentList[k].m_InteractablePriceTagList.Count; l++)
				{
					UI_PriceTag ui_PriceTag = PriceTagUISpawner.SpawnPriceTagWorldUIGrp(this.m_Shelf_WorldUIGrp, this.m_ItemCompartmentList[k].m_InteractablePriceTagList[l].transform);
					this.m_UIPriceTagList.Add(ui_PriceTag);
					this.m_ItemCompartmentList[k].m_InteractablePriceTagList[l].SetPriceTagUI(ui_PriceTag);
					this.m_ItemCompartmentList[k].m_InteractablePriceTagList[l].SetVisibility(false);
				}
			}
		}
	}

	// Token: 0x06000361 RID: 865 RVA: 0x0001EAB8 File Offset: 0x0001CCB8
	protected override void LateUpdate()
	{
		base.LateUpdate();
		if (this.m_IsMovingObject && this.m_Shelf_WorldUIGrp)
		{
			this.m_Shelf_WorldUIGrp.transform.position = base.transform.position;
			this.m_Shelf_WorldUIGrp.transform.rotation = base.transform.rotation;
		}
	}

	// Token: 0x06000362 RID: 866 RVA: 0x0001EB16 File Offset: 0x0001CD16
	public override void OnDestroyed()
	{
		ShelfManager.RemoveShelf(this);
		base.OnDestroyed();
	}

	// Token: 0x06000363 RID: 867 RVA: 0x0001EB24 File Offset: 0x0001CD24
	protected override void OnPlacedMovedObject()
	{
		base.OnPlacedMovedObject();
	}

	// Token: 0x06000364 RID: 868 RVA: 0x0001EB2C File Offset: 0x0001CD2C
	public override void BoxUpObject(bool holdBox)
	{
		base.BoxUpObject(holdBox);
	}

	// Token: 0x06000365 RID: 869 RVA: 0x0001EB38 File Offset: 0x0001CD38
	public bool HasEmptyItemSlotOnShelf()
	{
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (this.m_ItemCompartmentList[i].GetItemType() == EItemType.None)
			{
				return true;
			}
			if (this.m_ItemCompartmentList[i].GetItemCount() < this.m_ItemCompartmentList[i].GetMaxItemCount())
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000366 RID: 870 RVA: 0x0001EB98 File Offset: 0x0001CD98
	public bool HasItemOnShelf()
	{
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (this.m_ItemCompartmentList[i].GetItemCount() > 0)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000367 RID: 871 RVA: 0x0001EBD4 File Offset: 0x0001CDD4
	public bool HasItemTypeOnShelf(List<EItemType> itemTypeList)
	{
		if (itemTypeList == null || itemTypeList.Count == 0)
		{
			return true;
		}
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (itemTypeList.Contains(this.m_ItemCompartmentList[i].GetItemType()))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000368 RID: 872 RVA: 0x0001EC20 File Offset: 0x0001CE20
	public ShelfCompartment GetNonFullItemCompartment(EItemType itemType, bool ignoreNoneType = false)
	{
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (!ignoreNoneType && (this.m_ItemCompartmentList[i].GetItemType() == EItemType.None || this.m_ItemCompartmentList[i].GetItemCount() == 0))
			{
				return this.m_ItemCompartmentList[i];
			}
			if (this.m_ItemCompartmentList[i].GetItemType() == itemType && this.m_ItemCompartmentList[i].GetItemCount() < this.m_ItemCompartmentList[i].GetMaxItemCount())
			{
				return this.m_ItemCompartmentList[i];
			}
		}
		return null;
	}

	// Token: 0x06000369 RID: 873 RVA: 0x0001ECC8 File Offset: 0x0001CEC8
	public List<ShelfCompartment> GetNonFullItemCompartmentList(EItemType itemType, bool ignoreNoneType = false)
	{
		List<ShelfCompartment> list = new List<ShelfCompartment>();
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (!ignoreNoneType && (this.m_ItemCompartmentList[i].GetItemType() == EItemType.None || this.m_ItemCompartmentList[i].GetItemCount() == 0))
			{
				list.Add(this.m_ItemCompartmentList[i]);
			}
			else if (this.m_ItemCompartmentList[i].GetItemType() == itemType && this.m_ItemCompartmentList[i].GetItemCount() < this.m_ItemCompartmentList[i].GetMaxItemCount())
			{
				list.Add(this.m_ItemCompartmentList[i]);
			}
		}
		return list;
	}

	// Token: 0x0600036A RID: 874 RVA: 0x0001ED80 File Offset: 0x0001CF80
	public ShelfCompartment GetCustomerTargetItemCompartment(List<EItemType> targetBuyItemList)
	{
		List<int> list = new List<int>();
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (this.m_ItemCompartmentList[i].GetItemCount() > 0 && (targetBuyItemList == null || targetBuyItemList.Count == 0 || targetBuyItemList.Contains(this.m_ItemCompartmentList[i].GetItemType())))
			{
				list.Add(i);
			}
		}
		if (list.Count > 0)
		{
			int index = list[Random.Range(0, list.Count)];
			return this.m_ItemCompartmentList[index];
		}
		return this.m_ItemCompartmentList[Random.Range(0, this.m_ItemCompartmentList.Count)];
	}

	// Token: 0x0600036B RID: 875 RVA: 0x0001EE2D File Offset: 0x0001D02D
	public List<ShelfCompartment> GetItemCompartmentList()
	{
		return this.m_ItemCompartmentList;
	}

	// Token: 0x0600036C RID: 876 RVA: 0x0001EE38 File Offset: 0x0001D038
	public void LoadItemCompartment(List<ItemTypeAmount> itemTypeAmountList)
	{
		int num = 0;
		while (num < this.m_ItemCompartmentList.Count && num < itemTypeAmountList.Count)
		{
			this.m_ItemCompartmentList[num].SetCompartmentItemType(itemTypeAmountList[num].itemType);
			this.m_ItemCompartmentList[num].CalculatePositionList();
			this.m_ItemCompartmentList[num].SpawnItem(itemTypeAmountList[num].amount, true);
			num++;
		}
	}

	// Token: 0x04000402 RID: 1026
	public bool m_ItemNotForSale;

	// Token: 0x04000403 RID: 1027
	public List<Transform> m_ShelfCompartmentGrpList;

	// Token: 0x04000404 RID: 1028
	public List<UI_PriceTag> m_UIPriceTagList = new List<UI_PriceTag>();
}
