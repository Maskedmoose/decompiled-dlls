﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200011C RID: 284
public class CRaycastTouch : MonoBehaviour
{
	// Token: 0x0600084F RID: 2127 RVA: 0x0003E220 File Offset: 0x0003C420
	private void Update()
	{
		if (this.m_MouseDown && Input.GetMouseButtonUp(0))
		{
			this.m_MouseDownTime = 0f;
			this.m_MouseDown = false;
			this.m_FirstRayCast = false;
			Vector3 vector = Input.mousePosition - this.m_MouseStartPos;
			CEventManager.QueueEvent(new CEventPlayer_TouchReleased(new Vector3(vector.x / (float)Screen.width, vector.y / (float)Screen.height, 0f)));
		}
		if (this.m_MouseDown)
		{
			if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
			{
				foreach (Touch touch in Input.touches)
				{
					if (touch.fingerId == 0 && (touch.phase == TouchPhase.Moved || touch.phase == TouchPhase.Began))
					{
						this.EvaluateRaycast(touch.position);
						this.m_MouseCurrentPos = touch.position;
					}
				}
				return;
			}
			this.EvaluateRaycast(Input.mousePosition);
			this.m_MouseCurrentPos = Input.mousePosition;
		}
	}

	// Token: 0x06000850 RID: 2128 RVA: 0x0003E324 File Offset: 0x0003C524
	private Vector3 CalculateMouseSpeed()
	{
		Vector3 result = Vector3.zero;
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			foreach (Touch touch in Input.touches)
			{
				if (touch.fingerId == 0)
				{
					Vector3 b = new Vector3(touch.position.x, touch.position.y, 0f);
					result = this.m_MouseCurrentPos - b;
				}
			}
		}
		else
		{
			result = this.m_MouseCurrentPos - Input.mousePosition;
		}
		return result;
	}

	// Token: 0x06000851 RID: 2129 RVA: 0x0003E3B4 File Offset: 0x0003C5B4
	private void EvaluateRaycast(Vector2 InputPosition)
	{
		if (!this.m_FirstRayCast)
		{
			this.m_FirstRayCast = true;
			this.ray = Camera.main.ScreenPointToRay(InputPosition);
			if (Physics.Raycast(this.ray, out this.hit))
			{
				if (this.hit.transform.root.tag == "Prop")
				{
					this.m_ObjectRootHit = this.hit.transform.root;
					this.TouchedProp(this.m_ObjectRootHit);
				}
				else if (this.hit.transform.tag == "CatFollow")
				{
					this.m_ObjectRootHit = this.hit.transform;
					this.TouchedProp(this.m_ObjectRootHit);
				}
				else if (this.hit.transform.tag == "Coin")
				{
					this.TouchedProp(this.hit.transform);
				}
			}
		}
		RaycastHit raycastHit;
		if (Physics.Raycast(Camera.main.ScreenPointToRay(InputPosition), out raycastHit) && raycastHit.transform.tag == "Coin")
		{
			this.TouchedProp(raycastHit.transform);
		}
	}

	// Token: 0x06000852 RID: 2130 RVA: 0x0003E4EA File Offset: 0x0003C6EA
	private void TouchedProp(Transform objectHitRoot)
	{
		objectHitRoot.SendMessage("RaycastHit");
	}

	// Token: 0x06000853 RID: 2131 RVA: 0x0003E4F8 File Offset: 0x0003C6F8
	private bool IsMouseMove()
	{
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			Vector3 vector = default(Vector3);
			foreach (Touch touch in Input.touches)
			{
				if (touch.fingerId == 0 && touch.phase == TouchPhase.Moved)
				{
					vector = touch.position - this.m_LastMouseCoordinate;
					this.m_LastMouseCoordinate = touch.position;
				}
				else if (touch.fingerId == 1 && touch.phase == TouchPhase.Moved)
				{
					vector = touch.position - this.m_LastMouseCoordinate;
					this.m_LastMouseCoordinate = touch.position;
				}
			}
			if (vector.x < 0f || vector.x > 0f)
			{
				return true;
			}
		}
		else
		{
			Vector3 vector2 = Input.mousePosition - this.m_LastMouseCoordinate;
			this.m_LastMouseCoordinate = Input.mousePosition;
			if (vector2.x < 0f || vector2.x > 0f)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000854 RID: 2132 RVA: 0x0003E618 File Offset: 0x0003C818
	public void TouchScreenButton()
	{
		if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer)
		{
			if (Input.touchCount == 1)
			{
				this.m_MouseDown = true;
				this.m_ObjectRootHit = null;
				CEventManager.QueueEvent(new CEventPlayer_TouchScreen());
				this.m_MouseStartPos = Input.mousePosition;
				return;
			}
		}
		else
		{
			this.m_MouseDown = true;
			this.m_ObjectRootHit = null;
			CEventManager.QueueEvent(new CEventPlayer_TouchScreen());
			this.m_MouseStartPos = Input.mousePosition;
		}
	}

	// Token: 0x0400100E RID: 4110
	private RaycastHit hit;

	// Token: 0x0400100F RID: 4111
	private Ray ray;

	// Token: 0x04001010 RID: 4112
	private bool m_MouseDown;

	// Token: 0x04001011 RID: 4113
	private bool m_FirstRayCast;

	// Token: 0x04001012 RID: 4114
	private Vector3 m_MouseStartPos;

	// Token: 0x04001013 RID: 4115
	private Vector3 m_MouseCurrentPos;

	// Token: 0x04001014 RID: 4116
	private Vector3 m_LastMouseCoordinate = Vector3.zero;

	// Token: 0x04001015 RID: 4117
	private Transform m_ObjectRootHit;

	// Token: 0x04001016 RID: 4118
	private float m_MouseDownTime;

	// Token: 0x04001017 RID: 4119
	public Text m_Text;
}
