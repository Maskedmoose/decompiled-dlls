﻿using System;
using UnityEngine;

// Token: 0x02000032 RID: 50
[Serializable]
public class ItemMeshData
{
	// Token: 0x0400030C RID: 780
	public string name;

	// Token: 0x0400030D RID: 781
	public Mesh mesh;

	// Token: 0x0400030E RID: 782
	public Material material;

	// Token: 0x0400030F RID: 783
	public Mesh meshSecondary;

	// Token: 0x04000310 RID: 784
	public Material materialSecondary;
}
