﻿using System;

// Token: 0x020000FF RID: 255
public enum ESpecialNPCType
{
	// Token: 0x04000E9A RID: 3738
	None = -1,
	// Token: 0x04000E9B RID: 3739
	LoanItem,
	// Token: 0x04000E9C RID: 3740
	CustomerTradeCard
}
