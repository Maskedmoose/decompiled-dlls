﻿using System;

// Token: 0x02000062 RID: 98
[Serializable]
public struct GameReportDataCollect
{
	// Token: 0x06000442 RID: 1090 RVA: 0x00024ED8 File Offset: 0x000230D8
	public void CopyData(GameReportDataCollect data)
	{
		this.customerVisited = data.customerVisited;
		this.checkoutCount = data.checkoutCount;
		this.customerDisatisfied = data.customerDisatisfied;
		this.customerBoughtItem = data.customerBoughtItem;
		this.customerBoughtCard = data.customerBoughtCard;
		this.customerPlayed = data.customerPlayed;
		this.storeExpGained = data.storeExpGained;
		this.storeLevelGained = data.storeLevelGained;
		this.itemAmountSold = data.itemAmountSold;
		this.cardAmountSold = data.cardAmountSold;
		this.totalPlayTableTime = data.totalPlayTableTime;
		this.totalItemEarning = data.totalItemEarning;
		this.totalCardEarning = data.totalCardEarning;
		this.totalPlayTableEarning = data.totalPlayTableEarning;
		this.supplyCost = data.supplyCost;
		this.upgradeCost = data.upgradeCost;
		this.employeeCost = data.employeeCost;
		this.rentCost = data.rentCost;
		this.billCost = data.billCost;
		this.cardPackOpened = data.cardPackOpened;
		this.smellyCustomerCleaned = data.smellyCustomerCleaned;
		this.manualCheckoutCount = data.manualCheckoutCount;
	}

	// Token: 0x06000443 RID: 1091 RVA: 0x00024FF0 File Offset: 0x000231F0
	public void ResetData()
	{
		this.customerVisited = 0;
		this.checkoutCount = 0;
		this.customerDisatisfied = 0;
		this.customerBoughtItem = 0;
		this.customerBoughtCard = 0;
		this.customerPlayed = 0;
		this.storeExpGained = 0;
		this.storeLevelGained = 0;
		this.itemAmountSold = 0;
		this.cardAmountSold = 0;
		this.totalPlayTableTime = 0f;
		this.totalItemEarning = 0f;
		this.totalCardEarning = 0f;
		this.totalPlayTableEarning = 0f;
		this.supplyCost = 0f;
		this.upgradeCost = 0f;
		this.employeeCost = 0f;
		this.rentCost = 0f;
		this.billCost = 0f;
		this.cardPackOpened = 0;
		this.smellyCustomerCleaned = 0;
		this.manualCheckoutCount = 0;
	}

	// Token: 0x04000517 RID: 1303
	public int customerVisited;

	// Token: 0x04000518 RID: 1304
	public int checkoutCount;

	// Token: 0x04000519 RID: 1305
	public int customerDisatisfied;

	// Token: 0x0400051A RID: 1306
	public int customerBoughtItem;

	// Token: 0x0400051B RID: 1307
	public int customerBoughtCard;

	// Token: 0x0400051C RID: 1308
	public int customerPlayed;

	// Token: 0x0400051D RID: 1309
	public int storeExpGained;

	// Token: 0x0400051E RID: 1310
	public int storeLevelGained;

	// Token: 0x0400051F RID: 1311
	public int itemAmountSold;

	// Token: 0x04000520 RID: 1312
	public int cardAmountSold;

	// Token: 0x04000521 RID: 1313
	public float totalPlayTableTime;

	// Token: 0x04000522 RID: 1314
	public float totalItemEarning;

	// Token: 0x04000523 RID: 1315
	public float totalCardEarning;

	// Token: 0x04000524 RID: 1316
	public float totalPlayTableEarning;

	// Token: 0x04000525 RID: 1317
	public float supplyCost;

	// Token: 0x04000526 RID: 1318
	public float upgradeCost;

	// Token: 0x04000527 RID: 1319
	public float employeeCost;

	// Token: 0x04000528 RID: 1320
	public float rentCost;

	// Token: 0x04000529 RID: 1321
	public float billCost;

	// Token: 0x0400052A RID: 1322
	public int cardPackOpened;

	// Token: 0x0400052B RID: 1323
	public int smellyCustomerCleaned;

	// Token: 0x0400052C RID: 1324
	public int manualCheckoutCount;
}
