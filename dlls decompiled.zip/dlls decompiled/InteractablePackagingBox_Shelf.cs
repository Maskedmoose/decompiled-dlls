﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000025 RID: 37
public class InteractablePackagingBox_Shelf : InteractablePackagingBox
{
	// Token: 0x060001DB RID: 475 RVA: 0x00013DF8 File Offset: 0x00011FF8
	protected override void Awake()
	{
		base.Awake();
		RestockManager.InitShelfPackageBox(this);
	}

	// Token: 0x060001DC RID: 476 RVA: 0x00013E06 File Offset: 0x00012006
	protected override void Update()
	{
		base.Update();
		if (this.m_IsOpeningBox)
		{
			base.transform.position += Vector3.up * Time.deltaTime * -1.2f;
		}
	}

	// Token: 0x060001DD RID: 477 RVA: 0x00013E48 File Offset: 0x00012048
	public void ExecuteBoxUpObject(InteractableObject obj, bool holdBox)
	{
		if (this.m_DelayResetOpenBox != null)
		{
			base.StopCoroutine(this.m_DelayResetOpenBox);
			this.m_IsOpeningBox = false;
			this.m_DelayResetOpenBox = null;
		}
		base.transform.position = obj.transform.position;
		base.transform.rotation = obj.transform.rotation;
		this.m_BoxAnim.Play("Close");
		base.gameObject.SetActive(true);
		this.m_BoxedObject = obj;
		this.m_BoxedObject.gameObject.SetActive(false);
		this.SpawnPriceTag();
		if (holdBox)
		{
			this.m_IsBeingHold = false;
			this.StartHoldBox(true, CSingleton<InteractionPlayerController>.Instance.m_HoldBigItemPos);
			this.SetPriceTagVisibility(false);
			base.StartCoroutine(base.DelaySetPriceTagVisibility(0.85f, true));
		}
	}

	// Token: 0x060001DE RID: 478 RVA: 0x00013F14 File Offset: 0x00012114
	public override void StartHoldBox(bool isPlayer, Transform holdItemPos)
	{
		if (this.m_IsBeingHold)
		{
			return;
		}
		base.StartHoldBox(isPlayer, CSingleton<InteractionPlayerController>.Instance.m_HoldBigItemPos);
		bool isBoxOpened = this.m_IsBoxOpened;
		if (isPlayer)
		{
			InteractionPlayerController.RemoveToolTip(EGameAction.OpenBox);
			InteractionPlayerController.AddToolTip(EGameAction.OpenBox, false, false);
			InteractionPlayerController.RemoveToolTip(EGameAction.SellBoxedUpShelf);
			InteractionPlayerController.AddToolTip(EGameAction.SellBoxedUpShelf, false, false);
			this.m_ItemCompartment.SetIgnoreCull(true);
		}
	}

	// Token: 0x060001DF RID: 479 RVA: 0x00013F71 File Offset: 0x00012171
	public override void ThrowBox(bool isPlayer)
	{
		base.ThrowBox(isPlayer);
		this.m_ItemCompartment.SetIgnoreCull(false);
	}

	// Token: 0x060001E0 RID: 480 RVA: 0x00013F86 File Offset: 0x00012186
	public override void DropBox(bool isPlayer)
	{
		base.DropBox(isPlayer);
		this.m_ItemCompartment.SetIgnoreCull(false);
	}

	// Token: 0x060001E1 RID: 481 RVA: 0x00013F9C File Offset: 0x0001219C
	protected override void SpawnPriceTag()
	{
		if (this.m_IsPriceTagSpawned)
		{
			return;
		}
		this.m_IsPriceTagSpawned = true;
		base.SpawnPriceTag();
		for (int i = 0; i < this.m_ItemCompartment.m_InteractablePriceTagList.Count; i++)
		{
			UI_PriceTag ui_PriceTag = PriceTagUISpawner.SpawnPriceTagPackageBoxWorldUIGrp(this.m_Shelf_WorldUIGrp, this.m_ItemCompartment.m_InteractablePriceTagList[i].transform);
			ui_PriceTag.SetObjectImage(this.m_BoxedObject.m_ObjectType);
			this.m_ItemCompartment.m_InteractablePriceTagList[i].SetPriceTagUI(ui_PriceTag);
			this.m_ItemCompartment.m_InteractablePriceTagList[i].SetVisibility(true);
		}
	}

	// Token: 0x060001E2 RID: 482 RVA: 0x0001403C File Offset: 0x0001223C
	public override void OnPressOpenBox()
	{
		if (this.m_IsOpeningBox)
		{
			return;
		}
		this.m_IsOpeningBox = true;
		this.m_DelayResetOpenBox = base.StartCoroutine(this.DelayResetOpenBox());
		base.OnPressOpenBox();
		if (this.m_BoxedObject)
		{
			this.m_BoxAnim.Play("Open");
			CSingleton<InteractionPlayerController>.Instance.OnExitHoldBoxMode();
			InteractionPlayerController.SetCurrentInteractableObject(this.m_BoxedObject);
			this.m_BoxedObject.transform.position = base.transform.position;
			this.m_BoxedObject.gameObject.SetActive(true);
			this.m_BoxedObject.StartMoveObject();
			this.SetPriceTagVisibility(false);
			SoundManager.PlayAudio("SFX_BoxOpen", 0.5f, 1f);
		}
	}

	// Token: 0x060001E3 RID: 483 RVA: 0x000140F6 File Offset: 0x000122F6
	protected IEnumerator DelayResetOpenBox()
	{
		yield return new WaitForSeconds(0.85f);
		this.m_IsOpeningBox = false;
		base.gameObject.SetActive(false);
		yield break;
	}

	// Token: 0x060001E4 RID: 484 RVA: 0x00014108 File Offset: 0x00012308
	public void SetOpenCloseBox(bool isOpen)
	{
		this.m_IsBoxOpened = isOpen;
		if (!this.m_IsBoxOpened)
		{
			this.m_OpenBox.SetActive(false);
			this.m_ClosedBox.SetActive(true);
			this.SetPriceTagVisibility(true);
			return;
		}
		this.m_OpenBox.SetActive(true);
		this.m_ClosedBox.SetActive(false);
		this.SetPriceTagVisibility(false);
	}

	// Token: 0x060001E5 RID: 485 RVA: 0x00014163 File Offset: 0x00012363
	public void EmptyBoxShelf()
	{
		this.m_BoxedObject = null;
	}

	// Token: 0x060001E6 RID: 486 RVA: 0x0001416C File Offset: 0x0001236C
	public override void OnDestroyed()
	{
		if (this.m_BoxedObject)
		{
			this.m_BoxedObject.gameObject.SetActive(false);
			this.m_BoxedObject.OnDestroyed();
		}
		RestockManager.RemoveShelfPackageBox(this);
		base.OnDestroyed();
	}

	// Token: 0x060001E7 RID: 487 RVA: 0x000141A4 File Offset: 0x000123A4
	protected override void SetPriceTagVisibility(bool isVisible)
	{
		base.SetPriceTagVisibility(isVisible);
		for (int i = 0; i < this.m_ItemCompartment.m_InteractablePriceTagList.Count; i++)
		{
			this.m_ItemCompartment.m_InteractablePriceTagList[i].SetVisibility(isVisible);
		}
	}

	// Token: 0x060001E8 RID: 488 RVA: 0x000141EA File Offset: 0x000123EA
	public EObjectType GetBoxedObjectType()
	{
		return this.m_BoxedObject.m_ObjectType;
	}

	// Token: 0x04000244 RID: 580
	public ShelfCompartment m_ItemCompartment;

	// Token: 0x04000245 RID: 581
	public GameObject m_StaticMeshGrp;

	// Token: 0x04000246 RID: 582
	public GameObject m_RigMeshGrp;

	// Token: 0x04000247 RID: 583
	public GameObject m_ClosedBox;

	// Token: 0x04000248 RID: 584
	public GameObject m_OpenBox;

	// Token: 0x04000249 RID: 585
	private InteractableObject m_BoxedObject;

	// Token: 0x0400024A RID: 586
	private bool m_IsBoxOpened;

	// Token: 0x0400024B RID: 587
	private bool m_IsPriceTagSpawned;

	// Token: 0x0400024C RID: 588
	private bool m_IsOpeningBox;

	// Token: 0x0400024D RID: 589
	private Coroutine m_DelayResetOpenBox;
}
