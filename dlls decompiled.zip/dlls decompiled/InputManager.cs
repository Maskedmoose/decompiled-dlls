﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.DualShock;

// Token: 0x0200011B RID: 283
public class InputManager : CSingleton<InputManager>
{
	// Token: 0x06000823 RID: 2083 RVA: 0x0003C4F8 File Offset: 0x0003A6F8
	private void Awake()
	{
		if (InputManager.m_Instance == null)
		{
			InputManager.m_Instance = this;
		}
		else if (InputManager.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
		this.m_SettingData = CSettingData.instance;
		this.ResetToDefaultKeybind();
		if (CSaveLoad.LoadSetting())
		{
			CSettingData.instance.PropagateLoadSettingData(CSaveLoad.m_SavedSetting);
		}
		for (int i = 0; i < this.m_KeybindBaseKeyListDefault.Count; i++)
		{
			if (i >= InputManager.m_KeybindBaseKeyList.Count || InputManager.m_KeybindBaseKeyList[i] == null || InputManager.m_KeybindBaseKeyList[i].bindKey == KeyCode.None)
			{
				KeybindBaseKey keybindBaseKey = new KeybindBaseKey();
				keybindBaseKey.baseKey = this.m_KeybindBaseKeyListDefault[i].baseKey;
				keybindBaseKey.bindKey = this.m_KeybindBaseKeyListDefault[i].bindKey;
				InputManager.m_KeybindBaseKeyList.Add(keybindBaseKey);
			}
		}
		for (int j = 0; j < this.m_KeybindBaseJoystickCtrlListDefault.Count; j++)
		{
			if (j >= InputManager.m_KeybindBaseJoystickCtrlList.Count || InputManager.m_KeybindBaseJoystickCtrlList[j] == null || InputManager.m_KeybindBaseJoystickCtrlList[j].ctrlBtn == EGamepadControlBtn.None)
			{
				KeybindBaseGamepadControl keybindBaseGamepadControl = new KeybindBaseGamepadControl();
				keybindBaseGamepadControl.baseKey = this.m_KeybindBaseJoystickCtrlListDefault[j].baseKey;
				keybindBaseGamepadControl.ctrlBtn = this.m_KeybindBaseJoystickCtrlListDefault[j].ctrlBtn;
				InputManager.m_KeybindBaseJoystickCtrlList.Add(keybindBaseGamepadControl);
			}
		}
		this.RefreshKeybindBeforeEdit();
	}

	// Token: 0x06000824 RID: 2084 RVA: 0x0003C668 File Offset: 0x0003A868
	public void SetIsControllerDisabledSetting(bool isDisabled)
	{
		if (!this.m_IsContollerDisabled && isDisabled)
		{
			this.SetGamepadControllerActive(false);
		}
		this.m_IsContollerDisabled = isDisabled;
	}

	// Token: 0x06000825 RID: 2085 RVA: 0x0003C688 File Offset: 0x0003A888
	private void SetGamepadControllerActive(bool isActive)
	{
		if (isActive && (CSingleton<CGameManager>.Instance.m_DisableController || this.m_IsContollerDisabled))
		{
			this.m_IsControllerActive = false;
			return;
		}
		if (isActive)
		{
			this.CheckIsPSController();
		}
		if (this.m_IsControllerActive != isActive)
		{
			this.m_IsControllerActive = isActive;
			ControllerScreenUIExtManager.SetControllerActive(isActive);
			if (CSingleton<CGameManager>.Instance.m_IsGameLevel)
			{
				if (CSingleton<InteractionPlayerController>.Instance.m_InputTooltipListDisplay)
				{
					CSingleton<InteractionPlayerController>.Instance.m_InputTooltipListDisplay.UpdatePhoneAndAlbumTooltip();
					CSingleton<InteractionPlayerController>.Instance.m_InputTooltipListDisplay.RefreshActiveTooltip();
				}
				CSingleton<GameUIScreen>.Instance.UpdateGoNextDayText();
			}
			if (this.m_IsControllerActive)
			{
				Cursor.visible = false;
				return;
			}
			if (InputManager.GetCursorLockMode() == CursorLockMode.Confined || !CSingleton<CGameManager>.Instance.m_IsGameLevel)
			{
				Cursor.visible = true;
				return;
			}
			Cursor.visible = false;
		}
	}

	// Token: 0x06000826 RID: 2086 RVA: 0x0003C74B File Offset: 0x0003A94B
	private void OnApplicationFocus(bool hasFocus)
	{
		if (hasFocus)
		{
			if (InputManager.GetCursorLockMode() == CursorLockMode.Confined || !CSingleton<CGameManager>.Instance.m_IsGameLevel)
			{
				Cursor.visible = true;
				return;
			}
			Cursor.visible = false;
		}
	}

	// Token: 0x06000827 RID: 2087 RVA: 0x0003C771 File Offset: 0x0003A971
	private void Start()
	{
		InputSystem.onDeviceChange += delegate(InputDevice device, InputDeviceChange change)
		{
			switch (change)
			{
			case InputDeviceChange.Added:
				this.m_CurrentGamepad = Gamepad.current;
				this.m_CurrentMouse = Mouse.current;
				this.SetGamepadControllerActive(true);
				return;
			case InputDeviceChange.Removed:
				this.SetGamepadControllerActive(false);
				this.m_CurrentGamepad = null;
				return;
			case InputDeviceChange.Disconnected:
				this.SetGamepadControllerActive(false);
				this.m_CurrentGamepad = null;
				return;
			case InputDeviceChange.Reconnected:
				this.m_CurrentGamepad = Gamepad.current;
				this.SetGamepadControllerActive(true);
				return;
			default:
				return;
			}
		};
		this.Init();
	}

	// Token: 0x06000828 RID: 2088 RVA: 0x0003C78A File Offset: 0x0003A98A
	public static void OnLevelFinishedLoading()
	{
		CSingleton<InputManager>.Instance.Init();
	}

	// Token: 0x06000829 RID: 2089 RVA: 0x0003C796 File Offset: 0x0003A996
	private void Init()
	{
		this.m_CurrentMouse = Mouse.current;
		this.m_CurrentGamepad = Gamepad.current;
		if (this.m_CurrentGamepad != null)
		{
			this.SetGamepadControllerActive(true);
		}
		else
		{
			this.SetGamepadControllerActive(false);
		}
		ControllerScreenUIExtManager.SetControllerActive(this.m_IsControllerActive);
	}

	// Token: 0x0600082A RID: 2090 RVA: 0x0003C7D4 File Offset: 0x0003A9D4
	private void CheckIsPSController()
	{
		if (this.m_CurrentGamepad == null)
		{
			return;
		}
		if (this.m_CurrentGamepad is DualShockGamepad || this.m_CurrentGamepad.layout == "DualSenseGamepadHID" || this.m_CurrentGamepad.layout == "DualSenseGamepad")
		{
			this.m_IsPSController = true;
			return;
		}
		this.m_IsPSController = false;
	}

	// Token: 0x0600082B RID: 2091 RVA: 0x0003C834 File Offset: 0x0003AA34
	private void Update()
	{
		if (this.m_IsControllerActive)
		{
			if (Input.GetMouseButtonDown(0) || Input.GetMouseButtonDown(1))
			{
				this.SetGamepadControllerActive(false);
			}
			else if (InputManager.GetKeyDownAction(EGameAction.MoveForward) || InputManager.GetKeyDownAction(EGameAction.MoveForwardAlt))
			{
				this.SetGamepadControllerActive(false);
			}
			else if (InputManager.GetKeyDownAction(EGameAction.MoveBackward) || InputManager.GetKeyDownAction(EGameAction.MoveBackwardAlt))
			{
				this.SetGamepadControllerActive(false);
			}
			else if (InputManager.GetKeyDownAction(EGameAction.MoveLeft) || InputManager.GetKeyDownAction(EGameAction.MoveLeftAlt))
			{
				this.SetGamepadControllerActive(false);
			}
			else if (InputManager.GetKeyDownAction(EGameAction.MoveRight) || InputManager.GetKeyDownAction(EGameAction.MoveRightAlt))
			{
				this.SetGamepadControllerActive(false);
			}
		}
		else if (this.m_CurrentGamepad != null && this.m_CurrentGamepad.enabled)
		{
			if (Mathf.Abs(Input.GetAxis("LJoystick X")) > 0f || Mathf.Abs(Input.GetAxis("LJoystick Y")) > 0f)
			{
				this.SetGamepadControllerActive(true);
			}
			else if (InputManager.GetGamepadButtonUp(EGamepadControlBtn.X) || InputManager.GetGamepadButtonUp(EGamepadControlBtn.O) || InputManager.GetGamepadButtonUp(EGamepadControlBtn.Triangle) || InputManager.GetGamepadButtonUp(EGamepadControlBtn.Square))
			{
				this.SetGamepadControllerActive(true);
			}
			else if (InputManager.GetGamepadButtonUp(EGamepadControlBtn.Start) || InputManager.GetGamepadButtonUp(EGamepadControlBtn.Select) || InputManager.GetGamepadButtonUp(EGamepadControlBtn.L1) || InputManager.GetGamepadButtonUp(EGamepadControlBtn.R1))
			{
				this.SetGamepadControllerActive(true);
			}
			else if (InputManager.GetGamepadButtonUp(EGamepadControlBtn.L2) || InputManager.GetGamepadButtonUp(EGamepadControlBtn.R2) || InputManager.GetGamepadButtonUp(EGamepadControlBtn.L3) || InputManager.GetGamepadButtonUp(EGamepadControlBtn.R3))
			{
				this.SetGamepadControllerActive(true);
			}
		}
		if (this.m_IsUpdatingKeybind)
		{
			using (IEnumerator enumerator = Enum.GetValues(typeof(KeyCode)).GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					object obj = enumerator.Current;
					KeyCode keyCode = (KeyCode)obj;
					if (Input.GetKey(keyCode))
					{
						InputManager.UpdateKeybind(this.m_CurrentKeybindGameBaseKey, keyCode);
						if (this.m_CurrentKeybindGameBaseKeySecondary != EGameBaseKey.None)
						{
							InputManager.UpdateKeybind(this.m_CurrentKeybindGameBaseKeySecondary, keyCode);
							this.m_CurrentKeybindGameBaseKeySecondary = EGameBaseKey.None;
						}
						this.m_IsUpdatingKeybind = false;
						this.m_CurrentKeybindSettingUI.OnFinishSetKeybind(keyCode);
						this.m_HasKeybindChanges = true;
					}
				}
				return;
			}
		}
		if (this.m_IsUpdatingGamepadKeybind)
		{
			this.m_CheckPressedGamepadControlBtn = InputManager.GetGamepadControlBtnEnum();
			if (this.m_CheckPressedGamepadControlBtn != EGamepadControlBtn.None)
			{
				InputManager.UpdateGamepadKeybind(this.m_CurrentKeybindGameBaseKey, this.m_CheckPressedGamepadControlBtn);
				if (this.m_CurrentKeybindGameBaseKeySecondary != EGameBaseKey.None)
				{
					InputManager.UpdateGamepadKeybind(this.m_CurrentKeybindGameBaseKeySecondary, this.m_CheckPressedGamepadControlBtn);
					this.m_CurrentKeybindGameBaseKeySecondary = EGameBaseKey.None;
				}
				this.m_IsUpdatingGamepadKeybind = false;
				this.m_CurrentKeybindSettingUI.OnFinishSetGamepadKeybind(this.m_CheckPressedGamepadControlBtn);
				this.m_CheckPressedGamepadControlBtn = EGamepadControlBtn.None;
				this.m_HasKeybindChanges = true;
			}
		}
	}

	// Token: 0x0600082C RID: 2092 RVA: 0x0003CAC8 File Offset: 0x0003ACC8
	public void UndoKeybind()
	{
		this.m_HasKeybindChanges = false;
		InputManager.m_KeybindBaseKeyList.Clear();
		for (int i = 0; i < this.m_KeybindBaseKeyListBeforeEdit.Count; i++)
		{
			KeybindBaseKey keybindBaseKey = new KeybindBaseKey();
			keybindBaseKey.baseKey = this.m_KeybindBaseKeyListBeforeEdit[i].baseKey;
			keybindBaseKey.bindKey = this.m_KeybindBaseKeyListBeforeEdit[i].bindKey;
			InputManager.m_KeybindBaseKeyList.Add(keybindBaseKey);
		}
		InputManager.m_KeybindBaseJoystickCtrlList.Clear();
		for (int j = 0; j < this.m_KeybindBaseJoystickCtrlListBeforeEdit.Count; j++)
		{
			KeybindBaseGamepadControl keybindBaseGamepadControl = new KeybindBaseGamepadControl();
			keybindBaseGamepadControl.baseKey = this.m_KeybindBaseJoystickCtrlListBeforeEdit[j].baseKey;
			keybindBaseGamepadControl.ctrlBtn = this.m_KeybindBaseJoystickCtrlListBeforeEdit[j].ctrlBtn;
			InputManager.m_KeybindBaseJoystickCtrlList.Add(keybindBaseGamepadControl);
		}
	}

	// Token: 0x0600082D RID: 2093 RVA: 0x0003CB9A File Offset: 0x0003AD9A
	public static void OnKeybindSettingSaved()
	{
		CSingleton<InputManager>.Instance.m_HasKeybindChanges = false;
		CSingleton<InputManager>.Instance.RefreshKeybindBeforeEdit();
	}

	// Token: 0x0600082E RID: 2094 RVA: 0x0003CBB4 File Offset: 0x0003ADB4
	public void ResetToDefaultKeybind()
	{
		InputManager.m_KeybindBaseKeyList.Clear();
		for (int i = 0; i < this.m_KeybindBaseKeyListDefault.Count; i++)
		{
			KeybindBaseKey keybindBaseKey = new KeybindBaseKey();
			keybindBaseKey.baseKey = this.m_KeybindBaseKeyListDefault[i].baseKey;
			keybindBaseKey.bindKey = this.m_KeybindBaseKeyListDefault[i].bindKey;
			InputManager.m_KeybindBaseKeyList.Add(keybindBaseKey);
		}
		InputManager.m_KeybindBaseJoystickCtrlList.Clear();
		for (int j = 0; j < this.m_KeybindBaseJoystickCtrlListDefault.Count; j++)
		{
			KeybindBaseGamepadControl keybindBaseGamepadControl = new KeybindBaseGamepadControl();
			keybindBaseGamepadControl.baseKey = this.m_KeybindBaseJoystickCtrlListDefault[j].baseKey;
			keybindBaseGamepadControl.ctrlBtn = this.m_KeybindBaseJoystickCtrlListDefault[j].ctrlBtn;
			InputManager.m_KeybindBaseJoystickCtrlList.Add(keybindBaseGamepadControl);
		}
	}

	// Token: 0x0600082F RID: 2095 RVA: 0x0003CC80 File Offset: 0x0003AE80
	public void RefreshKeybindBeforeEdit()
	{
		this.m_KeybindBaseKeyListBeforeEdit.Clear();
		for (int i = 0; i < InputManager.m_KeybindBaseKeyList.Count; i++)
		{
			KeybindBaseKey keybindBaseKey = new KeybindBaseKey();
			keybindBaseKey.baseKey = InputManager.m_KeybindBaseKeyList[i].baseKey;
			keybindBaseKey.bindKey = InputManager.m_KeybindBaseKeyList[i].bindKey;
			this.m_KeybindBaseKeyListBeforeEdit.Add(keybindBaseKey);
		}
		this.m_KeybindBaseJoystickCtrlListBeforeEdit.Clear();
		for (int j = 0; j < InputManager.m_KeybindBaseJoystickCtrlList.Count; j++)
		{
			KeybindBaseGamepadControl keybindBaseGamepadControl = new KeybindBaseGamepadControl();
			keybindBaseGamepadControl.baseKey = InputManager.m_KeybindBaseJoystickCtrlList[j].baseKey;
			keybindBaseGamepadControl.ctrlBtn = InputManager.m_KeybindBaseJoystickCtrlList[j].ctrlBtn;
			this.m_KeybindBaseJoystickCtrlListBeforeEdit.Add(keybindBaseGamepadControl);
		}
	}

	// Token: 0x06000830 RID: 2096 RVA: 0x0003CD49 File Offset: 0x0003AF49
	public static void OnPressKeybindButton(KeybindSetting keybindSettingUI, bool isGamepad, EGameBaseKey gameBaseKey, EGameBaseKey gameBaseKeySecondary)
	{
		CSingleton<InputManager>.Instance.m_CurrentKeybindSettingUI = keybindSettingUI;
		CSingleton<InputManager>.Instance.m_CurrentKeybindGameBaseKey = gameBaseKey;
		CSingleton<InputManager>.Instance.m_CurrentKeybindGameBaseKeySecondary = gameBaseKeySecondary;
		if (isGamepad)
		{
			CSingleton<InputManager>.Instance.m_IsUpdatingGamepadKeybind = true;
			return;
		}
		CSingleton<InputManager>.Instance.m_IsUpdatingKeybind = true;
	}

	// Token: 0x06000831 RID: 2097 RVA: 0x0003CD88 File Offset: 0x0003AF88
	public static void OnKeyboardTypeUpdated(int keyboardIndex)
	{
		if (CSingleton<InputManager>.Instance.m_CurrentKeyboardIndex != keyboardIndex)
		{
			CSingleton<InputManager>.Instance.m_CurrentKeyboardIndex = keyboardIndex;
			if (keyboardIndex == 0)
			{
				InputManager.UpdateKeybind(EGameBaseKey.Q, KeyCode.Q);
				InputManager.UpdateKeybind(EGameBaseKey.A, KeyCode.A);
				InputManager.UpdateKeybind(EGameBaseKey.W, KeyCode.W);
				return;
			}
			if (keyboardIndex == 1)
			{
				InputManager.UpdateKeybind(EGameBaseKey.Q, KeyCode.A);
				InputManager.UpdateKeybind(EGameBaseKey.A, KeyCode.Q);
				InputManager.UpdateKeybind(EGameBaseKey.W, KeyCode.Z);
			}
		}
	}

	// Token: 0x06000832 RID: 2098 RVA: 0x0003CDEC File Offset: 0x0003AFEC
	public static List<KeyCode> GetActionBindedKeyList(EGameAction action)
	{
		List<EGameBaseKey> list = new List<EGameBaseKey>();
		for (int i = 0; i < CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList.Count; i++)
		{
			if (CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[i].gameAction == action)
			{
				list.Add(CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[i].baseKey);
			}
		}
		List<KeyCode> list2 = new List<KeyCode>();
		for (int j = 0; j < list.Count; j++)
		{
			for (int k = 0; k < InputManager.m_KeybindBaseKeyList.Count; k++)
			{
				if (InputManager.m_KeybindBaseKeyList[k].baseKey == list[j])
				{
					list2.Add(InputManager.m_KeybindBaseKeyList[k].bindKey);
					break;
				}
			}
		}
		return list2;
	}

	// Token: 0x06000833 RID: 2099 RVA: 0x0003CEB0 File Offset: 0x0003B0B0
	public static List<EGamepadControlBtn> GetActionBindedGamepadBtnList(EGameAction action)
	{
		List<EGameBaseKey> list = new List<EGameBaseKey>();
		for (int i = 0; i < CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList.Count; i++)
		{
			if (CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList[i].gameAction == action)
			{
				list.Add(CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList[i].baseKey);
			}
		}
		if (list.Count == 0)
		{
			for (int j = 0; j < CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList.Count; j++)
			{
				if (CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[j].gameAction == action)
				{
					list.Add(CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[j].baseKey);
				}
			}
		}
		List<EGamepadControlBtn> list2 = new List<EGamepadControlBtn>();
		for (int k = 0; k < list.Count; k++)
		{
			for (int l = 0; l < InputManager.m_KeybindBaseJoystickCtrlList.Count; l++)
			{
				if (InputManager.m_KeybindBaseJoystickCtrlList[l].baseKey == list[k])
				{
					list2.Add(InputManager.m_KeybindBaseJoystickCtrlList[l].ctrlBtn);
					break;
				}
			}
		}
		return list2;
	}

	// Token: 0x06000834 RID: 2100 RVA: 0x0003CFD0 File Offset: 0x0003B1D0
	public static bool GetKeyUpAction(EGameAction action)
	{
		bool flag = false;
		if (CSingleton<InputManager>.Instance.m_IsControllerActive && CSingleton<InputManager>.Instance.m_CurrentGamepad != null)
		{
			for (int i = 0; i < CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList.Count; i++)
			{
				if (CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList[i].gameAction == action)
				{
					flag = true;
					if (InputManager.GetKeyUp(CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList[i].baseKey))
					{
						CSingleton<InputManager>.Instance.SetGamepadControllerActive(true);
						return true;
					}
				}
			}
		}
		if (flag)
		{
			return false;
		}
		for (int j = 0; j < CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList.Count; j++)
		{
			if (CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[j].gameAction == action && InputManager.GetKeyUp(CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[j].baseKey))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000835 RID: 2101 RVA: 0x0003D0AC File Offset: 0x0003B2AC
	public static bool GetKeyDownAction(EGameAction action)
	{
		bool flag = false;
		if (CSingleton<InputManager>.Instance.m_IsControllerActive && CSingleton<InputManager>.Instance.m_CurrentGamepad != null)
		{
			for (int i = 0; i < CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList.Count; i++)
			{
				if (CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList[i].gameAction == action)
				{
					flag = true;
					if (InputManager.GetKeyDown(CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList[i].baseKey))
					{
						CSingleton<InputManager>.Instance.SetGamepadControllerActive(true);
						return true;
					}
				}
			}
		}
		if (flag)
		{
			return false;
		}
		for (int j = 0; j < CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList.Count; j++)
		{
			if (CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[j].gameAction == action && InputManager.GetKeyDown(CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[j].baseKey))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000836 RID: 2102 RVA: 0x0003D188 File Offset: 0x0003B388
	public static bool GetKeyHoldAction(EGameAction action)
	{
		bool flag = false;
		if (CSingleton<InputManager>.Instance.m_IsControllerActive && CSingleton<InputManager>.Instance.m_CurrentGamepad != null)
		{
			for (int i = 0; i < CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList.Count; i++)
			{
				if (CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList[i].gameAction == action)
				{
					flag = true;
					if (InputManager.GetKeyHold(CSingleton<InputManager>.Instance.m_GameActionBaseJoystickCtrlDataList[i].baseKey))
					{
						return true;
					}
				}
			}
		}
		if (flag)
		{
			return false;
		}
		for (int j = 0; j < CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList.Count; j++)
		{
			if (CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[j].gameAction == action && InputManager.GetKeyHold(CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[j].baseKey))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000837 RID: 2103 RVA: 0x0003D258 File Offset: 0x0003B458
	public static string GetActionName(EGameAction action)
	{
		for (int i = 0; i < CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList.Count; i++)
		{
			if (CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[i].gameAction == action)
			{
				return CSingleton<InputManager>.Instance.m_GameActionBaseKeyDataList[i].GetName();
			}
		}
		return "";
	}

	// Token: 0x06000838 RID: 2104 RVA: 0x0003D2B4 File Offset: 0x0003B4B4
	public static bool GetKeyUp(EGameBaseKey gameBaseKey)
	{
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad != null)
		{
			for (int i = 0; i < InputManager.m_KeybindBaseJoystickCtrlList.Count; i++)
			{
				if (InputManager.m_KeybindBaseJoystickCtrlList[i].baseKey == gameBaseKey && InputManager.GetGamepadButtonUp(InputManager.m_KeybindBaseJoystickCtrlList[i].ctrlBtn))
				{
					CSingleton<InputManager>.Instance.SetGamepadControllerActive(true);
					return true;
				}
			}
		}
		for (int j = 0; j < InputManager.m_KeybindBaseKeyList.Count; j++)
		{
			if (InputManager.m_KeybindBaseKeyList[j].baseKey == gameBaseKey)
			{
				if (InputManager.m_KeybindBaseKeyList[j].bindKey == KeyCode.Mouse0)
				{
					if (CSingleton<InputManager>.Instance.m_CurrentMouse != null && CSingleton<InputManager>.Instance.m_CurrentMouse.leftButton.wasReleasedThisFrame)
					{
						CSingleton<InputManager>.Instance.SetGamepadControllerActive(false);
						return true;
					}
				}
				else if (InputManager.m_KeybindBaseKeyList[j].bindKey == KeyCode.Mouse1 && CSingleton<InputManager>.Instance.m_CurrentMouse != null && CSingleton<InputManager>.Instance.m_CurrentMouse.rightButton.wasReleasedThisFrame)
				{
					CSingleton<InputManager>.Instance.SetGamepadControllerActive(false);
					return true;
				}
				if (Input.GetKeyUp(InputManager.m_KeybindBaseKeyList[j].bindKey))
				{
					CSingleton<InputManager>.Instance.SetGamepadControllerActive(false);
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x06000839 RID: 2105 RVA: 0x0003D3FC File Offset: 0x0003B5FC
	public static bool GetKeyDown(EGameBaseKey gameBaseKey)
	{
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad != null)
		{
			for (int i = 0; i < InputManager.m_KeybindBaseJoystickCtrlList.Count; i++)
			{
				if (InputManager.m_KeybindBaseJoystickCtrlList[i].baseKey == gameBaseKey && InputManager.GetGamepadButtonDown(InputManager.m_KeybindBaseJoystickCtrlList[i].ctrlBtn))
				{
					CSingleton<InputManager>.Instance.SetGamepadControllerActive(true);
					return true;
				}
			}
		}
		for (int j = 0; j < InputManager.m_KeybindBaseKeyList.Count; j++)
		{
			if (InputManager.m_KeybindBaseKeyList[j].baseKey == gameBaseKey)
			{
				if (InputManager.m_KeybindBaseKeyList[j].bindKey == KeyCode.Mouse0)
				{
					if (CSingleton<InputManager>.Instance.m_CurrentMouse != null && CSingleton<InputManager>.Instance.m_CurrentMouse.leftButton.wasPressedThisFrame)
					{
						CSingleton<InputManager>.Instance.SetGamepadControllerActive(false);
						return true;
					}
				}
				else if (InputManager.m_KeybindBaseKeyList[j].bindKey == KeyCode.Mouse1 && CSingleton<InputManager>.Instance.m_CurrentMouse != null && CSingleton<InputManager>.Instance.m_CurrentMouse.rightButton.wasPressedThisFrame)
				{
					CSingleton<InputManager>.Instance.SetGamepadControllerActive(false);
					return true;
				}
				if (Input.GetKeyDown(InputManager.m_KeybindBaseKeyList[j].bindKey))
				{
					CSingleton<InputManager>.Instance.SetGamepadControllerActive(false);
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x0600083A RID: 2106 RVA: 0x0003D544 File Offset: 0x0003B744
	public static bool GetKeyHold(EGameBaseKey gameBaseKey)
	{
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad != null)
		{
			for (int i = 0; i < InputManager.m_KeybindBaseJoystickCtrlList.Count; i++)
			{
				if (InputManager.m_KeybindBaseJoystickCtrlList[i].baseKey == gameBaseKey && InputManager.GetGamepadButtonHold(InputManager.m_KeybindBaseJoystickCtrlList[i].ctrlBtn))
				{
					CSingleton<InputManager>.Instance.SetGamepadControllerActive(true);
					return true;
				}
			}
		}
		for (int j = 0; j < InputManager.m_KeybindBaseKeyList.Count; j++)
		{
			if (InputManager.m_KeybindBaseKeyList[j].baseKey == gameBaseKey)
			{
				if (InputManager.m_KeybindBaseKeyList[j].bindKey == KeyCode.Mouse0)
				{
					if (CSingleton<InputManager>.Instance.m_CurrentMouse != null && CSingleton<InputManager>.Instance.m_CurrentMouse.leftButton.isPressed)
					{
						CSingleton<InputManager>.Instance.SetGamepadControllerActive(false);
						return true;
					}
				}
				else if (InputManager.m_KeybindBaseKeyList[j].bindKey == KeyCode.Mouse1 && CSingleton<InputManager>.Instance.m_CurrentMouse != null && CSingleton<InputManager>.Instance.m_CurrentMouse.rightButton.isPressed)
				{
					CSingleton<InputManager>.Instance.SetGamepadControllerActive(false);
					return true;
				}
				if (Input.GetKey(InputManager.m_KeybindBaseKeyList[j].bindKey))
				{
					CSingleton<InputManager>.Instance.SetGamepadControllerActive(false);
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x0600083B RID: 2107 RVA: 0x0003D68C File Offset: 0x0003B88C
	public unsafe static bool GetLeftAnalogDown(int horizontalVerticalIndex, bool positiveValue)
	{
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad == null)
		{
			return false;
		}
		if (horizontalVerticalIndex == 0)
		{
			if (positiveValue)
			{
				if (CSingleton<InputManager>.Instance.m_CurrentLeftAnalogHorizontalAxis <= 0f && *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.x.value > CSingleton<InputManager>.Instance.m_AnalogAxisThresholdToRegisterAsDown)
				{
					CSingleton<InputManager>.Instance.m_CurrentLeftAnalogHorizontalAxis = 1f;
					return true;
				}
			}
			else if (CSingleton<InputManager>.Instance.m_CurrentLeftAnalogHorizontalAxis >= 0f && *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.x.value < -CSingleton<InputManager>.Instance.m_AnalogAxisThresholdToRegisterAsDown)
			{
				CSingleton<InputManager>.Instance.m_CurrentLeftAnalogHorizontalAxis = -1f;
				return true;
			}
		}
		else if (positiveValue)
		{
			if (CSingleton<InputManager>.Instance.m_CurrentLeftAnalogVerticalAxis <= 0f && *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.y.value > CSingleton<InputManager>.Instance.m_AnalogAxisThresholdToRegisterAsDown)
			{
				CSingleton<InputManager>.Instance.m_CurrentLeftAnalogVerticalAxis = 1f;
				return true;
			}
		}
		else if (CSingleton<InputManager>.Instance.m_CurrentLeftAnalogVerticalAxis >= 0f && *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.y.value < -CSingleton<InputManager>.Instance.m_AnalogAxisThresholdToRegisterAsDown)
		{
			CSingleton<InputManager>.Instance.m_CurrentLeftAnalogVerticalAxis = -1f;
			return true;
		}
		return false;
	}

	// Token: 0x0600083C RID: 2108 RVA: 0x0003D7E8 File Offset: 0x0003B9E8
	public unsafe static bool GetLeftAnalogUp(int horizontalVerticalIndex, bool positiveValue)
	{
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad == null)
		{
			return false;
		}
		if (horizontalVerticalIndex == 0)
		{
			if (positiveValue)
			{
				if (CSingleton<InputManager>.Instance.m_CurrentLeftAnalogHorizontalAxis > 0f && *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.x.value <= CSingleton<InputManager>.Instance.m_AnalogAxisThresholdToRegisterAsUp)
				{
					CSingleton<InputManager>.Instance.m_CurrentLeftAnalogHorizontalAxis = 0f;
					return true;
				}
			}
			else if (CSingleton<InputManager>.Instance.m_CurrentLeftAnalogHorizontalAxis < 0f && *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.x.value >= -CSingleton<InputManager>.Instance.m_AnalogAxisThresholdToRegisterAsUp)
			{
				CSingleton<InputManager>.Instance.m_CurrentLeftAnalogHorizontalAxis = 0f;
				return true;
			}
		}
		else if (positiveValue)
		{
			if (CSingleton<InputManager>.Instance.m_CurrentLeftAnalogVerticalAxis > 0f && *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.y.value <= CSingleton<InputManager>.Instance.m_AnalogAxisThresholdToRegisterAsUp)
			{
				CSingleton<InputManager>.Instance.m_CurrentLeftAnalogVerticalAxis = 0f;
				return true;
			}
		}
		else if (CSingleton<InputManager>.Instance.m_CurrentLeftAnalogVerticalAxis < 0f && *CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStick.y.value >= -CSingleton<InputManager>.Instance.m_AnalogAxisThresholdToRegisterAsUp)
		{
			CSingleton<InputManager>.Instance.m_CurrentLeftAnalogVerticalAxis = 0f;
			return true;
		}
		return false;
	}

	// Token: 0x0600083D RID: 2109 RVA: 0x0003D944 File Offset: 0x0003BB44
	private static bool GetGamepadButtonUp(EGamepadControlBtn controlBtn)
	{
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad == null)
		{
			return false;
		}
		switch (controlBtn)
		{
		case EGamepadControlBtn.X:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonSouth.wasReleasedThisFrame;
		case EGamepadControlBtn.O:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonEast.wasReleasedThisFrame;
		case EGamepadControlBtn.Square:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonWest.wasReleasedThisFrame;
		case EGamepadControlBtn.Triangle:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonNorth.wasReleasedThisFrame;
		case EGamepadControlBtn.L1:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.leftShoulder.wasReleasedThisFrame;
		case EGamepadControlBtn.R1:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.rightShoulder.wasReleasedThisFrame;
		case EGamepadControlBtn.L2:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.leftTrigger.wasReleasedThisFrame;
		case EGamepadControlBtn.R2:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.rightTrigger.wasReleasedThisFrame;
		case EGamepadControlBtn.L3:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStickButton.wasReleasedThisFrame;
		case EGamepadControlBtn.R3:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStickButton.wasReleasedThisFrame;
		case EGamepadControlBtn.DpadLeft:
			return false;
		case EGamepadControlBtn.DpadRight:
			return false;
		case EGamepadControlBtn.DpadUp:
			return false;
		case EGamepadControlBtn.DpadDown:
			return false;
		case EGamepadControlBtn.LStickLeft:
			return false;
		case EGamepadControlBtn.LStickRight:
			return false;
		case EGamepadControlBtn.LStickUp:
			return false;
		case EGamepadControlBtn.LStickDown:
			return false;
		case EGamepadControlBtn.RStickLeft:
			return false;
		case EGamepadControlBtn.RStickRight:
			return false;
		case EGamepadControlBtn.RStickUp:
			return false;
		case EGamepadControlBtn.RStickDown:
			return false;
		case EGamepadControlBtn.Start:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.startButton.wasReleasedThisFrame;
		case EGamepadControlBtn.Select:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.selectButton.wasReleasedThisFrame;
		case EGamepadControlBtn.Home:
			return false;
		default:
			return false;
		}
	}

	// Token: 0x0600083E RID: 2110 RVA: 0x0003DAE8 File Offset: 0x0003BCE8
	private static bool GetGamepadButtonDown(EGamepadControlBtn controlBtn)
	{
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad == null)
		{
			return false;
		}
		switch (controlBtn)
		{
		case EGamepadControlBtn.X:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonSouth.wasPressedThisFrame;
		case EGamepadControlBtn.O:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonEast.wasPressedThisFrame;
		case EGamepadControlBtn.Square:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonWest.wasPressedThisFrame;
		case EGamepadControlBtn.Triangle:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonNorth.wasPressedThisFrame;
		case EGamepadControlBtn.L1:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.leftShoulder.wasPressedThisFrame;
		case EGamepadControlBtn.R1:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.rightShoulder.wasPressedThisFrame;
		case EGamepadControlBtn.L2:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.leftTrigger.wasPressedThisFrame;
		case EGamepadControlBtn.R2:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.rightTrigger.wasPressedThisFrame;
		case EGamepadControlBtn.L3:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStickButton.wasPressedThisFrame;
		case EGamepadControlBtn.R3:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStickButton.wasPressedThisFrame;
		case EGamepadControlBtn.DpadLeft:
			return false;
		case EGamepadControlBtn.DpadRight:
			return false;
		case EGamepadControlBtn.DpadUp:
			return false;
		case EGamepadControlBtn.DpadDown:
			return false;
		case EGamepadControlBtn.LStickLeft:
			return false;
		case EGamepadControlBtn.LStickRight:
			return false;
		case EGamepadControlBtn.LStickUp:
			return false;
		case EGamepadControlBtn.LStickDown:
			return false;
		case EGamepadControlBtn.RStickLeft:
			return false;
		case EGamepadControlBtn.RStickRight:
			return false;
		case EGamepadControlBtn.RStickUp:
			return false;
		case EGamepadControlBtn.RStickDown:
			return false;
		case EGamepadControlBtn.Start:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.startButton.wasPressedThisFrame;
		case EGamepadControlBtn.Select:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.selectButton.wasPressedThisFrame;
		case EGamepadControlBtn.Home:
			return false;
		default:
			return false;
		}
	}

	// Token: 0x0600083F RID: 2111 RVA: 0x0003DC8C File Offset: 0x0003BE8C
	private static bool GetGamepadButtonHold(EGamepadControlBtn controlBtn)
	{
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad == null)
		{
			return false;
		}
		switch (controlBtn)
		{
		case EGamepadControlBtn.X:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonSouth.isPressed;
		case EGamepadControlBtn.O:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonEast.isPressed;
		case EGamepadControlBtn.Square:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonWest.isPressed;
		case EGamepadControlBtn.Triangle:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonNorth.isPressed;
		case EGamepadControlBtn.L1:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.leftShoulder.isPressed;
		case EGamepadControlBtn.R1:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.rightShoulder.isPressed;
		case EGamepadControlBtn.L2:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.leftTrigger.isPressed;
		case EGamepadControlBtn.R2:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.rightTrigger.isPressed;
		case EGamepadControlBtn.L3:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStickButton.isPressed;
		case EGamepadControlBtn.R3:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStickButton.isPressed;
		case EGamepadControlBtn.DpadLeft:
			return false;
		case EGamepadControlBtn.DpadRight:
			return false;
		case EGamepadControlBtn.DpadUp:
			return false;
		case EGamepadControlBtn.DpadDown:
			return false;
		case EGamepadControlBtn.LStickLeft:
			return false;
		case EGamepadControlBtn.LStickRight:
			return false;
		case EGamepadControlBtn.LStickUp:
			return false;
		case EGamepadControlBtn.LStickDown:
			return false;
		case EGamepadControlBtn.RStickLeft:
			return false;
		case EGamepadControlBtn.RStickRight:
			return false;
		case EGamepadControlBtn.RStickUp:
			return false;
		case EGamepadControlBtn.RStickDown:
			return false;
		case EGamepadControlBtn.Start:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.startButton.isPressed;
		case EGamepadControlBtn.Select:
			return CSingleton<InputManager>.Instance.m_CurrentGamepad.selectButton.isPressed;
		case EGamepadControlBtn.Home:
			return false;
		default:
			return false;
		}
	}

	// Token: 0x06000840 RID: 2112 RVA: 0x0003DE30 File Offset: 0x0003C030
	private static EGamepadControlBtn GetGamepadControlBtnEnum()
	{
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad == null)
		{
			return EGamepadControlBtn.None;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonSouth.wasPressedThisFrame)
		{
			return EGamepadControlBtn.X;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonEast.wasPressedThisFrame)
		{
			return EGamepadControlBtn.O;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonWest.wasPressedThisFrame)
		{
			return EGamepadControlBtn.Square;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.buttonNorth.wasPressedThisFrame)
		{
			return EGamepadControlBtn.Triangle;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.leftShoulder.wasPressedThisFrame)
		{
			return EGamepadControlBtn.L1;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.rightShoulder.wasPressedThisFrame)
		{
			return EGamepadControlBtn.R1;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.leftTrigger.wasPressedThisFrame)
		{
			return EGamepadControlBtn.L2;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.rightTrigger.wasPressedThisFrame)
		{
			return EGamepadControlBtn.R2;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.leftStickButton.wasPressedThisFrame)
		{
			return EGamepadControlBtn.L3;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStickButton.wasPressedThisFrame)
		{
			return EGamepadControlBtn.R3;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStickButton.wasPressedThisFrame)
		{
			return EGamepadControlBtn.DpadLeft;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStickButton.wasPressedThisFrame)
		{
			return EGamepadControlBtn.DpadRight;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStickButton.wasPressedThisFrame)
		{
			return EGamepadControlBtn.DpadUp;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.rightStickButton.wasPressedThisFrame)
		{
			return EGamepadControlBtn.DpadDown;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.startButton.wasPressedThisFrame)
		{
			return EGamepadControlBtn.Start;
		}
		if (CSingleton<InputManager>.Instance.m_CurrentGamepad.selectButton.wasPressedThisFrame)
		{
			return EGamepadControlBtn.Select;
		}
		return EGamepadControlBtn.None;
	}

	// Token: 0x06000841 RID: 2113 RVA: 0x0003DFD4 File Offset: 0x0003C1D4
	public static KeyCode GetBaseKeycodeBind(EGameBaseKey gameBaseKey)
	{
		for (int i = 0; i < InputManager.m_KeybindBaseKeyList.Count; i++)
		{
			if (InputManager.m_KeybindBaseKeyList[i].baseKey == gameBaseKey)
			{
				return InputManager.m_KeybindBaseKeyList[i].bindKey;
			}
		}
		return KeyCode.None;
	}

	// Token: 0x06000842 RID: 2114 RVA: 0x0003E01C File Offset: 0x0003C21C
	public static EGamepadControlBtn GetBaseGamepadBtnBind(EGameBaseKey gameBaseKey)
	{
		for (int i = 0; i < InputManager.m_KeybindBaseJoystickCtrlList.Count; i++)
		{
			if (InputManager.m_KeybindBaseJoystickCtrlList[i].baseKey == gameBaseKey)
			{
				return InputManager.m_KeybindBaseJoystickCtrlList[i].ctrlBtn;
			}
		}
		return EGamepadControlBtn.None;
	}

	// Token: 0x06000843 RID: 2115 RVA: 0x0003E064 File Offset: 0x0003C264
	public static void UpdateKeybind(EGameBaseKey gameBaseKey, KeyCode newKey)
	{
		for (int i = 0; i < InputManager.m_KeybindBaseKeyList.Count; i++)
		{
			if (InputManager.m_KeybindBaseKeyList[i].baseKey == gameBaseKey)
			{
				InputManager.m_KeybindBaseKeyList[i].bindKey = newKey;
			}
		}
	}

	// Token: 0x06000844 RID: 2116 RVA: 0x0003E0AC File Offset: 0x0003C2AC
	public static void UpdateGamepadKeybind(EGameBaseKey gameBaseKey, EGamepadControlBtn ctrlBtn)
	{
		for (int i = 0; i < InputManager.m_KeybindBaseJoystickCtrlList.Count; i++)
		{
			if (InputManager.m_KeybindBaseJoystickCtrlList[i].baseKey == gameBaseKey)
			{
				InputManager.m_KeybindBaseJoystickCtrlList[i].ctrlBtn = ctrlBtn;
			}
		}
	}

	// Token: 0x06000845 RID: 2117 RVA: 0x0003E0F2 File Offset: 0x0003C2F2
	public static string GetGamepadButtonName(EGamepadControlBtn gamepadControlBtn)
	{
		return "";
	}

	// Token: 0x06000846 RID: 2118 RVA: 0x0003E0F9 File Offset: 0x0003C2F9
	public static string GetKeycodeName(KeyCode keycode)
	{
		return keycode.ToString();
	}

	// Token: 0x06000847 RID: 2119 RVA: 0x0003E108 File Offset: 0x0003C308
	public static bool HasKeybindChanges()
	{
		return CSingleton<InputManager>.Instance.m_HasKeybindChanges;
	}

	// Token: 0x06000848 RID: 2120 RVA: 0x0003E114 File Offset: 0x0003C314
	public static bool IsSliderActive()
	{
		return CSingleton<InputManager>.Instance.m_IsSliderActive;
	}

	// Token: 0x06000849 RID: 2121 RVA: 0x0003E120 File Offset: 0x0003C320
	public static void SetSliderActive(bool isActive)
	{
		CSingleton<InputManager>.Instance.m_IsSliderActive = isActive;
	}

	// Token: 0x0600084A RID: 2122 RVA: 0x0003E12D File Offset: 0x0003C32D
	public static void SetCursorLockMode(CursorLockMode cursorLockMode)
	{
		CSingleton<InputManager>.Instance.m_CurrentCursorLockMode = cursorLockMode;
		if (cursorLockMode != CursorLockMode.Confined)
		{
			Cursor.lockState = cursorLockMode;
			return;
		}
		if (CSingleton<CGameManager>.Instance.m_CanConfineMouseCursor)
		{
			Cursor.lockState = CursorLockMode.Confined;
			return;
		}
		Cursor.lockState = CursorLockMode.None;
	}

	// Token: 0x0600084B RID: 2123 RVA: 0x0003E15E File Offset: 0x0003C35E
	public static CursorLockMode GetCursorLockMode()
	{
		return CSingleton<InputManager>.Instance.m_CurrentCursorLockMode;
	}

	// Token: 0x04000FF0 RID: 4080
	public static InputManager m_Instance = null;

	// Token: 0x04000FF1 RID: 4081
	public List<KeybindBaseKey> m_KeybindBaseKeyListDefault;

	// Token: 0x04000FF2 RID: 4082
	public List<KeybindBaseGamepadControl> m_KeybindBaseJoystickCtrlListDefault;

	// Token: 0x04000FF3 RID: 4083
	public static List<KeybindBaseKey> m_KeybindBaseKeyList = new List<KeybindBaseKey>();

	// Token: 0x04000FF4 RID: 4084
	public static List<KeybindBaseGamepadControl> m_KeybindBaseJoystickCtrlList = new List<KeybindBaseGamepadControl>();

	// Token: 0x04000FF5 RID: 4085
	public List<KeybindBaseKey> m_KeybindBaseKeyListBeforeEdit;

	// Token: 0x04000FF6 RID: 4086
	public List<KeybindBaseGamepadControl> m_KeybindBaseJoystickCtrlListBeforeEdit;

	// Token: 0x04000FF7 RID: 4087
	public List<GameActionBaseKeyData> m_GameActionBaseKeyDataList;

	// Token: 0x04000FF8 RID: 4088
	public List<GameActionBaseKeyData> m_GameActionBaseJoystickCtrlDataList;

	// Token: 0x04000FF9 RID: 4089
	public bool m_IsControllerActive;

	// Token: 0x04000FFA RID: 4090
	public bool m_IsUpdatingKeybind;

	// Token: 0x04000FFB RID: 4091
	public bool m_IsUpdatingGamepadKeybind;

	// Token: 0x04000FFC RID: 4092
	public bool m_IsPSController;

	// Token: 0x04000FFD RID: 4093
	private bool m_IsCursorVisible;

	// Token: 0x04000FFE RID: 4094
	private bool m_HasKeybindChanges;

	// Token: 0x04000FFF RID: 4095
	private bool m_IsSliderActive;

	// Token: 0x04001000 RID: 4096
	private bool m_IsContollerDisabled;

	// Token: 0x04001001 RID: 4097
	private int m_CurrentKeyboardIndex;

	// Token: 0x04001002 RID: 4098
	private float m_CurrentLeftAnalogHorizontalAxis;

	// Token: 0x04001003 RID: 4099
	private float m_CurrentLeftAnalogVerticalAxis;

	// Token: 0x04001004 RID: 4100
	private float m_AnalogAxisThresholdToRegisterAsDown = 0.5f;

	// Token: 0x04001005 RID: 4101
	private float m_AnalogAxisThresholdToRegisterAsUp = 0.2f;

	// Token: 0x04001006 RID: 4102
	public Gamepad m_CurrentGamepad;

	// Token: 0x04001007 RID: 4103
	public Mouse m_CurrentMouse;

	// Token: 0x04001008 RID: 4104
	private KeybindSetting m_CurrentKeybindSettingUI;

	// Token: 0x04001009 RID: 4105
	private EGameBaseKey m_CurrentKeybindGameBaseKey;

	// Token: 0x0400100A RID: 4106
	private EGameBaseKey m_CurrentKeybindGameBaseKeySecondary;

	// Token: 0x0400100B RID: 4107
	private EGamepadControlBtn m_CheckPressedGamepadControlBtn = EGamepadControlBtn.None;

	// Token: 0x0400100C RID: 4108
	private CSettingData m_SettingData;

	// Token: 0x0400100D RID: 4109
	private CursorLockMode m_CurrentCursorLockMode;
}
