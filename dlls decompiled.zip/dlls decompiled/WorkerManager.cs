﻿using System;
using System.Collections;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;

// Token: 0x02000093 RID: 147
public class WorkerManager : CSingleton<WorkerManager>
{
	// Token: 0x060005C7 RID: 1479 RVA: 0x00030800 File Offset: 0x0002EA00
	private void Start()
	{
		this.m_WorkerList = new List<Worker>();
		for (int i = 0; i < this.m_WorkerParentGrp.childCount; i++)
		{
			this.m_WorkerList.Add(this.m_WorkerParentGrp.GetChild(i).gameObject.GetComponent<Worker>());
		}
		for (int j = 0; j < this.m_WorkerList.Count; j++)
		{
			this.m_WorkerList[j].gameObject.SetActive(false);
			this.m_WorkerList[j].RandomizeCharacterMesh();
			this.m_WorkerList[j].SetOutOfScreen();
		}
	}

	// Token: 0x060005C8 RID: 1480 RVA: 0x0003089E File Offset: 0x0002EA9E
	private void Init()
	{
		if (this.m_FinishLoading)
		{
			return;
		}
		this.m_FinishLoading = true;
		this.m_WorkerSaveDataList = CPlayerData.m_WorkerSaveDataList;
		base.StartCoroutine(this.DelayLoadWorker());
	}

	// Token: 0x060005C9 RID: 1481 RVA: 0x000308C8 File Offset: 0x0002EAC8
	public void ActivateWorker(int index, bool resetTask)
	{
		if (LightManager.GetHasDayEnded())
		{
			return;
		}
		this.UpdateWorkerCount(1);
		this.m_WorkerList[index].ActivateWorker(resetTask);
		this.m_WorkerList[index].gameObject.SetActive(true);
		this.EvaluateSalaryCost();
	}

	// Token: 0x060005CA RID: 1482 RVA: 0x00030908 File Offset: 0x0002EB08
	private void EvaluateSalaryCost()
	{
		this.m_TotalSalaryCost = 0f;
		for (int i = 0; i < this.m_WorkerList.Count; i++)
		{
			if (CPlayerData.GetIsWorkerHired(i))
			{
				this.m_TotalSalaryCostList.Add(this.m_WorkerDataList[i].costPerDay);
				this.m_TotalSalaryCost += this.m_WorkerDataList[i].costPerDay;
			}
		}
	}

	// Token: 0x060005CB RID: 1483 RVA: 0x00030978 File Offset: 0x0002EB78
	public float GetTotalSalaryCost()
	{
		this.EvaluateSalaryCost();
		return this.m_TotalSalaryCost;
	}

	// Token: 0x060005CC RID: 1484 RVA: 0x00030986 File Offset: 0x0002EB86
	public void UpdateWorkerCount(int addAmount)
	{
		this.m_TotalCurrentWorkerCount += addAmount;
	}

	// Token: 0x060005CD RID: 1485 RVA: 0x00030998 File Offset: 0x0002EB98
	private void AddWorkerPrefab()
	{
		Worker worker;
		if (Random.Range(0, 3) == 0)
		{
			worker = Object.Instantiate<Worker>(this.m_WorkerFemalePrefab, new Vector3(0f, 0f, 0f), Quaternion.identity, this.m_WorkerParentGrp);
			worker.name = "FemaleWorker" + this.m_SpawnedWorkerCount.ToString();
		}
		else
		{
			worker = Object.Instantiate<Worker>(this.m_WorkerPrefab, new Vector3(0f, 0f, 0f), Quaternion.identity, this.m_WorkerParentGrp);
			worker.name = "Worker" + this.m_SpawnedWorkerCount.ToString();
		}
		worker.gameObject.SetActive(false);
		this.m_WorkerList.Add(worker);
		this.m_SpawnedWorkerCount++;
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x00030A64 File Offset: 0x0002EC64
	public static Transform GetWorkerRestPoint(int index)
	{
		return CSingleton<WorkerManager>.Instance.m_WorkerRestPointList[index];
	}

	// Token: 0x060005CF RID: 1487 RVA: 0x00030A76 File Offset: 0x0002EC76
	public static string GetTaskName(EWorkerTask task)
	{
		if (task >= (EWorkerTask)CSingleton<WorkerManager>.Instance.m_TaskNameList.Count)
		{
			return "-";
		}
		return LocalizationManager.GetTranslation(CSingleton<WorkerManager>.Instance.m_TaskNameList[(int)task], true, 0, true, false, null, null, true);
	}

	// Token: 0x060005D0 RID: 1488 RVA: 0x00030AAC File Offset: 0x0002ECAC
	public static WorkerData GetWorkerData(int index)
	{
		return CSingleton<WorkerManager>.Instance.m_WorkerDataList[index];
	}

	// Token: 0x060005D1 RID: 1489 RVA: 0x00030ABE File Offset: 0x0002ECBE
	public static List<Worker> GetWorkerList()
	{
		return CSingleton<WorkerManager>.Instance.m_WorkerList;
	}

	// Token: 0x060005D2 RID: 1490 RVA: 0x00030ACC File Offset: 0x0002ECCC
	public static int GetActiveWorkerCount()
	{
		int num = 0;
		for (int i = 0; i < CSingleton<WorkerManager>.Instance.m_WorkerList.Count; i++)
		{
			if (CSingleton<WorkerManager>.Instance.m_WorkerList[i].m_IsActive)
			{
				num++;
			}
		}
		return num;
	}

	// Token: 0x060005D3 RID: 1491 RVA: 0x00030B14 File Offset: 0x0002ED14
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.AddListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
		}
	}

	// Token: 0x060005D4 RID: 1492 RVA: 0x00030B64 File Offset: 0x0002ED64
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.RemoveListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
		}
	}

	// Token: 0x060005D5 RID: 1493 RVA: 0x00030BB2 File Offset: 0x0002EDB2
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x00030BBC File Offset: 0x0002EDBC
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		this.m_IsDayEnded = false;
		for (int i = 0; i < this.m_WorkerList.Count; i++)
		{
			this.m_WorkerList[i].DeactivateWorker();
		}
		for (int j = 0; j < this.m_WorkerList.Count; j++)
		{
			if (CPlayerData.GetIsWorkerHired(j))
			{
				this.ActivateWorker(j, false);
				this.m_WorkerList[j].SetExtraSpeedMultiplier(Random.Range(1f + WorkerManager.GetWorkerData(j).arriveEarlySpeedMin, 5f + WorkerManager.GetWorkerData(j).arriveEarlySpeedMax));
			}
		}
		AchievementManager.OnStaffHired(WorkerManager.GetActiveWorkerCount());
		base.StartCoroutine(this.DelayResetCustomerExtraSpeed());
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x00030C6C File Offset: 0x0002EE6C
	private IEnumerator DelayResetCustomerExtraSpeed()
	{
		yield return new WaitForSeconds(1.65f);
		for (int i = 0; i < this.m_WorkerList.Count; i++)
		{
			this.m_WorkerList[i].ResetExtraSpeedMultiplier();
		}
		yield break;
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x00030C7C File Offset: 0x0002EE7C
	protected void OnDayEnded(CEventPlayer_OnDayEnded evt)
	{
		this.m_IsDayEnded = true;
		for (int i = 0; i < this.m_WorkerList.Count; i++)
		{
			if (CPlayerData.GetIsWorkerHired(i))
			{
				this.m_WorkerList[i].OnDayEnded();
			}
		}
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x00030CBF File Offset: 0x0002EEBF
	private IEnumerator DelayLoadWorker()
	{
		List<Worker> loadWorkerList = new List<Worker>();
		yield return new WaitForSeconds(0.02f);
		for (int i = 0; i < this.m_WorkerList.Count; i++)
		{
			if (!this.m_WorkerList[i].IsActive() && CPlayerData.GetIsWorkerHired(i) && !LightManager.GetHasDayEnded())
			{
				this.UpdateWorkerCount(1);
				this.m_WorkerList[i].ActivateWorker(true);
				if (i < this.m_WorkerSaveDataList.Count)
				{
					this.m_WorkerList[i].LoadWorkerSaveData(this.m_WorkerSaveDataList[i]);
				}
				this.m_WorkerList[i].gameObject.SetActive(true);
				loadWorkerList.Add(this.m_WorkerList[i]);
			}
		}
		yield break;
	}

	// Token: 0x060005DA RID: 1498 RVA: 0x00030CD0 File Offset: 0x0002EED0
	public void SaveWorkerData()
	{
		this.m_WorkerSaveDataList.Clear();
		for (int i = 0; i < this.m_WorkerList.Count; i++)
		{
			WorkerSaveData workerSaveData = this.m_WorkerList[i].GetWorkerSaveData();
			this.m_WorkerSaveDataList.Add(workerSaveData);
		}
		CPlayerData.m_WorkerSaveDataList = this.m_WorkerSaveDataList;
	}

	// Token: 0x04000794 RID: 1940
	private bool m_IsPausing;

	// Token: 0x04000795 RID: 1941
	protected bool m_FinishLoading;

	// Token: 0x04000796 RID: 1942
	public List<WorkerData> m_WorkerDataList;

	// Token: 0x04000797 RID: 1943
	public Worker m_WorkerPrefab;

	// Token: 0x04000798 RID: 1944
	public Worker m_WorkerFemalePrefab;

	// Token: 0x04000799 RID: 1945
	public Transform m_WorkerParentGrp;

	// Token: 0x0400079A RID: 1946
	public InteractableTrashBin m_TrashBin;

	// Token: 0x0400079B RID: 1947
	public List<Transform> m_WorkerRestPointList;

	// Token: 0x0400079C RID: 1948
	public List<string> m_TaskNameList;

	// Token: 0x0400079D RID: 1949
	private bool m_IsDayEnded;

	// Token: 0x0400079E RID: 1950
	public int m_TotalCurrentWorkerCount;

	// Token: 0x0400079F RID: 1951
	private int m_WorkerCountMax = 8;

	// Token: 0x040007A0 RID: 1952
	private int m_SpawnedWorkerCount;

	// Token: 0x040007A1 RID: 1953
	public float m_TotalSalaryCost;

	// Token: 0x040007A2 RID: 1954
	public List<float> m_TotalSalaryCostList = new List<float>();

	// Token: 0x040007A3 RID: 1955
	private List<Worker> m_WorkerList = new List<Worker>();

	// Token: 0x040007A4 RID: 1956
	public List<WorkerSaveData> m_WorkerSaveDataList = new List<WorkerSaveData>();
}
