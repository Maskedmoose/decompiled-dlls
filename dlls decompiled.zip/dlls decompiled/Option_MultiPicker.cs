﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace CC
{
	// Token: 0x020001C8 RID: 456
	public class Option_MultiPicker : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CC7 RID: 3271 RVA: 0x00058B9B File Offset: 0x00056D9B
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util ParentUI)
		{
			this.customizer = customizerScript;
			this.parentUI = ParentUI;
			this.RefreshUIElement();
		}

		// Token: 0x06000CC8 RID: 3272 RVA: 0x00058BB1 File Offset: 0x00056DB1
		public void RefreshUIElement()
		{
			if (this.CustomizationType == Option_MultiPicker.Type.Texture)
			{
				this.optionsCount = this.Properties[0].Objects.Count;
				this.getSavedOption(this.customizer.StoredCharacterData.TextureProperties);
			}
		}

		// Token: 0x06000CC9 RID: 3273 RVA: 0x00058BF0 File Offset: 0x00056DF0
		public void getSavedOption(List<CC_Property> savedProps)
		{
			CC_Property property0 = this.Properties[0].Property;
			int savedIndex = savedProps.FindIndex((CC_Property t) => t.propertyName == property0.propertyName && t.materialIndex == property0.materialIndex && t.meshTag == property0.meshTag);
			if (savedIndex != -1)
			{
				this.navIndex = this.Properties[0].Objects.FindIndex((string t) => t == savedProps[savedIndex].stringValue);
			}
			else
			{
				this.navIndex = 0;
			}
			this.updateOptionText();
		}

		// Token: 0x06000CCA RID: 3274 RVA: 0x00058C80 File Offset: 0x00056E80
		public void updateOptionText()
		{
			this.OptionText.SetText((this.navIndex + 1).ToString() + "/" + this.optionsCount.ToString(), true);
		}

		// Token: 0x06000CCB RID: 3275 RVA: 0x00058CC0 File Offset: 0x00056EC0
		public void setOption(int j)
		{
			this.navIndex = j;
			this.updateOptionText();
			if (this.CustomizationType == Option_MultiPicker.Type.Texture)
			{
				for (int i = 0; i < this.Properties.Count; i++)
				{
					this.Properties[i].Property.stringValue = this.Properties[i].Objects[j];
					this.customizer.setTextureProperty(this.Properties[i].Property, true, null);
				}
			}
		}

		// Token: 0x06000CCC RID: 3276 RVA: 0x00058D43 File Offset: 0x00056F43
		public void navLeft()
		{
			this.setOption((this.navIndex == 0) ? (this.optionsCount - 1) : (this.navIndex - 1));
		}

		// Token: 0x06000CCD RID: 3277 RVA: 0x00058D65 File Offset: 0x00056F65
		public void navRight()
		{
			this.setOption((this.navIndex == this.optionsCount - 1) ? 0 : (this.navIndex + 1));
		}

		// Token: 0x06000CCE RID: 3278 RVA: 0x00058D88 File Offset: 0x00056F88
		public void randomize()
		{
			this.setOption(Random.Range(0, this.optionsCount));
		}

		// Token: 0x040013AB RID: 5035
		private CharacterCustomization customizer;

		// Token: 0x040013AC RID: 5036
		private CC_UI_Util parentUI;

		// Token: 0x040013AD RID: 5037
		public List<MultiPicker> Properties = new List<MultiPicker>();

		// Token: 0x040013AE RID: 5038
		public Option_MultiPicker.Type CustomizationType;

		// Token: 0x040013AF RID: 5039
		public int Slot;

		// Token: 0x040013B0 RID: 5040
		public TextMeshProUGUI OptionText;

		// Token: 0x040013B1 RID: 5041
		private int navIndex;

		// Token: 0x040013B2 RID: 5042
		private int optionsCount;

		// Token: 0x02000274 RID: 628
		public enum Type
		{
			// Token: 0x0400167A RID: 5754
			Texture
		}
	}
}
