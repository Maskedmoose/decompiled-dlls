﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001EE RID: 494
	public class SmoothPosition : MonoBehaviour
	{
		// Token: 0x06000DBA RID: 3514 RVA: 0x0005DB28 File Offset: 0x0005BD28
		private void Awake()
		{
			if (this.target == null)
			{
				this.target = base.transform.parent;
			}
			this.tr = base.transform;
			this.currentPosition = base.transform.position;
			this.localPositionOffset = this.tr.localPosition;
		}

		// Token: 0x06000DBB RID: 3515 RVA: 0x0005DB82 File Offset: 0x0005BD82
		private void OnEnable()
		{
			this.ResetCurrentPosition();
		}

		// Token: 0x06000DBC RID: 3516 RVA: 0x0005DB8A File Offset: 0x0005BD8A
		private void Update()
		{
			if (this.updateType == SmoothPosition.UpdateType.LateUpdate)
			{
				return;
			}
			this.SmoothUpdate();
		}

		// Token: 0x06000DBD RID: 3517 RVA: 0x0005DB9C File Offset: 0x0005BD9C
		private void LateUpdate()
		{
			if (this.updateType == SmoothPosition.UpdateType.Update)
			{
				return;
			}
			this.SmoothUpdate();
		}

		// Token: 0x06000DBE RID: 3518 RVA: 0x0005DBAD File Offset: 0x0005BDAD
		private void SmoothUpdate()
		{
			this.currentPosition = this.Smooth(this.currentPosition, this.target.position, this.lerpSpeed);
			this.tr.position = this.currentPosition;
		}

		// Token: 0x06000DBF RID: 3519 RVA: 0x0005DBE4 File Offset: 0x0005BDE4
		private Vector3 Smooth(Vector3 _start, Vector3 _target, float _smoothTime)
		{
			Vector3 b = this.tr.localToWorldMatrix * this.localPositionOffset;
			if (this.extrapolatePosition)
			{
				Vector3 b2 = _target - (_start - b);
				_target += b2;
			}
			_target += b;
			SmoothPosition.SmoothType smoothType = this.smoothType;
			if (smoothType == SmoothPosition.SmoothType.Lerp)
			{
				return Vector3.Lerp(_start, _target, Time.deltaTime * _smoothTime);
			}
			if (smoothType != SmoothPosition.SmoothType.SmoothDamp)
			{
				return Vector3.zero;
			}
			return Vector3.SmoothDamp(_start, _target, ref this.refVelocity, this.smoothDampTime);
		}

		// Token: 0x06000DC0 RID: 3520 RVA: 0x0005DC74 File Offset: 0x0005BE74
		public void ResetCurrentPosition()
		{
			Vector3 b = this.tr.localToWorldMatrix * this.localPositionOffset;
			this.currentPosition = this.target.position + b;
		}

		// Token: 0x040014B1 RID: 5297
		public Transform target;

		// Token: 0x040014B2 RID: 5298
		private Transform tr;

		// Token: 0x040014B3 RID: 5299
		private Vector3 currentPosition;

		// Token: 0x040014B4 RID: 5300
		public float lerpSpeed = 20f;

		// Token: 0x040014B5 RID: 5301
		public float smoothDampTime = 0.02f;

		// Token: 0x040014B6 RID: 5302
		public bool extrapolatePosition;

		// Token: 0x040014B7 RID: 5303
		public SmoothPosition.UpdateType updateType;

		// Token: 0x040014B8 RID: 5304
		public SmoothPosition.SmoothType smoothType;

		// Token: 0x040014B9 RID: 5305
		private Vector3 localPositionOffset;

		// Token: 0x040014BA RID: 5306
		private Vector3 refVelocity;

		// Token: 0x02000283 RID: 643
		public enum UpdateType
		{
			// Token: 0x040016AA RID: 5802
			Update,
			// Token: 0x040016AB RID: 5803
			LateUpdate
		}

		// Token: 0x02000284 RID: 644
		public enum SmoothType
		{
			// Token: 0x040016AD RID: 5805
			Lerp,
			// Token: 0x040016AE RID: 5806
			SmoothDamp
		}
	}
}
