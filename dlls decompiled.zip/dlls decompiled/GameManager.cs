﻿using System;
using UnityEngine;

// Token: 0x02000143 RID: 323
public class GameManager : MonoBehaviour
{
	// Token: 0x0600092B RID: 2347 RVA: 0x00042524 File Offset: 0x00040724
	private void Start()
	{
		this.text_fx_name.text = "[" + (this.index_fx + 1).ToString() + "] " + this.fx_prefabs[this.index_fx].name;
	}

	// Token: 0x0600092C RID: 2348 RVA: 0x00042570 File Offset: 0x00040770
	private void Update()
	{
		if (Input.GetMouseButtonDown(0))
		{
			this.ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			this.ray_cast_hit = Physics2D.Raycast(new Vector2(this.ray.origin.x, this.ray.origin.y), new Vector2(0f, 0f));
			if (this.ray_cast_hit)
			{
				string name = this.ray_cast_hit.transform.name;
				if (!(name == "BG"))
				{
					if (!(name == "UI-arrow-right"))
					{
						if (!(name == "UI-arrow-left"))
						{
							if (name == "Instructions")
							{
								Object.Destroy(this.ray_cast_hit.transform.gameObject);
							}
						}
						else
						{
							this.ray_cast_hit.transform.SendMessage("Go");
							this.index_fx--;
							if (this.index_fx <= -1)
							{
								this.index_fx = this.fx_prefabs.Length - 1;
							}
							this.text_fx_name.text = "[" + (this.index_fx + 1).ToString() + "] " + this.fx_prefabs[this.index_fx].name;
						}
					}
					else
					{
						this.ray_cast_hit.transform.SendMessage("Go");
						this.index_fx++;
						if (this.index_fx >= this.fx_prefabs.Length)
						{
							this.index_fx = 0;
						}
						this.text_fx_name.text = "[" + (this.index_fx + 1).ToString() + "] " + this.fx_prefabs[this.index_fx].name;
					}
				}
				else
				{
					Object.Instantiate<GameObject>(this.fx_prefabs[this.index_fx], new Vector3(this.ray.origin.x, this.ray.origin.y, 0f), Quaternion.identity);
				}
			}
		}
		if (Input.GetKeyDown("z") || Input.GetKeyDown("left"))
		{
			GameObject.Find("UI-arrow-left").SendMessage("Go");
			this.index_fx--;
			if (this.index_fx <= -1)
			{
				this.index_fx = this.fx_prefabs.Length - 1;
			}
			this.text_fx_name.text = "[" + (this.index_fx + 1).ToString() + "] " + this.fx_prefabs[this.index_fx].name;
		}
		if (Input.GetKeyDown("x") || Input.GetKeyDown("right"))
		{
			GameObject.Find("UI-arrow-right").SendMessage("Go");
			this.index_fx++;
			if (this.index_fx >= this.fx_prefabs.Length)
			{
				this.index_fx = 0;
			}
			this.text_fx_name.text = "[" + (this.index_fx + 1).ToString() + "] " + this.fx_prefabs[this.index_fx].name;
		}
		if (Input.GetKeyDown("space"))
		{
			Object.Instantiate<GameObject>(this.fx_prefabs[this.index_fx], new Vector3(0f, 0f, 0f), Quaternion.identity);
		}
	}

	// Token: 0x04001138 RID: 4408
	public TextMesh text_fx_name;

	// Token: 0x04001139 RID: 4409
	public GameObject[] fx_prefabs;

	// Token: 0x0400113A RID: 4410
	public int index_fx;

	// Token: 0x0400113B RID: 4411
	private Ray ray;

	// Token: 0x0400113C RID: 4412
	private RaycastHit2D ray_cast_hit;
}
