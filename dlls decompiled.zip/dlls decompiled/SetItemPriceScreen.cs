﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000080 RID: 128
public class SetItemPriceScreen : CSingleton<SetItemPriceScreen>
{
	// Token: 0x06000509 RID: 1289 RVA: 0x0002B30A File Offset: 0x0002950A
	private void Awake()
	{
		this.m_ScreenGrp.SetActive(false);
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x0002B318 File Offset: 0x00029518
	private void Update()
	{
		if (!this.m_ScreenGrp.activeSelf)
		{
			return;
		}
		if (Input.GetKeyUp(KeyCode.Escape))
		{
			this.OnPressConfirm();
		}
	}

	// Token: 0x0600050B RID: 1291 RVA: 0x0002B338 File Offset: 0x00029538
	public void OpenSetCardPriceScreen(CardData cardData)
	{
		this.m_IsSetCardPrice = true;
		if (cardData == null || cardData.monsterType == EMonsterType.None)
		{
			Debug.LogError("Card type cannot be none");
			return;
		}
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(true);
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		this.m_CardData = cardData;
		this.m_PriceSet = CPlayerData.GetCardPrice(this.m_CardData);
		this.m_AverageCost = 0f;
		this.m_MarketPrice = CPlayerData.GetCardMarketPrice(this.m_CardData);
		this.m_ItemImage.gameObject.SetActive(false);
		this.m_ItemName.gameObject.SetActive(false);
		this.m_SetPriceCardUI.SetCardUI(this.m_CardData);
		this.m_SetPriceCardUI.gameObject.SetActive(true);
		this.m_SetPrice.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_SetPriceInputDisplay.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_AverageCostText.text = "-";
		this.m_MarketPriceText.text = GameInstance.GetPriceString(this.m_MarketPrice, false, true, false, "F2");
		this.m_SetPriceInputDisplay.gameObject.SetActive(false);
		this.EvaluateProfit();
		this.m_ScreenGrp.SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x0002B49C File Offset: 0x0002969C
	public void OpenScreen(EItemType itemType)
	{
		this.m_IsSetCardPrice = false;
		if (itemType == EItemType.None)
		{
			Debug.LogError("Item type cannot be none");
			return;
		}
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(true);
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		this.m_ItemType = itemType;
		this.m_PriceSet = CPlayerData.GetItemPrice(itemType, false);
		this.m_AverageCost = CPlayerData.GetAverageItemCost(itemType);
		this.m_MarketPrice = CPlayerData.GetItemMarketPrice(itemType);
		this.m_ItemImage.sprite = InventoryBase.GetItemData(itemType).icon;
		this.m_ItemName.text = InventoryBase.GetItemData(itemType).GetName();
		this.m_ItemImage.gameObject.SetActive(true);
		this.m_ItemName.gameObject.SetActive(true);
		this.m_SetPriceCardUI.gameObject.SetActive(false);
		this.m_SetPrice.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_SetPriceInputDisplay.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_AverageCostText.text = GameInstance.GetPriceString(this.m_AverageCost, false, true, false, "F2");
		this.m_MarketPriceText.text = GameInstance.GetPriceString(this.m_MarketPrice, false, true, false, "F2");
		this.m_SetPriceInputDisplay.gameObject.SetActive(false);
		this.EvaluateProfit();
		this.m_ScreenGrp.SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x0002B61C File Offset: 0x0002981C
	public void CloseScreen()
	{
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(false);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
		this.m_ScreenGrp.SetActive(false);
		SoundManager.GenericMenuClose(1f, 1f);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x0600050E RID: 1294 RVA: 0x0002B66C File Offset: 0x0002986C
	private void EvaluateProfit()
	{
		float num = this.m_PriceSet - this.m_AverageCost;
		num = GameInstance.GetConvertedCurrencyPrice(this.m_PriceSet) - GameInstance.GetConvertedCurrencyPrice(this.m_AverageCost);
		num /= GameInstance.GetCurrencyConversionRate();
		this.m_Profit.text = GameInstance.GetPriceString(num, false, true, false, "F2");
		if (num > 0f)
		{
			this.m_Profit.color = Color.green;
			return;
		}
		if (num < 0f)
		{
			this.m_Profit.color = Color.red;
			return;
		}
		this.m_Profit.color = Color.white;
	}

	// Token: 0x0600050F RID: 1295 RVA: 0x0002B702 File Offset: 0x00029902
	public void OnPressConfirm()
	{
		if (this.m_IsSetCardPrice)
		{
			CPlayerData.SetCardPrice(this.m_CardData, this.m_PriceSet);
		}
		else
		{
			TutorialManager.AddTaskValue(ETutorialTaskCondition.SetItemPrice, 1f);
			CPlayerData.SetItemPrice(this.m_ItemType, this.m_PriceSet);
		}
		this.CloseScreen();
	}

	// Token: 0x06000510 RID: 1296 RVA: 0x0002B744 File Offset: 0x00029944
	public void OnInputChanged(string text)
	{
		float num = GameInstance.GetInvariantCultureDecimal(text) / GameInstance.GetCurrencyConversionRate();
		num = (float)Mathf.RoundToInt(num * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		this.m_SetPriceInputDisplay.text = GameInstance.GetPriceString(num, false, true, false, "F2");
		this.m_SetPriceInputDisplay.gameObject.SetActive(true);
		this.m_SetPrice.gameObject.SetActive(false);
		this.EvaluateProfit();
	}

	// Token: 0x06000511 RID: 1297 RVA: 0x0002B7B4 File Offset: 0x000299B4
	public void OnInputTextSelected(string text)
	{
		this.m_SetPriceInputDisplay.gameObject.SetActive(true);
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F0");
		}
		else
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F2");
		}
		this.m_SetPrice.gameObject.SetActive(false);
	}

	// Token: 0x06000512 RID: 1298 RVA: 0x0002B830 File Offset: 0x00029A30
	public void OnInputTextUpdated(string text)
	{
		float num = GameInstance.GetInvariantCultureDecimal(text) / GameInstance.GetCurrencyConversionRate();
		this.m_PriceSet = (float)Mathf.RoundToInt(num * GameInstance.GetCurrencyRoundDivideAmount()) / GameInstance.GetCurrencyRoundDivideAmount();
		if (this.m_PriceSet < 0f)
		{
			this.m_PriceSet = 0f;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F0");
		}
		else
		{
			this.m_SetPriceInput.text = GameInstance.GetPriceString(this.m_PriceSet, false, false, false, "F2");
		}
		this.m_SetPriceInputDisplay.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_SetPrice.text = GameInstance.GetPriceString(this.m_PriceSet, false, true, false, "F2");
		this.m_SetPriceInputDisplay.gameObject.SetActive(false);
		this.m_SetPrice.gameObject.SetActive(true);
		this.EvaluateProfit();
	}

	// Token: 0x06000513 RID: 1299 RVA: 0x0002B92C File Offset: 0x00029B2C
	public void OnPressSetMarketPrice()
	{
		SoundManager.GenericConfirm(1f, 1f);
		this.OnInputTextUpdated((this.m_MarketPrice * GameInstance.GetCurrencyConversionRate()).ToString());
	}

	// Token: 0x06000514 RID: 1300 RVA: 0x0002B964 File Offset: 0x00029B64
	public void OnPressAddPriceTenPercent()
	{
		SoundManager.GenericConfirm(1f, 1f);
		if (this.m_PriceSet <= 0f)
		{
			this.m_PriceSet = this.m_MarketPrice;
		}
		this.OnInputTextUpdated((this.m_PriceSet * 1.1f * GameInstance.GetCurrencyConversionRate()).ToString());
	}

	// Token: 0x06000515 RID: 1301 RVA: 0x0002B9BC File Offset: 0x00029BBC
	public void OnPressReducePriceTenPercent()
	{
		SoundManager.GenericConfirm(1f, 1f);
		if (this.m_PriceSet <= 0f)
		{
			this.m_PriceSet = this.m_MarketPrice;
		}
		this.OnInputTextUpdated((this.m_PriceSet * 0.9f * GameInstance.GetCurrencyConversionRate()).ToString());
	}

	// Token: 0x06000516 RID: 1302 RVA: 0x0002BA14 File Offset: 0x00029C14
	public void OnPressRoundPriceToFullNumber()
	{
		SoundManager.GenericConfirm(1f, 1f);
		if (this.m_PriceSet <= 0f)
		{
			this.m_PriceSet = this.m_MarketPrice;
		}
		if (CSingleton<CGameManager>.Instance.m_CurrencyType == EMoneyCurrencyType.Yen)
		{
			this.OnInputTextUpdated((Mathf.RoundToInt(this.m_PriceSet * GameInstance.GetCurrencyConversionRate() / 100f) * 100).ToString());
			return;
		}
		this.OnInputTextUpdated(Mathf.RoundToInt(this.m_PriceSet * GameInstance.GetCurrencyConversionRate()).ToString());
	}

	// Token: 0x040006AD RID: 1709
	public GameObject m_ScreenGrp;

	// Token: 0x040006AE RID: 1710
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040006AF RID: 1711
	public Image m_ItemImage;

	// Token: 0x040006B0 RID: 1712
	public TextMeshProUGUI m_ItemName;

	// Token: 0x040006B1 RID: 1713
	public TextMeshProUGUI m_AverageCostText;

	// Token: 0x040006B2 RID: 1714
	public TextMeshProUGUI m_MarketPriceText;

	// Token: 0x040006B3 RID: 1715
	public TMP_InputField m_SetPriceInput;

	// Token: 0x040006B4 RID: 1716
	public TextMeshProUGUI m_SetPriceInputDisplay;

	// Token: 0x040006B5 RID: 1717
	public TextMeshProUGUI m_SetPrice;

	// Token: 0x040006B6 RID: 1718
	public TextMeshProUGUI m_Profit;

	// Token: 0x040006B7 RID: 1719
	public CardUI m_SetPriceCardUI;

	// Token: 0x040006B8 RID: 1720
	private float m_PriceSet;

	// Token: 0x040006B9 RID: 1721
	private float m_AverageCost;

	// Token: 0x040006BA RID: 1722
	private float m_MarketPrice;

	// Token: 0x040006BB RID: 1723
	private EItemType m_ItemType = EItemType.None;

	// Token: 0x040006BC RID: 1724
	private CardData m_CardData;

	// Token: 0x040006BD RID: 1725
	private bool m_IsSetCardPrice = true;
}
