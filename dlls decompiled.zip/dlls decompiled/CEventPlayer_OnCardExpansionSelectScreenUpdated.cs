﻿using System;

// Token: 0x020000C2 RID: 194
public class CEventPlayer_OnCardExpansionSelectScreenUpdated : CEvent
{
	// Token: 0x17000020 RID: 32
	// (get) Token: 0x06000729 RID: 1833 RVA: 0x000381C7 File Offset: 0x000363C7
	// (set) Token: 0x0600072A RID: 1834 RVA: 0x000381CF File Offset: 0x000363CF
	public int m_CardExpansionTypeIndex { get; private set; }

	// Token: 0x0600072B RID: 1835 RVA: 0x000381D8 File Offset: 0x000363D8
	public CEventPlayer_OnCardExpansionSelectScreenUpdated(int cardExpansionTypeIndex)
	{
		this.m_CardExpansionTypeIndex = cardExpansionTypeIndex;
	}
}
