﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000026 RID: 38
public class InteractablePlayTable : InteractableObject
{
	// Token: 0x060001EA RID: 490 RVA: 0x00014200 File Offset: 0x00012400
	public bool IsLookingForPlayer(bool findTableWithPlayerWaiting)
	{
		return (!findTableWithPlayerWaiting && this.m_CurrentPlayerCount == 0 && this.HasSeatBooking() && this.HasEmptySeatBooking()) || (this.m_CurrentPlayerCount > 0 && this.m_CurrentPlayerCount < this.m_MaxSeatCount && this.HasEmptySeatBooking());
	}

	// Token: 0x060001EB RID: 491 RVA: 0x0001424C File Offset: 0x0001244C
	protected override void Awake()
	{
		base.Awake();
		ShelfManager.InitPlayTable(this);
		for (int i = 0; i < this.m_MaxSeatCount; i++)
		{
			this.m_IsSeatBooked.Add(false);
			this.m_IsSeatOccupied.Add(false);
			this.m_IsQueueOccupied.Add(false);
			this.m_IsCustomerSmelly.Add(false);
			this.m_IsStandLocValid.Add(true);
			this.m_IsStandLocBValid.Add(true);
			this.m_OccupiedCustomer.Add(null);
			this.m_PlayTableFee.Add(0f);
		}
		for (int j = 0; j < this.m_OccupiedCustomer.Count; j++)
		{
			this.m_TableGameItemSetList[j].gameObject.SetActive(false);
		}
	}

	// Token: 0x060001EC RID: 492 RVA: 0x00014307 File Offset: 0x00012507
	public override void StartMoveObject()
	{
		if (this.m_CurrentPlayerCount > 0)
		{
			this.StopTableGame();
			return;
		}
		base.StartMoveObject();
	}

	// Token: 0x060001ED RID: 493 RVA: 0x0001431F File Offset: 0x0001251F
	protected override void OnPlacedMovedObject()
	{
		base.OnPlacedMovedObject();
		if (this.m_ObjectType == EObjectType.PlayTable)
		{
			TutorialManager.AddTaskValue(ETutorialTaskCondition.BuyPlayTable, 1f);
		}
		this.EvaluateValidStandLoc();
	}

	// Token: 0x060001EE RID: 494 RVA: 0x00014344 File Offset: 0x00012544
	private void EvaluateValidStandLoc()
	{
		for (int i = 0; i < this.m_StandLocList.Count; i++)
		{
			int mask = LayerMask.GetMask(new string[]
			{
				"PlayTableStandLocBlockedArea",
				"Glass"
			});
			Collider[] array = Physics.OverlapBox(this.m_StandLocList[i].position + Vector3.up, Vector3.one * 0.1f, this.m_StandLocList[i].rotation, mask);
			this.m_IsStandLocValid[i] = (array.Length == 0);
		}
		for (int j = 0; j < this.m_StandLocBList.Count; j++)
		{
			int mask2 = LayerMask.GetMask(new string[]
			{
				"PlayTableStandLocBlockedArea",
				"Glass"
			});
			Collider[] array2 = Physics.OverlapBox(this.m_StandLocBList[j].position + Vector3.up, Vector3.one * 0.1f, Quaternion.identity, mask2);
			this.m_IsStandLocBValid[j] = (array2.Length == 0);
		}
	}

	// Token: 0x060001EF RID: 495 RVA: 0x00014456 File Offset: 0x00012656
	protected override void Update()
	{
		base.Update();
		if (this.m_HasStartPlay)
		{
			this.m_CurrentPlayTime += Time.deltaTime;
			if (this.m_CurrentPlayTime >= this.m_CurrentPlayTimeMax)
			{
				this.StopTableGame();
			}
		}
	}

	// Token: 0x060001F0 RID: 496 RVA: 0x0001448C File Offset: 0x0001268C
	private void StopTableGame()
	{
		if (!this.m_HasStartPlay)
		{
			this.m_CurrentPlayTime = 0f;
		}
		for (int i = 0; i < this.m_OccupiedCustomer.Count; i++)
		{
			if (this.m_OccupiedCustomer[i])
			{
				this.m_OccupiedCustomer[i].PlayTableGameEnded(this.m_CurrentPlayTime, this.m_PlayTableFee[i]);
			}
		}
		for (int j = 0; j < this.m_OccupiedCustomer.Count; j++)
		{
			this.m_TableGameItemSetList[j].gameObject.SetActive(false);
		}
		this.m_HasStartPlay = false;
		this.m_CurrentPlayTime = 0f;
		this.m_CurrentPlayerCount = 0;
		for (int k = 0; k < this.m_IsSeatOccupied.Count; k++)
		{
			this.m_IsSeatOccupied[k] = false;
			this.m_IsSeatBooked[k] = false;
			this.m_IsCustomerSmelly[k] = false;
			this.m_IsQueueOccupied[k] = false;
			this.m_OccupiedCustomer[k] = null;
			this.m_PlayTableFee[k] = 0f;
		}
		this.m_EmptySeatIndex.Clear();
		this.m_OccupiedSeatIndex.Clear();
	}

	// Token: 0x060001F1 RID: 497 RVA: 0x000145BC File Offset: 0x000127BC
	public void LoadData(PlayTableSaveData playTableSaveData)
	{
		this.m_HasStartPlay = playTableSaveData.hasStartPlay;
		this.m_IsSeatOccupied = playTableSaveData.isSeatOccupied;
		this.m_CurrentPlayerCount = playTableSaveData.currentPlayerCount;
		this.m_CurrentPlayTime = playTableSaveData.currentPlayTime;
		this.m_CurrentPlayTimeMax = playTableSaveData.currentPlayTimeMax;
		if (playTableSaveData.isCustomerSmelly != null)
		{
			this.m_IsCustomerSmelly = playTableSaveData.isCustomerSmelly;
		}
		if (playTableSaveData.playTableFee == null || playTableSaveData.playTableFee.Count < this.m_MaxSeatCount)
		{
			playTableSaveData.playTableFee = new List<float>();
			playTableSaveData.playTableFee.Clear();
			for (int i = 0; i < this.m_MaxSeatCount; i++)
			{
				playTableSaveData.playTableFee.Add(0f);
			}
		}
		this.m_PlayTableFee = playTableSaveData.playTableFee;
		int num = 0;
		for (int j = 0; j < this.m_IsSeatOccupied.Count; j++)
		{
			if (this.m_IsSeatOccupied[j])
			{
				Customer newCustomer = CSingleton<CustomerManager>.Instance.GetNewCustomer();
				newCustomer.InstantSnapToPlayTable(this, j, this.m_HasStartPlay);
				this.m_OccupiedCustomer[j] = newCustomer;
				if (this.m_IsCustomerSmelly[j])
				{
					newCustomer.SetSmelly();
				}
				num++;
			}
		}
		if (this.m_HasStartPlay)
		{
			for (int k = 0; k < this.m_OccupiedCustomer.Count; k++)
			{
				this.m_TableGameItemSetList[k].gameObject.SetActive(true);
			}
		}
		else if (num >= this.m_MaxSeatCount)
		{
			this.m_CurrentPlayerCount = 0;
			for (int l = 0; l < this.m_MaxSeatCount; l++)
			{
				this.CustomerHasReached(this.m_OccupiedCustomer[l], l);
			}
		}
		this.EvaluateValidStandLoc();
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x00014757 File Offset: 0x00012957
	public Transform GetStandLoc(int index, bool canReturnNull = false)
	{
		if (this.m_IsStandLocValid[index])
		{
			return this.m_StandLocList[index];
		}
		if (canReturnNull)
		{
			return null;
		}
		return this.GetStandLocB(index, true);
	}

	// Token: 0x060001F3 RID: 499 RVA: 0x00014781 File Offset: 0x00012981
	public Transform GetStandLocB(int index, bool canReturnNull = false)
	{
		if (this.m_IsStandLocBValid[index])
		{
			return this.m_StandLocBList[index];
		}
		if (canReturnNull)
		{
			return null;
		}
		return this.GetStandLoc(index, true);
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x000147AB File Offset: 0x000129AB
	public Transform GetSitLoc(int index)
	{
		return this.m_SitLocList[index];
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x000147B9 File Offset: 0x000129B9
	public void CustomerBookSeatIndex(int bookedSeatIndex)
	{
	}

	// Token: 0x060001F6 RID: 502 RVA: 0x000147BB File Offset: 0x000129BB
	public void CustomerUnbookSeatIndex(int bookedSeatIndex)
	{
		this.m_IsSeatBooked[bookedSeatIndex] = false;
	}

	// Token: 0x060001F7 RID: 503 RVA: 0x000147CA File Offset: 0x000129CA
	public void CustomerBookQueueIndex(int bookedSeatIndex)
	{
		this.m_IsQueueOccupied[bookedSeatIndex] = true;
	}

	// Token: 0x060001F8 RID: 504 RVA: 0x000147D9 File Offset: 0x000129D9
	public void CustomerUnbookQueueIndex(int bookedSeatIndex)
	{
		this.m_IsQueueOccupied[bookedSeatIndex] = false;
	}

	// Token: 0x060001F9 RID: 505 RVA: 0x000147E8 File Offset: 0x000129E8
	public void CustomerHasReached(Customer customer, int seatIndex)
	{
		this.m_OccupiedCustomer[seatIndex] = customer;
		this.m_IsSeatBooked[seatIndex] = false;
		this.m_IsSeatOccupied[seatIndex] = true;
		this.m_PlayTableFee[seatIndex] = customer.GetCurrentPlayTableFee();
		this.m_IsCustomerSmelly[seatIndex] = customer.IsSmelly();
		this.m_CurrentPlayerCount++;
		if (this.m_CurrentPlayerCount >= this.m_MaxSeatCount)
		{
			this.m_HasStartPlay = true;
			this.m_CurrentPlayTime = 0f;
			this.m_CurrentPlayTimeMax = (float)Random.Range(15, 180);
			for (int i = 0; i < this.m_OccupiedCustomer.Count; i++)
			{
				this.m_OccupiedCustomer[i].PlayTableGameStarted();
			}
			for (int j = 0; j < this.m_OccupiedCustomer.Count; j++)
			{
				this.m_TableGameItemSetList[j].gameObject.SetActive(true);
			}
		}
	}

	// Token: 0x060001FA RID: 506 RVA: 0x000148D8 File Offset: 0x00012AD8
	public bool HasSeatBooking()
	{
		for (int i = 0; i < this.m_IsSeatBooked.Count; i++)
		{
			if (this.m_IsSeatBooked[i])
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060001FB RID: 507 RVA: 0x0001490C File Offset: 0x00012B0C
	public bool HasEmptySeatBooking()
	{
		for (int i = 0; i < this.m_IsSeatBooked.Count; i++)
		{
			if (!this.m_IsSeatBooked[i])
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060001FC RID: 508 RVA: 0x00014940 File Offset: 0x00012B40
	public bool HasEmptyQueue()
	{
		for (int i = 0; i < this.m_IsQueueOccupied.Count; i++)
		{
			if (!this.m_IsQueueOccupied[i])
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060001FD RID: 509 RVA: 0x00014974 File Offset: 0x00012B74
	public bool IsSeatEmpty(int index)
	{
		return !this.m_IsSeatOccupied[index];
	}

	// Token: 0x060001FE RID: 510 RVA: 0x00014985 File Offset: 0x00012B85
	public bool IsQueueEmpty(int index)
	{
		return !this.m_IsQueueOccupied[index];
	}

	// Token: 0x060001FF RID: 511 RVA: 0x00014998 File Offset: 0x00012B98
	public int GetEmptySeatBookingIndex()
	{
		this.m_EmptySeatIndex.Clear();
		this.m_OccupiedSeatIndex.Clear();
		for (int i = 0; i < this.m_IsSeatBooked.Count; i++)
		{
			if (!this.m_IsSeatBooked[i])
			{
				this.m_EmptySeatIndex.Add(i);
			}
			else
			{
				this.m_OccupiedSeatIndex.Add(i);
			}
		}
		if (this.m_EmptySeatIndex.Count <= 0)
		{
			return -1;
		}
		return this.m_EmptySeatIndex[Random.Range(0, this.m_EmptySeatIndex.Count)];
	}

	// Token: 0x06000200 RID: 512 RVA: 0x00014A28 File Offset: 0x00012C28
	public int GetEmptySeatIndex()
	{
		if (this.m_CurrentPlayerCount >= this.m_MaxSeatCount)
		{
			return -1;
		}
		this.m_EmptySeatIndex.Clear();
		this.m_OccupiedSeatIndex.Clear();
		for (int i = 0; i < this.m_IsSeatOccupied.Count; i++)
		{
			if (!this.m_IsSeatOccupied[i])
			{
				this.m_EmptySeatIndex.Add(i);
			}
			else
			{
				this.m_OccupiedSeatIndex.Add(i);
			}
		}
		if (this.m_EmptySeatIndex.Count <= 0)
		{
			return -1;
		}
		return this.m_EmptySeatIndex[Random.Range(0, this.m_EmptySeatIndex.Count)];
	}

	// Token: 0x06000201 RID: 513 RVA: 0x00014AC5 File Offset: 0x00012CC5
	public override void OnDestroyed()
	{
		ShelfManager.RemovePlayTable(this);
		base.OnDestroyed();
	}

	// Token: 0x06000202 RID: 514 RVA: 0x00014AD3 File Offset: 0x00012CD3
	public void SetIndex(int index)
	{
		this.m_Index = index;
	}

	// Token: 0x06000203 RID: 515 RVA: 0x00014ADC File Offset: 0x00012CDC
	public int GetIndex()
	{
		return this.m_Index;
	}

	// Token: 0x06000204 RID: 516 RVA: 0x00014AE4 File Offset: 0x00012CE4
	public bool GetHasStartPlay()
	{
		return this.m_HasStartPlay;
	}

	// Token: 0x06000205 RID: 517 RVA: 0x00014AEC File Offset: 0x00012CEC
	public List<bool> GetIsSeatOccupied()
	{
		return this.m_IsSeatOccupied;
	}

	// Token: 0x06000206 RID: 518 RVA: 0x00014AF4 File Offset: 0x00012CF4
	public List<bool> GetIsCustomerSmelly()
	{
		return this.m_IsCustomerSmelly;
	}

	// Token: 0x06000207 RID: 519 RVA: 0x00014AFC File Offset: 0x00012CFC
	public List<float> GetPlayTableFee()
	{
		return this.m_PlayTableFee;
	}

	// Token: 0x06000208 RID: 520 RVA: 0x00014B04 File Offset: 0x00012D04
	public int GetCurrentPlayerCount()
	{
		return this.m_CurrentPlayerCount;
	}

	// Token: 0x06000209 RID: 521 RVA: 0x00014B0C File Offset: 0x00012D0C
	public float GetCurrentPlayTime()
	{
		return this.m_CurrentPlayTime;
	}

	// Token: 0x0600020A RID: 522 RVA: 0x00014B14 File Offset: 0x00012D14
	public float GetCurrentPlayTimeMax()
	{
		return this.m_CurrentPlayTimeMax;
	}

	// Token: 0x0600020B RID: 523 RVA: 0x00014B1C File Offset: 0x00012D1C
	public void OnPressGoNextDay()
	{
		this.StopTableGame();
	}

	// Token: 0x0600020C RID: 524 RVA: 0x00014B24 File Offset: 0x00012D24
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.AddListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x0600020D RID: 525 RVA: 0x00014B74 File Offset: 0x00012D74
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.RemoveListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x0600020E RID: 526 RVA: 0x00014BC4 File Offset: 0x00012DC4
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		for (int i = 0; i < this.m_OccupiedCustomer.Count; i++)
		{
			if (this.m_OccupiedCustomer[i])
			{
				this.m_OccupiedCustomer[i].DeactivateCustomer();
			}
			this.m_OccupiedCustomer[i] = null;
		}
		this.StopTableGame();
	}

	// Token: 0x0600020F RID: 527 RVA: 0x00014C1E File Offset: 0x00012E1E
	protected void OnDayEnded(CEventPlayer_OnDayEnded evt)
	{
		this.m_CurrentPlayTimeMax -= Random.Range(0f, this.m_CurrentPlayTimeMax - this.m_CurrentPlayTime);
	}

	// Token: 0x06000210 RID: 528 RVA: 0x00014C44 File Offset: 0x00012E44
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.EvaluateValidStandLoc();
	}

	// Token: 0x0400024E RID: 590
	public List<Transform> m_StandLocList;

	// Token: 0x0400024F RID: 591
	public List<Transform> m_StandLocBList;

	// Token: 0x04000250 RID: 592
	public List<Transform> m_SitLocList;

	// Token: 0x04000251 RID: 593
	public List<TableGameItemSet> m_TableGameItemSetList;

	// Token: 0x04000252 RID: 594
	public int m_MaxSeatCount = 2;

	// Token: 0x04000253 RID: 595
	public bool m_HasStartPlay;

	// Token: 0x04000254 RID: 596
	public List<bool> m_IsSeatBooked = new List<bool>();

	// Token: 0x04000255 RID: 597
	public List<bool> m_IsSeatOccupied = new List<bool>();

	// Token: 0x04000256 RID: 598
	public List<bool> m_IsQueueOccupied = new List<bool>();

	// Token: 0x04000257 RID: 599
	public List<bool> m_IsCustomerSmelly = new List<bool>();

	// Token: 0x04000258 RID: 600
	public List<bool> m_IsStandLocValid = new List<bool>();

	// Token: 0x04000259 RID: 601
	public List<bool> m_IsStandLocBValid = new List<bool>();

	// Token: 0x0400025A RID: 602
	private List<int> m_EmptySeatIndex = new List<int>();

	// Token: 0x0400025B RID: 603
	private List<int> m_OccupiedSeatIndex = new List<int>();

	// Token: 0x0400025C RID: 604
	public List<float> m_PlayTableFee = new List<float>();

	// Token: 0x0400025D RID: 605
	private List<Customer> m_OccupiedCustomer = new List<Customer>();

	// Token: 0x0400025E RID: 606
	private int m_Index;

	// Token: 0x0400025F RID: 607
	public int m_CurrentPlayerCount;

	// Token: 0x04000260 RID: 608
	public float m_CurrentPlayTime;

	// Token: 0x04000261 RID: 609
	public float m_CurrentPlayTimeMax;
}
