﻿using System;

// Token: 0x020000F9 RID: 249
public enum EAchievementID
{
	// Token: 0x04000D9D RID: 3485
	Main1,
	// Token: 0x04000D9E RID: 3486
	Main2,
	// Token: 0x04000D9F RID: 3487
	Main3,
	// Token: 0x04000DA0 RID: 3488
	Main4,
	// Token: 0x04000DA1 RID: 3489
	Main5,
	// Token: 0x04000DA2 RID: 3490
	TetramonCollector1,
	// Token: 0x04000DA3 RID: 3491
	TetramonCollector2,
	// Token: 0x04000DA4 RID: 3492
	TetramonCollector3,
	// Token: 0x04000DA5 RID: 3493
	TetramonCollector4,
	// Token: 0x04000DA6 RID: 3494
	TetramonCollector5,
	// Token: 0x04000DA7 RID: 3495
	TetramonCollector6,
	// Token: 0x04000DA8 RID: 3496
	BasicCardBox,
	// Token: 0x04000DA9 RID: 3497
	LegendaryPack,
	// Token: 0x04000DAA RID: 3498
	BasicPackSales1,
	// Token: 0x04000DAB RID: 3499
	BasicPackSales2,
	// Token: 0x04000DAC RID: 3500
	BasicPackSales3,
	// Token: 0x04000DAD RID: 3501
	RareBoxSales1,
	// Token: 0x04000DAE RID: 3502
	RareBoxSales2,
	// Token: 0x04000DAF RID: 3503
	RareBoxSales3,
	// Token: 0x04000DB0 RID: 3504
	EpicPackSales1,
	// Token: 0x04000DB1 RID: 3505
	EpicPackSales2,
	// Token: 0x04000DB2 RID: 3506
	EpicPackSales3,
	// Token: 0x04000DB3 RID: 3507
	LegendaryBoxSales1,
	// Token: 0x04000DB4 RID: 3508
	LegendaryBoxSales2,
	// Token: 0x04000DB5 RID: 3509
	LegendaryBoxSales3,
	// Token: 0x04000DB6 RID: 3510
	Customer1,
	// Token: 0x04000DB7 RID: 3511
	Customer2,
	// Token: 0x04000DB8 RID: 3512
	Customer3,
	// Token: 0x04000DB9 RID: 3513
	Global1,
	// Token: 0x04000DBA RID: 3514
	Global2,
	// Token: 0x04000DBB RID: 3515
	Global3,
	// Token: 0x04000DBC RID: 3516
	ShopExpand1,
	// Token: 0x04000DBD RID: 3517
	ShopExpand2,
	// Token: 0x04000DBE RID: 3518
	ShopExpand3,
	// Token: 0x04000DBF RID: 3519
	ShopAttract1,
	// Token: 0x04000DC0 RID: 3520
	ShopAttract2,
	// Token: 0x04000DC1 RID: 3521
	ShopAttract3,
	// Token: 0x04000DC2 RID: 3522
	ShopAttract4,
	// Token: 0x04000DC3 RID: 3523
	Shelf1,
	// Token: 0x04000DC4 RID: 3524
	Shelf2,
	// Token: 0x04000DC5 RID: 3525
	Shelf3,
	// Token: 0x04000DC6 RID: 3526
	SmTable1,
	// Token: 0x04000DC7 RID: 3527
	SmTable2,
	// Token: 0x04000DC8 RID: 3528
	SmTable3,
	// Token: 0x04000DC9 RID: 3529
	MediumTable1,
	// Token: 0x04000DCA RID: 3530
	MediumTable2,
	// Token: 0x04000DCB RID: 3531
	MediumTable3,
	// Token: 0x04000DCC RID: 3532
	LongShelf1,
	// Token: 0x04000DCD RID: 3533
	LongShelf2,
	// Token: 0x04000DCE RID: 3534
	LongShelf3,
	// Token: 0x04000DCF RID: 3535
	ATM1,
	// Token: 0x04000DD0 RID: 3536
	ATM2,
	// Token: 0x04000DD1 RID: 3537
	ATM3,
	// Token: 0x04000DD2 RID: 3538
	Loudspeaker1,
	// Token: 0x04000DD3 RID: 3539
	Loudspeaker2,
	// Token: 0x04000DD4 RID: 3540
	Loudspeaker3,
	// Token: 0x04000DD5 RID: 3541
	Trolley1,
	// Token: 0x04000DD6 RID: 3542
	Trolley2,
	// Token: 0x04000DD7 RID: 3543
	Trolley3,
	// Token: 0x04000DD8 RID: 3544
	PackStorage1,
	// Token: 0x04000DD9 RID: 3545
	PackStorage2,
	// Token: 0x04000DDA RID: 3546
	PackStorage3,
	// Token: 0x04000DDB RID: 3547
	Pigni1,
	// Token: 0x04000DDC RID: 3548
	Pigni2,
	// Token: 0x04000DDD RID: 3549
	Pigni3,
	// Token: 0x04000DDE RID: 3550
	Trickstar1,
	// Token: 0x04000DDF RID: 3551
	Trickstar2,
	// Token: 0x04000DE0 RID: 3552
	Trickstar3,
	// Token: 0x04000DE1 RID: 3553
	Meganite1,
	// Token: 0x04000DE2 RID: 3554
	Meganite2,
	// Token: 0x04000DE3 RID: 3555
	Meganite3,
	// Token: 0x04000DE4 RID: 3556
	Dracunix1,
	// Token: 0x04000DE5 RID: 3557
	Dracunix2,
	// Token: 0x04000DE6 RID: 3558
	Dracunix3,
	// Token: 0x04000DE7 RID: 3559
	Vehicle1,
	// Token: 0x04000DE8 RID: 3560
	Vehicle2,
	// Token: 0x04000DE9 RID: 3561
	Vehicle3,
	// Token: 0x04000DEA RID: 3562
	Bike1,
	// Token: 0x04000DEB RID: 3563
	Bike2,
	// Token: 0x04000DEC RID: 3564
	Bike3,
	// Token: 0x04000DED RID: 3565
	Van1,
	// Token: 0x04000DEE RID: 3566
	Van2,
	// Token: 0x04000DEF RID: 3567
	Van3,
	// Token: 0x04000DF0 RID: 3568
	Helicopter1,
	// Token: 0x04000DF1 RID: 3569
	Helicopter2,
	// Token: 0x04000DF2 RID: 3570
	Helicopter3,
	// Token: 0x04000DF3 RID: 3571
	DestinyCard1,
	// Token: 0x04000DF4 RID: 3572
	DestinyCard2,
	// Token: 0x04000DF5 RID: 3573
	DestinyCard3,
	// Token: 0x04000DF6 RID: 3574
	DestinyCard4,
	// Token: 0x04000DF7 RID: 3575
	DestinyCard5,
	// Token: 0x04000DF8 RID: 3576
	DestinyCard6,
	// Token: 0x04000DF9 RID: 3577
	DestinyBasic1,
	// Token: 0x04000DFA RID: 3578
	DestinyBasic2,
	// Token: 0x04000DFB RID: 3579
	DestinyBasic3,
	// Token: 0x04000DFC RID: 3580
	DestinyRare1,
	// Token: 0x04000DFD RID: 3581
	DestinyRare2,
	// Token: 0x04000DFE RID: 3582
	DestinyRare3,
	// Token: 0x04000DFF RID: 3583
	DestinyEpic1,
	// Token: 0x04000E00 RID: 3584
	DestinyEpic2,
	// Token: 0x04000E01 RID: 3585
	DestinyEpic3,
	// Token: 0x04000E02 RID: 3586
	DestinyLegendary1,
	// Token: 0x04000E03 RID: 3587
	DestinyLegendary2,
	// Token: 0x04000E04 RID: 3588
	DestinyLegendary3,
	// Token: 0x04000E05 RID: 3589
	GhostCard1,
	// Token: 0x04000E06 RID: 3590
	GhostCard2,
	// Token: 0x04000E07 RID: 3591
	GhostCard3,
	// Token: 0x04000E08 RID: 3592
	GhostCard4,
	// Token: 0x04000E09 RID: 3593
	GhostCard5,
	// Token: 0x04000E0A RID: 3594
	GhostCard6,
	// Token: 0x04000E0B RID: 3595
	GhostPack1,
	// Token: 0x04000E0C RID: 3596
	GhostPack2,
	// Token: 0x04000E0D RID: 3597
	GhostPack3
}
