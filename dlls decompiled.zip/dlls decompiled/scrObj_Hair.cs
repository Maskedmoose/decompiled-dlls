﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B3 RID: 435
	[CreateAssetMenu(fileName = "Hair", menuName = "ScriptableObjects/Hair")]
	public class scrObj_Hair : ScriptableObject
	{
		// Token: 0x04001351 RID: 4945
		public List<scrObj_Hair.Hairstyle> Hairstyles = new List<scrObj_Hair.Hairstyle>();

		// Token: 0x04001352 RID: 4946
		public string ShadowMapProperty;

		// Token: 0x04001353 RID: 4947
		public string TintProperty;

		// Token: 0x02000268 RID: 616
		[Serializable]
		public struct Hairstyle
		{
			// Token: 0x04001655 RID: 5717
			public GameObject Mesh;

			// Token: 0x04001656 RID: 5718
			public string Name;

			// Token: 0x04001657 RID: 5719
			public Texture2D ShadowMap;

			// Token: 0x04001658 RID: 5720
			public bool AddCopyPoseScript;

			// Token: 0x04001659 RID: 5721
			public Sprite Icon;
		}
	}
}
