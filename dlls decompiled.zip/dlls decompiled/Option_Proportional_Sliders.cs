﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001CA RID: 458
	public class Option_Proportional_Sliders : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CDA RID: 3290 RVA: 0x0005915C File Offset: 0x0005735C
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util ParentUI)
		{
			this.customizer = customizerScript;
			this.parentUI = ParentUI;
			for (int i = 0; i < this.Objects.Count; i++)
			{
				Option_Slider component = Object.Instantiate<GameObject>(this.SliderObject, base.transform).GetComponent<Option_Slider>();
				this.sliderObjects.Add(component);
				component.Property.propertyName = this.Objects[i];
				component.CustomizationType = Option_Slider.Type.Blendshape;
				component.InitializeUIElement(customizerScript, ParentUI);
				Slider slider = component.GetComponentInChildren<Slider>();
				this.sliders.Add(slider);
				slider.onValueChanged.AddListener(delegate(float <p0>)
				{
					this.checkExcess(slider);
				});
				component.GetComponentInChildren<TextMeshProUGUI>().text = this.TextPrefix + (i + 1).ToString();
				component.GetComponent<RectTransform>().SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this.SliderHeight);
				if (this.RemoveText)
				{
					Object.Destroy(component.GetComponentInChildren<TextMeshProUGUI>().gameObject);
				}
			}
			base.gameObject.GetComponent<RectTransform>().SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, base.gameObject.GetComponent<RectTransform>().rect.height + (this.SliderHeight + base.gameObject.GetComponent<VerticalLayoutGroup>().spacing) * (float)this.sliderObjects.Count);
		}

		// Token: 0x06000CDB RID: 3291 RVA: 0x000592BC File Offset: 0x000574BC
		public void RefreshUIElement()
		{
		}

		// Token: 0x06000CDC RID: 3292 RVA: 0x000592C0 File Offset: 0x000574C0
		public void checkExcess(Slider mainSlider)
		{
			this.sliderSum = 0f;
			foreach (Slider slider in this.sliders)
			{
				this.sliderSum = slider.value + this.sliderSum;
			}
			if (this.sliderSum > 1f)
			{
				for (int i = 0; i < this.sliders.Count; i++)
				{
					if (mainSlider != this.sliders[i])
					{
						this.distributeExcess(this.sliderSum - mainSlider.value, this.sliderSum - 1f, i);
					}
				}
			}
		}

		// Token: 0x06000CDD RID: 3293 RVA: 0x00059384 File Offset: 0x00057584
		public void distributeExcess(float sum, float excess, int index)
		{
			this.sliders[index].SetValueWithoutNotify(this.sliders[index].value - this.sliders[index].value / sum * excess);
			this.sliderObjects[index].setProperty(this.sliders[index].value);
		}

		// Token: 0x040013BB RID: 5051
		private CharacterCustomization customizer;

		// Token: 0x040013BC RID: 5052
		private CC_UI_Util parentUI;

		// Token: 0x040013BD RID: 5053
		public List<string> Objects = new List<string>();

		// Token: 0x040013BE RID: 5054
		public string MeshTag = "";

		// Token: 0x040013BF RID: 5055
		public int MaterialIndex = -1;

		// Token: 0x040013C0 RID: 5056
		public float SliderHeight = 60f;

		// Token: 0x040013C1 RID: 5057
		public string TextPrefix = "";

		// Token: 0x040013C2 RID: 5058
		public bool RemoveText;

		// Token: 0x040013C3 RID: 5059
		private float sliderSum;

		// Token: 0x040013C4 RID: 5060
		public GameObject SliderObject;

		// Token: 0x040013C5 RID: 5061
		private List<Slider> sliders = new List<Slider>();

		// Token: 0x040013C6 RID: 5062
		private List<Option_Slider> sliderObjects = new List<Option_Slider>();
	}
}
