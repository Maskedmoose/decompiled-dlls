﻿using System;
using UnityEngine;

// Token: 0x0200014A RID: 330
public class CeilingDetector : MonoBehaviour
{
	// Token: 0x0600094F RID: 2383 RVA: 0x000437F3 File Offset: 0x000419F3
	private void Awake()
	{
		this.tr = base.transform;
	}

	// Token: 0x06000950 RID: 2384 RVA: 0x00043801 File Offset: 0x00041A01
	private void OnCollisionEnter(Collision _collision)
	{
		this.CheckCollisionAngles(_collision);
	}

	// Token: 0x06000951 RID: 2385 RVA: 0x0004380A File Offset: 0x00041A0A
	private void OnCollisionStay(Collision _collision)
	{
		this.CheckCollisionAngles(_collision);
	}

	// Token: 0x06000952 RID: 2386 RVA: 0x00043814 File Offset: 0x00041A14
	private void CheckCollisionAngles(Collision _collision)
	{
		float num = 0f;
		if (this.ceilingDetectionMethod == CeilingDetector.CeilingDetectionMethod.OnlyCheckFirstContact)
		{
			num = Vector3.Angle(-this.tr.up, _collision.contacts[0].normal);
			if (num < this.ceilingAngleLimit)
			{
				this.ceilingWasHit = true;
			}
			if (this.isInDebugMode)
			{
				Debug.DrawRay(_collision.contacts[0].point, _collision.contacts[0].normal, Color.red, this.debugDrawDuration);
			}
		}
		if (this.ceilingDetectionMethod == CeilingDetector.CeilingDetectionMethod.CheckAllContacts)
		{
			for (int i = 0; i < _collision.contacts.Length; i++)
			{
				num = Vector3.Angle(-this.tr.up, _collision.contacts[i].normal);
				if (num < this.ceilingAngleLimit)
				{
					this.ceilingWasHit = true;
				}
				if (this.isInDebugMode)
				{
					Debug.DrawRay(_collision.contacts[i].point, _collision.contacts[i].normal, Color.red, this.debugDrawDuration);
				}
			}
		}
		if (this.ceilingDetectionMethod == CeilingDetector.CeilingDetectionMethod.CheckAverageOfAllContacts)
		{
			for (int j = 0; j < _collision.contacts.Length; j++)
			{
				num += Vector3.Angle(-this.tr.up, _collision.contacts[j].normal);
				if (this.isInDebugMode)
				{
					Debug.DrawRay(_collision.contacts[j].point, _collision.contacts[j].normal, Color.red, this.debugDrawDuration);
				}
			}
			if (num / (float)_collision.contacts.Length < this.ceilingAngleLimit)
			{
				this.ceilingWasHit = true;
			}
		}
	}

	// Token: 0x06000953 RID: 2387 RVA: 0x000439CC File Offset: 0x00041BCC
	public bool HitCeiling()
	{
		return this.ceilingWasHit;
	}

	// Token: 0x06000954 RID: 2388 RVA: 0x000439D4 File Offset: 0x00041BD4
	public void ResetFlags()
	{
		this.ceilingWasHit = false;
	}

	// Token: 0x04001181 RID: 4481
	private bool ceilingWasHit;

	// Token: 0x04001182 RID: 4482
	public float ceilingAngleLimit = 10f;

	// Token: 0x04001183 RID: 4483
	public CeilingDetector.CeilingDetectionMethod ceilingDetectionMethod;

	// Token: 0x04001184 RID: 4484
	public bool isInDebugMode;

	// Token: 0x04001185 RID: 4485
	private float debugDrawDuration = 2f;

	// Token: 0x04001186 RID: 4486
	private Transform tr;

	// Token: 0x0200023A RID: 570
	public enum CeilingDetectionMethod
	{
		// Token: 0x040015C7 RID: 5575
		OnlyCheckFirstContact,
		// Token: 0x040015C8 RID: 5576
		CheckAllContacts,
		// Token: 0x040015C9 RID: 5577
		CheckAverageOfAllContacts
	}
}
