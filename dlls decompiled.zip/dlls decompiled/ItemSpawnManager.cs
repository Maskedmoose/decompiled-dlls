﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000038 RID: 56
public class ItemSpawnManager : CSingleton<ItemSpawnManager>
{
	// Token: 0x060002D3 RID: 723 RVA: 0x0001A688 File Offset: 0x00018888
	private void Start()
	{
		for (int i = 0; i < this.m_ItemParentGrp.childCount; i++)
		{
			this.m_ItemList.Add(this.m_ItemParentGrp.GetChild(i).gameObject.GetComponent<Item>());
		}
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x0001A6CC File Offset: 0x000188CC
	public static Item GetItem(Transform parent)
	{
		Item item = null;
		for (int i = 0; i < CSingleton<ItemSpawnManager>.Instance.m_ItemList.Count; i++)
		{
			if (CSingleton<ItemSpawnManager>.Instance.m_ItemList[i] && !CSingleton<ItemSpawnManager>.Instance.m_ItemList[i].gameObject.activeSelf && CSingleton<ItemSpawnManager>.Instance.m_ItemList[i].transform.parent == CSingleton<ItemSpawnManager>.Instance.m_ItemParentGrp)
			{
				item = CSingleton<ItemSpawnManager>.Instance.m_ItemList[i];
				break;
			}
		}
		if (!item)
		{
			item = CSingleton<ItemSpawnManager>.Instance.AddItemPrefab();
		}
		item.transform.parent = parent;
		return item;
	}

	// Token: 0x060002D5 RID: 725 RVA: 0x0001A78C File Offset: 0x0001898C
	public static void DisableItem(Item item)
	{
		item.transform.parent = CSingleton<ItemSpawnManager>.Instance.m_ItemParentGrp;
		item.transform.localPosition = Vector3.zero;
		item.transform.localRotation = Quaternion.identity;
		item.transform.localScale = Vector3.one;
		item.gameObject.SetActive(false);
		item.m_Mesh.enabled = true;
	}

	// Token: 0x060002D6 RID: 726 RVA: 0x0001A7F8 File Offset: 0x000189F8
	private Item AddItemPrefab()
	{
		Item item = Object.Instantiate<Item>(this.m_ItemPrefab, new Vector3(0f, 0f, 0f), Quaternion.identity, this.m_ItemParentGrp);
		item.name = "ItemGrp" + this.m_SpawnedItemCount.ToString();
		item.gameObject.SetActive(false);
		this.m_ItemList.Add(item);
		this.m_SpawnedItemCount++;
		return item;
	}

	// Token: 0x04000346 RID: 838
	public static ItemSpawnManager m_Instance;

	// Token: 0x04000347 RID: 839
	public Item m_ItemPrefab;

	// Token: 0x04000348 RID: 840
	public Transform m_ItemParentGrp;

	// Token: 0x04000349 RID: 841
	private int m_SpawnedItemCount;

	// Token: 0x0400034A RID: 842
	private List<Item> m_ItemList = new List<Item>();
}
