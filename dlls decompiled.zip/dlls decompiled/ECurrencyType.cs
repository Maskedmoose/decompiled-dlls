﻿using System;

// Token: 0x020000FD RID: 253
public enum ECurrencyType
{
	// Token: 0x04000E94 RID: 3732
	Gold,
	// Token: 0x04000E95 RID: 3733
	Gem,
	// Token: 0x04000E96 RID: 3734
	FamePoint
}
