﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200005B RID: 91
public class CheckPricePanelUI : UIElementBase
{
	// Token: 0x0600040A RID: 1034 RVA: 0x000238F4 File Offset: 0x00021AF4
	public void InitItem(CheckPriceScreen checkPriceScreen, EItemType itemType)
	{
		this.m_UIGrp.SetActive(true);
		this.m_PrologueUIGrp.SetActive(false);
		if (CSingleton<CGameManager>.Instance.m_IsPrologue)
		{
			List<RestockData> restockDataUsingItemType = InventoryBase.GetRestockDataUsingItemType(itemType);
			if (restockDataUsingItemType.Count > 0 && !restockDataUsingItemType[0].prologueShow)
			{
				this.m_UIGrp.SetActive(false);
				this.m_PrologueUIGrp.SetActive(true);
			}
		}
		this.m_IsItem = true;
		this.m_IsCard = false;
		this.m_CheckPriceScreen = checkPriceScreen;
		this.m_ItemType = itemType;
		ItemData itemData = InventoryBase.GetItemData(this.m_ItemType);
		this.m_ItemImage.sprite = itemData.icon;
		this.m_TotalPrice = CPlayerData.GetItemMarketPrice(this.m_ItemType);
		this.m_NameText.text = itemData.GetName();
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_TotalPrice, false, true, false, "F2");
		this.m_ItemImage.enabled = true;
		this.m_CardUI.gameObject.SetActive(false);
		if (itemData.isHideItemUntilUnlocked)
		{
			int restockDataIndex = InventoryBase.GetRestockDataIndex(this.m_ItemType);
			bool flag = false;
			if (restockDataIndex > 0)
			{
				flag = CPlayerData.GetIsItemLicenseUnlocked(restockDataIndex);
			}
			if (!flag)
			{
				this.m_ItemImage.sprite = InventoryBase.GetQuestionMarkSprite();
				this.m_NameText.text = "???";
			}
		}
		List<float> floatDataList = CPlayerData.m_ItemPricePercentPastChangeList[(int)itemType].floatDataList;
		if (floatDataList.Count <= 1)
		{
			this.m_UpArrow.SetActive(false);
			this.m_DownArrow.SetActive(false);
			this.m_NoChangeArrow.SetActive(true);
			this.m_PriceChangeText.text = "+" + GameInstance.GetPriceString(0f, false, true, false, "F2");
			this.m_PriceChangeText.color = this.m_CheckPriceScreen.m_NeutralColor;
			return;
		}
		float itemMarketPriceCustomPercent = CPlayerData.GetItemMarketPriceCustomPercent(itemType, floatDataList[floatDataList.Count - 2]);
		float num = this.m_TotalPrice - itemMarketPriceCustomPercent;
		if (num > 0.005f)
		{
			this.m_UpArrow.SetActive(true);
			this.m_DownArrow.SetActive(false);
			this.m_NoChangeArrow.SetActive(false);
			this.m_PriceChangeText.text = "+" + GameInstance.GetPriceString(num, false, true, false, "F2");
			this.m_PriceChangeText.color = this.m_CheckPriceScreen.m_PositiveColor;
			return;
		}
		if (num < -0.005f)
		{
			this.m_UpArrow.SetActive(false);
			this.m_DownArrow.SetActive(true);
			this.m_NoChangeArrow.SetActive(false);
			this.m_PriceChangeText.text = GameInstance.GetPriceString(num, false, true, false, "F2");
			this.m_PriceChangeText.color = this.m_CheckPriceScreen.m_NegativeColor;
			return;
		}
		this.m_UpArrow.SetActive(false);
		this.m_DownArrow.SetActive(false);
		this.m_NoChangeArrow.SetActive(true);
		this.m_PriceChangeText.text = "+" + GameInstance.GetPriceString(0f, false, true, false, "F2");
		this.m_PriceChangeText.color = this.m_CheckPriceScreen.m_NeutralColor;
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x00023C00 File Offset: 0x00021E00
	public void InitCard(CheckPriceScreen checkPriceScreen, int cardIndex, ECardExpansionType expansionType, bool isDestiny)
	{
		CardData cardData = new CardData();
		cardData.monsterType = CPlayerData.GetMonsterTypeFromCardSaveIndex(cardIndex, expansionType);
		cardData.isFoil = (cardIndex % CPlayerData.GetCardAmountPerMonsterType(expansionType, true) >= CPlayerData.GetCardAmountPerMonsterType(expansionType, false));
		cardData.borderType = (ECardBorderType)(cardIndex % CPlayerData.GetCardAmountPerMonsterType(expansionType, false));
		cardData.isDestiny = isDestiny;
		cardData.expansionType = expansionType;
		this.m_UIGrp.SetActive(true);
		this.m_PrologueUIGrp.SetActive(false);
		if (CSingleton<CGameManager>.Instance.m_IsPrologue && InventoryBase.GetMonsterData(cardData.monsterType).Rarity > ERarity.Common)
		{
			this.m_UIGrp.SetActive(false);
			this.m_PrologueUIGrp.SetActive(true);
			return;
		}
		this.m_IsItem = false;
		this.m_IsCard = true;
		this.m_CheckPriceScreen = checkPriceScreen;
		this.m_CardIndex = cardIndex;
		this.m_CardExpansionType = expansionType;
		this.m_IsDestiny = isDestiny;
		this.m_CardUI.SetCardUI(cardData);
		this.m_TotalPrice = CPlayerData.GetCardMarketPrice(cardData);
		this.m_NameText.text = InventoryBase.GetMonsterData(cardData.monsterType).GetName() + " - " + CPlayerData.GetFullCardTypeName(cardData, false);
		this.m_TotalPriceText.text = GameInstance.GetPriceString(this.m_TotalPrice, false, true, false, "F2");
		this.m_ItemImage.enabled = false;
		this.m_CardUI.gameObject.SetActive(true);
		List<float> pastCardPricePercentChange = CPlayerData.GetPastCardPricePercentChange(cardIndex, expansionType, isDestiny);
		if (pastCardPricePercentChange.Count <= 1)
		{
			this.m_UpArrow.SetActive(false);
			this.m_DownArrow.SetActive(false);
			this.m_NoChangeArrow.SetActive(true);
			this.m_PriceChangeText.text = "+" + GameInstance.GetPriceString(0f, false, true, false, "F2");
			this.m_PriceChangeText.color = this.m_CheckPriceScreen.m_NeutralColor;
			return;
		}
		float cardMarketPriceCustomPercent = CPlayerData.GetCardMarketPriceCustomPercent(cardIndex, expansionType, isDestiny, pastCardPricePercentChange[pastCardPricePercentChange.Count - 2]);
		float num = this.m_TotalPrice - cardMarketPriceCustomPercent;
		if (num > 0.005f)
		{
			this.m_UpArrow.SetActive(true);
			this.m_DownArrow.SetActive(false);
			this.m_NoChangeArrow.SetActive(false);
			this.m_PriceChangeText.text = "+" + GameInstance.GetPriceString(num, false, true, false, "F2");
			this.m_PriceChangeText.color = this.m_CheckPriceScreen.m_PositiveColor;
			return;
		}
		if (num < -0.005f)
		{
			this.m_UpArrow.SetActive(false);
			this.m_DownArrow.SetActive(true);
			this.m_NoChangeArrow.SetActive(false);
			this.m_PriceChangeText.text = GameInstance.GetPriceString(num, false, true, false, "F2");
			this.m_PriceChangeText.color = this.m_CheckPriceScreen.m_NegativeColor;
			return;
		}
		this.m_UpArrow.SetActive(false);
		this.m_DownArrow.SetActive(false);
		this.m_NoChangeArrow.SetActive(true);
		this.m_PriceChangeText.text = "+" + GameInstance.GetPriceString(0f, false, true, false, "F2");
		this.m_PriceChangeText.color = this.m_CheckPriceScreen.m_NeutralColor;
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x00023F10 File Offset: 0x00022110
	public override void OnPressButton()
	{
		SoundManager.GenericConfirm(1f, 1f);
		if (this.m_IsItem)
		{
			this.m_CheckPriceScreen.OnPressOpenItemPriceGraph(this.m_ItemType);
			return;
		}
		if (this.m_IsCard)
		{
			this.m_CheckPriceScreen.OnPressOpenCardPriceGraph(this.m_CardIndex, this.m_CardExpansionType, this.m_IsDestiny);
		}
	}

	// Token: 0x040004D5 RID: 1237
	public Image m_ItemImage;

	// Token: 0x040004D6 RID: 1238
	public TextMeshProUGUI m_NameText;

	// Token: 0x040004D7 RID: 1239
	public TextMeshProUGUI m_TotalPriceText;

	// Token: 0x040004D8 RID: 1240
	public TextMeshProUGUI m_PriceChangeText;

	// Token: 0x040004D9 RID: 1241
	public GameObject m_UpArrow;

	// Token: 0x040004DA RID: 1242
	public GameObject m_DownArrow;

	// Token: 0x040004DB RID: 1243
	public GameObject m_NoChangeArrow;

	// Token: 0x040004DC RID: 1244
	public GameObject m_PrologueUIGrp;

	// Token: 0x040004DD RID: 1245
	public CardUI m_CardUI;

	// Token: 0x040004DE RID: 1246
	private bool m_IsItem;

	// Token: 0x040004DF RID: 1247
	private bool m_IsCard;

	// Token: 0x040004E0 RID: 1248
	private bool m_IsDestiny;

	// Token: 0x040004E1 RID: 1249
	private int m_CardIndex;

	// Token: 0x040004E2 RID: 1250
	private ECardExpansionType m_CardExpansionType;

	// Token: 0x040004E3 RID: 1251
	private float m_TotalPrice;

	// Token: 0x040004E4 RID: 1252
	private EItemType m_ItemType = EItemType.None;

	// Token: 0x040004E5 RID: 1253
	private CheckPriceScreen m_CheckPriceScreen;
}
