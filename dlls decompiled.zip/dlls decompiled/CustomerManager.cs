﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000015 RID: 21
public class CustomerManager : CSingleton<CustomerManager>
{
	// Token: 0x060000D3 RID: 211 RVA: 0x0000E09C File Offset: 0x0000C29C
	private void Start()
	{
		this.m_CustomerList = new List<Customer>();
		for (int i = 0; i < this.m_CustomerParentGrp.childCount; i++)
		{
			this.m_CustomerList.Add(this.m_CustomerParentGrp.GetChild(i).gameObject.GetComponent<Customer>());
		}
		for (int j = 0; j < this.m_CustomerList.Count; j++)
		{
			this.m_CustomerList[j].gameObject.SetActive(false);
			this.m_CustomerList[j].RandomizeCharacterMesh();
			this.m_CustomerList[j].SetOutOfScreen();
		}
		this.EvaluateMaxCustomerCount();
	}

	// Token: 0x060000D4 RID: 212 RVA: 0x0000E140 File Offset: 0x0000C340
	public int GetCustomerModelIndex(bool isMale)
	{
		if (isMale)
		{
			if (this.m_CustomerMaleModelIndexList.Count <= 0)
			{
				for (int i = 0; i < this.m_MaxMaleModelIndex + 1; i++)
				{
					this.m_CustomerMaleModelIndexList.Add(i);
				}
			}
			int index = Random.Range(0, this.m_CustomerMaleModelIndexList.Count);
			int result = this.m_CustomerMaleModelIndexList[index];
			this.m_CustomerMaleModelIndexList.RemoveAt(index);
			return result;
		}
		if (this.m_CustomerFemaleModelIndexList.Count <= 0)
		{
			for (int j = 0; j < this.m_MaxFemaleModelIndex + 1; j++)
			{
				this.m_CustomerFemaleModelIndexList.Add(j);
			}
		}
		int index2 = Random.Range(0, this.m_CustomerFemaleModelIndexList.Count);
		int result2 = this.m_CustomerFemaleModelIndexList[index2];
		this.m_CustomerFemaleModelIndexList.RemoveAt(index2);
		return result2;
	}

	// Token: 0x060000D5 RID: 213 RVA: 0x0000E200 File Offset: 0x0000C400
	public int GetCustomerBuyItemChance(float currentPrice, float marketPrice)
	{
		int num = Mathf.RoundToInt((currentPrice - marketPrice) / marketPrice * 100f);
		num = Mathf.RoundToInt((float)num / Mathf.Lerp(1f, 10f, Mathf.Clamp((2f - marketPrice) / 2f, 0f, 1f)));
		int result;
		if (num <= -20)
		{
			result = 100;
		}
		else if (num > -20 && num <= -10)
		{
			result = Mathf.RoundToInt(Mathf.Lerp(95f, 100f, (float)((num - -10) / -10)));
		}
		else if (num > -10 && num <= 0)
		{
			result = Mathf.RoundToInt(Mathf.Lerp(90f, 95f, (float)(num / -10)));
		}
		else if (num > 0 && num <= 10)
		{
			result = Mathf.RoundToInt(Mathf.Lerp(75f, 90f, (float)((num - 10) / -10)));
		}
		else if (num > 10 && num <= 20)
		{
			result = Mathf.RoundToInt(Mathf.Lerp(60f, 75f, (float)((num - 20) / -10)));
		}
		else if (num > 20 && num <= 30)
		{
			result = Mathf.RoundToInt(Mathf.Lerp(45f, 60f, (float)((num - 30) / -10)));
		}
		else if (num > 30 && num <= 40)
		{
			result = Mathf.RoundToInt(Mathf.Lerp(15f, 45f, (float)((num - 40) / -10)));
		}
		else if (num > 40 && num <= 50)
		{
			result = Mathf.RoundToInt(Mathf.Lerp(5f, 15f, (float)((num - 50) / -10)));
		}
		else if (num > 50 && num <= 60)
		{
			result = Mathf.RoundToInt(Mathf.Lerp(1f, 5f, (float)((num - 60) / -10)));
		}
		else
		{
			result = 0;
		}
		return result;
	}

	// Token: 0x060000D6 RID: 214 RVA: 0x0000E3B4 File Offset: 0x0000C5B4
	public float GetCustomerMaxMoney()
	{
		int num = Random.Range(0, 1000);
		if (num < 3)
		{
			return Random.Range(300f, this.m_CustomerMaxMoney * 4f);
		}
		if (num < 50)
		{
			return Random.Range(40f, this.m_CustomerMaxMoney * 2f);
		}
		return Random.Range(20f, this.m_CustomerMaxMoney);
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x0000E414 File Offset: 0x0000C614
	private void EvaluateMaxCustomerCount()
	{
		float num = 0f;
		int num2 = CPlayerData.m_UnlockRoomCount;
		for (int i = 0; i < CPlayerData.m_UnlockRoomCount + 1; i++)
		{
			if (num2 >= i)
			{
				num2 -= i;
				num += 1.25f;
			}
		}
		int num3 = 0;
		int num4 = CPlayerData.m_ShopLevel;
		for (int j = 0; j < CPlayerData.m_ShopLevel + 1; j++)
		{
			if (num4 >= j)
			{
				num4 -= j;
				num3++;
			}
		}
		num3--;
		this.m_CustomerCountMax = Mathf.Clamp(this.m_CustomerCountMaxBase + Mathf.RoundToInt(num) + num3 + Mathf.CeilToInt((float)this.m_PlayTableSitdownCustomerCount / 2f), 3, 28);
		this.m_TimePerCustomer = Mathf.Clamp(8f - (float)CPlayerData.m_UnlockRoomCount * 0.05f - (float)CPlayerData.m_ShopLevel * 0.05f, 4f, 10f);
		int num5 = 0;
		if (CPlayerData.m_IsWarehouseRoomUnlocked)
		{
			num5 = 500;
		}
		this.m_CustomerMaxMoney = (float)Mathf.Clamp(100 + CPlayerData.m_UnlockRoomCount * 250 + num5 + CPlayerData.m_UnlockWarehouseRoomCount * 400 + CPlayerData.m_ShopLevel * 100, 100, 30000);
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x0000E533 File Offset: 0x0000C733
	public void AddPlayTableSitdownCustomerCount(int count)
	{
		this.m_PlayTableSitdownCustomerCount += count;
		this.EvaluateMaxCustomerCount();
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x0000E54C File Offset: 0x0000C74C
	private void Init()
	{
		if (this.m_FinishLoading)
		{
			return;
		}
		this.m_FinishLoading = true;
		this.EvaluateMaxCustomerCount();
		this.m_CustomerSaveDataList = CPlayerData.m_CustomerSaveDataList;
		if (this.m_CustomerSaveDataList.Count > 0)
		{
			base.StartCoroutine(this.DelayLoadCustomer());
			return;
		}
		base.StartCoroutine(this.DelaySpawnGameStartCustomer());
	}

	// Token: 0x060000DA RID: 218 RVA: 0x0000E5A3 File Offset: 0x0000C7A3
	private IEnumerator DelaySpawnGameStartCustomer()
	{
		yield return new WaitForSeconds(0.01f);
		this.SpawnGameStartCustomer();
		yield break;
	}

	// Token: 0x060000DB RID: 219 RVA: 0x0000E5B4 File Offset: 0x0000C7B4
	private void SpawnGameStartCustomer()
	{
		if (LightManager.GetHasDayEnded())
		{
			return;
		}
		for (int i = 0; i < this.m_CustomerList.Count; i++)
		{
			if (this.m_CustomerList[i].IsActive())
			{
				this.m_CustomerList[i].DeactivateCustomer();
			}
		}
		this.m_TotalCurrentCustomerCount = 0;
		for (int j = 0; j < this.m_CustomerCountMax / 2 + 1; j++)
		{
			this.CustomerEnterShop();
		}
		bool flag = true;
		for (int k = 0; k < this.m_CustomerList.Count; k++)
		{
			if (this.m_CustomerList[k].IsActive())
			{
				this.m_CustomerList[k].SetExtraSpeedMultiplier((float)Random.Range(5, 200));
				if (flag)
				{
					this.m_CustomerList[k].SetExtraSpeedMultiplier((float)Random.Range(200, 400));
					flag = false;
				}
			}
		}
		base.StartCoroutine(this.DelayResetCustomerExtraSpeed());
	}

	// Token: 0x060000DC RID: 220 RVA: 0x0000E6A0 File Offset: 0x0000C8A0
	private IEnumerator DelayResetCustomerExtraSpeed()
	{
		yield return new WaitForSeconds(1f);
		for (int i = 0; i < this.m_CustomerList.Count; i++)
		{
			this.m_CustomerList[i].ResetExtraSpeedMultiplier();
		}
		yield break;
	}

	// Token: 0x060000DD RID: 221 RVA: 0x0000E6B0 File Offset: 0x0000C8B0
	private void Update()
	{
		if (this.m_IsPausing || this.m_IsDayEnded)
		{
			return;
		}
		this.m_Timer += Time.deltaTime;
		if (this.m_Timer >= this.m_TimePerCustomer)
		{
			this.m_Timer = 0f;
			this.CustomerEnterShop();
		}
	}

	// Token: 0x060000DE RID: 222 RVA: 0x0000E700 File Offset: 0x0000C900
	private void CustomerEnterShop()
	{
		if (this.GetUnableFindQueueCustomerCount() >= 3)
		{
			return;
		}
		if (this.m_TotalCurrentCustomerCount < this.m_CustomerCountMax)
		{
			if (Random.Range(0, 2) == 0)
			{
				List<Customer> list = new List<Customer>();
				for (int i = 0; i < this.m_CustomerList.Count; i++)
				{
					if (!this.m_CustomerList[i].IsActive())
					{
						list.Add(this.m_CustomerList[i]);
					}
				}
				if (list.Count > 0)
				{
					this.UpdateCustomerCount(1);
					int index = Random.Range(0, list.Count);
					list[index].ActivateCustomer();
					list[index].gameObject.SetActive(true);
					return;
				}
			}
			for (int j = 0; j < this.m_CustomerList.Count; j++)
			{
				if (!this.m_CustomerList[j].IsActive())
				{
					bool flag = false;
					if (!flag)
					{
						flag = true;
						this.UpdateCustomerCount(1);
						this.m_CustomerList[j].ActivateCustomer();
						this.m_CustomerList[j].gameObject.SetActive(true);
					}
					if (flag)
					{
						if (this.m_TotalCurrentCustomerCount >= this.m_CustomerList.Count)
						{
							this.AddCustomerPrefab();
							return;
						}
						break;
					}
				}
			}
		}
	}

	// Token: 0x060000DF RID: 223 RVA: 0x0000E830 File Offset: 0x0000CA30
	public Customer GetNewCustomer()
	{
		for (int i = 0; i < this.m_CustomerList.Count; i++)
		{
			if (!this.m_CustomerList[i].IsActive())
			{
				this.UpdateCustomerCount(1);
				this.m_CustomerList[i].ActivateCustomer();
				this.m_CustomerList[i].gameObject.SetActive(true);
				return this.m_CustomerList[i];
			}
		}
		return null;
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x0000E8A4 File Offset: 0x0000CAA4
	private int GetUnableFindQueueCustomerCount()
	{
		int num = 0;
		for (int i = 0; i < this.m_CustomerList.Count; i++)
		{
			if (this.m_CustomerList[i].gameObject.activeSelf && this.m_CustomerList[i].IsUnableToFindQueue())
			{
				num++;
			}
		}
		return num;
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x0000E8F9 File Offset: 0x0000CAF9
	private IEnumerator SpawnCustomer()
	{
		int num;
		for (int i = 0; i < 20; i = num)
		{
			yield return new WaitForSeconds(0.01f * (float)i);
			this.CustomerEnterShop();
			num = i + 1;
		}
		yield break;
	}

	// Token: 0x060000E2 RID: 226 RVA: 0x0000E908 File Offset: 0x0000CB08
	public void UpdateCustomerCount(int addAmount)
	{
		this.m_TotalCurrentCustomerCount += addAmount;
		if (this.m_TotalCurrentCustomerCount < this.m_CustomerCountMax)
		{
		}
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x0000E92C File Offset: 0x0000CB2C
	private void AddCustomerPrefab()
	{
		Customer customer;
		if (Random.Range(0, 3) == 0)
		{
			customer = Object.Instantiate<Customer>(this.m_CustomerFemalePrefab, new Vector3(0f, 0f, 0f), Quaternion.identity, this.m_CustomerParentGrp);
			customer.name = "FemaleCustomer" + this.m_SpawnedCustomerCount.ToString();
		}
		else
		{
			customer = Object.Instantiate<Customer>(this.m_CustomerPrefab, new Vector3(0f, 0f, 0f), Quaternion.identity, this.m_CustomerParentGrp);
			customer.name = "Customer" + this.m_SpawnedCustomerCount.ToString();
		}
		customer.gameObject.SetActive(false);
		this.m_CustomerList.Add(customer);
		this.m_SpawnedCustomerCount++;
	}

	// Token: 0x060000E4 RID: 228 RVA: 0x0000E9F8 File Offset: 0x0000CBF8
	public void CustomerBuy(Customer customer, int shelfArrayIndex, EItemType itemType, int amount)
	{
	}

	// Token: 0x060000E5 RID: 229 RVA: 0x0000E9FA File Offset: 0x0000CBFA
	public CustomerProfile GenerateRandomCustomerProfile()
	{
		return new CustomerProfile();
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x0000EA01 File Offset: 0x0000CC01
	public static Transform GetRandomShopLocationPoint()
	{
		return CSingleton<CustomerManager>.Instance.m_ShopLocationPointList[Random.Range(0, CSingleton<CustomerManager>.Instance.m_ShopLocationPointList.Count)];
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x0000EA27 File Offset: 0x0000CC27
	public static Transform GetRandomExitPoint()
	{
		return CSingleton<CustomerManager>.Instance.m_CustomerExitPointList[Random.Range(0, CSingleton<CustomerManager>.Instance.m_CustomerExitPointList.Count)];
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x0000EA4D File Offset: 0x0000CC4D
	public static Transform GetRandomShopWindowOutsidePoint()
	{
		return CSingleton<CustomerManager>.Instance.m_ShopWindowOutsidePointList[Random.Range(0, CSingleton<CustomerManager>.Instance.m_ShopWindowOutsidePointList.Count)];
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x0000EA74 File Offset: 0x0000CC74
	public static bool CheckIsInsideShop(Vector3 customerPos)
	{
		if ((customerPos - CSingleton<CustomerManager>.Instance.m_ShopEntranceLocationPoint.position).magnitude < 0.2f)
		{
			return true;
		}
		for (int i = 0; i < CSingleton<CustomerManager>.Instance.m_ShopEntranceLocationPointList.Count; i++)
		{
			if ((customerPos - CSingleton<CustomerManager>.Instance.m_ShopEntranceLocationPointList[i].position).magnitude < 0.2f)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060000EA RID: 234 RVA: 0x0000EAEE File Offset: 0x0000CCEE
	public void AddToSmellyCustomerList(Customer customer)
	{
		if (!this.m_SmellyCustomerList.Contains(customer))
		{
			this.m_SmellyCustomerList.Add(customer);
		}
	}

	// Token: 0x060000EB RID: 235 RVA: 0x0000EB0A File Offset: 0x0000CD0A
	public void RemoveFromSmellyCustomerList(Customer customer)
	{
		if (this.m_SmellyCustomerList.Contains(customer))
		{
			this.m_SmellyCustomerList.Remove(customer);
		}
	}

	// Token: 0x060000EC RID: 236 RVA: 0x0000EB27 File Offset: 0x0000CD27
	public List<Customer> GetCustomerList()
	{
		return this.m_CustomerList;
	}

	// Token: 0x060000ED RID: 237 RVA: 0x0000EB2F File Offset: 0x0000CD2F
	public List<Customer> GetSmellyCustomerList()
	{
		return this.m_SmellyCustomerList;
	}

	// Token: 0x060000EE RID: 238 RVA: 0x0000EB38 File Offset: 0x0000CD38
	public int GetSmellyCustomerInsideShopCount()
	{
		int num = 0;
		for (int i = 0; i < this.m_SmellyCustomerList.Count; i++)
		{
			if (this.m_SmellyCustomerList[i].IsActive() && this.m_SmellyCustomerList[i].IsInsideShop() && this.m_SmellyCustomerList[i].IsSmelly())
			{
				num++;
			}
		}
		return num;
	}

	// Token: 0x060000EF RID: 239 RVA: 0x0000EB9C File Offset: 0x0000CD9C
	public bool IsWithinSmellyCustomerRange(Vector3 currentPos)
	{
		for (int i = 0; i < this.m_SmellyCustomerList.Count; i++)
		{
			if (this.m_SmellyCustomerList[i].IsActive() && this.m_SmellyCustomerList[i].IsInsideShop() && this.m_SmellyCustomerList[i].IsSmelly() && (this.m_SmellyCustomerList[i].transform.position - currentPos).magnitude < 3f)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x0000EC28 File Offset: 0x0000CE28
	public bool HasCustomerInShop()
	{
		for (int i = 0; i < this.m_CustomerList.Count; i++)
		{
			if (this.m_CustomerList[i].IsActive() && this.m_CustomerList[i].IsInsideShop() && !this.m_CustomerList[i].HasCheckedOut())
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x0000EC87 File Offset: 0x0000CE87
	public void AddCustomerExactChangeChance()
	{
		this.m_CustomerExactChangeChance += Random.Range(5, 15);
	}

	// Token: 0x060000F2 RID: 242 RVA: 0x0000EC9E File Offset: 0x0000CE9E
	public int GetCustomerExactChangeChance()
	{
		return this.m_CustomerExactChangeChance;
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x0000ECA6 File Offset: 0x0000CEA6
	public void ResetCustomerExactChangeChance()
	{
		this.m_CustomerExactChangeChance = 0;
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x0000ECB0 File Offset: 0x0000CEB0
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.AddListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
			CEventManager.AddListener<CEventPlayer_ShopLeveledUp>(new CEventManager.EventDelegate<CEventPlayer_ShopLeveledUp>(this.OnShopLeveledUp));
			CEventManager.AddListener<CEventPlayer_NewRoomUnlocked>(new CEventManager.EventDelegate<CEventPlayer_NewRoomUnlocked>(this.OnNewRoomUnlocked));
		}
	}

	// Token: 0x060000F5 RID: 245 RVA: 0x0000ED20 File Offset: 0x0000CF20
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.RemoveListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
			CEventManager.RemoveListener<CEventPlayer_ShopLeveledUp>(new CEventManager.EventDelegate<CEventPlayer_ShopLeveledUp>(this.OnShopLeveledUp));
			CEventManager.RemoveListener<CEventPlayer_NewRoomUnlocked>(new CEventManager.EventDelegate<CEventPlayer_NewRoomUnlocked>(this.OnNewRoomUnlocked));
		}
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x0000ED90 File Offset: 0x0000CF90
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.Init();
	}

	// Token: 0x060000F7 RID: 247 RVA: 0x0000ED98 File Offset: 0x0000CF98
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		this.m_IsDayEnded = false;
		base.StartCoroutine(this.DelaySpawnGameStartCustomer());
		this.m_SmellyCustomerList.Clear();
		this.m_PlayTableSitdownCustomerCount = 0;
	}

	// Token: 0x060000F8 RID: 248 RVA: 0x0000EDC0 File Offset: 0x0000CFC0
	protected void OnDayEnded(CEventPlayer_OnDayEnded evt)
	{
		this.m_IsDayEnded = true;
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x0000EDC9 File Offset: 0x0000CFC9
	protected void OnShopLeveledUp(CEventPlayer_ShopLeveledUp evt)
	{
		this.EvaluateMaxCustomerCount();
	}

	// Token: 0x060000FA RID: 250 RVA: 0x0000EDD1 File Offset: 0x0000CFD1
	protected void OnNewRoomUnlocked(CEventPlayer_NewRoomUnlocked evt)
	{
		this.EvaluateMaxCustomerCount();
	}

	// Token: 0x060000FB RID: 251 RVA: 0x0000EDD9 File Offset: 0x0000CFD9
	private IEnumerator DelayLoadCustomer()
	{
		List<Customer> loadCustomerList = new List<Customer>();
		yield return new WaitForSeconds(0.02f);
		for (int i = 0; i < this.m_CustomerSaveDataList.Count; i++)
		{
			for (int j = 0; j < this.m_CustomerList.Count; j++)
			{
				if (!this.m_CustomerList[j].IsActive())
				{
					this.UpdateCustomerCount(1);
					this.m_CustomerList[j].ActivateCustomer();
					this.m_CustomerList[j].LoadCustomerSaveData(this.m_CustomerSaveDataList[i]);
					this.m_CustomerList[j].gameObject.SetActive(true);
					loadCustomerList.Add(this.m_CustomerList[j]);
					break;
				}
			}
		}
		yield break;
	}

	// Token: 0x060000FC RID: 252 RVA: 0x0000EDE8 File Offset: 0x0000CFE8
	public void SaveCustomerData()
	{
		this.m_CustomerSaveDataList.Clear();
		for (int i = 0; i < this.m_CustomerList.Count; i++)
		{
			if (this.m_CustomerList[i] && this.m_CustomerList[i].m_IsActive)
			{
				CustomerSaveData customerSaveData = this.m_CustomerList[i].GetCustomerSaveData();
				if (customerSaveData.currentState != ECustomerState.PlayingAtTable && customerSaveData.currentState != ECustomerState.ExitingShop)
				{
					this.m_CustomerSaveDataList.Add(customerSaveData);
				}
			}
		}
		CPlayerData.m_CustomerSaveDataList = this.m_CustomerSaveDataList;
	}

	// Token: 0x0400015E RID: 350
	private bool m_IsPausing;

	// Token: 0x0400015F RID: 351
	protected bool m_FinishLoading;

	// Token: 0x04000160 RID: 352
	public StockItemData_ScriptableObject m_StockItemData_SO;

	// Token: 0x04000161 RID: 353
	public static CustomerManager m_Instance;

	// Token: 0x04000162 RID: 354
	public Customer m_CustomerPrefab;

	// Token: 0x04000163 RID: 355
	public Customer m_CustomerFemalePrefab;

	// Token: 0x04000164 RID: 356
	public Transform m_CustomerParentGrp;

	// Token: 0x04000165 RID: 357
	public Transform m_ShopEntranceLocationPoint;

	// Token: 0x04000166 RID: 358
	public List<Transform> m_ShopEntranceLocationPointList;

	// Token: 0x04000167 RID: 359
	public List<Transform> m_ShopLocationPointList;

	// Token: 0x04000168 RID: 360
	public List<Transform> m_CustomerExitPointList;

	// Token: 0x04000169 RID: 361
	public List<Transform> m_ShopWindowOutsidePointList;

	// Token: 0x0400016A RID: 362
	private List<Customer> m_CustomerList = new List<Customer>();

	// Token: 0x0400016B RID: 363
	private List<Customer> m_SmellyCustomerList = new List<Customer>();

	// Token: 0x0400016C RID: 364
	private float m_Timer;

	// Token: 0x0400016D RID: 365
	public float m_TimePerCustomer = 10f;

	// Token: 0x0400016E RID: 366
	public int m_TotalCurrentCustomerCount;

	// Token: 0x0400016F RID: 367
	public int m_CustomerCountMax = 25;

	// Token: 0x04000170 RID: 368
	private int m_CustomerCountMaxBase = 1;

	// Token: 0x04000171 RID: 369
	private int m_CustomerCountMaxAddPerRoom = 1;

	// Token: 0x04000172 RID: 370
	private int m_SpawnedCustomerCount;

	// Token: 0x04000173 RID: 371
	private int m_CustomerExactChangeChance;

	// Token: 0x04000174 RID: 372
	private int m_PlayTableSitdownCustomerCount;

	// Token: 0x04000175 RID: 373
	private float m_CustomerMaxMoney = 100f;

	// Token: 0x04000176 RID: 374
	private bool m_IsDayEnded;

	// Token: 0x04000177 RID: 375
	private List<CustomerSaveData> m_CustomerSaveDataList = new List<CustomerSaveData>();

	// Token: 0x04000178 RID: 376
	private List<int> m_CustomerMaleModelIndexList = new List<int>();

	// Token: 0x04000179 RID: 377
	private List<int> m_CustomerFemaleModelIndexList = new List<int>();

	// Token: 0x0400017A RID: 378
	private int m_MaxMaleModelIndex = 23;

	// Token: 0x0400017B RID: 379
	private int m_MaxFemaleModelIndex = 12;
}
