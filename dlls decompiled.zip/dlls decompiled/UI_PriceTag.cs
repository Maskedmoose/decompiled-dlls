﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000044 RID: 68
public class UI_PriceTag : MonoBehaviour
{
	// Token: 0x06000337 RID: 823 RVA: 0x0001D5E8 File Offset: 0x0001B7E8
	public void SetItemImage(EItemType itemType)
	{
		this.m_ItemType = itemType;
		if (itemType == EItemType.None)
		{
			this.m_Icon.sprite = null;
			return;
		}
		this.m_Icon.sprite = InventoryBase.GetItemData(itemType).icon;
	}

	// Token: 0x06000338 RID: 824 RVA: 0x0001D618 File Offset: 0x0001B818
	public void SetObjectImage(EObjectType objectType)
	{
		this.m_ObjectType = objectType;
		if (objectType == EObjectType.None)
		{
			this.m_Icon.sprite = null;
			return;
		}
		this.m_Icon.sprite = InventoryBase.GetFurniturePurchaseData(objectType).icon;
	}

	// Token: 0x06000339 RID: 825 RVA: 0x0001D648 File Offset: 0x0001B848
	public void SetAmountText(int amount)
	{
		this.m_AmountText.text = amount.ToString();
	}

	// Token: 0x0600033A RID: 826 RVA: 0x0001D65C File Offset: 0x0001B85C
	public void SetPriceText(float price)
	{
		this.m_CurrentPrice = price;
		this.m_PriceText.text = GameInstance.GetPriceString(price, true, true, false, "F2");
		if (price <= 0f)
		{
			this.m_IsPriceZero = true;
			if (this.m_PriceZeroWarningIndicator)
			{
				this.m_PriceZeroWarningIndicator.SetActive(true);
				return;
			}
		}
		else
		{
			this.m_IsPriceZero = false;
			if (this.m_PriceZeroWarningIndicator)
			{
				this.m_PriceZeroWarningIndicator.SetActive(false);
			}
		}
	}

	// Token: 0x0600033B RID: 827 RVA: 0x0001D6D2 File Offset: 0x0001B8D2
	public void RefreshPriceText()
	{
		this.SetPriceText(this.m_CurrentPrice);
	}

	// Token: 0x0600033C RID: 828 RVA: 0x0001D6E0 File Offset: 0x0001B8E0
	public void SetBrightness(float brightness)
	{
		Color color = this.m_BrightnessImage.color;
		color.a = (1f - brightness) * 0.975f;
		this.m_BrightnessImage.color = color;
	}

	// Token: 0x0600033D RID: 829 RVA: 0x0001D719 File Offset: 0x0001B919
	public EItemType GetItemType()
	{
		return this.m_ItemType;
	}

	// Token: 0x0600033E RID: 830 RVA: 0x0001D721 File Offset: 0x0001B921
	public void SetCardData(CardData cardData)
	{
		this.m_CardData = cardData;
	}

	// Token: 0x0600033F RID: 831 RVA: 0x0001D72A File Offset: 0x0001B92A
	public CardData GetCardData()
	{
		return this.m_CardData;
	}

	// Token: 0x06000340 RID: 832 RVA: 0x0001D732 File Offset: 0x0001B932
	private void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_ItemPriceChanged>(new CEventManager.EventDelegate<CEventPlayer_ItemPriceChanged>(this.CPlayer_OnItemPriceChanged));
			CEventManager.AddListener<CEventPlayer_CardPriceChanged>(new CEventManager.EventDelegate<CEventPlayer_CardPriceChanged>(this.CPlayer_OnCardPriceChanged));
		}
	}

	// Token: 0x06000341 RID: 833 RVA: 0x0001D764 File Offset: 0x0001B964
	private void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_ItemPriceChanged>(new CEventManager.EventDelegate<CEventPlayer_ItemPriceChanged>(this.CPlayer_OnItemPriceChanged));
			CEventManager.RemoveListener<CEventPlayer_CardPriceChanged>(new CEventManager.EventDelegate<CEventPlayer_CardPriceChanged>(this.CPlayer_OnCardPriceChanged));
		}
	}

	// Token: 0x06000342 RID: 834 RVA: 0x0001D796 File Offset: 0x0001B996
	private void CPlayer_OnItemPriceChanged(CEventPlayer_ItemPriceChanged evt)
	{
		if (this.m_ItemType == evt.m_ItemType)
		{
			this.SetPriceText(evt.m_Price);
		}
	}

	// Token: 0x06000343 RID: 835 RVA: 0x0001D7B2 File Offset: 0x0001B9B2
	private void CPlayer_OnCardPriceChanged(CEventPlayer_CardPriceChanged evt)
	{
		if (this.m_CardData != null && this.m_CardData.monsterType != EMonsterType.None && CPlayerData.GetCardSaveIndex(this.m_CardData) == CPlayerData.GetCardSaveIndex(evt.m_CardData))
		{
			this.SetPriceText(evt.m_Price);
		}
	}

	// Token: 0x040003E2 RID: 994
	public Transform m_UIGrp;

	// Token: 0x040003E3 RID: 995
	public TextMeshProUGUI m_PriceText;

	// Token: 0x040003E4 RID: 996
	public TextMeshProUGUI m_AmountText;

	// Token: 0x040003E5 RID: 997
	public Image m_Icon;

	// Token: 0x040003E6 RID: 998
	public Image m_BrightnessImage;

	// Token: 0x040003E7 RID: 999
	private EItemType m_ItemType = EItemType.None;

	// Token: 0x040003E8 RID: 1000
	private EObjectType m_ObjectType = EObjectType.None;

	// Token: 0x040003E9 RID: 1001
	public bool m_IsPriceZero;

	// Token: 0x040003EA RID: 1002
	public bool m_IgnoreCull;

	// Token: 0x040003EB RID: 1003
	public GameObject m_PriceZeroWarningIndicator;

	// Token: 0x040003EC RID: 1004
	private CardData m_CardData;

	// Token: 0x040003ED RID: 1005
	private float m_CurrentPrice;
}
