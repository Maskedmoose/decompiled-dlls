﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D0 RID: 464
	public class AudioControl : MonoBehaviour
	{
		// Token: 0x06000CF5 RID: 3317 RVA: 0x00059A44 File Offset: 0x00057C44
		private void Start()
		{
			this.controller = base.GetComponent<Controller>();
			this.animator = base.GetComponentInChildren<Animator>();
			this.mover = base.GetComponent<Mover>();
			this.tr = base.transform;
			Controller controller = this.controller;
			controller.OnLand = (Controller.VectorEvent)Delegate.Combine(controller.OnLand, new Controller.VectorEvent(this.OnLand));
			Controller controller2 = this.controller;
			controller2.OnJump = (Controller.VectorEvent)Delegate.Combine(controller2.OnJump, new Controller.VectorEvent(this.OnJump));
			if (!this.animator)
			{
				this.useAnimationBasedFootsteps = false;
			}
		}

		// Token: 0x06000CF6 RID: 3318 RVA: 0x00059AE4 File Offset: 0x00057CE4
		private void Update()
		{
			this.FootStepUpdate(VectorMath.RemoveDotVector(this.controller.GetVelocity(), this.tr.up).magnitude);
		}

		// Token: 0x06000CF7 RID: 3319 RVA: 0x00059B1C File Offset: 0x00057D1C
		private void FootStepUpdate(float _movementSpeed)
		{
			float num = 0.05f;
			if (this.useAnimationBasedFootsteps)
			{
				float @float = this.animator.GetFloat("FootStep");
				if (((this.currentFootStepValue <= 0f && @float > 0f) || (this.currentFootStepValue >= 0f && @float < 0f)) && this.mover.IsGrounded() && _movementSpeed > num)
				{
					this.PlayFootstepSound(_movementSpeed);
				}
				this.currentFootStepValue = @float;
				return;
			}
			this.currentFootstepDistance += Time.deltaTime * _movementSpeed;
			if (this.currentFootstepDistance > this.footstepDistance)
			{
				if (this.mover.IsGrounded() && _movementSpeed > num)
				{
					this.PlayFootstepSound(_movementSpeed);
				}
				this.currentFootstepDistance = 0f;
			}
		}

		// Token: 0x06000CF8 RID: 3320 RVA: 0x00059BD8 File Offset: 0x00057DD8
		private void PlayFootstepSound(float _movementSpeed)
		{
			int num = Random.Range(0, this.footStepClips.Length);
			this.audioSource.PlayOneShot(this.footStepClips[num], SoundManager.SFXVolume * (this.audioClipVolume + this.audioClipVolume * Random.Range(-this.relativeRandomizedVolumeRange, this.relativeRandomizedVolumeRange)));
		}

		// Token: 0x06000CF9 RID: 3321 RVA: 0x00059C2D File Offset: 0x00057E2D
		private void OnLand(Vector3 _v)
		{
			if (VectorMath.GetDotProduct(_v, this.tr.up) > -this.landVelocityThreshold)
			{
				return;
			}
			this.audioSource.PlayOneShot(this.landClip, SoundManager.SFXVolume * this.audioClipVolume);
		}

		// Token: 0x06000CFA RID: 3322 RVA: 0x00059C67 File Offset: 0x00057E67
		private void OnJump(Vector3 _v)
		{
			this.audioSource.PlayOneShot(this.jumpClip, SoundManager.SFXVolume * this.audioClipVolume);
		}

		// Token: 0x040013DB RID: 5083
		private Controller controller;

		// Token: 0x040013DC RID: 5084
		private Animator animator;

		// Token: 0x040013DD RID: 5085
		private Mover mover;

		// Token: 0x040013DE RID: 5086
		private Transform tr;

		// Token: 0x040013DF RID: 5087
		public AudioSource audioSource;

		// Token: 0x040013E0 RID: 5088
		public bool useAnimationBasedFootsteps = true;

		// Token: 0x040013E1 RID: 5089
		public float landVelocityThreshold = 5f;

		// Token: 0x040013E2 RID: 5090
		public float footstepDistance = 0.2f;

		// Token: 0x040013E3 RID: 5091
		private float currentFootstepDistance;

		// Token: 0x040013E4 RID: 5092
		private float currentFootStepValue;

		// Token: 0x040013E5 RID: 5093
		[Range(0f, 1f)]
		public float audioClipVolume = 0.1f;

		// Token: 0x040013E6 RID: 5094
		public float relativeRandomizedVolumeRange = 0.2f;

		// Token: 0x040013E7 RID: 5095
		public AudioClip[] footStepClips;

		// Token: 0x040013E8 RID: 5096
		public AudioClip jumpClip;

		// Token: 0x040013E9 RID: 5097
		public AudioClip landClip;
	}
}
