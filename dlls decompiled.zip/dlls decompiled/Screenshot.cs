﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000121 RID: 289
public class Screenshot : MonoBehaviour
{
	// Token: 0x0600086B RID: 2155 RVA: 0x0003ECE0 File Offset: 0x0003CEE0
	protected static string SaveImageToGallery(Texture2D a_Texture, string a_Title, string a_Description)
	{
		string result;
		using (AndroidJavaClass androidJavaClass = new AndroidJavaClass("android.provider.MediaStore$Images$Media"))
		{
			using (AndroidJavaObject androidJavaObject = Screenshot.Activity.Call<AndroidJavaObject>("getContentResolver", Array.Empty<object>()))
			{
				AndroidJavaObject androidJavaObject2 = Screenshot.Texture2DToAndroidBitmap(a_Texture);
				result = androidJavaClass.CallStatic<string>("insertImage", new object[]
				{
					androidJavaObject,
					androidJavaObject2,
					a_Title,
					a_Description
				});
			}
		}
		return result;
	}

	// Token: 0x0600086C RID: 2156 RVA: 0x0003ED6C File Offset: 0x0003CF6C
	protected static AndroidJavaObject Texture2DToAndroidBitmap(Texture2D a_Texture)
	{
		byte[] array = a_Texture.EncodeToPNG();
		AndroidJavaObject result;
		using (AndroidJavaClass androidJavaClass = new AndroidJavaClass("android.graphics.BitmapFactory"))
		{
			result = androidJavaClass.CallStatic<AndroidJavaObject>("decodeByteArray", new object[]
			{
				array,
				0,
				array.Length
			});
		}
		return result;
	}

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x0600086D RID: 2157 RVA: 0x0003EDD4 File Offset: 0x0003CFD4
	protected static AndroidJavaObject Activity
	{
		get
		{
			if (Screenshot.m_Activity == null)
			{
				Screenshot.m_Activity = new AndroidJavaClass("com.unity3d.player.UnityPlayer").GetStatic<AndroidJavaObject>("currentActivity");
			}
			return Screenshot.m_Activity;
		}
	}

	// Token: 0x0600086E RID: 2158 RVA: 0x0003EDFB File Offset: 0x0003CFFB
	public void CaptureScreenshot()
	{
	}

	// Token: 0x0600086F RID: 2159 RVA: 0x0003EDFD File Offset: 0x0003CFFD
	private IEnumerator CaptureScreenshotCoroutine(int width, int height)
	{
		yield return new WaitForEndOfFrame();
		Texture2D tex = new Texture2D(width, height);
		tex.ReadPixels(new Rect(0f, 0f, (float)width, (float)height), 0, 0);
		tex.Apply();
		yield return tex;
		string str = Screenshot.SaveImageToGallery(tex, "Name", "Description");
		Debug.Log("Picture has been saved at:\n" + str);
		yield break;
	}

	// Token: 0x0400102E RID: 4142
	protected const string MEDIA_STORE_IMAGE_MEDIA = "android.provider.MediaStore$Images$Media";

	// Token: 0x0400102F RID: 4143
	protected static AndroidJavaObject m_Activity;
}
