﻿using System;
using UnityEngine;

// Token: 0x0200014F RID: 335
public class scrolltex : MonoBehaviour
{
	// Token: 0x06000979 RID: 2425 RVA: 0x00044CC8 File Offset: 0x00042EC8
	private void Update()
	{
		float x = Time.time * this.Scrollx;
		float y = Time.time * this.Scrolly;
		base.GetComponent<Renderer>().material.mainTextureOffset = new Vector2(x, y);
	}

	// Token: 0x040011C1 RID: 4545
	public float Scrollx = 0.5f;

	// Token: 0x040011C2 RID: 4546
	public float Scrolly = 0.5f;
}
