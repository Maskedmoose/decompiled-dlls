﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200009C RID: 156
public class TitleScreen : MonoBehaviour
{
	// Token: 0x0600061A RID: 1562 RVA: 0x0003205C File Offset: 0x0003025C
	private void Start()
	{
		if (CSaveLoad.HasSaveFile(0))
		{
			this.m_ContinueButton.interactable = true;
		}
		else
		{
			this.m_ContinueButton.interactable = false;
		}
		if (!CSaveLoad.HasSaveFile(0) && !CSaveLoad.HasSaveFile(1) && !CSaveLoad.HasSaveFile(2))
		{
			CSaveLoad.HasSaveFile(3);
		}
		this.m_VersionText.text = "v" + Application.version;
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x0600061B RID: 1563 RVA: 0x000320D0 File Offset: 0x000302D0
	public void OnPressStartGame()
	{
		if (this.m_IsOpeningLevel)
		{
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		if (CSaveLoad.HasSaveFile(0))
		{
			this.m_ConfirmOverwriteSaveScreen.SetActive(true);
			ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension_OverwriteSaveScreen);
			Debug.Log("Has save file, prompt if want to overwrite");
			return;
		}
		this.m_IsOpeningLevel = true;
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Start", -1);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x0600061C RID: 1564 RVA: 0x00032144 File Offset: 0x00030344
	public void OnPressConfirmOverwrite()
	{
		if (this.m_IsOpeningLevel)
		{
			return;
		}
		CSaveLoad.AutoSaveMoveToEmptySaveSlot();
		SoundManager.GenericLightTap(1f, 1f);
		this.m_IsOpeningLevel = true;
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Start", -1);
		UnityAnalytic.PressOverwriteSave();
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_OverwriteSaveScreen);
	}

	// Token: 0x0600061D RID: 1565 RVA: 0x000321A0 File Offset: 0x000303A0
	public void OnPressCloseOverwrite()
	{
		SoundManager.GenericLightTap(1f, 1f);
		this.m_ConfirmOverwriteSaveScreen.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_OverwriteSaveScreen);
	}

	// Token: 0x0600061E RID: 1566 RVA: 0x000321C8 File Offset: 0x000303C8
	public void OnPressLoadGame()
	{
		if (this.m_IsOpeningLevel)
		{
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		this.m_IsOpeningLevel = true;
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Start", 0);
		UnityAnalytic.PressLoadGame();
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension);
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x00032214 File Offset: 0x00030414
	public void OpenLoadGameSlotScreen()
	{
		if (this.m_IsOpeningLevel)
		{
			return;
		}
		SoundManager.GenericLightTap(1f, 1f);
		SaveLoadGameSlotSelectScreen.OpenScreen(false);
	}

	// Token: 0x06000620 RID: 1568 RVA: 0x00032234 File Offset: 0x00030434
	public void OnPressSetting()
	{
		SoundManager.GenericLightTap(1f, 1f);
		SettingScreen.OpenScreen(true);
	}

	// Token: 0x06000621 RID: 1569 RVA: 0x0003224B File Offset: 0x0003044B
	public void OnPressQuit()
	{
		SoundManager.GenericLightTap(1f, 1f);
		Application.Quit();
	}

	// Token: 0x06000622 RID: 1570 RVA: 0x00032261 File Offset: 0x00030461
	public void OnPressWishlistOnSteam()
	{
		Application.OpenURL("https://store.steampowered.com/app/3070070?utm_source=prologue&utm_campaign=prologue1&utm_medium=game");
		UnityAnalytic.PressWishlist(0);
	}

	// Token: 0x06000623 RID: 1571 RVA: 0x00032273 File Offset: 0x00030473
	public void OnPressFeedbackBtn()
	{
		Application.OpenURL("https://steamcommunity.com/app/3070070/discussions/");
		UnityAnalytic.PressFeedback(0);
	}

	// Token: 0x06000624 RID: 1572 RVA: 0x00032285 File Offset: 0x00030485
	public void OnPressDiscordBtn()
	{
		Application.OpenURL("https://discord.gg/2YaaUZzrRY");
		UnityAnalytic.JoinDiscord();
	}

	// Token: 0x040007E7 RID: 2023
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040007E8 RID: 2024
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_OverwriteSaveScreen;

	// Token: 0x040007E9 RID: 2025
	public GameObject m_ConfirmOverwriteSaveScreen;

	// Token: 0x040007EA RID: 2026
	public Button m_ContinueButton;

	// Token: 0x040007EB RID: 2027
	public Button m_LoadGameButton;

	// Token: 0x040007EC RID: 2028
	public TextMeshProUGUI m_VersionText;

	// Token: 0x040007ED RID: 2029
	private bool m_IsOpeningLevel;
}
