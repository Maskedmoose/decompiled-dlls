﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D5 RID: 469
	public class CameraDistanceRaycaster : MonoBehaviour
	{
		// Token: 0x06000D1C RID: 3356 RVA: 0x0005A4CC File Offset: 0x000586CC
		private void Awake()
		{
			this.tr = base.transform;
			this.ignoreListLayers = new int[this.ignoreList.Length];
			this.ignoreRaycastLayer = LayerMask.NameToLayer("Ignore Raycast");
			if (this.layerMask == (this.layerMask | 1 << this.ignoreRaycastLayer))
			{
				this.layerMask ^= 1 << this.ignoreRaycastLayer;
			}
			if (this.cameraTransform == null)
			{
				Debug.LogWarning("No camera transform has been assigned.", this);
			}
			if (this.cameraTargetTransform == null)
			{
				Debug.LogWarning("No camera target transform has been assigned.", this);
			}
			if (this.cameraTransform == null || this.cameraTargetTransform == null)
			{
				base.enabled = false;
				return;
			}
			this.currentDistance = (this.cameraTargetTransform.position - this.tr.position).magnitude;
		}

		// Token: 0x06000D1D RID: 3357 RVA: 0x0005A5D0 File Offset: 0x000587D0
		private void LateUpdate()
		{
			if (this.ignoreListLayers.Length != this.ignoreList.Length)
			{
				this.ignoreListLayers = new int[this.ignoreList.Length];
			}
			for (int i = 0; i < this.ignoreList.Length; i++)
			{
				this.ignoreListLayers[i] = this.ignoreList[i].gameObject.layer;
				this.ignoreList[i].gameObject.layer = this.ignoreRaycastLayer;
			}
			float cameraDistance = this.GetCameraDistance();
			for (int j = 0; j < this.ignoreList.Length; j++)
			{
				this.ignoreList[j].gameObject.layer = this.ignoreListLayers[j];
			}
			this.currentDistance = Mathf.Lerp(this.currentDistance, cameraDistance, Time.deltaTime * this.smoothingFactor);
			this.cameraTransform.position = this.tr.position + (this.cameraTargetTransform.position - this.tr.position).normalized * this.currentDistance;
		}

		// Token: 0x06000D1E RID: 3358 RVA: 0x0005A6E4 File Offset: 0x000588E4
		private float GetCameraDistance()
		{
			Vector3 direction = this.cameraTargetTransform.position - this.tr.position;
			RaycastHit raycastHit;
			if (this.castType == CameraDistanceRaycaster.CastType.Raycast)
			{
				if (Physics.Raycast(new Ray(this.tr.position, direction), out raycastHit, direction.magnitude + this.minimumDistanceFromObstacles, this.layerMask, QueryTriggerInteraction.Ignore))
				{
					if (raycastHit.distance - this.minimumDistanceFromObstacles < 0f)
					{
						return raycastHit.distance;
					}
					return raycastHit.distance - this.minimumDistanceFromObstacles;
				}
			}
			else if (Physics.SphereCast(new Ray(this.tr.position, direction), this.spherecastRadius, out raycastHit, direction.magnitude, this.layerMask, QueryTriggerInteraction.Ignore))
			{
				return raycastHit.distance;
			}
			return direction.magnitude;
		}

		// Token: 0x04001408 RID: 5128
		public Transform cameraTransform;

		// Token: 0x04001409 RID: 5129
		public Transform cameraTargetTransform;

		// Token: 0x0400140A RID: 5130
		private Transform tr;

		// Token: 0x0400140B RID: 5131
		public CameraDistanceRaycaster.CastType castType;

		// Token: 0x0400140C RID: 5132
		public LayerMask layerMask = -1;

		// Token: 0x0400140D RID: 5133
		private int ignoreRaycastLayer;

		// Token: 0x0400140E RID: 5134
		public Collider[] ignoreList;

		// Token: 0x0400140F RID: 5135
		private int[] ignoreListLayers;

		// Token: 0x04001410 RID: 5136
		private float currentDistance;

		// Token: 0x04001411 RID: 5137
		public float minimumDistanceFromObstacles = 0.1f;

		// Token: 0x04001412 RID: 5138
		public float smoothingFactor = 25f;

		// Token: 0x04001413 RID: 5139
		public float spherecastRadius = 0.2f;

		// Token: 0x0200027C RID: 636
		public enum CastType
		{
			// Token: 0x0400168E RID: 5774
			Raycast,
			// Token: 0x0400168F RID: 5775
			Spherecast
		}
	}
}
