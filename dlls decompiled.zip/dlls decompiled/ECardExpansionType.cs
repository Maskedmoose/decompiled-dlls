﻿using System;

// Token: 0x020000DB RID: 219
public enum ECardExpansionType
{
	// Token: 0x04000A1C RID: 2588
	None = -1,
	// Token: 0x04000A1D RID: 2589
	Tetramon,
	// Token: 0x04000A1E RID: 2590
	Destiny,
	// Token: 0x04000A1F RID: 2591
	Ghost,
	// Token: 0x04000A20 RID: 2592
	Megabot,
	// Token: 0x04000A21 RID: 2593
	FantasyRPG,
	// Token: 0x04000A22 RID: 2594
	CatJob,
	// Token: 0x04000A23 RID: 2595
	FoodieGO,
	// Token: 0x04000A24 RID: 2596
	MAX
}
