﻿using System;

// Token: 0x020000F7 RID: 247
public enum EIAPDataType
{
	// Token: 0x04000D8D RID: 3469
	GoldCount,
	// Token: 0x04000D8E RID: 3470
	GemCount,
	// Token: 0x04000D8F RID: 3471
	InstantCrate,
	// Token: 0x04000D90 RID: 3472
	IAPGem1,
	// Token: 0x04000D91 RID: 3473
	IAPGem2,
	// Token: 0x04000D92 RID: 3474
	IAPGem3,
	// Token: 0x04000D93 RID: 3475
	IAPGem4,
	// Token: 0x04000D94 RID: 3476
	IAPGem5,
	// Token: 0x04000D95 RID: 3477
	IAPGem6,
	// Token: 0x04000D96 RID: 3478
	IAPGem7,
	// Token: 0x04000D97 RID: 3479
	PermaGoldCount,
	// Token: 0x04000D98 RID: 3480
	PermaGemCount
}
