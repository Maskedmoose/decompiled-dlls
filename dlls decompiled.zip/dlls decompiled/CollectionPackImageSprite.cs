﻿using System;
using UnityEngine;

// Token: 0x02000030 RID: 48
[Serializable]
public struct CollectionPackImageSprite
{
	// Token: 0x040002F8 RID: 760
	public ECollectionPackType colelctionPackType;

	// Token: 0x040002F9 RID: 761
	public Sprite fullSprite;

	// Token: 0x040002FA RID: 762
	public Sprite topSprite;

	// Token: 0x040002FB RID: 763
	public Sprite bottomSprite;
}
