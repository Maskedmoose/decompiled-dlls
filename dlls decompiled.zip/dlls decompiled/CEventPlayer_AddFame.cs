﻿using System;

// Token: 0x020000B0 RID: 176
public class CEventPlayer_AddFame : CEvent
{
	// Token: 0x17000012 RID: 18
	// (get) Token: 0x060006FB RID: 1787 RVA: 0x00037FE7 File Offset: 0x000361E7
	// (set) Token: 0x060006FC RID: 1788 RVA: 0x00037FEF File Offset: 0x000361EF
	public int m_FameValue { get; private set; }

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x060006FD RID: 1789 RVA: 0x00037FF8 File Offset: 0x000361F8
	// (set) Token: 0x060006FE RID: 1790 RVA: 0x00038000 File Offset: 0x00036200
	public bool m_NoLerp { get; private set; }

	// Token: 0x060006FF RID: 1791 RVA: 0x00038009 File Offset: 0x00036209
	public CEventPlayer_AddFame(int fameValue, bool noLerp = false)
	{
		this.m_FameValue = fameValue;
		this.m_NoLerp = noLerp;
	}
}
