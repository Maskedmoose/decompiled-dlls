﻿using System;
using System.Collections.Generic;
using HeathenEngineering.SteamworksIntegration;
using UnityEngine;

// Token: 0x0200009E RID: 158
public class AchievementManager : CSingleton<AchievementManager>
{
	// Token: 0x0600062A RID: 1578 RVA: 0x000324E4 File Offset: 0x000306E4
	private void Awake()
	{
		if (AchievementManager.m_Instance == null)
		{
			AchievementManager.m_Instance = this;
		}
		else if (AchievementManager.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
	}

	// Token: 0x0600062B RID: 1579 RVA: 0x0003251C File Offset: 0x0003071C
	public static void OnItemLicenseUnlocked(EItemType itemType)
	{
		if (itemType == EItemType.BasicCardBox)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockBasicCardBox");
			return;
		}
		if (itemType == EItemType.RareCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockRareCardPack");
			return;
		}
		if (itemType == EItemType.EpicCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockEpicCardPack");
			return;
		}
		if (itemType == EItemType.LegendaryCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockLegendCardPack");
			return;
		}
		if (itemType == EItemType.DestinyBasicCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockDestinyBasicPack");
			return;
		}
		if (itemType == EItemType.DestinyRareCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockDestinyRarePack");
			return;
		}
		if (itemType == EItemType.DestinyEpicCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockDestinyEpicPack");
			return;
		}
		if (itemType == EItemType.DestinyLegendaryCardPack)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockDestinyLegendPack");
		}
	}

	// Token: 0x0600062C RID: 1580 RVA: 0x000325CB File Offset: 0x000307CB
	public static void OnStaffHired(int count)
	{
		if (count >= 8)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Worker3");
		}
		if (count >= 4)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Worker2");
		}
		if (count >= 1)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Worker1");
		}
	}

	// Token: 0x0600062D RID: 1581 RVA: 0x00032608 File Offset: 0x00030808
	public static void OnCardPackOpened(int count)
	{
		if (count >= 100)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_OpenPack1");
		}
		if (count >= 1000)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_OpenPack2");
		}
		if (count >= 10000)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_OpenPack3");
		}
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x00032658 File Offset: 0x00030858
	public static void OnCustomerFinishPlay(int count)
	{
		if (count >= 100)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CustomerPlay1");
		}
		if (count >= 1500)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CustomerPlay2");
		}
		if (count >= 5000)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CustomerPlay3");
		}
	}

	// Token: 0x0600062F RID: 1583 RVA: 0x000326A7 File Offset: 0x000308A7
	public static void OnCustomerFinishCheckout(int count)
	{
		if (count >= 1000)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Checkout");
		}
	}

	// Token: 0x06000630 RID: 1584 RVA: 0x000326C0 File Offset: 0x000308C0
	public static void OnSoldCardPrice(float priceAmount)
	{
		if (priceAmount >= 200f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_SellCard1");
		}
		if (priceAmount >= 5000f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_SellCard2");
		}
		if (priceAmount >= 10000f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_SellCard3");
		}
	}

	// Token: 0x06000631 RID: 1585 RVA: 0x00032714 File Offset: 0x00030914
	public static void OnDailyProfitReached(float priceAmount)
	{
		if (priceAmount >= 30000f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Profit3");
			return;
		}
		if (priceAmount >= 10000f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Profit2");
			return;
		}
		if (priceAmount >= 1000f)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_Profit1");
		}
	}

	// Token: 0x06000632 RID: 1586 RVA: 0x00032768 File Offset: 0x00030968
	public static void OnGetFullArtFoil(bool isGet)
	{
		if (isGet)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_FullArtFoil");
		}
	}

	// Token: 0x06000633 RID: 1587 RVA: 0x0003277C File Offset: 0x0003097C
	public static void OnGetFullArtGhostFoil(bool isGet)
	{
		if (isGet)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_GhostFoil");
		}
	}

	// Token: 0x06000634 RID: 1588 RVA: 0x00032790 File Offset: 0x00030990
	public static void OnCheckAlbumCardCount(int count)
	{
		if (count >= 100)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CardCollector1");
		}
		if (count >= 500)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CardCollector2");
		}
		if (count >= 1500)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CardCollector3");
		}
		if (count >= 2500)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_CardCollector4");
		}
	}

	// Token: 0x06000635 RID: 1589 RVA: 0x000327F6 File Offset: 0x000309F6
	public static void OnCleanSmellyCustomer(int count)
	{
		if (count >= 20)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_SmellyClean1");
		}
		if (count >= 200)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_SmellyClean2");
		}
	}

	// Token: 0x06000636 RID: 1590 RVA: 0x00032823 File Offset: 0x00030A23
	public static void OnShopLotBUnlocked()
	{
		CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_UnlockShopLotB");
	}

	// Token: 0x06000637 RID: 1591 RVA: 0x00032834 File Offset: 0x00030A34
	public static void OnUnlockShopExpansion(int roomCount)
	{
		if (roomCount >= 4)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopExpansion1");
		}
		if (roomCount >= 10)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopExpansion2");
		}
		if (roomCount >= 20)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopExpansion3");
		}
	}

	// Token: 0x06000638 RID: 1592 RVA: 0x00032874 File Offset: 0x00030A74
	private void OnShopLevelUp(CEventPlayer_ShopLeveledUp evt)
	{
		if (evt.m_ShopLevel + 1 >= 5)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel1");
		}
		if (evt.m_ShopLevel + 1 >= 20)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel2");
		}
		if (evt.m_ShopLevel + 1 >= 50)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel3");
		}
		if (evt.m_ShopLevel + 1 >= 100)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel4");
		}
	}

	// Token: 0x06000639 RID: 1593 RVA: 0x000328EC File Offset: 0x00030AEC
	public static void ShopLevelCheck(int level)
	{
		if (level + 1 >= 5)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel1");
		}
		if (level + 1 >= 20)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel2");
		}
		if (level + 1 >= 50)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel3");
		}
		if (level + 1 >= 100)
		{
			CSingleton<AchievementManager>.Instance.UnlockAchievement("ACH_ShopLevel4");
		}
	}

	// Token: 0x0600063A RID: 1594 RVA: 0x00032950 File Offset: 0x00030B50
	public void UnlockAchievement(string achievementID)
	{
		try
		{
			AchievementData achievementData = achievementID;
			if (!achievementData.IsAchieved)
			{
				achievementData.IsAchieved = true;
				achievementData.Store();
			}
		}
		catch
		{
		}
		int index = this.m_AchievementSringList.IndexOf(achievementID);
		CPlayerData.m_IsAchievementUnlocked[index] = true;
	}

	// Token: 0x0600063B RID: 1595 RVA: 0x000329AC File Offset: 0x00030BAC
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_ShopLeveledUp>(new CEventManager.EventDelegate<CEventPlayer_ShopLeveledUp>(this.OnShopLevelUp));
			CEventManager.AddListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
		}
	}

	// Token: 0x0600063C RID: 1596 RVA: 0x000329DE File Offset: 0x00030BDE
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_ShopLeveledUp>(new CEventManager.EventDelegate<CEventPlayer_ShopLeveledUp>(this.OnShopLevelUp));
			CEventManager.RemoveListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
		}
	}

	// Token: 0x0600063D RID: 1597 RVA: 0x00032A10 File Offset: 0x00030C10
	protected void OnFinishHideLoadingScreen(CEventPlayer_FinishHideLoadingScreen evt)
	{
		AchievementManager.ShopLevelCheck(CPlayerData.m_ShopLevel);
		for (int i = 0; i < CPlayerData.m_IsAchievementUnlocked.Count; i++)
		{
			if (CPlayerData.m_IsAchievementUnlocked[i])
			{
				this.UnlockAchievement(this.m_AchievementSringList[i]);
			}
		}
	}

	// Token: 0x040007F7 RID: 2039
	public static AchievementManager m_Instance;

	// Token: 0x040007F8 RID: 2040
	public List<string> m_AchievementSringList;
}
