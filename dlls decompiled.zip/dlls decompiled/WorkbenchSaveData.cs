﻿using System;
using System.Collections.Generic;

// Token: 0x0200004F RID: 79
[Serializable]
public class WorkbenchSaveData
{
	// Token: 0x04000463 RID: 1123
	public List<EItemType> itemTypeList;

	// Token: 0x04000464 RID: 1124
	public Vector3Serializer pos;

	// Token: 0x04000465 RID: 1125
	public QuaternionSerializer rot;

	// Token: 0x04000466 RID: 1126
	public bool isBoxed;

	// Token: 0x04000467 RID: 1127
	public Vector3Serializer boxedPackagePos;

	// Token: 0x04000468 RID: 1128
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x04000469 RID: 1129
	public EObjectType objectType;
}
