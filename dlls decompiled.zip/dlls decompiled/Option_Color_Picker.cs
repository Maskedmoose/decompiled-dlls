﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001C6 RID: 454
	public class Option_Color_Picker : MonoBehaviour, ICustomizerUI
	{
		// Token: 0x06000CBB RID: 3259 RVA: 0x0005875C File Offset: 0x0005695C
		public void InitializeUIElement(CharacterCustomization customizerScript, CC_UI_Util ParentUI)
		{
			this.customizer = customizerScript;
			this.parentUI = ParentUI;
			this.RefreshUIElement();
		}

		// Token: 0x06000CBC RID: 3260 RVA: 0x00058774 File Offset: 0x00056974
		public void RefreshUIElement()
		{
			int num = this.customizer.StoredCharacterData.ColorProperties.FindIndex((CC_Property t) => t.propertyName == this.Property.propertyName && t.materialIndex == this.Property.materialIndex && t.meshTag == this.Property.meshTag);
			Color color;
			if (this.Hair)
			{
				if (ColorUtility.TryParseHtmlString("#" + this.customizer.StoredCharacterData.HairColor[(this.HairSlot == -1) ? 0 : this.HairSlot].stringValue, out color))
				{
					this.color = color;
					this.ColorPreview.color = this.color;
					Color.RGBToHSV(this.color, out this.hue, out this.sat, out this.val);
					this.HueSlider.SetValueWithoutNotify(this.hue);
					this.SatSlider.SetValueWithoutNotify(this.sat);
					this.ValSlider.SetValueWithoutNotify(this.val);
				}
			}
			else if (num != -1 && ColorUtility.TryParseHtmlString("#" + this.customizer.StoredCharacterData.ColorProperties[num].stringValue, out color))
			{
				this.color = color;
				this.ColorPreview.color = this.color;
				Color.RGBToHSV(this.color, out this.hue, out this.sat, out this.val);
				this.HueSlider.SetValueWithoutNotify(this.hue);
				this.SatSlider.SetValueWithoutNotify(this.sat);
				this.ValSlider.SetValueWithoutNotify(this.val);
			}
			num = this.customizer.StoredCharacterData.FloatProperties.FindIndex((CC_Property t) => t.propertyName == this.OpacityProperty.propertyName && t.materialIndex == this.OpacityProperty.materialIndex && t.meshTag == this.OpacityProperty.meshTag);
			if (num != -1 && this.OpacitySlider != null)
			{
				this.OpacitySlider.SetValueWithoutNotify(this.customizer.StoredCharacterData.FloatProperties[num].floatValue);
			}
		}

		// Token: 0x06000CBD RID: 3261 RVA: 0x00058954 File Offset: 0x00056B54
		public void setColor()
		{
			this.color = Color.HSVToRGB(this.hue, this.sat, this.val);
			this.ColorPreview.color = this.color;
			if (this.Hair)
			{
				this.customizer.setHairColor(this.Property, this.color, this.HairSlot, true);
				return;
			}
			this.customizer.setColorProperty(this.Property, this.color, true);
		}

		// Token: 0x06000CBE RID: 3262 RVA: 0x000589CE File Offset: 0x00056BCE
		public void setHue(float value)
		{
			this.hue = value;
			this.setColor();
		}

		// Token: 0x06000CBF RID: 3263 RVA: 0x000589DD File Offset: 0x00056BDD
		public void setSat(float value)
		{
			this.sat = value;
			this.setColor();
		}

		// Token: 0x06000CC0 RID: 3264 RVA: 0x000589EC File Offset: 0x00056BEC
		public void setVal(float value)
		{
			this.val = value;
			this.setColor();
		}

		// Token: 0x06000CC1 RID: 3265 RVA: 0x000589FB File Offset: 0x00056BFB
		public void setOpacity(float value)
		{
			this.OpacityProperty.floatValue = value;
			this.customizer.setFloatProperty(this.OpacityProperty, true);
		}

		// Token: 0x06000CC2 RID: 3266 RVA: 0x00058A1C File Offset: 0x00056C1C
		public void randomize(bool RandomizeOpacity)
		{
			this.hue = Random.Range(0f, 1f);
			this.val = Random.Range(0f, 1f);
			this.sat = Random.Range(0f, 1f);
			this.setColor();
			this.HueSlider.value = this.hue;
			this.SatSlider.value = this.sat;
			this.ValSlider.value = this.val;
			if (RandomizeOpacity)
			{
				float num = Random.Range(0f, 1f);
				this.setOpacity(num);
				this.OpacitySlider.value = num;
			}
		}

		// Token: 0x0400139A RID: 5018
		private CharacterCustomization customizer;

		// Token: 0x0400139B RID: 5019
		private CC_UI_Util parentUI;

		// Token: 0x0400139C RID: 5020
		public CC_Property Property;

		// Token: 0x0400139D RID: 5021
		public CC_Property OpacityProperty;

		// Token: 0x0400139E RID: 5022
		public bool Hair;

		// Token: 0x0400139F RID: 5023
		public int HairSlot;

		// Token: 0x040013A0 RID: 5024
		public Image ColorPreview;

		// Token: 0x040013A1 RID: 5025
		public Slider HueSlider;

		// Token: 0x040013A2 RID: 5026
		public Slider SatSlider;

		// Token: 0x040013A3 RID: 5027
		public Slider ValSlider;

		// Token: 0x040013A4 RID: 5028
		public Slider OpacitySlider;

		// Token: 0x040013A5 RID: 5029
		private Color color;

		// Token: 0x040013A6 RID: 5030
		private float hue;

		// Token: 0x040013A7 RID: 5031
		private float sat = 0.5f;

		// Token: 0x040013A8 RID: 5032
		private float val = 0.5f;
	}
}
