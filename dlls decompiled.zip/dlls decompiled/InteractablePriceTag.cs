﻿using System;
using UnityEngine;

// Token: 0x02000027 RID: 39
public class InteractablePriceTag : InteractableObject
{
	// Token: 0x06000212 RID: 530 RVA: 0x00014CD4 File Offset: 0x00012ED4
	public void Init(ShelfCompartment shelfCompartment)
	{
		this.m_ShelfCompartment = shelfCompartment;
	}

	// Token: 0x06000213 RID: 531 RVA: 0x00014CE0 File Offset: 0x00012EE0
	protected override void ShowToolTip()
	{
		for (int i = 0; i < this.m_GameActionInputDisplayList.Count; i++)
		{
			if (this.m_GameActionInputDisplayList[i] == EGameAction.RemoveLabel)
			{
				if (this.m_ShelfCompartment.GetItemCount() == 0)
				{
					InteractionPlayerController.AddToolTip(this.m_GameActionInputDisplayList[i], false, false);
				}
			}
			else
			{
				InteractionPlayerController.AddToolTip(this.m_GameActionInputDisplayList[i], false, false);
			}
		}
	}

	// Token: 0x06000214 RID: 532 RVA: 0x00014D48 File Offset: 0x00012F48
	public void SetPriceTagUI(UI_PriceTag PriceTagUI)
	{
		this.m_PriceTagUI = PriceTagUI;
	}

	// Token: 0x06000215 RID: 533 RVA: 0x00014D51 File Offset: 0x00012F51
	public UI_PriceTag GetPriceTagUI()
	{
		return this.m_PriceTagUI;
	}

	// Token: 0x06000216 RID: 534 RVA: 0x00014D59 File Offset: 0x00012F59
	public override void OnMouseButtonUp()
	{
		CSingleton<SetItemPriceScreen>.Instance.OpenScreen(this.m_PriceTagUI.GetItemType());
	}

	// Token: 0x06000217 RID: 535 RVA: 0x00014D70 File Offset: 0x00012F70
	public override void OnRightMouseButtonUp()
	{
		if (this.m_ShelfCompartment)
		{
			this.m_ShelfCompartment.RemoveLabel(true);
		}
	}

	// Token: 0x06000218 RID: 536 RVA: 0x00014D8B File Offset: 0x00012F8B
	public void SetVisibility(bool isVisible)
	{
		base.gameObject.SetActive(isVisible);
		this.m_PriceTagUI.gameObject.SetActive(isVisible);
	}

	// Token: 0x06000219 RID: 537 RVA: 0x00014DAA File Offset: 0x00012FAA
	public void SetItemImage(EItemType itemType)
	{
		this.m_PriceTagUI.SetItemImage(itemType);
	}

	// Token: 0x0600021A RID: 538 RVA: 0x00014DB8 File Offset: 0x00012FB8
	public void SetAmountText(int amount)
	{
		this.m_PriceTagUI.SetAmountText(amount);
	}

	// Token: 0x0600021B RID: 539 RVA: 0x00014DC6 File Offset: 0x00012FC6
	public void SetPriceText(float price)
	{
		this.m_PriceTagUI.SetPriceText(price);
	}

	// Token: 0x0600021C RID: 540 RVA: 0x00014DD4 File Offset: 0x00012FD4
	public void RefreshPriceText()
	{
		this.m_PriceTagUI.RefreshPriceText();
	}

	// Token: 0x0600021D RID: 541 RVA: 0x00014DE1 File Offset: 0x00012FE1
	public void SetPriceTagScale(float scale)
	{
		this.m_PriceTagUI.transform.localScale = Vector3.one * scale;
	}

	// Token: 0x0600021E RID: 542 RVA: 0x00014DFE File Offset: 0x00012FFE
	public void SetIgnoreCull(bool ignoreCull)
	{
		this.m_PriceTagUI.m_IgnoreCull = ignoreCull;
		if (ignoreCull)
		{
			this.m_PriceTagUI.m_UIGrp.gameObject.SetActive(true);
		}
	}

	// Token: 0x04000262 RID: 610
	private ShelfCompartment m_ShelfCompartment;

	// Token: 0x04000263 RID: 611
	public UI_PriceTag m_PriceTagUI;
}
