﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E2 RID: 482
	public abstract class CameraInput : MonoBehaviour
	{
		// Token: 0x06000D8F RID: 3471
		public abstract float GetHorizontalCameraInput();

		// Token: 0x06000D90 RID: 3472
		public abstract float GetVerticalCameraInput();
	}
}
