﻿using System;
using System.Collections.Generic;

// Token: 0x02000014 RID: 20
[Serializable]
public class CustomerSaveData
{
	// Token: 0x0400014C RID: 332
	public ECustomerState currentState;

	// Token: 0x0400014D RID: 333
	public bool hasPlayedGame;

	// Token: 0x0400014E RID: 334
	public bool hasCheckedOut;

	// Token: 0x0400014F RID: 335
	public bool hasTookItemFromShelf;

	// Token: 0x04000150 RID: 336
	public bool hasTookCardFromShelf;

	// Token: 0x04000151 RID: 337
	public bool isInsideShop;

	// Token: 0x04000152 RID: 338
	public bool isSmelly;

	// Token: 0x04000153 RID: 339
	public int smellyMeter;

	// Token: 0x04000154 RID: 340
	public float currentCostTotal;

	// Token: 0x04000155 RID: 341
	public float maxMoney;

	// Token: 0x04000156 RID: 342
	public float totalScannedItemCost;

	// Token: 0x04000157 RID: 343
	public float currentPlayTableFee;

	// Token: 0x04000158 RID: 344
	public Vector3Serializer pos;

	// Token: 0x04000159 RID: 345
	public QuaternionSerializer rot;

	// Token: 0x0400015A RID: 346
	public List<EItemType> itemInBagList;

	// Token: 0x0400015B RID: 347
	public List<float> itemInBagPriceList;

	// Token: 0x0400015C RID: 348
	public List<CardData> cardInBagList;

	// Token: 0x0400015D RID: 349
	public List<float> cardInBagPriceList;
}
