﻿using System;
using UnityEngine;

// Token: 0x02000005 RID: 5
public class TableGameItemSet : MonoBehaviour
{
	// Token: 0x0600000C RID: 12 RVA: 0x000022A8 File Offset: 0x000004A8
	private void Start()
	{
	}

	// Token: 0x0600000D RID: 13 RVA: 0x000022AA File Offset: 0x000004AA
	private void Update()
	{
	}
}
