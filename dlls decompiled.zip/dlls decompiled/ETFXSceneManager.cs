﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000141 RID: 321
public class ETFXSceneManager : MonoBehaviour
{
	// Token: 0x06000918 RID: 2328 RVA: 0x0004225F File Offset: 0x0004045F
	public void LoadScene1()
	{
		SceneManager.LoadScene("etfx_explosions");
	}

	// Token: 0x06000919 RID: 2329 RVA: 0x0004226B File Offset: 0x0004046B
	public void LoadScene2()
	{
		SceneManager.LoadScene("etfx_explosions2");
	}

	// Token: 0x0600091A RID: 2330 RVA: 0x00042277 File Offset: 0x00040477
	public void LoadScene3()
	{
		SceneManager.LoadScene("etfx_portals");
	}

	// Token: 0x0600091B RID: 2331 RVA: 0x00042283 File Offset: 0x00040483
	public void LoadScene4()
	{
		SceneManager.LoadScene("etfx_magic");
	}

	// Token: 0x0600091C RID: 2332 RVA: 0x0004228F File Offset: 0x0004048F
	public void LoadScene5()
	{
		SceneManager.LoadScene("etfx_emojis");
	}

	// Token: 0x0600091D RID: 2333 RVA: 0x0004229B File Offset: 0x0004049B
	public void LoadScene6()
	{
		SceneManager.LoadScene("etfx_sparkles");
	}

	// Token: 0x0600091E RID: 2334 RVA: 0x000422A7 File Offset: 0x000404A7
	public void LoadScene7()
	{
		SceneManager.LoadScene("etfx_fireworks");
	}

	// Token: 0x0600091F RID: 2335 RVA: 0x000422B3 File Offset: 0x000404B3
	public void LoadScene8()
	{
		SceneManager.LoadScene("etfx_powerups");
	}

	// Token: 0x06000920 RID: 2336 RVA: 0x000422BF File Offset: 0x000404BF
	public void LoadScene9()
	{
		SceneManager.LoadScene("etfx_swordcombat");
	}

	// Token: 0x06000921 RID: 2337 RVA: 0x000422CB File Offset: 0x000404CB
	public void LoadScene10()
	{
		SceneManager.LoadScene("etfx_maindemo");
	}

	// Token: 0x06000922 RID: 2338 RVA: 0x000422D7 File Offset: 0x000404D7
	public void LoadScene11()
	{
		SceneManager.LoadScene("etfx_combat");
	}

	// Token: 0x06000923 RID: 2339 RVA: 0x000422E3 File Offset: 0x000404E3
	public void LoadScene12()
	{
		SceneManager.LoadScene("etfx_2ddemo");
	}

	// Token: 0x06000924 RID: 2340 RVA: 0x000422EF File Offset: 0x000404EF
	public void LoadScene13()
	{
		SceneManager.LoadScene("etfx_missiles");
	}

	// Token: 0x06000925 RID: 2341 RVA: 0x000422FC File Offset: 0x000404FC
	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.L))
		{
			this.GUIHide = !this.GUIHide;
			if (this.GUIHide)
			{
				GameObject.Find("CanvasSceneSelect").GetComponent<Canvas>().enabled = false;
			}
			else
			{
				GameObject.Find("CanvasSceneSelect").GetComponent<Canvas>().enabled = true;
			}
		}
		if (Input.GetKeyDown(KeyCode.J))
		{
			this.GUIHide2 = !this.GUIHide2;
			if (this.GUIHide2)
			{
				GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
			}
			else
			{
				GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
			}
		}
		if (Input.GetKeyDown(KeyCode.H))
		{
			this.GUIHide3 = !this.GUIHide3;
			if (this.GUIHide3)
			{
				GameObject.Find("ParticleSysDisplayCanvas").GetComponent<Canvas>().enabled = false;
				return;
			}
			GameObject.Find("ParticleSysDisplayCanvas").GetComponent<Canvas>().enabled = true;
		}
	}

	// Token: 0x04001130 RID: 4400
	public bool GUIHide;

	// Token: 0x04001131 RID: 4401
	public bool GUIHide2;

	// Token: 0x04001132 RID: 4402
	public bool GUIHide3;
}
