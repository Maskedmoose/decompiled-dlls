﻿using System;

// Token: 0x0200003D RID: 61
[Serializable]
public class GhostCardData
{
	// Token: 0x040003B1 RID: 945
	public string Name;

	// Token: 0x040003B2 RID: 946
	public EMonsterType MonsterType;

	// Token: 0x040003B3 RID: 947
	public EGhostCardEffect GhostCardEffect;
}
