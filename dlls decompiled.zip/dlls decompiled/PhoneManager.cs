﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200003E RID: 62
public class PhoneManager : CSingleton<PhoneManager>
{
	// Token: 0x06000304 RID: 772 RVA: 0x0001C1AB File Offset: 0x0001A3AB
	private void Awake()
	{
	}

	// Token: 0x06000305 RID: 773 RVA: 0x0001C1B0 File Offset: 0x0001A3B0
	private void Update()
	{
		if (this.m_IsPhoneMode)
		{
			this.m_Timer = Mathf.Clamp(this.m_Timer + Time.deltaTime * this.m_LerpSpeed, 0f, 1f);
		}
		else
		{
			this.m_Timer = Mathf.Clamp(this.m_Timer - Time.deltaTime * this.m_LerpSpeed, 0f, 1f);
		}
		this.m_PhoneGrp.transform.position = Vector3.Lerp(this.m_StartPos.position, this.m_EndPos.position, this.m_Timer);
	}

	// Token: 0x06000306 RID: 774 RVA: 0x0001C248 File Offset: 0x0001A448
	public static void EnterPhoneMode()
	{
		SoundManager.PlayAudio("SFX_Throw", 0.1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.OnEnterPhoneScreenMode();
		CSingleton<PhoneManager>.Instance.m_IsPhoneMode = true;
		CSingleton<PhoneManager>.Instance.m_UI_PhoneScreen.OpenScreen();
		UnityAnalytic.OpenPhone();
	}

	// Token: 0x06000307 RID: 775 RVA: 0x0001C288 File Offset: 0x0001A488
	public static void ExitPhoneMode()
	{
		if (PhoneManager.CanClosePhone())
		{
			SoundManager.PlayAudio("SFX_Throw", 0.1f, 0.8f);
			CSingleton<InteractionPlayerController>.Instance.OnExitPhoneScreenMode();
			CSingleton<PhoneManager>.Instance.m_IsPhoneMode = false;
		}
		CSingleton<PhoneManager>.Instance.m_UI_PhoneScreen.OnPressBack();
	}

	// Token: 0x06000308 RID: 776 RVA: 0x0001C2D4 File Offset: 0x0001A4D4
	public static void SetCanClosePhone(bool canClose)
	{
		if (canClose)
		{
			InteractionPlayerController.RemoveToolTip(EGameAction.ClosePhone);
			InteractionPlayerController.AddToolTip(EGameAction.ClosePhone, false, false);
		}
		else
		{
			InteractionPlayerController.RemoveToolTip(EGameAction.ClosePhone);
		}
		CSingleton<PhoneManager>.Instance.m_CanClosePhone = canClose;
	}

	// Token: 0x06000309 RID: 777 RVA: 0x0001C2FD File Offset: 0x0001A4FD
	public static bool CanClosePhone()
	{
		return CSingleton<PhoneManager>.Instance.m_CanClosePhone && !CSingleton<PhoneManager>.Instance.m_IsOpeningPhone;
	}

	// Token: 0x0600030A RID: 778 RVA: 0x0001C31A File Offset: 0x0001A51A
	public IEnumerator DelayOpenManageEventScreen()
	{
		this.m_IsOpeningPhone = true;
		PhoneManager.EnterPhoneMode();
		yield return new WaitForSeconds(0.1f);
		this.m_UI_PhoneScreen.OnPressManageEventBtn();
		this.m_IsOpeningPhone = false;
		yield break;
	}

	// Token: 0x0600030B RID: 779 RVA: 0x0001C329 File Offset: 0x0001A529
	public void SetBillNotificationVisible(bool isVisible)
	{
		this.m_UI_PhoneScreen.SetBillNotificationVisible(isVisible);
	}

	// Token: 0x0600030C RID: 780 RVA: 0x0001C338 File Offset: 0x0001A538
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
			CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.AddListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
		}
	}

	// Token: 0x0600030D RID: 781 RVA: 0x0001C39C File Offset: 0x0001A59C
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
			CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
			CEventManager.RemoveListener<CEventPlayer_OnDayEnded>(new CEventManager.EventDelegate<CEventPlayer_OnDayEnded>(this.OnDayEnded));
		}
	}

	// Token: 0x0600030E RID: 782 RVA: 0x0001C3FD File Offset: 0x0001A5FD
	protected virtual void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.m_RentBillScreen.OnGameFinishLoaded();
	}

	// Token: 0x0600030F RID: 783 RVA: 0x0001C40A File Offset: 0x0001A60A
	protected virtual void OnFinishHideLoadingScreen(CEventPlayer_FinishHideLoadingScreen evt)
	{
	}

	// Token: 0x06000310 RID: 784 RVA: 0x0001C40C File Offset: 0x0001A60C
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		if (CPlayerData.m_CurrentDay > 0)
		{
			this.m_RentBillScreen.EvaluateNewDayBill();
		}
	}

	// Token: 0x06000311 RID: 785 RVA: 0x0001C421 File Offset: 0x0001A621
	protected void OnDayEnded(CEventPlayer_OnDayEnded evt)
	{
	}

	// Token: 0x040003B4 RID: 948
	public static PhoneManager m_Instance;

	// Token: 0x040003B5 RID: 949
	public Transform m_PhoneGrp;

	// Token: 0x040003B6 RID: 950
	public Transform m_StartPos;

	// Token: 0x040003B7 RID: 951
	public Transform m_EndPos;

	// Token: 0x040003B8 RID: 952
	public UI_PhoneScreen m_UI_PhoneScreen;

	// Token: 0x040003B9 RID: 953
	public RestockItemScreen m_RestockItemScreen;

	// Token: 0x040003BA RID: 954
	public FurnitureShopUIScreen m_FurnitureShopUIScreen;

	// Token: 0x040003BB RID: 955
	public ExpansionShopUIScreen m_ExpandShopUIScreen;

	// Token: 0x040003BC RID: 956
	public SetGameEventScreen m_SetGameEventUIScreen;

	// Token: 0x040003BD RID: 957
	public CheckPriceScreen m_CheckPriceScreen;

	// Token: 0x040003BE RID: 958
	public HireWorkerScreen m_HireWorkerScreen;

	// Token: 0x040003BF RID: 959
	public RentBillScreen m_RentBillScreen;

	// Token: 0x040003C0 RID: 960
	private bool m_IsPhoneMode;

	// Token: 0x040003C1 RID: 961
	private bool m_IsOpeningPhone;

	// Token: 0x040003C2 RID: 962
	private bool m_CanClosePhone = true;

	// Token: 0x040003C3 RID: 963
	private float m_Timer;

	// Token: 0x040003C4 RID: 964
	private float m_LerpSpeed = 3f;
}
