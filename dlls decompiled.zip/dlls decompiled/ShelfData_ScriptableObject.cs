﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000132 RID: 306
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 9)]
public class ShelfData_ScriptableObject : ScriptableObject
{
	// Token: 0x040010DD RID: 4317
	public List<ObjectData> m_ObjectDataList;

	// Token: 0x040010DE RID: 4318
	public List<FurniturePurchaseData> m_FurniturePurchaseDataList;
}
