﻿using System;

// Token: 0x020000B8 RID: 184
public class CEventPlayer_OnGameServiceLoginSuccess : CEvent
{
	// Token: 0x1700001E RID: 30
	// (get) Token: 0x0600071B RID: 1819 RVA: 0x00038147 File Offset: 0x00036347
	// (set) Token: 0x0600071C RID: 1820 RVA: 0x0003814F File Offset: 0x0003634F
	public bool m_LoginSuccess { get; private set; }

	// Token: 0x0600071D RID: 1821 RVA: 0x00038158 File Offset: 0x00036358
	public CEventPlayer_OnGameServiceLoginSuccess(bool loginSuccess)
	{
		this.m_LoginSuccess = loginSuccess;
	}
}
