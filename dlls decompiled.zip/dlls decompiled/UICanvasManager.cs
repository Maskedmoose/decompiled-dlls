﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200013F RID: 319
public class UICanvasManager : MonoBehaviour
{
	// Token: 0x0600090B RID: 2315 RVA: 0x00041F13 File Offset: 0x00040113
	private void Awake()
	{
		UICanvasManager.GlobalAccess = this;
	}

	// Token: 0x0600090C RID: 2316 RVA: 0x00041F1B File Offset: 0x0004011B
	private void Start()
	{
		if (this.PENameText != null)
		{
			this.PENameText.text = ParticleEffectsLibrary.GlobalAccess.GetCurrentPENameString();
		}
	}

	// Token: 0x0600090D RID: 2317 RVA: 0x00041F40 File Offset: 0x00040140
	private void Update()
	{
		if (!this.MouseOverButton && Input.GetMouseButtonUp(0))
		{
			this.SpawnCurrentParticleEffect();
		}
		if (Input.GetKeyUp(KeyCode.A))
		{
			this.SelectPreviousPE();
		}
		if (Input.GetKeyUp(KeyCode.D))
		{
			this.SelectNextPE();
		}
	}

	// Token: 0x0600090E RID: 2318 RVA: 0x00041F76 File Offset: 0x00040176
	public void UpdateToolTip(ButtonTypes toolTipType)
	{
		if (this.ToolTipText != null)
		{
			if (toolTipType == ButtonTypes.Previous)
			{
				this.ToolTipText.text = "Select Previous Particle Effect";
				return;
			}
			if (toolTipType == ButtonTypes.Next)
			{
				this.ToolTipText.text = "Select Next Particle Effect";
			}
		}
	}

	// Token: 0x0600090F RID: 2319 RVA: 0x00041FAF File Offset: 0x000401AF
	public void ClearToolTip()
	{
		if (this.ToolTipText != null)
		{
			this.ToolTipText.text = "";
		}
	}

	// Token: 0x06000910 RID: 2320 RVA: 0x00041FCF File Offset: 0x000401CF
	private void SelectPreviousPE()
	{
		ParticleEffectsLibrary.GlobalAccess.PreviousParticleEffect();
		if (this.PENameText != null)
		{
			this.PENameText.text = ParticleEffectsLibrary.GlobalAccess.GetCurrentPENameString();
		}
	}

	// Token: 0x06000911 RID: 2321 RVA: 0x00041FFE File Offset: 0x000401FE
	private void SelectNextPE()
	{
		ParticleEffectsLibrary.GlobalAccess.NextParticleEffect();
		if (this.PENameText != null)
		{
			this.PENameText.text = ParticleEffectsLibrary.GlobalAccess.GetCurrentPENameString();
		}
	}

	// Token: 0x06000912 RID: 2322 RVA: 0x0004202D File Offset: 0x0004022D
	private void SpawnCurrentParticleEffect()
	{
		if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out this.rayHit))
		{
			ParticleEffectsLibrary.GlobalAccess.SpawnParticleEffect(this.rayHit.point);
		}
	}

	// Token: 0x06000913 RID: 2323 RVA: 0x00042060 File Offset: 0x00040260
	public void UIButtonClick(ButtonTypes buttonTypeClicked)
	{
		if (buttonTypeClicked == ButtonTypes.Previous)
		{
			this.SelectPreviousPE();
			return;
		}
		if (buttonTypeClicked != ButtonTypes.Next)
		{
			return;
		}
		this.SelectNextPE();
	}

	// Token: 0x04001125 RID: 4389
	public static UICanvasManager GlobalAccess;

	// Token: 0x04001126 RID: 4390
	public bool MouseOverButton;

	// Token: 0x04001127 RID: 4391
	public Text PENameText;

	// Token: 0x04001128 RID: 4392
	public Text ToolTipText;

	// Token: 0x04001129 RID: 4393
	private RaycastHit rayHit;
}
