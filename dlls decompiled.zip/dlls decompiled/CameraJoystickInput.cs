﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E3 RID: 483
	public class CameraJoystickInput : CameraInput
	{
		// Token: 0x06000D92 RID: 3474 RVA: 0x0005D200 File Offset: 0x0005B400
		public override float GetHorizontalCameraInput()
		{
			float num = Input.GetAxisRaw(this.joystickHorizontalAxis);
			if (Mathf.Abs(num) < this.deadZoneThreshold)
			{
				num = 0f;
			}
			if (this.invertHorizontalInput)
			{
				return num * -1f;
			}
			return num;
		}

		// Token: 0x06000D93 RID: 3475 RVA: 0x0005D240 File Offset: 0x0005B440
		public override float GetVerticalCameraInput()
		{
			float num = Input.GetAxisRaw(this.joystickVerticalAxis);
			if (Mathf.Abs(num) < this.deadZoneThreshold)
			{
				num = 0f;
			}
			if (this.invertVerticalInput)
			{
				return num;
			}
			return num * -1f;
		}

		// Token: 0x0400147F RID: 5247
		public string joystickHorizontalAxis = "Joystick X";

		// Token: 0x04001480 RID: 5248
		public string joystickVerticalAxis = "Joystick Y";

		// Token: 0x04001481 RID: 5249
		public bool invertHorizontalInput;

		// Token: 0x04001482 RID: 5250
		public bool invertVerticalInput;

		// Token: 0x04001483 RID: 5251
		public float deadZoneThreshold = 0.2f;
	}
}
