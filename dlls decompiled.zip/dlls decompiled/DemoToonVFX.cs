﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000145 RID: 325
public class DemoToonVFX : MonoBehaviour
{
	// Token: 0x06000930 RID: 2352 RVA: 0x0004290C File Offset: 0x00040B0C
	private void Start()
	{
		if (Screen.dpi < 1f)
		{
			this.windowDpi = 1f;
		}
		if (Screen.dpi < 200f)
		{
			this.windowDpi = 1f;
		}
		else
		{
			this.windowDpi = Screen.dpi / 200f;
		}
		Vector3 eulerAngles = base.transform.eulerAngles;
		this.x = eulerAngles.y;
		this.y = eulerAngles.x;
		this.Counter(0);
		this.animObject.GetComponent<Animator>();
	}

	// Token: 0x06000931 RID: 2353 RVA: 0x00042994 File Offset: 0x00040B94
	private void OnGUI()
	{
		if (GUI.Button(new Rect(5f * this.windowDpi, 5f * this.windowDpi, 110f * this.windowDpi, 35f * this.windowDpi), "Previous effect"))
		{
			this.Counter(-1);
		}
		if (GUI.Button(new Rect(120f * this.windowDpi, 5f * this.windowDpi, 110f * this.windowDpi, 35f * this.windowDpi), "Play again"))
		{
			this.Counter(0);
		}
		if (GUI.Button(new Rect(235f * this.windowDpi, 5f * this.windowDpi, 110f * this.windowDpi, 35f * this.windowDpi), "Next effect"))
		{
			this.Counter(1);
		}
		this.StartColor = this.HueColor;
		this.HueColor = GUI.HorizontalSlider(new Rect(5f * this.windowDpi, 45f * this.windowDpi, 340f * this.windowDpi, 35f * this.windowDpi), this.HueColor, 0f, 1f);
		GUI.DrawTexture(new Rect(5f * this.windowDpi, 65f * this.windowDpi, 340f * this.windowDpi, 15f * this.windowDpi), this.HueTexture, ScaleMode.StretchToFill, false, 0f);
		if (this.HueColor != this.StartColor)
		{
			int num = 0;
			ParticleSystem[] array = this.particleSystems;
			for (int i = 0; i < array.Length; i++)
			{
				ParticleSystem.MainModule main = array[i].main;
				Color color = Color.HSVToRGB(this.HueColor + this.H * 0f, this.svList[num].S, this.svList[num].V);
				main.startColor = new Color(color.r, color.g, color.b, this.svList[num].A);
				num++;
			}
		}
	}

	// Token: 0x06000932 RID: 2354 RVA: 0x00042BCC File Offset: 0x00040DCC
	private void Counter(int count)
	{
		this.Prefab += count;
		if (this.Prefab > this.Prefabs.Length - 1)
		{
			this.Prefab = 0;
		}
		else if (this.Prefab < 0)
		{
			this.Prefab = this.Prefabs.Length - 1;
		}
		if (this.Instance != null)
		{
			Object.Destroy(this.Instance);
		}
		this.Instance = Object.Instantiate<GameObject>(this.Prefabs[this.Prefab]);
		this.Instance.SetActive(false);
		if (this.activationTime.Length == this.Prefabs.Length)
		{
			base.CancelInvoke();
			if (this.activationTime[this.Prefab] > 0.01f)
			{
				base.Invoke("Activate", this.activationTime[this.Prefab]);
			}
			if (this.activationTime[this.Prefab] == 0f)
			{
				this.Instance.SetActive(true);
			}
		}
		this.particleSystems = this.Instance.GetComponentsInChildren<ParticleSystem>();
		this.svList.Clear();
		ParticleSystem[] array = this.particleSystems;
		for (int i = 0; i < array.Length; i++)
		{
			Color color = array[i].main.startColor.color;
			DemoToonVFX.SVA item = default(DemoToonVFX.SVA);
			Color.RGBToHSV(color, out this.H, out item.S, out item.V);
			item.A = color.a;
			this.svList.Add(item);
		}
		if (this.useAnimation)
		{
			this.animObject.SetInteger("toDo", this.Prefab);
		}
	}

	// Token: 0x06000933 RID: 2355 RVA: 0x00042D61 File Offset: 0x00040F61
	private void Activate()
	{
		this.Instance.SetActive(true);
	}

	// Token: 0x06000934 RID: 2356 RVA: 0x00042D70 File Offset: 0x00040F70
	private void LateUpdate()
	{
		if (this.currDistance < 2f)
		{
			this.currDistance = 2f;
		}
		this.currDistance -= Input.GetAxis("Mouse ScrollWheel") * 2f;
		if (this.Holder && (Input.GetMouseButton(0) || Input.GetMouseButton(1)))
		{
			Vector3 mousePosition = Input.mousePosition;
			if (Screen.dpi < 1f)
			{
			}
			float num;
			if (Screen.dpi < 200f)
			{
				num = 1f;
			}
			else
			{
				num = Screen.dpi / 200f;
			}
			if (mousePosition.x < 380f * num && (float)Screen.height - mousePosition.y < 250f * num)
			{
				return;
			}
			Cursor.visible = false;
			Cursor.lockState = CursorLockMode.Locked;
			this.x += (float)((double)(Input.GetAxis("Mouse X") * this.xRotate) * 0.02);
			this.y -= (float)((double)(Input.GetAxis("Mouse Y") * this.yRotate) * 0.02);
			this.y = DemoToonVFX.ClampAngle(this.y, this.yMinLimit, this.yMaxLimit);
			Quaternion rotation = Quaternion.Euler(this.y, this.x, 0f);
			Vector3 position = rotation * new Vector3(0f, 0f, -this.currDistance) + this.Holder.position;
			base.transform.rotation = rotation;
			base.transform.position = position;
		}
		else
		{
			Cursor.visible = true;
			Cursor.lockState = CursorLockMode.None;
		}
		if (this.prevDistance != this.currDistance)
		{
			this.prevDistance = this.currDistance;
			Quaternion rotation2 = Quaternion.Euler(this.y, this.x, 0f);
			Vector3 position2 = rotation2 * new Vector3(0f, 0f, -this.currDistance) + this.Holder.position;
			base.transform.rotation = rotation2;
			base.transform.position = position2;
		}
	}

	// Token: 0x06000935 RID: 2357 RVA: 0x00042F9B File Offset: 0x0004119B
	private static float ClampAngle(float angle, float min, float max)
	{
		if (angle < -360f)
		{
			angle += 360f;
		}
		if (angle > 360f)
		{
			angle -= 360f;
		}
		return Mathf.Clamp(angle, min, max);
	}

	// Token: 0x0400113E RID: 4414
	public Transform Holder;

	// Token: 0x0400113F RID: 4415
	public float currDistance = 5f;

	// Token: 0x04001140 RID: 4416
	public float xRotate = 250f;

	// Token: 0x04001141 RID: 4417
	public float yRotate = 120f;

	// Token: 0x04001142 RID: 4418
	public float yMinLimit = -20f;

	// Token: 0x04001143 RID: 4419
	public float yMaxLimit = 80f;

	// Token: 0x04001144 RID: 4420
	public float prevDistance;

	// Token: 0x04001145 RID: 4421
	private float x;

	// Token: 0x04001146 RID: 4422
	private float y;

	// Token: 0x04001147 RID: 4423
	[Header("GUI")]
	private float windowDpi;

	// Token: 0x04001148 RID: 4424
	public GameObject[] Prefabs;

	// Token: 0x04001149 RID: 4425
	private int Prefab;

	// Token: 0x0400114A RID: 4426
	private GameObject Instance;

	// Token: 0x0400114B RID: 4427
	private float StartColor;

	// Token: 0x0400114C RID: 4428
	private float HueColor;

	// Token: 0x0400114D RID: 4429
	public Texture HueTexture;

	// Token: 0x0400114E RID: 4430
	public float[] activationTime;

	// Token: 0x0400114F RID: 4431
	public Animator animObject;

	// Token: 0x04001150 RID: 4432
	private ParticleSystem[] particleSystems = new ParticleSystem[0];

	// Token: 0x04001151 RID: 4433
	private List<DemoToonVFX.SVA> svList = new List<DemoToonVFX.SVA>();

	// Token: 0x04001152 RID: 4434
	private float H;

	// Token: 0x04001153 RID: 4435
	public bool useAnimation;

	// Token: 0x02000238 RID: 568
	public struct SVA
	{
		// Token: 0x040015C0 RID: 5568
		public float S;

		// Token: 0x040015C1 RID: 5569
		public float V;

		// Token: 0x040015C2 RID: 5570
		public float A;
	}
}
