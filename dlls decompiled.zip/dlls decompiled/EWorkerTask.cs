﻿using System;

// Token: 0x0200008E RID: 142
public enum EWorkerTask
{
	// Token: 0x0400073D RID: 1853
	Rest,
	// Token: 0x0400073E RID: 1854
	ManCounter,
	// Token: 0x0400073F RID: 1855
	RestockShelf,
	// Token: 0x04000740 RID: 1856
	GoBackHome = 99,
	// Token: 0x04000741 RID: 1857
	Fired
}
