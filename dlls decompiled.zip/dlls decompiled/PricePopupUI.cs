﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000042 RID: 66
public class PricePopupUI : MonoBehaviour
{
	// Token: 0x06000327 RID: 807 RVA: 0x0001D147 File Offset: 0x0001B347
	public void Init()
	{
		this.m_Transform = base.transform;
	}

	// Token: 0x06000328 RID: 808 RVA: 0x0001D155 File Offset: 0x0001B355
	public void SetFollowTransform(Transform follow, float offsetUp)
	{
		this.m_FollowTransform = follow;
		this.m_OffsetUp = offsetUp;
	}

	// Token: 0x040003D1 RID: 977
	public Transform m_Transform;

	// Token: 0x040003D2 RID: 978
	public Transform m_FollowTransform;

	// Token: 0x040003D3 RID: 979
	public TextMeshProUGUI m_Text;

	// Token: 0x040003D4 RID: 980
	public float m_OffsetUp;
}
