﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001EA RID: 490
	public class FPSCounter : MonoBehaviour
	{
		// Token: 0x06000DB0 RID: 3504 RVA: 0x0005D918 File Offset: 0x0005BB18
		private void Update()
		{
			this.currentPassedFrames++;
			this.currentPassedTime += Time.deltaTime;
			if (this.currentPassedTime >= this.checkInterval)
			{
				this.currentFrameRate = (float)this.currentPassedFrames / this.currentPassedTime;
				this.currentPassedTime = 0f;
				this.currentPassedFrames = 0;
				this.currentFrameRate *= 100f;
				this.currentFrameRate = (float)((int)this.currentFrameRate);
				this.currentFrameRate /= 100f;
				this.currentFrameRateString = this.currentFrameRate.ToString();
			}
		}

		// Token: 0x06000DB1 RID: 3505 RVA: 0x0005D9BC File Offset: 0x0005BBBC
		private void OnGUI()
		{
			GUI.contentColor = Color.black;
			float num = 40f;
			float num2 = 2f;
			GUI.Label(new Rect((float)Screen.width - num + num2, num2, num, 30f), this.currentFrameRateString);
			GUI.contentColor = Color.white;
			GUI.Label(new Rect((float)Screen.width - num, 0f, num, 30f), this.currentFrameRateString);
		}

		// Token: 0x040014A4 RID: 5284
		public float checkInterval = 1f;

		// Token: 0x040014A5 RID: 5285
		private int currentPassedFrames;

		// Token: 0x040014A6 RID: 5286
		private float currentPassedTime;

		// Token: 0x040014A7 RID: 5287
		public float currentFrameRate;

		// Token: 0x040014A8 RID: 5288
		private string currentFrameRateString = "";
	}
}
