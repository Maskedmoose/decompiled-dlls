﻿using System;
using System.Collections.Generic;

namespace CC
{
	// Token: 0x020001C7 RID: 455
	[Serializable]
	public class MultiPicker
	{
		// Token: 0x040013A9 RID: 5033
		public CC_Property Property;

		// Token: 0x040013AA RID: 5034
		public List<string> Objects = new List<string>();
	}
}
