﻿using System;
using System.Collections.Generic;
using I2.Loc;
using UnityEngine;

// Token: 0x02000036 RID: 54
public class InventoryBase : CSingleton<InventoryBase>
{
	// Token: 0x060002AA RID: 682 RVA: 0x000198CF File Offset: 0x00017ACF
	private void Awake()
	{
	}

	// Token: 0x060002AB RID: 683 RVA: 0x000198D1 File Offset: 0x00017AD1
	private void Start()
	{
	}

	// Token: 0x060002AC RID: 684 RVA: 0x000198D4 File Offset: 0x00017AD4
	public static InteractableObject GetSpawnInteractableObjectPrefab(EObjectType objType)
	{
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_ObjectDataList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_ObjectDataList[i].objectType == objType)
			{
				return CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_ObjectDataList[i].spawnPrefab;
			}
		}
		return null;
	}

	// Token: 0x060002AD RID: 685 RVA: 0x00019939 File Offset: 0x00017B39
	public static FurniturePurchaseData GetFurniturePurchaseData(int index)
	{
		return CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_FurniturePurchaseDataList[index];
	}

	// Token: 0x060002AE RID: 686 RVA: 0x00019950 File Offset: 0x00017B50
	public static FurniturePurchaseData GetFurniturePurchaseData(EObjectType objType)
	{
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_ObjectDataList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_FurniturePurchaseDataList[i].objectType == objType)
			{
				return CSingleton<InventoryBase>.Instance.m_ObjectData_SO.m_FurniturePurchaseDataList[i];
			}
		}
		return null;
	}

	// Token: 0x060002AF RID: 687 RVA: 0x000199B0 File Offset: 0x00017BB0
	public static GameEventData GetGameEventData(EGameEventFormat gameEventFormat)
	{
		if (gameEventFormat == EGameEventFormat.None)
		{
			return new GameEventData();
		}
		return CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_GameEventDataList[(int)gameEventFormat];
	}

	// Token: 0x060002B0 RID: 688 RVA: 0x000199D1 File Offset: 0x00017BD1
	public static ItemData GetItemData(EItemType itemType)
	{
		if (itemType == EItemType.None)
		{
			return new ItemData();
		}
		return CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemDataList[(int)itemType];
	}

	// Token: 0x060002B1 RID: 689 RVA: 0x000199F2 File Offset: 0x00017BF2
	public static ItemMeshData GetItemMeshData(EItemType itemType)
	{
		if (itemType == EItemType.None)
		{
			return new ItemMeshData();
		}
		return CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ItemMeshDataList[(int)itemType];
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x00019A13 File Offset: 0x00017C13
	public static RestockData GetRestockData(int index)
	{
		return CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[index];
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x00019A2C File Offset: 0x00017C2C
	public static List<RestockData> GetRestockDataUsingItemType(EItemType itemType)
	{
		List<RestockData> list = new List<RestockData>();
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i].itemType == itemType)
			{
				list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i]);
			}
		}
		return list;
	}

	// Token: 0x060002B4 RID: 692 RVA: 0x00019A98 File Offset: 0x00017C98
	public static int GetRestockDataIndex(EItemType itemType)
	{
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i].itemType == itemType)
			{
				return i;
			}
		}
		return -1;
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x00019AE4 File Offset: 0x00017CE4
	public static List<EItemType> GetUnlockableItemTypeAtShopLevel(int level)
	{
		List<EItemType> list = new List<EItemType>();
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList.Count; i++)
		{
			if (!CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i].isHideItemUntilUnlocked && level >= CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i].licenseShopLevelRequired)
			{
				list.Add(CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[i].itemType);
			}
		}
		return list;
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x00019B70 File Offset: 0x00017D70
	public static List<EMonsterType> GetShownMonsterList(ECardExpansionType expansionType)
	{
		if (expansionType == ECardExpansionType.Tetramon || expansionType == ECardExpansionType.Destiny)
		{
			return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownMonsterList;
		}
		if (expansionType == ECardExpansionType.Ghost)
		{
			return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownGhostMonsterList;
		}
		if (expansionType == ECardExpansionType.Megabot)
		{
			return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownMegabotList;
		}
		if (expansionType == ECardExpansionType.FantasyRPG)
		{
			return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownFantasyRPGList;
		}
		if (expansionType == ECardExpansionType.CatJob)
		{
			return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownCatJobList;
		}
		return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_ShownMonsterList;
	}

	// Token: 0x060002B7 RID: 695 RVA: 0x00019BF4 File Offset: 0x00017DF4
	public static MonsterData GetMonsterData(EMonsterType monsterType)
	{
		if (monsterType == EMonsterType.None)
		{
			return null;
		}
		if (monsterType < EMonsterType.MAX)
		{
			return InventoryBase.GetMonsterDataMatchWithType(CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_DataList, monsterType);
		}
		if (monsterType > EMonsterType.MAX && monsterType < EMonsterType.MAX_MEGABOT)
		{
			return InventoryBase.GetMonsterDataMatchWithType(CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_MegabotDataList, monsterType);
		}
		if (monsterType > EMonsterType.MAX_MEGABOT && monsterType < EMonsterType.MAX_FANTASYRPG)
		{
			return InventoryBase.GetMonsterDataMatchWithType(CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_FantasyRPGDataList, monsterType);
		}
		if (monsterType > EMonsterType.MAX_FANTASYRPG && monsterType < EMonsterType.MAX_CATJOB)
		{
			return InventoryBase.GetMonsterDataMatchWithType(CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_CatJobDataList, monsterType);
		}
		return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_DataList[(int)monsterType];
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x00019CA8 File Offset: 0x00017EA8
	private static MonsterData GetMonsterDataMatchWithType(List<MonsterData> listMonsterData, EMonsterType monsterType)
	{
		for (int i = 0; i < listMonsterData.Count; i++)
		{
			if (listMonsterData[i].MonsterType == monsterType)
			{
				return listMonsterData[i];
			}
		}
		return null;
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x00019CDE File Offset: 0x00017EDE
	public static Sprite GetAncientArtifactSprite(EMonsterType monsterType)
	{
		return null;
	}

	// Token: 0x060002BA RID: 698 RVA: 0x00019CE5 File Offset: 0x00017EE5
	public static Sprite GetMonsterGhostIconSprite(EMonsterType monsterType)
	{
		return null;
	}

	// Token: 0x060002BB RID: 699 RVA: 0x00019CEC File Offset: 0x00017EEC
	public static Sprite GetTetramonIconSprite(EMonsterType monsterType)
	{
		if (monsterType == EMonsterType.None)
		{
			return null;
		}
		int index = (int)(monsterType % (EMonsterType)CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_TetramonImageList.Count);
		return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_TetramonImageList[index];
	}

	// Token: 0x060002BC RID: 700 RVA: 0x00019D2C File Offset: 0x00017F2C
	public static Sprite GetSpecialCardImage(EMonsterType monsterType)
	{
		if (monsterType == EMonsterType.None)
		{
			return null;
		}
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_SpecialCardImageList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_SpecialCardImageList[i].MonsterType == monsterType)
			{
				return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_SpecialCardImageList[i].GetIcon(ECardExpansionType.None);
			}
		}
		return null;
	}

	// Token: 0x060002BD RID: 701 RVA: 0x00019D97 File Offset: 0x00017F97
	public static CardUISetting GetCardUISetting(ECardExpansionType expansionType)
	{
		return CSingleton<InventoryBase>.Instance.m_MonsterData_SO.m_CardUISettingList[(int)expansionType];
	}

	// Token: 0x060002BE RID: 702 RVA: 0x00019DB0 File Offset: 0x00017FB0
	public static ECardExpansionType GetCardExpansionType(ECollectionPackType collectionPackType)
	{
		if (collectionPackType == ECollectionPackType.BasicCardPack || collectionPackType == ECollectionPackType.RareCardPack || collectionPackType == ECollectionPackType.EpicCardPack || collectionPackType == ECollectionPackType.LegendaryCardPack)
		{
			return ECardExpansionType.Tetramon;
		}
		if (collectionPackType == ECollectionPackType.DestinyBasicCardPack || collectionPackType == ECollectionPackType.DestinyRareCardPack || collectionPackType == ECollectionPackType.DestinyEpicCardPack || collectionPackType == ECollectionPackType.DestinyLegendaryCardPack)
		{
			return ECardExpansionType.Destiny;
		}
		if (collectionPackType == ECollectionPackType.GhostPack)
		{
			return ECardExpansionType.Ghost;
		}
		if (collectionPackType == ECollectionPackType.MegabotPack)
		{
			return ECardExpansionType.Megabot;
		}
		if (collectionPackType == ECollectionPackType.FantasyRPGPack)
		{
			return ECardExpansionType.FantasyRPG;
		}
		if (collectionPackType == ECollectionPackType.CatJobPack)
		{
			return ECardExpansionType.CatJob;
		}
		return ECardExpansionType.None;
	}

	// Token: 0x060002BF RID: 703 RVA: 0x00019DFC File Offset: 0x00017FFC
	public static ECollectionPackType ItemTypeToCollectionPackType(EItemType itemType)
	{
		if (itemType == EItemType.BasicCardPack || itemType == EItemType.BasicCardBox)
		{
			return ECollectionPackType.BasicCardPack;
		}
		if (itemType == EItemType.RareCardPack || itemType == EItemType.RareCardBox)
		{
			return ECollectionPackType.RareCardPack;
		}
		if (itemType == EItemType.EpicCardPack || itemType == EItemType.EpicCardBox)
		{
			return ECollectionPackType.EpicCardPack;
		}
		if (itemType == EItemType.LegendaryCardPack || itemType == EItemType.LegendaryCardBox)
		{
			return ECollectionPackType.LegendaryCardPack;
		}
		if (itemType == EItemType.DestinyBasicCardPack || itemType == EItemType.DestinyBasicCardBox)
		{
			return ECollectionPackType.DestinyBasicCardPack;
		}
		if (itemType == EItemType.DestinyRareCardPack || itemType == EItemType.DestinyRareCardBox)
		{
			return ECollectionPackType.DestinyRareCardPack;
		}
		if (itemType == EItemType.DestinyEpicCardPack || itemType == EItemType.DestinyEpicCardBox)
		{
			return ECollectionPackType.DestinyEpicCardPack;
		}
		if (itemType == EItemType.DestinyLegendaryCardPack || itemType == EItemType.DestinyLegendaryCardBox)
		{
			return ECollectionPackType.DestinyLegendaryCardPack;
		}
		if (itemType == EItemType.GhostPack)
		{
			return ECollectionPackType.GhostPack;
		}
		if (itemType == EItemType.MegabotPack)
		{
			return ECollectionPackType.MegabotPack;
		}
		if (itemType == EItemType.FantasyRPGPack)
		{
			return ECollectionPackType.FantasyRPGPack;
		}
		if (itemType == EItemType.CatJobPack)
		{
			return ECollectionPackType.CatJobPack;
		}
		return ECollectionPackType.None;
	}

	// Token: 0x060002C0 RID: 704 RVA: 0x00019E80 File Offset: 0x00018080
	public static string GetPriceChangeTypeText(EPriceChangeType priceChangeType, bool isIncrease)
	{
		for (int i = 0; i < CSingleton<InventoryBase>.Instance.m_TextSO.m_PriceChangeTypeTextList.Count; i++)
		{
			if (CSingleton<InventoryBase>.Instance.m_TextSO.m_PriceChangeTypeTextList[i].priceChangeType == priceChangeType)
			{
				return CSingleton<InventoryBase>.Instance.m_TextSO.m_PriceChangeTypeTextList[i].GetName(isIncrease);
			}
		}
		return LocalizationManager.GetTranslation("No effect on card pack price.", true, 0, true, false, null, null, true);
	}

	// Token: 0x060002C1 RID: 705 RVA: 0x00019EF6 File Offset: 0x000180F6
	public static string GetCardExpansionName(ECardExpansionType cardExpansion)
	{
		return LocalizationManager.GetTranslation(CSingleton<InventoryBase>.Instance.m_TextSO.m_CardExpansionNameList[(int)cardExpansion], true, 0, true, false, null, null, true);
	}

	// Token: 0x060002C2 RID: 706 RVA: 0x00019F19 File Offset: 0x00018119
	public static Material GetCurrencyMaterial(EMoneyCurrencyType currencyType)
	{
		return CSingleton<InventoryBase>.Instance.m_TextSO.m_CurrencyMaterialList[(int)currencyType];
	}

	// Token: 0x060002C3 RID: 707 RVA: 0x00019F30 File Offset: 0x00018130
	public static Sprite GetQuestionMarkSprite()
	{
		return CSingleton<InventoryBase>.Instance.m_TextSO.m_QuestionMarkImage;
	}

	// Token: 0x04000327 RID: 807
	public StockItemData_ScriptableObject m_StockItemData_SO;

	// Token: 0x04000328 RID: 808
	public MonsterData_ScriptableObject m_MonsterData_SO;

	// Token: 0x04000329 RID: 809
	public ShelfData_ScriptableObject m_ObjectData_SO;

	// Token: 0x0400032A RID: 810
	public Text_ScriptableObject m_TextSO;

	// Token: 0x0400032B RID: 811
	public static InventoryBase m_Instance;
}
