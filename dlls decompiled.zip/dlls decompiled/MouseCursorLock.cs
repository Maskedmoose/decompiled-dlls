﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001EB RID: 491
	public class MouseCursorLock : MonoBehaviour
	{
		// Token: 0x06000DB3 RID: 3507 RVA: 0x0005DA4B File Offset: 0x0005BC4B
		private void Start()
		{
			if (this.lockCursorAtGameStart)
			{
				Cursor.lockState = CursorLockMode.Locked;
				Cursor.visible = false;
			}
		}

		// Token: 0x06000DB4 RID: 3508 RVA: 0x0005DA61 File Offset: 0x0005BC61
		private void Update()
		{
			if (Input.GetKeyDown(this.unlockKeyCode))
			{
				Cursor.lockState = CursorLockMode.None;
				Cursor.visible = true;
			}
			if (Input.GetKeyDown(this.lockKeyCode))
			{
				Cursor.lockState = CursorLockMode.Locked;
				Cursor.visible = false;
			}
		}

		// Token: 0x040014A9 RID: 5289
		public bool lockCursorAtGameStart = true;

		// Token: 0x040014AA RID: 5290
		public KeyCode unlockKeyCode = KeyCode.Escape;

		// Token: 0x040014AB RID: 5291
		public KeyCode lockKeyCode = KeyCode.Mouse0;
	}
}
