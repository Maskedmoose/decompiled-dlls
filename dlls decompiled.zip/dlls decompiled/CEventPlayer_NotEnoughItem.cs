﻿using System;

// Token: 0x020000B5 RID: 181
public class CEventPlayer_NotEnoughItem : CEvent
{
	// Token: 0x17000019 RID: 25
	// (get) Token: 0x0600070E RID: 1806 RVA: 0x000380B7 File Offset: 0x000362B7
	// (set) Token: 0x0600070F RID: 1807 RVA: 0x000380BF File Offset: 0x000362BF
	public EItemType m_ItemType { get; private set; }

	// Token: 0x06000710 RID: 1808 RVA: 0x000380C8 File Offset: 0x000362C8
	public CEventPlayer_NotEnoughItem(EItemType itemType)
	{
		this.m_ItemType = itemType;
	}
}
