﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace CC
{
	// Token: 0x020001BD RID: 445
	public class DragHandle : MonoBehaviour, IDragHandler, IEventSystemHandler, IPointerDownHandler
	{
		// Token: 0x06000C9C RID: 3228 RVA: 0x00057DFA File Offset: 0x00055FFA
		public void OnDrag(PointerEventData eventData)
		{
			this.rectTransform.anchoredPosition += eventData.delta / this.canvas.scaleFactor;
		}

		// Token: 0x06000C9D RID: 3229 RVA: 0x00057E28 File Offset: 0x00056028
		public void OnPointerDown(PointerEventData eventData)
		{
			this.rectTransform.SetAsLastSibling();
		}

		// Token: 0x06000C9E RID: 3230 RVA: 0x00057E38 File Offset: 0x00056038
		private void Start()
		{
			this.rectTransform = this.WindowToDrag.GetComponent<RectTransform>();
			Canvas[] componentsInParent = base.GetComponentsInParent<Canvas>();
			this.canvas = componentsInParent[componentsInParent.Length - 1];
		}

		// Token: 0x04001371 RID: 4977
		public GameObject WindowToDrag;

		// Token: 0x04001372 RID: 4978
		private RectTransform rectTransform;

		// Token: 0x04001373 RID: 4979
		private Canvas canvas;
	}
}
