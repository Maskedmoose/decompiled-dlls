﻿using System;
using System.Collections.Generic;

namespace CC
{
	// Token: 0x020001AE RID: 430
	[Serializable]
	public class CC_CharacterData
	{
		// Token: 0x04001332 RID: 4914
		public string CharacterName;

		// Token: 0x04001333 RID: 4915
		public string CharacterPrefab;

		// Token: 0x04001334 RID: 4916
		public List<CC_Property> Blendshapes;

		// Token: 0x04001335 RID: 4917
		public List<string> HairNames;

		// Token: 0x04001336 RID: 4918
		public List<string> ApparelNames;

		// Token: 0x04001337 RID: 4919
		public List<int> ApparelMaterials;

		// Token: 0x04001338 RID: 4920
		public List<CC_Property> HairColor;

		// Token: 0x04001339 RID: 4921
		public List<CC_Property> FloatProperties;

		// Token: 0x0400133A RID: 4922
		public List<CC_Property> TextureProperties;

		// Token: 0x0400133B RID: 4923
		public List<CC_Property> ColorProperties;
	}
}
