﻿using System;
using System.Collections.Generic;

// Token: 0x0200010B RID: 267
[Serializable]
public struct ControllerBtnList
{
	// Token: 0x04000F06 RID: 3846
	public List<ControllerButton> rowList;
}
