﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

// Token: 0x0200012B RID: 299
public static class CSaveLoad
{
	// Token: 0x060008C5 RID: 2245 RVA: 0x0004088C File Offset: 0x0003EA8C
	public static void AutoSaveMoveToEmptySaveSlot()
	{
		string text = Application.persistentDataPath + "/savedGames_Release0.gd";
		if (File.Exists(text))
		{
			if (!File.Exists(Application.persistentDataPath + "/savedGames_Release1.gd"))
			{
				string destFileName = Application.persistentDataPath + "/savedGames_Release1.gd";
				File.Copy(text, destFileName);
				return;
			}
			if (!File.Exists(Application.persistentDataPath + "/savedGames_Release2.gd"))
			{
				string destFileName = Application.persistentDataPath + "/savedGames_Release2.gd";
				File.Copy(text, destFileName);
				return;
			}
			if (!File.Exists(Application.persistentDataPath + "/savedGames_Release3.gd"))
			{
				string destFileName = Application.persistentDataPath + "/savedGames_Release3.gd";
				File.Copy(text, destFileName);
			}
		}
	}

	// Token: 0x060008C6 RID: 2246 RVA: 0x00040944 File Offset: 0x0003EB44
	public static void Save()
	{
		CSaveLoad.m_SavedGame = CGameData.instance;
		int saveLoadSlotSelectedIndex = CGameManager.GetSaveLoadSlotSelectedIndex();
		string path = Application.persistentDataPath + "/savedGames_Release" + saveLoadSlotSelectedIndex.ToString() + ".json";
		try
		{
			string contents = JsonUtility.ToJson(CSaveLoad.m_SavedGame);
			File.WriteAllText(path, contents);
		}
		catch
		{
			Debug.Log("Error saving JSON");
		}
		using (FileStream fileStream = File.Create(Application.persistentDataPath + "/savedGames_Release" + saveLoadSlotSelectedIndex.ToString() + ".gd"))
		{
			new BinaryFormatter().Serialize(fileStream, CSaveLoad.m_SavedGame);
			fileStream.Close();
		}
	}

	// Token: 0x060008C7 RID: 2247 RVA: 0x00040A00 File Offset: 0x0003EC00
	public static bool Load()
	{
		int saveLoadSlotSelectedIndex = CGameManager.GetSaveLoadSlotSelectedIndex();
		string path = Application.persistentDataPath + "/savedGames_Release" + saveLoadSlotSelectedIndex.ToString() + ".gd";
		string path2 = Application.persistentDataPath + "/savedGames_Release" + saveLoadSlotSelectedIndex.ToString() + ".json";
		bool flag = false;
		if (File.Exists(path))
		{
			using (FileStream fileStream = File.Open(path, FileMode.Open))
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				if (fileStream.Length > 0L)
				{
					try
					{
						fileStream.Position = 0L;
						CSaveLoad.m_SavedGame = (CGameData)binaryFormatter.Deserialize(fileStream);
						fileStream.Close();
						return true;
					}
					catch
					{
						fileStream.Close();
						flag = true;
						goto IL_B9;
					}
				}
				fileStream.Close();
				flag = true;
				goto IL_B9;
			}
		}
		flag = true;
		IL_B9:
		if (flag)
		{
			if (File.Exists(path2))
			{
				try
				{
					CSaveLoad.m_SavedGame = JsonUtility.FromJson<CGameData>(File.ReadAllText(path2));
					return true;
				}
				catch
				{
					return false;
				}
			}
			return false;
		}
		return false;
	}

	// Token: 0x060008C8 RID: 2248 RVA: 0x00040B1C File Offset: 0x0003ED1C
	public static void SaveBackup()
	{
		CSaveLoad.m_SavedGame = CGameData.instance;
		using (FileStream fileStream = File.Create(Application.persistentDataPath + "/savedGames_ReleaseBackupFile" + (CPlayerData.m_SaveIndex % 9).ToString() + ".gd"))
		{
			new BinaryFormatter().Serialize(fileStream, CSaveLoad.m_SavedGame);
			fileStream.Close();
		}
	}

	// Token: 0x060008C9 RID: 2249 RVA: 0x00040B90 File Offset: 0x0003ED90
	public static bool LoadBackup()
	{
		if (File.Exists(Application.persistentDataPath + "/savedGames_ReleaseBackupFile0.gd"))
		{
			using (FileStream fileStream = File.Open(Application.persistentDataPath + "/savedGames_ReleaseBackupFile0.gd", FileMode.Open))
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				if (fileStream.Length > 0L)
				{
					try
					{
						fileStream.Position = 0L;
						CSaveLoad.m_SavedGame = (CGameData)binaryFormatter.Deserialize(fileStream);
						fileStream.Close();
						return true;
					}
					catch
					{
						fileStream.Close();
						return false;
					}
				}
				fileStream.Close();
				return false;
			}
			return false;
		}
		return false;
	}

	// Token: 0x060008CA RID: 2250 RVA: 0x00040C3C File Offset: 0x0003EE3C
	public static void SaveSetting()
	{
		CSaveLoad.m_SavedSetting = CSettingData.instance;
		using (FileStream fileStream = File.Create(Application.persistentDataPath + "/savedGames_KeybindSetting.gd"))
		{
			new BinaryFormatter().Serialize(fileStream, CSaveLoad.m_SavedSetting);
			fileStream.Close();
		}
	}

	// Token: 0x060008CB RID: 2251 RVA: 0x00040C9C File Offset: 0x0003EE9C
	public static bool LoadSetting()
	{
		if (File.Exists(Application.persistentDataPath + "/savedGames_KeybindSetting.gd"))
		{
			using (FileStream fileStream = File.Open(Application.persistentDataPath + "/savedGames_KeybindSetting.gd", FileMode.Open))
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				if (fileStream.Length > 0L)
				{
					try
					{
						fileStream.Position = 0L;
						CSaveLoad.m_SavedSetting = (CSettingData)binaryFormatter.Deserialize(fileStream);
						fileStream.Close();
						return true;
					}
					catch
					{
						fileStream.Close();
						return false;
					}
				}
				fileStream.Close();
				return false;
			}
			return false;
		}
		return false;
	}

	// Token: 0x060008CC RID: 2252 RVA: 0x00040D4C File Offset: 0x0003EF4C
	public static void Delete()
	{
		if (File.Exists(Application.persistentDataPath + "/savedGames_Release"))
		{
			File.Delete(Application.persistentDataPath + "/savedGames_Release");
		}
	}

	// Token: 0x060008CD RID: 2253 RVA: 0x00040D78 File Offset: 0x0003EF78
	public static void DeleteBackup()
	{
		if (File.Exists(Application.persistentDataPath + "/savedGames_ReleaseBackupFile0.gd"))
		{
			File.Delete(Application.persistentDataPath + "/savedGames_ReleaseBackupFile0.gd");
		}
	}

	// Token: 0x060008CE RID: 2254 RVA: 0x00040DA4 File Offset: 0x0003EFA4
	public static void DeleteCloudFile()
	{
		if (File.Exists(Application.persistentDataPath + "/savedGames_Debug02.gd"))
		{
			File.Delete(Application.persistentDataPath + "/savedGames_Debug02.gd");
		}
	}

	// Token: 0x060008CF RID: 2255 RVA: 0x00040DD0 File Offset: 0x0003EFD0
	public static byte[] GetLocalSaveFileAsByteArray()
	{
		if (!File.Exists(Application.persistentDataPath + "/savedGames_Release"))
		{
			return null;
		}
		return File.ReadAllBytes(Application.persistentDataPath + "/savedGames_Release");
	}

	// Token: 0x060008D0 RID: 2256 RVA: 0x00040E00 File Offset: 0x0003F000
	public static void LoadCloudFile(byte[] data)
	{
		Debug.Log("DSCloudSaveLoadTest LoadingCloudFile");
		try
		{
			using (FileStream fileStream = new FileStream(Application.persistentDataPath + "/savedGames_Debug02.gd", FileMode.Create, FileAccess.Write))
			{
				fileStream.Write(data, 0, data.Length);
				fileStream.Close();
				if (File.Exists(Application.persistentDataPath + "/savedGames_Debug02.gd"))
				{
					using (FileStream fileStream2 = File.Open(Application.persistentDataPath + "/savedGames_Debug02.gd", FileMode.Open))
					{
						BinaryFormatter binaryFormatter = new BinaryFormatter();
						if (fileStream2.Length > 0L)
						{
							try
							{
								fileStream2.Position = 0L;
								CSaveLoad.m_SavedGameBackup = (CGameData)binaryFormatter.Deserialize(fileStream2);
								fileStream2.Close();
								Debug.Log("DSCloudSaveLoadTest LoadCloudFile sucess");
								goto IL_C5;
							}
							catch
							{
								fileStream2.Close();
								Debug.Log("DSCloudSaveLoadTest LoadCloudFile failed to deserialize");
								goto IL_C5;
							}
						}
						fileStream2.Close();
						Debug.Log("DSCloudSaveLoadTest LoadCloudFile failed, file length 0");
						IL_C5:;
					}
				}
			}
		}
		catch
		{
			Debug.Log("DSCloudSaveLoadTest LoadCloudFile failed");
		}
	}

	// Token: 0x060008D1 RID: 2257 RVA: 0x00040F30 File Offset: 0x0003F130
	public static bool HasSaveFile(int saveloadSlotIndex)
	{
		return File.Exists(Application.persistentDataPath + "/savedGames_Release" + saveloadSlotIndex.ToString() + ".gd") || File.Exists(Application.persistentDataPath + "/savedGames_Release" + saveloadSlotIndex.ToString() + ".json");
	}

	// Token: 0x060008D2 RID: 2258 RVA: 0x00040F84 File Offset: 0x0003F184
	public static bool LoadSavedSlotData(int slotIndex)
	{
		string path = Application.persistentDataPath + "/savedGames_Release" + slotIndex.ToString() + ".gd";
		string path2 = Application.persistentDataPath + "/savedGames_Release" + slotIndex.ToString() + ".json";
		bool flag = false;
		if (File.Exists(path))
		{
			using (FileStream fileStream = File.Open(path, FileMode.Open))
			{
				BinaryFormatter binaryFormatter = new BinaryFormatter();
				if (fileStream.Length > 0L)
				{
					try
					{
						fileStream.Position = 0L;
						CSaveLoad.m_SavedGameBackup = (CGameData)binaryFormatter.Deserialize(fileStream);
						fileStream.Close();
						return true;
					}
					catch
					{
						fileStream.Close();
						flag = true;
						goto IL_AA;
					}
				}
				fileStream.Close();
				flag = true;
				goto IL_AA;
			}
		}
		flag = true;
		IL_AA:
		if (flag)
		{
			if (File.Exists(path2))
			{
				try
				{
					CSaveLoad.m_SavedGameBackup = JsonUtility.FromJson<CGameData>(File.ReadAllText(path2));
					return true;
				}
				catch
				{
					return false;
				}
			}
			return false;
		}
		return false;
	}

	// Token: 0x040010A4 RID: 4260
	public static CGameData m_SavedGame = new CGameData();

	// Token: 0x040010A5 RID: 4261
	public static CGameData m_SavedGameBackup = new CGameData();

	// Token: 0x040010A6 RID: 4262
	public static CSettingData m_SavedSetting = new CSettingData();

	// Token: 0x040010A7 RID: 4263
	private const string m_FileName = "/savedGames_Release";

	// Token: 0x040010A8 RID: 4264
	private const string m_FileNameExt = ".gd";

	// Token: 0x040010A9 RID: 4265
	private const string m_JSONFileNameExt = ".json";

	// Token: 0x040010AA RID: 4266
	private const string m_BackupFileName = "/savedGames_ReleaseBackupFile";

	// Token: 0x040010AB RID: 4267
	private const string m_CloudFileName = "/savedGames_Debug02.gd";

	// Token: 0x040010AC RID: 4268
	private const string m_SettingFileName = "/savedGames_KeybindSetting.gd";
}
