﻿using System;
using System.Collections.Generic;

// Token: 0x0200006C RID: 108
public class HireWorkerScreen : GenericSliderScreen
{
	// Token: 0x06000498 RID: 1176 RVA: 0x00027AA4 File Offset: 0x00025CA4
	protected override void Init()
	{
		base.Init();
		for (int i = 0; i < this.m_HireWorkerPanelUIList.Count; i++)
		{
			this.m_HireWorkerPanelUIList[i].SetActive(false);
		}
		for (int j = 0; j < CSingleton<WorkerManager>.Instance.m_WorkerDataList.Count; j++)
		{
			this.m_HireWorkerPanelUIList[j].Init(this, j);
			this.m_HireWorkerPanelUIList[j].SetActive(true);
			this.m_ScrollEndPosParent = this.m_HireWorkerPanelUIList[j].gameObject;
		}
	}

	// Token: 0x06000499 RID: 1177 RVA: 0x00027B35 File Offset: 0x00025D35
	protected override void OnOpenScreen()
	{
		this.Init();
		base.OnOpenScreen();
	}

	// Token: 0x040005C0 RID: 1472
	public List<HireWorkerPanelUI> m_HireWorkerPanelUIList;
}
