﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Rendering;

// Token: 0x0200014C RID: 332
[ExecuteInEditMode]
[AddComponentMenu("Skybox Blender/Skybox Blender")]
public class SkyboxBlender : MonoBehaviour
{
	// Token: 0x17000034 RID: 52
	// (get) Token: 0x06000959 RID: 2393 RVA: 0x00043AA7 File Offset: 0x00041CA7
	public int CurrentIndex
	{
		get
		{
			return this.index;
		}
	}

	// Token: 0x0600095A RID: 2394 RVA: 0x00043AB0 File Offset: 0x00041CB0
	private void Awake()
	{
		this.skyboxBlenderMaterial = (Resources.Load("Material & Shader/Skybox Blend Material", typeof(Material)) as Material);
		if (this.skyboxBlenderMaterial)
		{
			this.defaultBlend = this.skyboxBlenderMaterial.GetFloat("_BlendCubemaps");
			this.defaultRotation = this.skyboxBlenderMaterial.GetFloat("_Rotation");
			this.defaultSkyboxMaterial = this.skyboxBlenderMaterial;
			this.InspectorAndAwakeChanges();
		}
		else
		{
			Debug.LogWarning("Can't find Skybox Blend Material in resources. Please re-import!");
		}
		if (this.updateLighting || this.updateReflections)
		{
			this.SetReflectionProbe();
			this.UpdateLightingAndReflections(true);
		}
	}

	// Token: 0x0600095B RID: 2395 RVA: 0x00043B50 File Offset: 0x00041D50
	private void OnValidate()
	{
		if (this.skyboxBlenderMaterial == null)
		{
			this.skyboxBlenderMaterial = (Resources.Load("Material & Shader/Skybox Blend Material", typeof(Material)) as Material);
		}
		this.InspectorAndAwakeChanges();
	}

	// Token: 0x0600095C RID: 2396 RVA: 0x00043B88 File Offset: 0x00041D88
	private void OnApplicationQuit()
	{
		this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", this.defaultBlend);
		this.skyboxBlenderMaterial.SetFloat("_Rotation", this.defaultRotation);
		if (this.currentTexture != null)
		{
			this.skyboxBlenderMaterial.SetTexture("_Tex", this.currentTexture);
		}
		RenderSettings.skybox = this.defaultSkyboxMaterial;
	}

	// Token: 0x0600095D RID: 2397 RVA: 0x00043BF0 File Offset: 0x00041DF0
	private void Update()
	{
		if (!Application.isPlaying)
		{
			if (RenderSettings.skybox == null)
			{
				return;
			}
			if (RenderSettings.skybox.HasProperty("_Tex"))
			{
				this.skyboxBlenderMaterial.SetTexture("_Tex", RenderSettings.skybox.GetTexture("_Tex"));
				this.skyboxBlenderMaterial.SetColor("_Tint", RenderSettings.skybox.GetColor("_Tint"));
			}
			return;
		}
		else
		{
			if (this.updateReflections && !this.isSetReflectionProbeOnStart && !this.SetReflectionProbeTexture())
			{
				return;
			}
			if (this.linearBlending && !this.stopped)
			{
				this.usedBlend = 1;
				this.blendValue += Time.deltaTime * this.blendSpeed;
				this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", this.blendValue);
				this.UpdateLightingAndReflections(false);
				if (this.skyboxBlenderMaterial.GetFloat("_BlendCubemaps") >= this.totalBlendValue)
				{
					this.blendFinished = true;
					this.linearBlending = false;
					this.blendValue = 0f;
					base.StopAllCoroutines();
					this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", 0f);
					this.SetSkyBoxes(true, this.index, false, 0, true);
					this.UpdateLightingAndReflections(true);
					if (this.comingFromLoop)
					{
						this.index = 0;
					}
					if (this.index + 1 < this.skyboxMaterials.Length)
					{
						if (!this.comingFromLoop)
						{
							this.index++;
						}
						this.comingFromLoop = false;
						this.SetSkyBoxes(true, this.index, false, 0, false);
						if (this.index + 1 < this.skyboxMaterials.Length)
						{
							this.SetSkyBoxes(false, 0, true, this.index + 1, false);
						}
						if (this.index - (this.skyboxMaterials.Length - 1) > 0)
						{
							if (!this.oneTickBlend)
							{
								this.linearBlending = true;
							}
						}
						else if (!this.oneTickBlend)
						{
							base.StartCoroutine(this.WaitBeforeBlending());
						}
					}
					if (this.index >= this.skyboxMaterials.Length - 1)
					{
						if (this.loop)
						{
							if (this.oneTickBlend)
							{
								this.stillRunning = false;
								return;
							}
							this.SetSkyBoxes(true, this.index, true, 0, true);
							this.comingFromLoop = true;
							base.StartCoroutine(this.WaitBeforeBlending());
						}
						else
						{
							this.stillRunning = false;
							if (this.stopRotationOnBlendFinish)
							{
								this.StopRotation();
							}
						}
					}
				}
				else
				{
					this.blendFinished = false;
				}
			}
			if (this.singleBlend && !this.stopped)
			{
				this.blendValue += Time.deltaTime * this.blendSpeed;
				this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", this.blendValue);
				this.UpdateLightingAndReflections(false);
				if (this.skyboxBlenderMaterial.GetFloat("_BlendCubemaps") >= this.totalBlendValue)
				{
					this.blendFinished = true;
					this.singleBlend = false;
					this.blendValue = 0f;
					base.StopAllCoroutines();
					if (this.blendByIndex)
					{
						this.index = this.indexToBlend;
						this.blendByIndex = false;
					}
					else if (this.index + 1 < this.skyboxMaterials.Length)
					{
						this.index++;
					}
					else
					{
						this.index = 0;
					}
					this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", 0f);
					this.SetSkyBoxes(true, this.index, false, 0, true);
					this.UpdateLightingAndReflections(true);
					this.stillRunning = false;
					if (this.stopRotationOnBlendFinish)
					{
						this.StopRotation();
					}
				}
				else
				{
					this.blendFinished = false;
				}
			}
			if (this.currentSkyboxNotFirstMaterialBlending && !this.stopped)
			{
				this.usedBlend = 2;
				this.blendValue += Time.deltaTime * this.blendSpeed;
				this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", this.blendValue);
				this.UpdateLightingAndReflections(false);
				if (this.skyboxBlenderMaterial.GetFloat("_BlendCubemaps") >= this.totalBlendValue)
				{
					this.blendFinished = true;
					this.currentSkyboxNotFirstMaterialBlending = false;
					this.blendValue = 0f;
					base.StopAllCoroutines();
					int secondTexIndex = 1;
					this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", 0f);
					if (this.skyboxMaterials.Length == 1)
					{
						secondTexIndex = 0;
					}
					this.SetSkyBoxes(true, 0, true, secondTexIndex, true);
					this.UpdateLightingAndReflections(true);
					if (this.oneTickBlend)
					{
						this.stillRunning = false;
					}
					else
					{
						base.StartCoroutine(this.WaitBeforeBlending());
					}
					if (this.stopRotationOnBlendFinish && !this.blendingCurrentSkyToListNotSingleBlend)
					{
						this.StopRotation();
					}
					this.blendingCurrentSkyToListNotSingleBlend = false;
				}
				else
				{
					this.blendFinished = false;
				}
			}
			this.rotationSpeedValue += Time.deltaTime * this.rotationSpeed;
			if (this.keepRotating)
			{
				this.skyboxBlenderMaterial.SetFloat("_Rotation", this.rotationSpeedValue);
				return;
			}
			if (this.skyboxBlenderMaterial.GetFloat("_Rotation") < this.rotateToAngle)
			{
				this.skyboxBlenderMaterial.SetFloat("_Rotation", this.rotationSpeedValue);
				return;
			}
			this.rotateSkybox = false;
			this.skyboxBlenderMaterial.SetFloat("_Rotation", this.rotateToAngle);
			return;
		}
	}

	// Token: 0x0600095E RID: 2398 RVA: 0x000440F4 File Offset: 0x000422F4
	private void SetSkyBoxes(bool firstTex = false, int firstTexIndex = 0, bool secondTex = false, int secondTexIndex = 0, bool apply = false)
	{
		if (firstTex)
		{
			this.skyboxBlenderMaterial.SetTexture("_Tex", this.skyboxMaterials[firstTexIndex].GetTexture("_Tex"));
			this.skyboxBlenderMaterial.SetColor("_Tint", this.skyboxMaterials[firstTexIndex].GetColor("_Tint"));
		}
		if (secondTex)
		{
			this.skyboxBlenderMaterial.SetTexture("_Tex2", this.skyboxMaterials[secondTexIndex].GetTexture("_Tex"));
			this.skyboxBlenderMaterial.SetColor("_Tint2", this.skyboxMaterials[secondTexIndex].GetColor("_Tint"));
		}
		if (apply)
		{
			RenderSettings.skybox = this.skyboxBlenderMaterial;
		}
	}

	// Token: 0x0600095F RID: 2399 RVA: 0x000441A0 File Offset: 0x000423A0
	private void PrepareMaterialForBlend(int skyboxIndex)
	{
		this.skyboxBlenderMaterial.SetTexture("_Tex", RenderSettings.skybox.GetTexture("_Tex"));
		this.skyboxBlenderMaterial.SetTexture("_Tex2", this.skyboxMaterials[skyboxIndex].GetTexture("_Tex"));
		this.skyboxBlenderMaterial.SetColor("_Tint", RenderSettings.skybox.GetColor("_Tint"));
		this.skyboxBlenderMaterial.SetColor("_Tint2", this.skyboxMaterials[skyboxIndex].GetColor("_Tint"));
	}

	// Token: 0x06000960 RID: 2400 RVA: 0x0004422F File Offset: 0x0004242F
	private IEnumerator WaitBeforeBlending()
	{
		this.isLinearBlend = true;
		yield return new WaitForSeconds(this.timeToWait);
		this.linearBlending = true;
		yield break;
	}

	// Token: 0x06000961 RID: 2401 RVA: 0x00044240 File Offset: 0x00042440
	private void InspectorAndAwakeChanges()
	{
		if (this.makeFirstMaterialSkybox)
		{
			if (this.skyboxMaterials.Length >= 1)
			{
				if (this.skyboxMaterials[0] != null)
				{
					this.skyboxBlenderMaterial.SetTexture("_Tex", this.skyboxMaterials[0].GetTexture("_Tex"));
					this.skyboxBlenderMaterial.SetColor("_Tint", this.skyboxMaterials[0].GetColor("_Tint"));
					RenderSettings.skybox = this.skyboxBlenderMaterial;
				}
			}
			else
			{
				Debug.LogWarning("You need to set a material first to make it the skybox");
			}
		}
		if (this.skyboxMaterials != null && this.skyboxMaterials.Length > 1 && this.skyboxMaterials[1] != null)
		{
			this.skyboxBlenderMaterial.SetTexture("_Tex2", this.skyboxMaterials[1].GetTexture("_Tex"));
			this.skyboxBlenderMaterial.SetColor("_Tint2", this.skyboxMaterials[1].GetColor("_Tint"));
		}
	}

	// Token: 0x06000962 RID: 2402 RVA: 0x00044334 File Offset: 0x00042534
	private void SetReflectionProbe()
	{
		this.reflectionProbe = base.GetComponent<ReflectionProbe>();
		if (this.reflectionProbe == null)
		{
			this.reflectionProbe = base.gameObject.AddComponent<ReflectionProbe>();
		}
		this.reflectionProbe.cullingMask = 0;
		this.reflectionProbe.refreshMode = ReflectionProbeRefreshMode.ViaScripting;
		this.reflectionProbe.mode = ReflectionProbeMode.Realtime;
		this.reflectionProbe.timeSlicingMode = ReflectionProbeTimeSlicingMode.NoTimeSlicing;
		if (this.updateReflections)
		{
			RenderSettings.defaultReflectionMode = DefaultReflectionMode.Custom;
			this.cubemap = new Cubemap(this.reflectionProbe.resolution, this.reflectionProbe.hdr ? TextureFormat.RGBAHalf : TextureFormat.RGBA32, true);
		}
	}

	// Token: 0x06000963 RID: 2403 RVA: 0x000443D4 File Offset: 0x000425D4
	public void UpdateLightingAndReflections(bool forceUpdate = false)
	{
		if (!this.updateReflections && !this.updateLighting)
		{
			this.LightAndReflectionFrames = 0;
			return;
		}
		if (!forceUpdate && this.LightAndReflectionFrames < this.updateEveryFrames)
		{
			this.LightAndReflectionFrames++;
			return;
		}
		if (this.updateLighting && this.blendValue > 0.02f && this.blendValue < 0.98f)
		{
			DynamicGI.UpdateEnvironment();
		}
		if (!this.updateReflections)
		{
			return;
		}
		this.LightAndReflectionFrames = 0;
		this.reflectionProbe.RenderProbe();
		if (this.reflectionProbe.texture != null)
		{
			Graphics.CopyTexture(this.reflectionProbe.texture, this.cubemap);
			RenderSettings.customReflection = this.cubemap;
			return;
		}
	}

	// Token: 0x06000964 RID: 2404 RVA: 0x00044491 File Offset: 0x00042691
	private bool SetReflectionProbeTexture()
	{
		if (!this.isSetReflectionProbeOnStart)
		{
			this.SetReflectionProbe();
			this.UpdateLightingAndReflections(true);
			if (this.reflectionProbe.texture != null)
			{
				this.isSetReflectionProbeOnStart = true;
			}
		}
		return this.isSetReflectionProbeOnStart;
	}

	// Token: 0x06000965 RID: 2405 RVA: 0x000444C8 File Offset: 0x000426C8
	public void Blend(bool singlePassBlend = false, bool rotate = true)
	{
		if (this.currentSkyboxNotFirstMaterialBlending && !this.stopped)
		{
			return;
		}
		if (this.isLinearBlend && !this.stopped)
		{
			return;
		}
		if (rotate)
		{
			this.rotateSkybox = true;
			this.stopRotation = false;
		}
		if ((this.stopped || this.stillRunning) && !singlePassBlend)
		{
			this.stopped = false;
			if (this.blendFinished && (this.usedBlend == 1 || this.usedBlend == 2) && !this.stillRunning)
			{
				base.StartCoroutine(this.WaitBeforeBlending());
				return;
			}
		}
		this.stopped = false;
		this.blendByIndex = false;
		base.StopAllCoroutines();
		this.currentTexture = RenderSettings.skybox.GetTexture("_Tex");
		if (this.blendValue > 0f)
		{
			this.oneTickBlend = singlePassBlend;
			return;
		}
		if (singlePassBlend)
		{
			if (this.index == 0 && this.currentTexture != this.skyboxMaterials[0].GetTexture("_Tex"))
			{
				this.PrepareMaterialForBlend(0);
				this.currentSkyboxNotFirstMaterialBlending = true;
			}
			else
			{
				int num = this.index;
				if (!this.stopped)
				{
					if (this.index >= this.skyboxMaterials.Length - 1)
					{
						num = 0;
					}
					else
					{
						num++;
					}
				}
				this.PrepareMaterialForBlend(num);
				this.singleBlend = true;
			}
			RenderSettings.skybox = this.skyboxBlenderMaterial;
			this.stillRunning = true;
		}
		else
		{
			if (this.skyboxMaterials.Length == 1)
			{
				if (this.currentTexture != this.skyboxMaterials[0].GetTexture("_Tex"))
				{
					this.PrepareMaterialForBlend(0);
					RenderSettings.skybox = this.skyboxBlenderMaterial;
				}
			}
			else if (this.index == 0 && this.skyboxMaterials[0] != null)
			{
				if (this.currentTexture == this.skyboxMaterials[0].GetTexture("_Tex"))
				{
					this.SetSkyBoxes(true, 0, false, 0, true);
				}
				else
				{
					this.SetSkyBoxes(false, 0, true, 0, true);
					this.currentSkyboxNotFirstMaterialBlending = true;
					this.blendingCurrentSkyToListNotSingleBlend = true;
				}
			}
			if (this.index >= this.skyboxMaterials.Length - 1)
			{
				this.comingFromLoop = true;
			}
			if (rotate)
			{
				this.rotateSkybox = true;
				this.stopRotation = false;
			}
			if (!this.currentSkyboxNotFirstMaterialBlending)
			{
				this.linearBlending = true;
				this.stillRunning = true;
				if (rotate)
				{
					this.rotateSkybox = true;
				}
			}
			this.isLinearBlend = true;
		}
		this.oneTickBlend = singlePassBlend;
	}

	// Token: 0x06000966 RID: 2406 RVA: 0x00044710 File Offset: 0x00042910
	public void Blend(int skyboxIndex, bool rotate = true)
	{
		this.stopped = false;
		if (this.stillRunning)
		{
			return;
		}
		if (this.index == skyboxIndex)
		{
			return;
		}
		if (skyboxIndex > this.skyboxMaterials.Length - 1)
		{
			Debug.Log("The passed index is bigger than the length of the skybox materials list.");
			return;
		}
		if (skyboxIndex < 0)
		{
			skyboxIndex = this.skyboxMaterials.Length - 1;
		}
		if (this.skyboxMaterials[skyboxIndex] == null)
		{
			Debug.Log("There is no material in the list with the passed index.");
			return;
		}
		base.StopAllCoroutines();
		this.currentTexture = RenderSettings.skybox.GetTexture("_Tex");
		this.blendByIndex = true;
		this.indexToBlend = skyboxIndex;
		this.PrepareMaterialForBlend(skyboxIndex);
		this.singleBlend = true;
		RenderSettings.skybox = this.skyboxBlenderMaterial;
		if (rotate)
		{
			this.rotateSkybox = true;
			this.stopRotation = false;
		}
		this.stillRunning = true;
		this.oneTickBlend = true;
	}

	// Token: 0x06000967 RID: 2407 RVA: 0x000447DC File Offset: 0x000429DC
	public void Cancel()
	{
		base.StopAllCoroutines();
		this.linearBlending = false;
		this.singleBlend = false;
		this.currentSkyboxNotFirstMaterialBlending = false;
		this.blendingCurrentSkyToListNotSingleBlend = false;
		this.oneTickBlend = false;
		this.stopped = false;
		this.blendValue = 0f;
		this.stillRunning = false;
		this.isLinearBlend = false;
		this.comingFromLoop = false;
		this.skyboxBlenderMaterial.SetFloat("_BlendCubemaps", 0f);
		this.SetSkyBoxes(true, this.index, false, 0, true);
		this.UpdateLightingAndReflections(true);
	}

	// Token: 0x06000968 RID: 2408 RVA: 0x00044865 File Offset: 0x00042A65
	public void Stop(bool stopRot = true)
	{
		this.stopped = true;
		base.StopAllCoroutines();
		if (stopRot && this.rotateSkybox)
		{
			this.stopRotation = true;
		}
	}

	// Token: 0x06000969 RID: 2409 RVA: 0x00044886 File Offset: 0x00042A86
	public void Resume(bool resumeRot = true)
	{
		this.stopped = false;
		if (resumeRot)
		{
			this.stopRotation = false;
		}
		if ((this.usedBlend == 1 || this.usedBlend == 2) && this.blendFinished)
		{
			base.StartCoroutine(this.WaitBeforeBlending());
		}
	}

	// Token: 0x0600096A RID: 2410 RVA: 0x000448C0 File Offset: 0x00042AC0
	public bool IsBlending()
	{
		return !this.stopped && (this.linearBlending || this.singleBlend || this.currentSkyboxNotFirstMaterialBlending);
	}

	// Token: 0x0600096B RID: 2411 RVA: 0x000448E8 File Offset: 0x00042AE8
	public void Rotate()
	{
		this.skyboxBlenderMaterial.SetTexture("_Tex", RenderSettings.skybox.GetTexture("_Tex"));
		this.skyboxBlenderMaterial.SetColor("_Tint", RenderSettings.skybox.GetColor("_Tint"));
		RenderSettings.skybox = this.skyboxBlenderMaterial;
		this.rotateSkybox = true;
		this.stopRotation = false;
	}

	// Token: 0x0600096C RID: 2412 RVA: 0x0004494C File Offset: 0x00042B4C
	public void StopRotation()
	{
		this.rotateSkybox = false;
		this.stopRotation = false;
	}

	// Token: 0x0400118A RID: 4490
	[Tooltip("The materials you want to blend to linearly.")]
	public Material[] skyboxMaterials;

	// Token: 0x0400118B RID: 4491
	[Tooltip("Checking this will instantly make the first material your current skybox.")]
	public bool makeFirstMaterialSkybox;

	// Token: 0x0400118C RID: 4492
	[Min(0f)]
	[Tooltip("The speed of the blending between the skyboxes.")]
	public float blendSpeed = 0.5f;

	// Token: 0x0400118D RID: 4493
	[Min(0f)]
	[Tooltip("The time to wait before blending the next skybox material.")]
	public float timeToWait;

	// Token: 0x0400118E RID: 4494
	[Tooltip("If enabled, will loop the materials list. When the blender reaches the last skybox in the list, it'll blend back to the first one.")]
	public bool loop = true;

	// Token: 0x0400118F RID: 4495
	[Tooltip("If enabled, the lighting of the world will be updated to that of the skyboxes blending.")]
	public bool updateLighting;

	// Token: 0x04001190 RID: 4496
	[Tooltip("If enabled, the reflections of the world will be updated to that of the skyboxes blending.")]
	public bool updateReflections;

	// Token: 0x04001191 RID: 4497
	[Range(1f, 30f)]
	[Tooltip("Set how many frames need to pass during blend before updating the reflections & lighting each time. Updating these take a toll on performance so the higher this number is, the more performant your game will be (during blend) but the less accurate the lighting & reflections update will be. The less this number is, the slower the game will be but the accuracy increases. By average the best performance/accuracy results is setting it between 5-10.")]
	public int updateEveryFrames = 5;

	// Token: 0x04001192 RID: 4498
	[Tooltip("Keep rotating the skybox infinetly while blending.")]
	public bool keepRotating;

	// Token: 0x04001193 RID: 4499
	[Tooltip("if you would prefer a certain degree to rotate the skybox to during blending - 360 is a full turn.")]
	public float rotateToAngle = 180f;

	// Token: 0x04001194 RID: 4500
	[Min(0f)]
	[Tooltip("The speed of the skybox rotation.")]
	public float rotationSpeed;

	// Token: 0x04001195 RID: 4501
	[Tooltip("If enabled, the rotation will stop when the blend finishes. If disabled, even after blending the skybox will continue rotating. TAKE NOTE: if loop is enabled in blend options. This will not take effect.")]
	public bool stopRotationOnBlendFinish;

	// Token: 0x04001196 RID: 4502
	private Material defaultSkyboxMaterial;

	// Token: 0x04001197 RID: 4503
	private Material skyboxBlenderMaterial;

	// Token: 0x04001198 RID: 4504
	private Texture currentTexture;

	// Token: 0x04001199 RID: 4505
	private float totalBlendValue = 1f;

	// Token: 0x0400119A RID: 4506
	public float blendValue;

	// Token: 0x0400119B RID: 4507
	private float defaultBlend;

	// Token: 0x0400119C RID: 4508
	private float defaultRotation;

	// Token: 0x0400119D RID: 4509
	private float rotationSpeedValue;

	// Token: 0x0400119E RID: 4510
	private int index;

	// Token: 0x0400119F RID: 4511
	private int indexToBlend;

	// Token: 0x040011A0 RID: 4512
	private int usedBlend;

	// Token: 0x040011A1 RID: 4513
	private int LightAndReflectionFrames;

	// Token: 0x040011A2 RID: 4514
	private bool linearBlending;

	// Token: 0x040011A3 RID: 4515
	private bool currentSkyboxNotFirstMaterialBlending;

	// Token: 0x040011A4 RID: 4516
	private bool comingFromLoop;

	// Token: 0x040011A5 RID: 4517
	private bool rotateSkybox;

	// Token: 0x040011A6 RID: 4518
	private bool oneTickBlend;

	// Token: 0x040011A7 RID: 4519
	private bool stillRunning;

	// Token: 0x040011A8 RID: 4520
	private bool singleBlend;

	// Token: 0x040011A9 RID: 4521
	private bool stopped;

	// Token: 0x040011AA RID: 4522
	private bool blendByIndex;

	// Token: 0x040011AB RID: 4523
	private bool stopRotation;

	// Token: 0x040011AC RID: 4524
	private bool blendFinished;

	// Token: 0x040011AD RID: 4525
	private bool blendingCurrentSkyToListNotSingleBlend;

	// Token: 0x040011AE RID: 4526
	private bool isLinearBlend;

	// Token: 0x040011AF RID: 4527
	private bool isSetReflectionProbeOnStart;

	// Token: 0x040011B0 RID: 4528
	private ReflectionProbe reflectionProbe;

	// Token: 0x040011B1 RID: 4529
	private Cubemap cubemap;
}
