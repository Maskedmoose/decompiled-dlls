﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D9 RID: 473
	public class SidescrollerController : AdvancedWalkerController
	{
		// Token: 0x06000D43 RID: 3395 RVA: 0x0005B66C File Offset: 0x0005986C
		protected override Vector3 CalculateMovementDirection()
		{
			if (this.characterInput == null)
			{
				return Vector3.zero;
			}
			Vector3 vector = Vector3.zero;
			if (this.cameraTransform == null)
			{
				vector += this.tr.right * this.characterInput.GetHorizontalMovementInput();
			}
			else
			{
				vector += Vector3.ProjectOnPlane(this.cameraTransform.right, this.tr.up).normalized * this.characterInput.GetHorizontalMovementInput();
			}
			return vector;
		}
	}
}
