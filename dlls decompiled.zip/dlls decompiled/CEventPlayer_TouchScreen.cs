﻿using System;

// Token: 0x020000C6 RID: 198
public class CEventPlayer_TouchScreen : CEvent
{
}
