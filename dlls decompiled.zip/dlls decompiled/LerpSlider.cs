﻿using System;
using UnityEngine;

// Token: 0x02000124 RID: 292
public class LerpSlider : MonoBehaviour
{
	// Token: 0x06000892 RID: 2194 RVA: 0x0003F7EC File Offset: 0x0003D9EC
	private void Start()
	{
		this.m_StartPos = base.transform.localPosition;
	}

	// Token: 0x06000893 RID: 2195 RVA: 0x0003F7FF File Offset: 0x0003D9FF
	private void Update()
	{
		base.transform.localPosition = Vector3.Lerp(base.transform.localPosition, this.m_LerpPos, Time.deltaTime * this.m_LerpSpeed);
	}

	// Token: 0x06000894 RID: 2196 RVA: 0x0003F82E File Offset: 0x0003DA2E
	public void SetLerpPos(float posX)
	{
		this.m_LerpPos = new Vector3(posX, this.m_StartPos.y, 0f);
		this.m_IsLerping = true;
	}

	// Token: 0x06000895 RID: 2197 RVA: 0x0003F853 File Offset: 0x0003DA53
	public void SetLerpPosY(float posY)
	{
		this.m_LerpPos = new Vector3(this.m_StartPos.x, posY, 0f);
		this.m_IsLerping = true;
	}

	// Token: 0x06000896 RID: 2198 RVA: 0x0003F878 File Offset: 0x0003DA78
	public void StopLerp()
	{
		this.m_IsLerping = false;
	}

	// Token: 0x0400105B RID: 4187
	private Vector3 m_StartPos;

	// Token: 0x0400105C RID: 4188
	private bool m_IsLerping;

	// Token: 0x0400105D RID: 4189
	private Vector3 m_LerpPos;

	// Token: 0x0400105E RID: 4190
	private float m_LerpSpeed = 7f;
}
