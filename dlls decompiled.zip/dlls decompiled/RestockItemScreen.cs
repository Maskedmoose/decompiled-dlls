﻿using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000079 RID: 121
public class RestockItemScreen : GenericSliderScreen
{
	// Token: 0x060004D4 RID: 1236 RVA: 0x00029D4B File Offset: 0x00027F4B
	protected override void Awake()
	{
		base.Awake();
		this.m_CartNotification.SetActive(false);
	}

	// Token: 0x060004D5 RID: 1237 RVA: 0x00029D5F File Offset: 0x00027F5F
	protected override void Init()
	{
		this.m_TotalCostText.text = GameInstance.GetPriceString(this.m_TotalCost, false, true, false, "F2");
		this.m_PageIndex = -1;
		this.EvaluateRestockItemPanelUI(0);
		base.Init();
	}

	// Token: 0x060004D6 RID: 1238 RVA: 0x00029D94 File Offset: 0x00027F94
	private void EvaluateRestockItemPanelUI(int pageIndex)
	{
		if (this.m_PageIndex == pageIndex)
		{
			return;
		}
		this.m_PageIndex = pageIndex;
		for (int i = 0; i < this.m_PageButtonHighlightList.Count; i++)
		{
			this.m_PageButtonHighlightList[i].SetActive(false);
		}
		this.m_PageButtonHighlightList[this.m_PageIndex].SetActive(true);
		List<EItemType> list = new List<EItemType>();
		if (pageIndex == 0)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownItemType;
		}
		else if (pageIndex == 1)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownAccessoryItemType;
		}
		else if (pageIndex == 2)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownFigurineItemType;
		}
		else if (pageIndex == 3)
		{
			list = CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_ShownAllItemType;
		}
		for (int j = 0; j < this.m_RestockItemPanelUIList.Count; j++)
		{
			this.m_RestockItemPanelUIList[j].SetActive(false);
		}
		this.m_CurrentRestockDataIndexList.Clear();
		for (int k = 0; k < list.Count; k++)
		{
			for (int l = 0; l < CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList.Count; l++)
			{
				if (list[k] == CSingleton<InventoryBase>.Instance.m_StockItemData_SO.m_RestockDataList[l].itemType)
				{
					this.m_CurrentRestockDataIndexList.Add(l);
				}
			}
		}
		int num = 0;
		while (num < this.m_CurrentRestockDataIndexList.Count && num < this.m_RestockItemPanelUIList.Count)
		{
			this.m_RestockItemPanelUIList[num].Init(this, this.m_CurrentRestockDataIndexList[num]);
			this.m_RestockItemPanelUIList[num].SetActive(true);
			this.m_ScrollEndPosParent = this.m_RestockItemPanelUIList[num].gameObject;
			num++;
		}
	}

	// Token: 0x060004D7 RID: 1239 RVA: 0x00029F58 File Offset: 0x00028158
	protected override void OnOpenScreen()
	{
		this.Init();
		base.OnOpenScreen();
	}

	// Token: 0x060004D8 RID: 1240 RVA: 0x00029F66 File Offset: 0x00028166
	public void OnPressChangePageButton(int index)
	{
		this.EvaluateRestockItemPanelUI(index);
		base.StartCoroutine(base.EvaluateActiveRestockUIScroller());
		this.m_PosX = 0f;
		this.m_LerpPosX = 0f;
	}

	// Token: 0x060004D9 RID: 1241 RVA: 0x00029F94 File Offset: 0x00028194
	public void EvaluateCartCheckout(float totalCost)
	{
		CEventManager.QueueEvent(new CEventPlayer_ReduceCoin(totalCost, false));
		CPlayerData.m_GameReportDataCollect.supplyCost = CPlayerData.m_GameReportDataCollect.supplyCost - totalCost;
		CPlayerData.m_GameReportDataCollectPermanent.supplyCost = CPlayerData.m_GameReportDataCollectPermanent.supplyCost - totalCost;
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		foreach (KeyValuePair<int, int> keyValuePair in this.m_CartItemList)
		{
			list.Add(keyValuePair.Key);
			list2.Add(keyValuePair.Value);
		}
		CSingleton<CGameManager>.Instance.m_CanRunDebugString = true;
		CPlayerData.m_DebugString = "indexList.Count" + list.Count.ToString();
		int num = 0;
		for (int i = 0; i < list.Count; i++)
		{
			RestockManager.SpawnPackageBoxItemMultipleFrame(InventoryBase.GetRestockData(list[i]), list2[i]);
			num += list2[i];
		}
		this.m_CartItemList.Clear();
		this.m_RestockItemCheckoutScreen.UpdateData(this, this.m_CartItemList, false);
		base.StartCoroutine(this.DelaySaveShelfData());
		CEventManager.QueueEvent(new CEventPlayer_AddShopExp(num * 5, false));
		TutorialManager.AddTaskValue(ETutorialTaskCondition.RestockItem, (float)num);
		SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
	}

	// Token: 0x060004DA RID: 1242 RVA: 0x0002A0EC File Offset: 0x000282EC
	private IEnumerator DelaySaveShelfData()
	{
		yield return new WaitForSeconds(1f);
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		yield break;
	}

	// Token: 0x060004DB RID: 1243 RVA: 0x0002A0F4 File Offset: 0x000282F4
	private void SpawnPackageItemBox(EItemType itemType, bool isBigBox, int boxCount)
	{
		for (int i = 0; i < boxCount; i++)
		{
			if (isBigBox)
			{
				RestockManager.SpawnPackageBoxItem(itemType, 64, true);
			}
			else
			{
				RestockManager.SpawnPackageBoxItem(itemType, 32, false);
			}
		}
	}

	// Token: 0x060004DC RID: 1244 RVA: 0x0002A126 File Offset: 0x00028326
	public void OnPressAddToCartButton(int index)
	{
		this.m_RestockItemAddToCartScreen.UpdateData(this, index);
		base.OpenChildScreen(this.m_RestockItemAddToCartScreen);
	}

	// Token: 0x060004DD RID: 1245 RVA: 0x0002A141 File Offset: 0x00028341
	public bool HasEnoughCartSlot()
	{
		return this.m_CartItemList.Count < this.m_RestockItemCheckoutScreen.m_RestockCheckoutItemBarUIList.Count;
	}

	// Token: 0x060004DE RID: 1246 RVA: 0x0002A164 File Offset: 0x00028364
	public void AddToCartForCheckout(int index, int boxCount)
	{
		if (this.m_CartItemList.ContainsKey(index))
		{
			Dictionary<int, int> cartItemList = this.m_CartItemList;
			cartItemList[index] += boxCount;
		}
		else
		{
			this.m_CartItemList.Add(index, boxCount);
		}
		this.m_RestockItemCheckoutScreen.UpdateData(this, this.m_CartItemList, false);
	}

	// Token: 0x060004DF RID: 1247 RVA: 0x0002A1BC File Offset: 0x000283BC
	public void RemoveFromCartForCheckout(int index, int boxCount)
	{
		bool hasItemRemoved = false;
		if (this.m_CartItemList.ContainsKey(index))
		{
			Dictionary<int, int> cartItemList = this.m_CartItemList;
			cartItemList[index] -= boxCount;
			if (this.m_CartItemList[index] <= 0)
			{
				hasItemRemoved = true;
				this.m_CartItemList.Remove(index);
			}
		}
		this.m_RestockItemCheckoutScreen.UpdateData(this, this.m_CartItemList, hasItemRemoved);
	}

	// Token: 0x060004E0 RID: 1248 RVA: 0x0002A223 File Offset: 0x00028423
	public int GetBoxCountInCart(int index)
	{
		if (this.m_CartItemList.ContainsKey(index))
		{
			return this.m_CartItemList[index];
		}
		return 0;
	}

	// Token: 0x060004E1 RID: 1249 RVA: 0x0002A241 File Offset: 0x00028441
	public void OnPressCheckoutButton()
	{
		this.m_RestockItemCheckoutScreen.UpdateData(this, this.m_CartItemList, false);
		base.OpenChildScreen(this.m_RestockItemCheckoutScreen);
	}

	// Token: 0x060004E2 RID: 1250 RVA: 0x0002A264 File Offset: 0x00028464
	public void UpdateCartTotalCost(float cost, int count)
	{
		this.m_TotalCost = cost;
		this.m_TotalCostText.text = GameInstance.GetPriceString(this.m_TotalCost, false, true, false, "F2");
		this.m_TotalCartItemCountText.text = count.ToString();
		if (count > 0)
		{
			this.m_CartNotification.SetActive(true);
			return;
		}
		this.m_CartNotification.SetActive(false);
	}

	// Token: 0x060004E3 RID: 1251 RVA: 0x0002A2C8 File Offset: 0x000284C8
	public RestockItemPanelUI GetRestockItemPanelUI(int index)
	{
		for (int i = 0; i < this.m_RestockItemPanelUIList.Count; i++)
		{
			if (this.m_RestockItemPanelUIList[i].GetIndex() == (float)index)
			{
				return this.m_RestockItemPanelUIList[i];
			}
		}
		return this.m_RestockItemPanelUIList[0];
	}

	// Token: 0x0400065F RID: 1631
	public List<RestockItemPanelUI> m_RestockItemPanelUIList;

	// Token: 0x04000660 RID: 1632
	public List<GameObject> m_PageButtonHighlightList;

	// Token: 0x04000661 RID: 1633
	public RestockItemAddToCartScreen m_RestockItemAddToCartScreen;

	// Token: 0x04000662 RID: 1634
	public RestockItemCheckoutScreen m_RestockItemCheckoutScreen;

	// Token: 0x04000663 RID: 1635
	public TextMeshProUGUI m_TotalCostText;

	// Token: 0x04000664 RID: 1636
	public TextMeshProUGUI m_TotalCartItemCountText;

	// Token: 0x04000665 RID: 1637
	public GameObject m_CartNotification;

	// Token: 0x04000666 RID: 1638
	private int m_PageIndex = -1;

	// Token: 0x04000667 RID: 1639
	private float m_TotalCost;

	// Token: 0x04000668 RID: 1640
	private Dictionary<int, int> m_CartItemList = new Dictionary<int, int>();

	// Token: 0x04000669 RID: 1641
	private List<int> m_CurrentRestockDataIndexList = new List<int>();
}
