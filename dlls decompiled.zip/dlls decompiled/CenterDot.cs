﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200005A RID: 90
public class CenterDot : CSingleton<CenterDot>
{
	// Token: 0x06000402 RID: 1026 RVA: 0x000237AC File Offset: 0x000219AC
	private void Start()
	{
		this.EvaluateDot();
	}

	// Token: 0x06000403 RID: 1027 RVA: 0x000237B4 File Offset: 0x000219B4
	public static void SetVisibility(bool isVisible)
	{
		CSingleton<CenterDot>.Instance.m_DotImage.enabled = isVisible;
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x000237C8 File Offset: 0x000219C8
	private void EvaluateDot()
	{
		if (CSingleton<CGameManager>.Instance.m_CenterDotHasOutline)
		{
			this.m_DotImage.sprite = this.m_OutlineSpriteList[CSingleton<CGameManager>.Instance.m_CenterDotSpriteTypeIndex];
		}
		else
		{
			this.m_DotImage.sprite = this.m_SpriteList[CSingleton<CGameManager>.Instance.m_CenterDotSpriteTypeIndex];
		}
		this.m_DotImage.color = this.m_ColorList[CSingleton<CGameManager>.Instance.m_CenterDotColorIndex];
		this.m_DotImage.transform.localScale = Vector3.one * Mathf.Clamp(CSingleton<CGameManager>.Instance.m_CenterDotSizeSlider, 0.05f, 1f);
	}

	// Token: 0x06000405 RID: 1029 RVA: 0x00023876 File Offset: 0x00021A76
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x06000406 RID: 1030 RVA: 0x000238A8 File Offset: 0x00021AA8
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x06000407 RID: 1031 RVA: 0x000238DA File Offset: 0x00021ADA
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.EvaluateDot();
	}

	// Token: 0x06000408 RID: 1032 RVA: 0x000238E2 File Offset: 0x00021AE2
	protected void OnSettingUpdated(CEventPlayer_OnSettingUpdated evt)
	{
		this.EvaluateDot();
	}

	// Token: 0x040004D1 RID: 1233
	public Image m_DotImage;

	// Token: 0x040004D2 RID: 1234
	public List<Color> m_ColorList;

	// Token: 0x040004D3 RID: 1235
	public List<Sprite> m_SpriteList;

	// Token: 0x040004D4 RID: 1236
	public List<Sprite> m_OutlineSpriteList;
}
