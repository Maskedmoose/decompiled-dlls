﻿using System;
using UnityEngine;

// Token: 0x02000104 RID: 260
public class FPSDisplay : MonoBehaviour
{
	// Token: 0x060007A3 RID: 1955 RVA: 0x00039537 File Offset: 0x00037737
	private void Update()
	{
		this.deltaTime += (Time.deltaTime - this.deltaTime) * 0.1f;
	}

	// Token: 0x060007A4 RID: 1956 RVA: 0x00039558 File Offset: 0x00037758
	private void OnGUI()
	{
		int width = Screen.width;
		int height = Screen.height;
		GUIStyle guistyle = new GUIStyle();
		Rect position = new Rect(250f, 550f, (float)width, (float)(height * 2 / 100));
		guistyle.alignment = TextAnchor.UpperLeft;
		guistyle.fontSize = height * 4 / 100;
		guistyle.normal.textColor = new Color(0f, 1f, 0f, 1f);
		float num = this.deltaTime * 1000f;
		float num2 = 1f / this.deltaTime;
		string text = string.Format("{0:0.0} ms ({1:0.} fps)", num, num2);
		GUI.Label(position, text, guistyle);
	}

	// Token: 0x04000ED9 RID: 3801
	private float deltaTime;
}
