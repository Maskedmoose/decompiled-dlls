﻿using System;

// Token: 0x020000B6 RID: 182
public class CEventPlayer_ItemPriceChanged : CEvent
{
	// Token: 0x1700001A RID: 26
	// (get) Token: 0x06000711 RID: 1809 RVA: 0x000380D7 File Offset: 0x000362D7
	// (set) Token: 0x06000712 RID: 1810 RVA: 0x000380DF File Offset: 0x000362DF
	public EItemType m_ItemType { get; private set; }

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x06000713 RID: 1811 RVA: 0x000380E8 File Offset: 0x000362E8
	// (set) Token: 0x06000714 RID: 1812 RVA: 0x000380F0 File Offset: 0x000362F0
	public float m_Price { get; private set; }

	// Token: 0x06000715 RID: 1813 RVA: 0x000380F9 File Offset: 0x000362F9
	public CEventPlayer_ItemPriceChanged(EItemType itemType, float price)
	{
		this.m_ItemType = itemType;
		this.m_Price = price;
	}
}
