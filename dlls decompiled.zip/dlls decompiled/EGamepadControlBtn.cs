﻿using System;

// Token: 0x02000115 RID: 277
public enum EGamepadControlBtn
{
	// Token: 0x04000F5E RID: 3934
	None = -1,
	// Token: 0x04000F5F RID: 3935
	X,
	// Token: 0x04000F60 RID: 3936
	O,
	// Token: 0x04000F61 RID: 3937
	Square,
	// Token: 0x04000F62 RID: 3938
	Triangle,
	// Token: 0x04000F63 RID: 3939
	L1,
	// Token: 0x04000F64 RID: 3940
	R1,
	// Token: 0x04000F65 RID: 3941
	L2,
	// Token: 0x04000F66 RID: 3942
	R2,
	// Token: 0x04000F67 RID: 3943
	L3,
	// Token: 0x04000F68 RID: 3944
	R3,
	// Token: 0x04000F69 RID: 3945
	DpadLeft,
	// Token: 0x04000F6A RID: 3946
	DpadRight,
	// Token: 0x04000F6B RID: 3947
	DpadUp,
	// Token: 0x04000F6C RID: 3948
	DpadDown,
	// Token: 0x04000F6D RID: 3949
	LStickLeft,
	// Token: 0x04000F6E RID: 3950
	LStickRight,
	// Token: 0x04000F6F RID: 3951
	LStickUp,
	// Token: 0x04000F70 RID: 3952
	LStickDown,
	// Token: 0x04000F71 RID: 3953
	RStickLeft,
	// Token: 0x04000F72 RID: 3954
	RStickRight,
	// Token: 0x04000F73 RID: 3955
	RStickUp,
	// Token: 0x04000F74 RID: 3956
	RStickDown,
	// Token: 0x04000F75 RID: 3957
	Start,
	// Token: 0x04000F76 RID: 3958
	Select,
	// Token: 0x04000F77 RID: 3959
	Home
}
