﻿using System;

// Token: 0x020000E4 RID: 228
public enum EUpgradeType
{
	// Token: 0x04000AC3 RID: 2755
	None = -1,
	// Token: 0x04000AC4 RID: 2756
	BasicCardPackSupply,
	// Token: 0x04000AC5 RID: 2757
	BasicCardBoxSupply,
	// Token: 0x04000AC6 RID: 2758
	RareCardPackSupply,
	// Token: 0x04000AC7 RID: 2759
	RareCardBoxSupply,
	// Token: 0x04000AC8 RID: 2760
	EpicCardPackSupply,
	// Token: 0x04000AC9 RID: 2761
	EpicCardBoxSupply,
	// Token: 0x04000ACA RID: 2762
	LegendaryCardPackSupply,
	// Token: 0x04000ACB RID: 2763
	LegendaryCardBoxSupply,
	// Token: 0x04000ACC RID: 2764
	BasicCardPackCollectionUsingGoldMax,
	// Token: 0x04000ACD RID: 2765
	BasicCardPackCollectionUsingGemMax,
	// Token: 0x04000ACE RID: 2766
	RareCardPackCollectionUsingGoldMax,
	// Token: 0x04000ACF RID: 2767
	RareCardPackCollectionUsingGemMax,
	// Token: 0x04000AD0 RID: 2768
	EpicCardPackCollectionUsingGoldMax,
	// Token: 0x04000AD1 RID: 2769
	EpicCardPackCollectionUsingGemMax,
	// Token: 0x04000AD2 RID: 2770
	LegendaryCardPackCollectionUsingGoldMax,
	// Token: 0x04000AD3 RID: 2771
	LegendaryCardPackCollectionUsingGemMax,
	// Token: 0x04000AD4 RID: 2772
	CommonPackEarningUp,
	// Token: 0x04000AD5 RID: 2773
	RarePackEarningUp,
	// Token: 0x04000AD6 RID: 2774
	EpicPackEarningUp,
	// Token: 0x04000AD7 RID: 2775
	LegendPackEarningUp,
	// Token: 0x04000AD8 RID: 2776
	CommonBoxEarningUp,
	// Token: 0x04000AD9 RID: 2777
	RareBoxEarningUp,
	// Token: 0x04000ADA RID: 2778
	EpicBoxEarningUp,
	// Token: 0x04000ADB RID: 2779
	LegendBoxEarningUp,
	// Token: 0x04000ADC RID: 2780
	TapPowerLevel,
	// Token: 0x04000ADD RID: 2781
	CustomerSpendingPower,
	// Token: 0x04000ADE RID: 2782
	CustomerBuyMoreItem,
	// Token: 0x04000ADF RID: 2783
	CustomerSpawnTime,
	// Token: 0x04000AE0 RID: 2784
	CustomerCollectorSpawnRate,
	// Token: 0x04000AE1 RID: 2785
	CustomerSuperCollectorSpawnRate,
	// Token: 0x04000AE2 RID: 2786
	CustomerUltimateCollectorSpawnRate,
	// Token: 0x04000AE3 RID: 2787
	CustomerLegendCollectorSpawnRate,
	// Token: 0x04000AE4 RID: 2788
	DestinyExtraGold,
	// Token: 0x04000AE5 RID: 2789
	DestinyExtraGem,
	// Token: 0x04000AE6 RID: 2790
	DestinyExtraFame,
	// Token: 0x04000AE7 RID: 2791
	DestinyCheaperShelfUpgrade,
	// Token: 0x04000AE8 RID: 2792
	DestinyDoubleCustomerChance,
	// Token: 0x04000AE9 RID: 2793
	DestinyReduceRestockTime,
	// Token: 0x04000AEA RID: 2794
	DestinyCustomerSpending,
	// Token: 0x04000AEB RID: 2795
	DestinyFoilChance,
	// Token: 0x04000AEC RID: 2796
	DestinyCustomerCountMax,
	// Token: 0x04000AED RID: 2797
	MAX
}
