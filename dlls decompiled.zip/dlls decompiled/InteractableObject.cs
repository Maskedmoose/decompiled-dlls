﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000021 RID: 33
public class InteractableObject : MonoBehaviour
{
	// Token: 0x06000185 RID: 389 RVA: 0x00012224 File Offset: 0x00010424
	protected virtual void Awake()
	{
	}

	// Token: 0x06000186 RID: 390 RVA: 0x00012226 File Offset: 0x00010426
	protected virtual void Start()
	{
		this.Init();
	}

	// Token: 0x06000187 RID: 391 RVA: 0x00012230 File Offset: 0x00010430
	public virtual void Init()
	{
		if (this.m_HasInit)
		{
			return;
		}
		this.m_HasInit = true;
		if (this.m_Mesh)
		{
			this.m_Material = this.m_Mesh.material;
			this.m_Material.SetFloat("_Outline", 0f);
		}
		else if (this.m_SkinMesh)
		{
			this.m_Material = this.m_SkinMesh.material;
			this.m_Material.SetFloat("_Outline", 0f);
		}
		else if (this.m_HighlightGameObj)
		{
			this.m_HighlightGameObj.SetActive(false);
		}
		this.m_OriginalLayer = base.gameObject.layer;
		this.m_TargetMoveObjectPosition = base.transform.position;
		if (this.m_IsGenericObject && this.m_ObjectType != EObjectType.None)
		{
			ShelfManager.InitInteractableObject(this);
		}
	}

	// Token: 0x06000188 RID: 392 RVA: 0x0001230C File Offset: 0x0001050C
	private void EvaluateSnapping()
	{
		if (this.m_IsSnappingPos)
		{
			if ((this.m_TargetMoveObjectPosition - this.m_TargetSnapPos).magnitude > 0.5f)
			{
				this.m_IsSnappingPos = false;
				if (this.m_TargetMoveObjectPosition.y < 0f)
				{
					this.m_TargetMoveObjectPosition.y = 0f;
				}
				base.transform.position = this.m_TargetMoveObjectPosition;
			}
			else
			{
				base.transform.position = this.m_TargetSnapPos;
			}
		}
		if (!this.m_IsSnappingPos && this.m_MoveStateValidArea && this.m_ShelfMoveStateValidArea && this.m_ShelfMoveStateValidArea.m_CanSnap)
		{
			int mask = LayerMask.GetMask(new string[]
			{
				"MoveStateBlockedArea"
			});
			Collider[] array = Physics.OverlapBox(this.m_MoveStateValidArea.position, this.m_MoveStateValidArea.lossyScale / 2f * 1.01f, this.m_MoveStateValidArea.rotation, mask);
			if (array.Length != 0)
			{
				ShelfMoveStateValidArea shelfMoveStateValidArea = null;
				for (int i = 0; i < array.Length; i++)
				{
					if (array[i].name == "MoveStateValidArea" && array[i].transform.parent != this.m_MoveStateValidArea && (array[i].transform.position - this.m_TargetMoveObjectPosition).magnitude <= 5f)
					{
						shelfMoveStateValidArea = array[i].transform.parent.GetComponent<ShelfMoveStateValidArea>();
						if (shelfMoveStateValidArea && shelfMoveStateValidArea.m_CanSnap)
						{
							break;
						}
						shelfMoveStateValidArea = null;
					}
				}
				if (shelfMoveStateValidArea)
				{
					Transform transform = null;
					float num = 0.3f;
					for (int j = 0; j < this.m_ShelfMoveStateValidArea.m_SnapLocList.Count; j++)
					{
						for (int k = 0; k < shelfMoveStateValidArea.m_SnapLocList.Count; k++)
						{
							float magnitude = (shelfMoveStateValidArea.m_SnapLocList[k].position - this.m_ShelfMoveStateValidArea.m_SnapLocList[j].position).magnitude;
							if (magnitude <= num)
							{
								num = magnitude;
								transform = shelfMoveStateValidArea.m_SnapLocList[k];
							}
						}
					}
					if (!transform)
					{
						return;
					}
					Transform transform2 = null;
					num = 0.3f;
					for (int l = 0; l < this.m_ShelfMoveStateValidArea.m_SnapLocList.Count; l++)
					{
						float magnitude2 = (transform.position - this.m_ShelfMoveStateValidArea.m_SnapLocList[l].position).magnitude;
						if (magnitude2 <= num)
						{
							num = magnitude2;
							transform2 = this.m_ShelfMoveStateValidArea.m_SnapLocList[l];
						}
					}
					Vector3 position = this.m_MoveStateValidArea.position;
					position.y = 0f;
					Vector3 normalized = (position - transform2.position).normalized;
					float magnitude3 = (this.m_ShelfMoveStateValidArea.transform.position - transform2.position).magnitude;
					Vector3 vector = transform.position + normalized * 0.005f + normalized * magnitude3;
					vector.y = 0f;
					base.transform.position = vector;
					this.m_IsSnappingPos = true;
					this.m_TargetSnapPos = vector;
				}
			}
		}
	}

	// Token: 0x06000189 RID: 393 RVA: 0x00012680 File Offset: 0x00010880
	protected virtual void Update()
	{
		if (this.m_IsLerpingToPos)
		{
			this.m_LerpPosTimer += Time.deltaTime * this.m_LerpPosSpeed;
			base.transform.position = Vector3.Lerp(this.m_StartLerpPos, this.m_TargetLerpTransform.position, this.m_LerpPosTimer);
			base.transform.rotation = Quaternion.Lerp(this.m_StartLerpRot, this.m_TargetLerpTransform.rotation, this.m_LerpPosTimer);
			base.transform.localScale = Vector3.Lerp(this.m_StartLerpScale, this.m_TargetLerpTransform.localScale, this.m_LerpPosTimer);
			if (this.m_LerpPosTimer >= 1f)
			{
				this.m_LerpPosTimer = 0f;
				this.m_IsLerpingToPos = false;
				this.OnFinishLerp();
				if (this.m_IsHideAfterFinishLerp)
				{
					this.m_IsHideAfterFinishLerp = false;
					base.gameObject.SetActive(false);
					return;
				}
			}
		}
		else if (this.m_IsMovingObject)
		{
			if (!this.m_IsSnappingPos)
			{
				base.transform.position = Vector3.Lerp(base.transform.position, this.m_TargetMoveObjectPosition, Time.deltaTime * 7.5f);
			}
			this.EvaluateSnapping();
			int mask = LayerMask.GetMask(new string[]
			{
				"MoveStateBlockedArea",
				"Customer"
			});
			Collider[] array = Physics.OverlapBox(this.m_MoveStateValidArea.position, this.m_MoveStateValidArea.lossyScale / 2f, this.m_MoveStateValidArea.rotation, mask);
			bool flag = true;
			if (this.m_PlaceObjectInShopOnly)
			{
				int mask2 = LayerMask.GetMask(new string[]
				{
					"MoveStateValidArea"
				});
				if (Physics.OverlapBox(this.m_MoveStateValidArea.position, this.m_MoveStateValidArea.lossyScale / 2f, this.m_MoveStateValidArea.rotation, mask2).Length == 0)
				{
					flag = false;
				}
			}
			else if (this.m_PlaceObjectInWarehouseOnly)
			{
				int mask3 = LayerMask.GetMask(new string[]
				{
					"MoveStateValidWarehouseArea"
				});
				if (Physics.OverlapBox(this.m_MoveStateValidArea.position, this.m_MoveStateValidArea.lossyScale / 2f, this.m_MoveStateValidArea.rotation, mask3).Length == 0)
				{
					flag = false;
				}
			}
			if (array.Length != 0 || base.transform.position.y > 0.1f)
			{
				flag = false;
			}
			if (this.m_IsMovingObjectValidState != flag)
			{
				this.m_IsMovingObjectValidState = flag;
				ShelfManager.SetMoveObjectPreviewModelValidState(this.m_IsMovingObjectValidState);
			}
		}
	}

	// Token: 0x0600018A RID: 394 RVA: 0x000128E2 File Offset: 0x00010AE2
	protected virtual void LateUpdate()
	{
	}

	// Token: 0x0600018B RID: 395 RVA: 0x000128E4 File Offset: 0x00010AE4
	public virtual void StartMoveObject()
	{
		if (!this.m_CanPickupMoveObject)
		{
			return;
		}
		CSingleton<InteractionPlayerController>.Instance.OnEnterMoveObjectMode();
		this.OnRaycastEnded();
		this.m_IsMovingObject = true;
		this.m_IsMovingObjectValidState = false;
		this.m_OriginalLayer = base.gameObject.layer;
		base.gameObject.layer = LayerMask.NameToLayer("Ignore Raycast");
		this.m_BoxCollider.enabled = false;
		for (int i = 0; i < this.m_BoxColliderList.Count; i++)
		{
			this.m_BoxColliderList[i].enabled = false;
		}
		this.m_MoveStateValidArea.gameObject.SetActive(false);
		ShelfManager.ActivateMoveObjectPreviewMode(base.transform, this.m_PickupObjectMesh, this.m_MoveStateValidArea);
		ShelfManager.SetMoveObjectPreviewModelValidState(false);
		if (this.m_BoxCollider)
		{
			CSingleton<ShelfManager>.Instance.m_MoveObjectCustomerBlocker.transform.position = base.transform.position;
			CSingleton<ShelfManager>.Instance.m_MoveObjectCustomerBlocker.transform.rotation = base.transform.rotation;
			CSingleton<ShelfManager>.Instance.m_MoveObjectCustomerBlocker.transform.localScale = this.m_MoveStateValidArea.transform.lossyScale + Vector3.one * 0.1f;
			CSingleton<ShelfManager>.Instance.m_MoveObjectCustomerBlocker.gameObject.SetActive(true);
		}
		this.OnStartMoveObject();
		SoundManager.PlayAudio("SFX_WhipSoft", 0.6f, 1f);
	}

	// Token: 0x0600018C RID: 396 RVA: 0x00012A55 File Offset: 0x00010C55
	protected virtual void OnStartMoveObject()
	{
	}

	// Token: 0x0600018D RID: 397 RVA: 0x00012A57 File Offset: 0x00010C57
	public void PlaceMovedObject()
	{
		if (!this.m_IsMovingObjectValidState)
		{
			return;
		}
		this.m_IsBoxedUp = false;
		this.OnPlacedMovedObject();
		this.PlayPlaceMoveObjectSFX();
	}

	// Token: 0x0600018E RID: 398 RVA: 0x00012A75 File Offset: 0x00010C75
	protected virtual void PlayPlaceMoveObjectSFX()
	{
		SoundManager.PlayAudio("SFX_PlaceShelf", 0.5f, 1f);
	}

	// Token: 0x0600018F RID: 399 RVA: 0x00012A8C File Offset: 0x00010C8C
	protected virtual void OnPlacedMovedObject()
	{
		this.m_IsSnappingPos = false;
		CSingleton<InteractionPlayerController>.Instance.OnExitMoveObjectMode();
		this.m_IsMovingObject = false;
		base.gameObject.layer = this.m_OriginalLayer;
		this.m_BoxCollider.enabled = true;
		for (int i = 0; i < this.m_BoxColliderList.Count; i++)
		{
			this.m_BoxColliderList[i].enabled = true;
		}
		Vector3 position = base.transform.position;
		position.y = 0f;
		base.transform.position = position;
		this.m_MoveStateValidArea.gameObject.SetActive(true);
		ShelfManager.DisableMoveObjectPreviewMode();
		if (this.m_BoxCollider)
		{
			CSingleton<ShelfManager>.Instance.m_MoveObjectCustomerBlocker.gameObject.SetActive(false);
		}
		if (!this.m_IsBoxedUp && this.m_InteractablePackagingBox_Shelf)
		{
			if (this.m_Shelf_WorldUIGrp)
			{
				this.m_Shelf_WorldUIGrp.transform.position = base.transform.position;
			}
			this.m_InteractablePackagingBox_Shelf.EmptyBoxShelf();
			this.m_InteractablePackagingBox_Shelf.OnDestroyed();
		}
		if (this.m_Shelf_WorldUIGrp && !this.m_IsBoxedUp)
		{
			this.m_Shelf_WorldUIGrp.transform.position = base.transform.position;
			this.m_Shelf_WorldUIGrp.transform.rotation = base.transform.rotation;
		}
		if (this.m_NavMeshCut)
		{
			this.m_NavMeshCut.SetActive(false);
			this.m_NavMeshCut.SetActive(true);
		}
	}

	// Token: 0x06000190 RID: 400 RVA: 0x00012C18 File Offset: 0x00010E18
	public virtual void BoxUpObject(bool holdBox)
	{
		this.OnPlacedMovedObject();
		this.m_IsBoxedUp = true;
		if (!this.m_InteractablePackagingBox_Shelf)
		{
			this.m_InteractablePackagingBox_Shelf = RestockManager.SpawnPackageBoxShelf(this, holdBox);
		}
		else
		{
			this.m_InteractablePackagingBox_Shelf.ExecuteBoxUpObject(this, holdBox);
		}
		if (this.m_Shelf_WorldUIGrp)
		{
			this.m_Shelf_WorldUIGrp.transform.position = Vector3.one * -10f;
		}
		if (holdBox)
		{
			SoundManager.PlayAudio("SFX_BoxClose", 0.5f, 1f);
		}
	}

	// Token: 0x06000191 RID: 401 RVA: 0x00012C9E File Offset: 0x00010E9E
	public void SetTargetMovePosition(Vector3 pos)
	{
		this.m_TargetMoveObjectPosition = pos;
		if (this.m_TargetMoveObjectPosition.y < 0f)
		{
			this.m_TargetMoveObjectPosition.y = 0f;
		}
	}

	// Token: 0x06000192 RID: 402 RVA: 0x00012CCC File Offset: 0x00010ECC
	public void SetMovePositionToCamera(float forwardDistnace = 3f)
	{
		this.m_TargetMoveObjectPosition = CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.position + CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.forward * forwardDistnace;
		this.m_TargetMoveObjectPosition += CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.up * -0.1f;
		if (this.m_TargetMoveObjectPosition.y < 0f)
		{
			this.m_TargetMoveObjectPosition.y = 0f;
		}
	}

	// Token: 0x06000193 RID: 403 RVA: 0x00012D64 File Offset: 0x00010F64
	public void AddObjectRotation(float rotY, float snapAmount = 0f)
	{
		base.transform.Rotate(0f, rotY, 0f);
		if (snapAmount > 0f)
		{
			Quaternion rotation = base.transform.rotation;
			Vector3 eulerAngles = rotation.eulerAngles;
			float y = (float)Mathf.RoundToInt(rotation.eulerAngles.y / snapAmount) * snapAmount;
			eulerAngles.y = y;
			rotation.eulerAngles = eulerAngles;
			base.transform.rotation = rotation;
		}
	}

	// Token: 0x06000194 RID: 404 RVA: 0x00012DD8 File Offset: 0x00010FD8
	public virtual void OnRaycasted()
	{
		if (!this.m_IsRaycasted)
		{
			if (this.m_Material)
			{
				this.m_Material.SetFloat("_Outline", this.m_HighlightOutlineWidth);
			}
			if (this.m_HighlightGameObj)
			{
				this.m_HighlightGameObj.SetActive(true);
			}
			this.m_IsRaycasted = true;
			this.ShowToolTip();
		}
	}

	// Token: 0x06000195 RID: 405 RVA: 0x00012E38 File Offset: 0x00011038
	protected virtual void ShowToolTip()
	{
		for (int i = 0; i < this.m_GameActionInputDisplayList.Count; i++)
		{
			InteractionPlayerController.AddToolTip(this.m_GameActionInputDisplayList[i], false, false);
		}
	}

	// Token: 0x06000196 RID: 406 RVA: 0x00012E70 File Offset: 0x00011070
	public virtual void OnRaycastEnded()
	{
		if (this.m_IsRaycasted)
		{
			if (this.m_Material)
			{
				this.m_Material.SetFloat("_Outline", 0f);
			}
			if (this.m_HighlightGameObj)
			{
				this.m_HighlightGameObj.SetActive(false);
			}
			this.m_IsRaycasted = false;
		}
		for (int i = 0; i < this.m_GameActionInputDisplayList.Count; i++)
		{
			InteractionPlayerController.RemoveToolTip(this.m_GameActionInputDisplayList[i]);
		}
	}

	// Token: 0x06000197 RID: 407 RVA: 0x00012EF0 File Offset: 0x000110F0
	public virtual void OnDestroyed()
	{
		for (int i = 0; i < this.m_ItemCompartmentList.Count; i++)
		{
			if (this.m_ItemCompartmentList[i])
			{
				this.m_ItemCompartmentList[i].DisableAllItem();
			}
		}
		if (this.m_IsGenericObject && this.m_ObjectType != EObjectType.None)
		{
			ShelfManager.RemoveInteractableObject(this);
		}
		if (this.m_Shelf_WorldUIGrp)
		{
			Object.Destroy(this.m_Shelf_WorldUIGrp.gameObject);
		}
		Object.Destroy(base.gameObject);
	}

	// Token: 0x06000198 RID: 408 RVA: 0x00012F76 File Offset: 0x00011176
	public virtual void OnMouseButtonUp()
	{
	}

	// Token: 0x06000199 RID: 409 RVA: 0x00012F78 File Offset: 0x00011178
	public virtual void OnRightMouseButtonUp()
	{
	}

	// Token: 0x0600019A RID: 410 RVA: 0x00012F7A File Offset: 0x0001117A
	public virtual void OnPressEsc()
	{
	}

	// Token: 0x0600019B RID: 411 RVA: 0x00012F7C File Offset: 0x0001117C
	public virtual void OnPressSpaceBar()
	{
	}

	// Token: 0x0600019C RID: 412 RVA: 0x00012F80 File Offset: 0x00011180
	public void LerpToTransform(Transform targetTransform, Transform targetParent)
	{
		this.m_LerpPosTimer = 0f;
		base.transform.parent = targetParent;
		this.m_StartLerpPos = base.transform.position;
		this.m_StartLerpRot = base.transform.rotation;
		this.m_StartLerpScale = base.transform.localScale;
		this.m_TargetLerpTransform = targetTransform;
		this.m_IsLerpingToPos = true;
		this.m_IsHideAfterFinishLerp = false;
	}

	// Token: 0x0600019D RID: 413 RVA: 0x00012FEC File Offset: 0x000111EC
	public void StopLerpToTransform()
	{
		this.m_LerpPosTimer = 0f;
		this.m_IsLerpingToPos = false;
		this.m_IsHideAfterFinishLerp = false;
	}

	// Token: 0x0600019E RID: 414 RVA: 0x00013007 File Offset: 0x00011207
	public void SetHideItemAfterFinishLerp()
	{
		this.m_IsHideAfterFinishLerp = true;
	}

	// Token: 0x0600019F RID: 415 RVA: 0x00013010 File Offset: 0x00011210
	protected virtual void OnFinishLerp()
	{
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x00013012 File Offset: 0x00011212
	public bool CanPickup()
	{
		return !this.m_IsLerpingToPos;
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x0001301D File Offset: 0x0001121D
	public bool IsValidObject()
	{
		return !this.m_IsMovingObject && !this.m_IsBoxedUp && !this.m_IsBeingHold;
	}

	// Token: 0x060001A2 RID: 418 RVA: 0x0001303A File Offset: 0x0001123A
	public bool GetIsBoxedUp()
	{
		return this.m_IsBoxedUp;
	}

	// Token: 0x060001A3 RID: 419 RVA: 0x00013042 File Offset: 0x00011242
	public bool GetIsMovingObject()
	{
		return this.m_IsMovingObject;
	}

	// Token: 0x060001A4 RID: 420 RVA: 0x0001304A File Offset: 0x0001124A
	public InteractablePackagingBox_Shelf GetPackagingBoxShelf()
	{
		return this.m_InteractablePackagingBox_Shelf;
	}

	// Token: 0x040001FC RID: 508
	public EObjectType m_ObjectType = EObjectType.None;

	// Token: 0x040001FD RID: 509
	public GameObject m_HighlightGameObj;

	// Token: 0x040001FE RID: 510
	public GameObject m_NavMeshCut;

	// Token: 0x040001FF RID: 511
	public MeshRenderer m_Mesh;

	// Token: 0x04000200 RID: 512
	public SkinnedMeshRenderer m_SkinMesh;

	// Token: 0x04000201 RID: 513
	public float m_HighlightOutlineWidth = 5f;

	// Token: 0x04000202 RID: 514
	public bool m_IsGenericObject;

	// Token: 0x04000203 RID: 515
	public bool m_CanPickupMoveObject;

	// Token: 0x04000204 RID: 516
	public bool m_CanBoxUpObject;

	// Token: 0x04000205 RID: 517
	public bool m_CanScanByCounter;

	// Token: 0x04000206 RID: 518
	public bool m_PlaceObjectInShopOnly = true;

	// Token: 0x04000207 RID: 519
	public bool m_PlaceObjectInWarehouseOnly;

	// Token: 0x04000208 RID: 520
	public MeshFilter m_PickupObjectMesh;

	// Token: 0x04000209 RID: 521
	public Transform m_MoveStateValidArea;

	// Token: 0x0400020A RID: 522
	public ShelfMoveStateValidArea m_ShelfMoveStateValidArea;

	// Token: 0x0400020B RID: 523
	public BoxCollider m_BoxCollider;

	// Token: 0x0400020C RID: 524
	public List<BoxCollider> m_BoxColliderList;

	// Token: 0x0400020D RID: 525
	public List<EGameAction> m_GameActionInputDisplayList;

	// Token: 0x0400020E RID: 526
	protected bool m_IsRaycasted;

	// Token: 0x0400020F RID: 527
	protected bool m_IsLerpingToPos;

	// Token: 0x04000210 RID: 528
	protected bool m_IsHideAfterFinishLerp;

	// Token: 0x04000211 RID: 529
	protected bool m_IsMovingObject;

	// Token: 0x04000212 RID: 530
	protected bool m_IsBeingHold;

	// Token: 0x04000213 RID: 531
	protected bool m_IsBoxedUp;

	// Token: 0x04000214 RID: 532
	protected bool m_HasInit;

	// Token: 0x04000215 RID: 533
	protected bool m_IsSnappingPos;

	// Token: 0x04000216 RID: 534
	protected int m_OriginalLayer;

	// Token: 0x04000217 RID: 535
	protected Vector3 m_OriginalScale;

	// Token: 0x04000218 RID: 536
	protected Vector3 m_TargetSnapPos;

	// Token: 0x04000219 RID: 537
	protected Transform m_OriginalParent;

	// Token: 0x0400021A RID: 538
	protected Material m_Material;

	// Token: 0x0400021B RID: 539
	protected Transform m_Shelf_WorldUIGrp;

	// Token: 0x0400021C RID: 540
	protected InteractablePackagingBox_Shelf m_InteractablePackagingBox_Shelf;

	// Token: 0x0400021D RID: 541
	protected List<ShelfCompartment> m_ItemCompartmentList = new List<ShelfCompartment>();

	// Token: 0x0400021E RID: 542
	protected bool m_IsMovingObjectValidState;

	// Token: 0x0400021F RID: 543
	private float m_LerpPosTimer;

	// Token: 0x04000220 RID: 544
	private float m_LerpPosSpeed = 3f;

	// Token: 0x04000221 RID: 545
	private Vector3 m_StartLerpPos;

	// Token: 0x04000222 RID: 546
	private Vector3 m_StartLerpScale;

	// Token: 0x04000223 RID: 547
	protected Vector3 m_TargetMoveObjectPosition;

	// Token: 0x04000224 RID: 548
	private Quaternion m_StartLerpRot;

	// Token: 0x04000225 RID: 549
	private Transform m_TargetLerpTransform;

	// Token: 0x04000226 RID: 550
	private float m_MoveObjectLerpSpeed = 0.002f;
}
