﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001CF RID: 463
	public class AnimationControl : MonoBehaviour
	{
		// Token: 0x06000CEE RID: 3310 RVA: 0x000597F1 File Offset: 0x000579F1
		private void Awake()
		{
			this.controller = base.GetComponent<Controller>();
			this.animator = base.GetComponentInChildren<Animator>();
			this.animatorTransform = this.animator.transform;
			this.tr = base.transform;
		}

		// Token: 0x06000CEF RID: 3311 RVA: 0x00059828 File Offset: 0x00057A28
		private void OnEnable()
		{
			Controller controller = this.controller;
			controller.OnLand = (Controller.VectorEvent)Delegate.Combine(controller.OnLand, new Controller.VectorEvent(this.OnLand));
			Controller controller2 = this.controller;
			controller2.OnJump = (Controller.VectorEvent)Delegate.Combine(controller2.OnJump, new Controller.VectorEvent(this.OnJump));
		}

		// Token: 0x06000CF0 RID: 3312 RVA: 0x00059884 File Offset: 0x00057A84
		private void OnDisable()
		{
			Controller controller = this.controller;
			controller.OnLand = (Controller.VectorEvent)Delegate.Remove(controller.OnLand, new Controller.VectorEvent(this.OnLand));
			Controller controller2 = this.controller;
			controller2.OnJump = (Controller.VectorEvent)Delegate.Remove(controller2.OnJump, new Controller.VectorEvent(this.OnJump));
		}

		// Token: 0x06000CF1 RID: 3313 RVA: 0x000598E0 File Offset: 0x00057AE0
		private void Update()
		{
			Vector3 velocity = this.controller.GetVelocity();
			Vector3 vector = VectorMath.RemoveDotVector(velocity, this.tr.up);
			Vector3 vector2 = velocity - vector;
			vector = Vector3.Lerp(this.oldMovementVelocity, vector, this.smoothingFactor * Time.deltaTime);
			this.oldMovementVelocity = vector;
			this.animator.SetFloat("VerticalSpeed", vector2.magnitude * VectorMath.GetDotProduct(vector2.normalized, this.tr.up));
			this.animator.SetFloat("HorizontalSpeed", vector.magnitude);
			if (this.useStrafeAnimations)
			{
				Vector3 vector3 = this.animatorTransform.InverseTransformVector(vector);
				this.animator.SetFloat("ForwardSpeed", vector3.z);
				this.animator.SetFloat("StrafeSpeed", vector3.x);
			}
			this.animator.SetBool("IsGrounded", this.controller.IsGrounded());
			this.animator.SetBool("IsStrafing", this.useStrafeAnimations);
		}

		// Token: 0x06000CF2 RID: 3314 RVA: 0x000599E9 File Offset: 0x00057BE9
		private void OnLand(Vector3 _v)
		{
			if (VectorMath.GetDotProduct(_v, this.tr.up) > -this.landVelocityThreshold)
			{
				return;
			}
			this.animator.SetTrigger("OnLand");
		}

		// Token: 0x06000CF3 RID: 3315 RVA: 0x00059A16 File Offset: 0x00057C16
		private void OnJump(Vector3 _v)
		{
		}

		// Token: 0x040013D3 RID: 5075
		private Controller controller;

		// Token: 0x040013D4 RID: 5076
		private Animator animator;

		// Token: 0x040013D5 RID: 5077
		private Transform animatorTransform;

		// Token: 0x040013D6 RID: 5078
		private Transform tr;

		// Token: 0x040013D7 RID: 5079
		public bool useStrafeAnimations;

		// Token: 0x040013D8 RID: 5080
		public float landVelocityThreshold = 5f;

		// Token: 0x040013D9 RID: 5081
		private float smoothingFactor = 40f;

		// Token: 0x040013DA RID: 5082
		private Vector3 oldMovementVelocity = Vector3.zero;
	}
}
