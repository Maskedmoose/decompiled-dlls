﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace CC
{
	// Token: 0x020001C2 RID: 450
	public class Grid_Picker : MonoBehaviour, IDragHandler, IEventSystemHandler, IBeginDragHandler
	{
		// Token: 0x06000CAC RID: 3244 RVA: 0x0005830C File Offset: 0x0005650C
		public void Start()
		{
			this.rectTransform = base.gameObject.GetComponent<RectTransform>();
			this.rectTransformPicker = this.Picker.GetComponent<RectTransform>();
			this.rectSize = this.rectTransform.sizeDelta;
			if (this._camera == null && this.UseCamera)
			{
				this._camera = Camera.main;
			}
		}

		// Token: 0x06000CAD RID: 3245 RVA: 0x00058370 File Offset: 0x00056570
		public void UpdatePosition(PointerEventData eventData)
		{
			Vector2 vector;
			RectTransformUtility.ScreenPointToLocalPointInRectangle(this.rectTransform, eventData.position, this._camera, out vector);
			vector.x = Mathf.Clamp(vector.x, 0f, this.rectSize.x);
			vector.y = Mathf.Clamp(vector.y, 0f, this.rectSize.y);
			this.rectTransformPicker.anchoredPosition = new Vector2(Mathf.Clamp(vector.x, 10f, this.rectSize.x - 10f), Mathf.Clamp(vector.y, 10f, this.rectSize.y - 10f));
			vector /= this.rectSize;
			this.m_onPickerDrag.Invoke(vector);
		}

		// Token: 0x06000CAE RID: 3246 RVA: 0x00058446 File Offset: 0x00056646
		public void OnDrag(PointerEventData eventData)
		{
			this.UpdatePosition(eventData);
		}

		// Token: 0x06000CAF RID: 3247 RVA: 0x0005844F File Offset: 0x0005664F
		public void OnBeginDrag(PointerEventData eventData)
		{
			this.rectSize = this.rectTransform.sizeDelta;
			this.UpdatePosition(eventData);
		}

		// Token: 0x06000CB0 RID: 3248 RVA: 0x0005846C File Offset: 0x0005666C
		public void randomize()
		{
			float num = Random.Range(0f, 1f);
			float num2 = Random.Range(0f, 1f);
			this.m_onPickerDrag.Invoke(new Vector2(num, num2));
			this.rectTransformPicker.anchoredPosition = new Vector2(Mathf.Clamp(num * this.rectSize.x, 10f, this.rectSize.x - 10f), Mathf.Clamp(num2 * this.rectSize.y, 10f, this.rectSize.y - 10f));
		}

		// Token: 0x04001387 RID: 4999
		private RectTransform rectTransform;

		// Token: 0x04001388 RID: 5000
		private RectTransform rectTransformPicker;

		// Token: 0x04001389 RID: 5001
		private Vector2 rectSize;

		// Token: 0x0400138A RID: 5002
		public Vector2 imageSize;

		// Token: 0x0400138B RID: 5003
		public Camera _camera;

		// Token: 0x0400138C RID: 5004
		public bool UseCamera;

		// Token: 0x0400138D RID: 5005
		public GameObject Picker;

		// Token: 0x0400138E RID: 5006
		public GameObject Background;

		// Token: 0x0400138F RID: 5007
		public OnPickerDrag m_onPickerDrag = new OnPickerDrag();
	}
}
