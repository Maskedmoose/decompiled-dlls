﻿using System;

// Token: 0x0200007A RID: 122
[Serializable]
public struct LoadSavedSlotData
{
	// Token: 0x0400066A RID: 1642
	public bool hasSaveData;

	// Token: 0x0400066B RID: 1643
	public string name;

	// Token: 0x0400066C RID: 1644
	public int level;

	// Token: 0x0400066D RID: 1645
	public int daysPassed;

	// Token: 0x0400066E RID: 1646
	public float moneyAmount;
}
