﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DD RID: 477
	public class FlipAtRightAngle : MonoBehaviour
	{
		// Token: 0x06000D75 RID: 3445 RVA: 0x0005CB55 File Offset: 0x0005AD55
		private void Start()
		{
			this.tr = base.transform;
			this.audioSource = base.GetComponent<AudioSource>();
		}

		// Token: 0x06000D76 RID: 3446 RVA: 0x0005CB6F File Offset: 0x0005AD6F
		private void OnTriggerEnter(Collider col)
		{
			if (col.GetComponent<Controller>() == null)
			{
				return;
			}
			this.SwitchDirection(this.tr.forward, col.GetComponent<Controller>());
		}

		// Token: 0x06000D77 RID: 3447 RVA: 0x0005CB98 File Offset: 0x0005AD98
		private void SwitchDirection(Vector3 _newUpDirection, Controller _controller)
		{
			float num = 0.001f;
			if (Vector3.Angle(_newUpDirection, _controller.transform.up) < num)
			{
				return;
			}
			this.audioSource.Play();
			Transform transform = _controller.transform;
			Quaternion lhs = Quaternion.FromToRotation(transform.up, _newUpDirection);
			transform.rotation = lhs * transform.rotation;
		}

		// Token: 0x04001472 RID: 5234
		private AudioSource audioSource;

		// Token: 0x04001473 RID: 5235
		private Transform tr;
	}
}
