﻿using System;
using System.Collections.Generic;

// Token: 0x0200004B RID: 75
[Serializable]
public class WarehouseShelfSaveData
{
	// Token: 0x0400043E RID: 1086
	public Vector3Serializer pos;

	// Token: 0x0400043F RID: 1087
	public QuaternionSerializer rot;

	// Token: 0x04000440 RID: 1088
	public bool isBoxed;

	// Token: 0x04000441 RID: 1089
	public Vector3Serializer boxedPackagePos;

	// Token: 0x04000442 RID: 1090
	public QuaternionSerializer boxedPackageRot;

	// Token: 0x04000443 RID: 1091
	public EObjectType objectType;

	// Token: 0x04000444 RID: 1092
	public List<EItemType> compartmentItemType;
}
