﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001E0 RID: 480
	public class TriggerArea : MonoBehaviour
	{
		// Token: 0x06000D85 RID: 3461 RVA: 0x0005D087 File Offset: 0x0005B287
		private void OnTriggerEnter(Collider col)
		{
			if (col.attachedRigidbody != null && col.GetComponent<Mover>() != null)
			{
				this.rigidbodiesInTriggerArea.Add(col.attachedRigidbody);
			}
		}

		// Token: 0x06000D86 RID: 3462 RVA: 0x0005D0B6 File Offset: 0x0005B2B6
		private void OnTriggerExit(Collider col)
		{
			if (col.attachedRigidbody != null && col.GetComponent<Mover>() != null)
			{
				this.rigidbodiesInTriggerArea.Remove(col.attachedRigidbody);
			}
		}

		// Token: 0x0400147E RID: 5246
		public List<Rigidbody> rigidbodiesInTriggerArea = new List<Rigidbody>();
	}
}
