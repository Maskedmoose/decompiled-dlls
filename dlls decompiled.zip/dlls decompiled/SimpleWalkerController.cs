﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001DA RID: 474
	public class SimpleWalkerController : Controller
	{
		// Token: 0x06000D45 RID: 3397 RVA: 0x0005B708 File Offset: 0x00059908
		private void Start()
		{
			this.tr = base.transform;
			this.mover = base.GetComponent<Mover>();
			this.characterInput = base.GetComponent<CharacterInput>();
		}

		// Token: 0x06000D46 RID: 3398 RVA: 0x0005B730 File Offset: 0x00059930
		private void FixedUpdate()
		{
			this.mover.CheckForGround();
			if (!this.isGrounded && this.mover.IsGrounded())
			{
				this.OnGroundContactRegained(this.lastVelocity);
			}
			this.isGrounded = this.mover.IsGrounded();
			Vector3 vector = Vector3.zero;
			vector += this.CalculateMovementDirection() * this.movementSpeed;
			if (!this.isGrounded)
			{
				this.currentVerticalSpeed -= this.gravity * Time.deltaTime;
			}
			else if (this.currentVerticalSpeed <= 0f)
			{
				this.currentVerticalSpeed = 0f;
			}
			if (this.characterInput != null && this.isGrounded && this.characterInput.IsJumpKeyPressed())
			{
				this.OnJumpStart();
				this.currentVerticalSpeed = this.jumpSpeed;
				this.isGrounded = false;
			}
			vector += this.tr.up * this.currentVerticalSpeed;
			this.lastVelocity = vector;
			this.mover.SetExtendSensorRange(this.isGrounded);
			this.mover.SetVelocity(vector);
		}

		// Token: 0x06000D47 RID: 3399 RVA: 0x0005B850 File Offset: 0x00059A50
		private Vector3 CalculateMovementDirection()
		{
			if (this.characterInput == null)
			{
				return Vector3.zero;
			}
			Vector3 vector = Vector3.zero;
			if (this.cameraTransform == null)
			{
				vector += this.tr.right * this.characterInput.GetHorizontalMovementInput();
				vector += this.tr.forward * this.characterInput.GetVerticalMovementInput();
			}
			else
			{
				vector += Vector3.ProjectOnPlane(this.cameraTransform.right, this.tr.up).normalized * this.characterInput.GetHorizontalMovementInput();
				vector += Vector3.ProjectOnPlane(this.cameraTransform.forward, this.tr.up).normalized * this.characterInput.GetVerticalMovementInput();
			}
			if (vector.magnitude > 1f)
			{
				vector.Normalize();
			}
			return vector;
		}

		// Token: 0x06000D48 RID: 3400 RVA: 0x0005B955 File Offset: 0x00059B55
		private void OnGroundContactRegained(Vector3 _collisionVelocity)
		{
			if (this.OnLand != null)
			{
				this.OnLand(_collisionVelocity);
			}
		}

		// Token: 0x06000D49 RID: 3401 RVA: 0x0005B96B File Offset: 0x00059B6B
		private void OnJumpStart()
		{
			if (this.OnJump != null)
			{
				this.OnJump(this.lastVelocity);
			}
		}

		// Token: 0x06000D4A RID: 3402 RVA: 0x0005B986 File Offset: 0x00059B86
		public override Vector3 GetVelocity()
		{
			return this.lastVelocity;
		}

		// Token: 0x06000D4B RID: 3403 RVA: 0x0005B98E File Offset: 0x00059B8E
		public override Vector3 GetMovementVelocity()
		{
			return this.lastVelocity;
		}

		// Token: 0x06000D4C RID: 3404 RVA: 0x0005B996 File Offset: 0x00059B96
		public override bool IsGrounded()
		{
			return this.isGrounded;
		}

		// Token: 0x04001436 RID: 5174
		private Mover mover;

		// Token: 0x04001437 RID: 5175
		private float currentVerticalSpeed;

		// Token: 0x04001438 RID: 5176
		private bool isGrounded;

		// Token: 0x04001439 RID: 5177
		public float movementSpeed = 7f;

		// Token: 0x0400143A RID: 5178
		public float jumpSpeed = 10f;

		// Token: 0x0400143B RID: 5179
		public float gravity = 10f;

		// Token: 0x0400143C RID: 5180
		private Vector3 lastVelocity = Vector3.zero;

		// Token: 0x0400143D RID: 5181
		public Transform cameraTransform;

		// Token: 0x0400143E RID: 5182
		private CharacterInput characterInput;

		// Token: 0x0400143F RID: 5183
		private Transform tr;
	}
}
