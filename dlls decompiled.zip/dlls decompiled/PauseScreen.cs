﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000099 RID: 153
public class PauseScreen : CSingleton<PauseScreen>
{
	// Token: 0x060005F0 RID: 1520 RVA: 0x000312E8 File Offset: 0x0002F4E8
	public static void OpenScreen()
	{
		if (CSingleton<PauseScreen>.Instance.m_ScreenGrp.activeSelf)
		{
			PauseScreen.CloseScreen();
			return;
		}
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		CSingleton<PauseScreen>.Instance.m_IsCursorVisible = Cursor.visible;
		CSingleton<PauseScreen>.Instance.m_CursorLockMode = InputManager.GetCursorLockMode();
		CSingleton<PauseScreen>.Instance.m_IsCameraEnabled = CSingleton<InteractionPlayerController>.Instance.m_CameraController.enabled;
		CSingleton<InteractionPlayerController>.Instance.ShowCursor();
		CSingleton<PauseScreen>.Instance.m_VersionText.text = "v" + Application.version;
		CSingleton<PauseScreen>.Instance.m_ScreenGrp.SetActive(true);
		SoundManager.MuteAllSound();
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<PauseScreen>.Instance.m_ControllerScreenUIExtension);
		Time.timeScale = 0f;
	}

	// Token: 0x060005F1 RID: 1521 RVA: 0x000313A4 File Offset: 0x0002F5A4
	public static void CloseScreen()
	{
		if (CSingleton<SaveLoadGameSlotSelectScreen>.Instance.m_ScreenGrp.activeSelf)
		{
			SaveLoadGameSlotSelectScreen.CloseScreen();
			return;
		}
		if (CSingleton<SettingScreen>.Instance.m_ScreenGrp.activeSelf)
		{
			SettingScreen.CloseScreen();
			return;
		}
		Time.timeScale = 1f;
		SoundManager.UnMuteAllSound();
		CSingleton<PauseScreen>.Instance.m_ScreenGrp.SetActive(false);
		if (InputManager.GetCursorLockMode() == CursorLockMode.Confined && !CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			Cursor.visible = true;
		}
		else
		{
			Cursor.visible = false;
		}
		if (CSingleton<PauseScreen>.Instance.m_CursorLockMode == CursorLockMode.Locked)
		{
			CenterDot.SetVisibility(true);
		}
		InputManager.SetCursorLockMode(CSingleton<PauseScreen>.Instance.m_CursorLockMode);
		CSingleton<InteractionPlayerController>.Instance.m_CameraController.enabled = CSingleton<PauseScreen>.Instance.m_IsCameraEnabled;
		SoundManager.GenericLightTap(1f, 1f);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<PauseScreen>.Instance.m_ControllerScreenUIExtension);
		CSingleton<InteractionPlayerController>.Instance.ResetMousePress();
	}

	// Token: 0x060005F2 RID: 1522 RVA: 0x00031483 File Offset: 0x0002F683
	public void OnPressSetting()
	{
		SoundManager.GenericLightTap(1f, 1f);
		SettingScreen.OpenScreen(false);
	}

	// Token: 0x060005F3 RID: 1523 RVA: 0x0003149A File Offset: 0x0002F69A
	public void OpenLoadGameSlotScreen()
	{
		SoundManager.GenericLightTap(1f, 1f);
		SaveLoadGameSlotSelectScreen.OpenScreen(false);
	}

	// Token: 0x060005F4 RID: 1524 RVA: 0x000314B1 File Offset: 0x0002F6B1
	public void OpenSaveGameSlotScreen()
	{
		SoundManager.GenericLightTap(1f, 1f);
		SaveLoadGameSlotSelectScreen.OpenScreen(true);
	}

	// Token: 0x060005F5 RID: 1525 RVA: 0x000314C8 File Offset: 0x0002F6C8
	public void OnPressBackMenu()
	{
		Time.timeScale = 1f;
		SoundManager.GenericLightTap(1f, 1f);
		CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Title", -1);
		CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		CSingleton<CGameManager>.Instance.SaveGameData(false, true);
	}

	// Token: 0x060005F6 RID: 1526 RVA: 0x00031515 File Offset: 0x0002F715
	public void OnPressQuit()
	{
		SoundManager.GenericLightTap(1f, 1f);
		Application.Quit();
	}

	// Token: 0x060005F7 RID: 1527 RVA: 0x0003152B File Offset: 0x0002F72B
	public void OnPressWishlistOnSteam()
	{
		Application.OpenURL("https://store.steampowered.com/app/3070070?utm_source=prologue&utm_campaign=prologue1&utm_medium=game");
		UnityAnalytic.PressWishlist(1);
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x0003153D File Offset: 0x0002F73D
	public void OnPressFeedbackBtn()
	{
		Application.OpenURL("https://steamcommunity.com/app/3070070/discussions/");
		UnityAnalytic.PressFeedback(1);
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x0003154F File Offset: 0x0002F74F
	public void OnPressDiscordBtn()
	{
		Application.OpenURL("https://discord.gg/2YaaUZzrRY");
		UnityAnalytic.JoinDiscord();
	}

	// Token: 0x040007CA RID: 1994
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040007CB RID: 1995
	public GameObject m_ScreenGrp;

	// Token: 0x040007CC RID: 1996
	public TextMeshProUGUI m_VersionText;

	// Token: 0x040007CD RID: 1997
	private bool m_IsCursorVisible;

	// Token: 0x040007CE RID: 1998
	private bool m_IsCameraEnabled;

	// Token: 0x040007CF RID: 1999
	private CursorLockMode m_CursorLockMode;
}
