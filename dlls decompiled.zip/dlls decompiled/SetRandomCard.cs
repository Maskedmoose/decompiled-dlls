﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000137 RID: 311
public class SetRandomCard : MonoBehaviour
{
	// Token: 0x060008EE RID: 2286 RVA: 0x00041541 File Offset: 0x0003F741
	private void Start()
	{
		this.EvaluateCard();
	}

	// Token: 0x060008EF RID: 2287 RVA: 0x00041549 File Offset: 0x0003F749
	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.B))
		{
			this.EvaluateCard();
		}
	}

	// Token: 0x060008F0 RID: 2288 RVA: 0x0004155C File Offset: 0x0003F75C
	private void EvaluateCard()
	{
		List<EMonsterType> shownMonsterList = InventoryBase.GetShownMonsterList(ECardExpansionType.Tetramon);
		for (int i = 0; i < this.m_CardList.Count; i++)
		{
			CardData cardData = new CardData();
			ECardBorderType borderType = ECardBorderType.Base;
			cardData.monsterType = shownMonsterList[Random.Range(0, shownMonsterList.Count)];
			cardData.borderType = borderType;
			cardData.expansionType = ECardExpansionType.Tetramon;
			cardData.isNew = false;
			this.m_CardList[i].m_CardUI.SetCardUI(cardData);
		}
	}

	// Token: 0x04001105 RID: 4357
	public List<Card3dUIGroup> m_CardList;
}
