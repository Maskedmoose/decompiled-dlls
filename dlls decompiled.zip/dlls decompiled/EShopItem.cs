﻿using System;

// Token: 0x020000FB RID: 251
public enum EShopItem
{
	// Token: 0x04000E1C RID: 3612
	None = -1,
	// Token: 0x04000E1D RID: 3613
	Gem1,
	// Token: 0x04000E1E RID: 3614
	Gem2,
	// Token: 0x04000E1F RID: 3615
	Gem3,
	// Token: 0x04000E20 RID: 3616
	Gem4,
	// Token: 0x04000E21 RID: 3617
	Gem5,
	// Token: 0x04000E22 RID: 3618
	Gem6,
	// Token: 0x04000E23 RID: 3619
	Gold1,
	// Token: 0x04000E24 RID: 3620
	Gold2,
	// Token: 0x04000E25 RID: 3621
	Gold3,
	// Token: 0x04000E26 RID: 3622
	RemoveAd,
	// Token: 0x04000E27 RID: 3623
	Earning1,
	// Token: 0x04000E28 RID: 3624
	Earning2,
	// Token: 0x04000E29 RID: 3625
	Earning3,
	// Token: 0x04000E2A RID: 3626
	OfflineTime1,
	// Token: 0x04000E2B RID: 3627
	OfflineTime2,
	// Token: 0x04000E2C RID: 3628
	OfflineTime3,
	// Token: 0x04000E2D RID: 3629
	SpecialPack1,
	// Token: 0x04000E2E RID: 3630
	SpecialPack2,
	// Token: 0x04000E2F RID: 3631
	SpecialPack3,
	// Token: 0x04000E30 RID: 3632
	ChestBundle1,
	// Token: 0x04000E31 RID: 3633
	ChestBundle2,
	// Token: 0x04000E32 RID: 3634
	ChestBundle3,
	// Token: 0x04000E33 RID: 3635
	ChestBundle4,
	// Token: 0x04000E34 RID: 3636
	ChestBundle5,
	// Token: 0x04000E35 RID: 3637
	AutoRestock,
	// Token: 0x04000E36 RID: 3638
	AutoPlaceItem,
	// Token: 0x04000E37 RID: 3639
	UnlimitedEnergy,
	// Token: 0x04000E38 RID: 3640
	FoilBasicPack,
	// Token: 0x04000E39 RID: 3641
	FoilRarePack,
	// Token: 0x04000E3A RID: 3642
	FoilEpicPack,
	// Token: 0x04000E3B RID: 3643
	FoilLegendPack,
	// Token: 0x04000E3C RID: 3644
	UltimateShopkeeperPack,
	// Token: 0x04000E3D RID: 3645
	PowerupEXPack,
	// Token: 0x04000E3E RID: 3646
	StarterPack,
	// Token: 0x04000E3F RID: 3647
	ProPack,
	// Token: 0x04000E40 RID: 3648
	UltimateShopkeeperPackFull,
	// Token: 0x04000E41 RID: 3649
	PowerupEXPackFull,
	// Token: 0x04000E42 RID: 3650
	StarterPackFull,
	// Token: 0x04000E43 RID: 3651
	ProPackFull,
	// Token: 0x04000E44 RID: 3652
	AutoManager,
	// Token: 0x04000E45 RID: 3653
	SubDollarUltimateShopkeeperPack,
	// Token: 0x04000E46 RID: 3654
	SubDollarGemPack,
	// Token: 0x04000E47 RID: 3655
	MassiveGemPack,
	// Token: 0x04000E48 RID: 3656
	SpecialSeasonBundle1,
	// Token: 0x04000E49 RID: 3657
	SpecialSeasonBundle2,
	// Token: 0x04000E4A RID: 3658
	SpecialConsumableBundle1,
	// Token: 0x04000E4B RID: 3659
	SpecialConsumableBundle2,
	// Token: 0x04000E4C RID: 3660
	StorePointUpgrade1,
	// Token: 0x04000E4D RID: 3661
	StorePointUpgrade2,
	// Token: 0x04000E4E RID: 3662
	StorePointUpgrade3,
	// Token: 0x04000E4F RID: 3663
	BeginnerBundle1,
	// Token: 0x04000E50 RID: 3664
	BeginnerBundle2,
	// Token: 0x04000E51 RID: 3665
	BuilderBundle1,
	// Token: 0x04000E52 RID: 3666
	BuilderBundle2,
	// Token: 0x04000E53 RID: 3667
	BuilderBundle3
}
