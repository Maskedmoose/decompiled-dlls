﻿using System;

// Token: 0x020000FC RID: 252
public enum EAnalyticLogSpendingEvent
{
	// Token: 0x04000E55 RID: 3669
	GemABuyUGSuperGiant,
	// Token: 0x04000E56 RID: 3670
	GemABuyUGGiant,
	// Token: 0x04000E57 RID: 3671
	GemABuyGold,
	// Token: 0x04000E58 RID: 3672
	GemABuyBaseSuperGiant,
	// Token: 0x04000E59 RID: 3673
	GemABuyBaseGiant,
	// Token: 0x04000E5A RID: 3674
	GemABuyBaseWeapon,
	// Token: 0x04000E5B RID: 3675
	GemABuyBaseChip,
	// Token: 0x04000E5C RID: 3676
	GemAStartUGQuickFight,
	// Token: 0x04000E5D RID: 3677
	GemASwitchUGOpponent,
	// Token: 0x04000E5E RID: 3678
	GemAFusePart,
	// Token: 0x04000E5F RID: 3679
	GemABuyBaseCrate,
	// Token: 0x04000E60 RID: 3680
	GemABuyUGCrate,
	// Token: 0x04000E61 RID: 3681
	GemAOpenBaseCrate,
	// Token: 0x04000E62 RID: 3682
	GemAOpenUGCrate,
	// Token: 0x04000E63 RID: 3683
	GemARefreshTitleMatch,
	// Token: 0x04000E64 RID: 3684
	GoldAStartUGQuickFight,
	// Token: 0x04000E65 RID: 3685
	GoldASwitchUGOpponent,
	// Token: 0x04000E66 RID: 3686
	GoldAFusePart,
	// Token: 0x04000E67 RID: 3687
	GoldABuySecretPartA,
	// Token: 0x04000E68 RID: 3688
	GoldABuySecretPartB,
	// Token: 0x04000E69 RID: 3689
	GoldSpend20To40K,
	// Token: 0x04000E6A RID: 3690
	GoldSpend40To60K,
	// Token: 0x04000E6B RID: 3691
	GoldSpend60To80K,
	// Token: 0x04000E6C RID: 3692
	GoldSpend80To100K,
	// Token: 0x04000E6D RID: 3693
	GoldSpend100To200K,
	// Token: 0x04000E6E RID: 3694
	GoldSpend200To400K,
	// Token: 0x04000E6F RID: 3695
	GoldSpend400T0600K,
	// Token: 0x04000E70 RID: 3696
	GoldSpend600To1Mil,
	// Token: 0x04000E71 RID: 3697
	GoldSpend1To2Mil,
	// Token: 0x04000E72 RID: 3698
	GoldSpend2To4Mil,
	// Token: 0x04000E73 RID: 3699
	GoldSpend4To6Mil,
	// Token: 0x04000E74 RID: 3700
	GoldSpend6To10Mil,
	// Token: 0x04000E75 RID: 3701
	GoldSpendMore10Mil,
	// Token: 0x04000E76 RID: 3702
	IAPAPressMegabotDetail,
	// Token: 0x04000E77 RID: 3703
	IAPAPressMegabot1Purchase,
	// Token: 0x04000E78 RID: 3704
	IAPAPressMegabot2Purchase,
	// Token: 0x04000E79 RID: 3705
	IAPAPressMegabot3Purchase,
	// Token: 0x04000E7A RID: 3706
	IAPAPressInstantCratePurchase,
	// Token: 0x04000E7B RID: 3707
	IAPAPressGem1Purchase,
	// Token: 0x04000E7C RID: 3708
	IAPAPressGem2Purchase,
	// Token: 0x04000E7D RID: 3709
	IAPAPressGem3Purchase,
	// Token: 0x04000E7E RID: 3710
	IAPAPressGem4Purchase,
	// Token: 0x04000E7F RID: 3711
	IAPAPressGem5Purchase,
	// Token: 0x04000E80 RID: 3712
	IAPAPressGem6Purchase,
	// Token: 0x04000E81 RID: 3713
	IAPAPressMassiveGemDiscountPurchase,
	// Token: 0x04000E82 RID: 3714
	IAPAPressGemDiscountLegendPurchase,
	// Token: 0x04000E83 RID: 3715
	IAPAPressInstantCrateLegendPurchase,
	// Token: 0x04000E84 RID: 3716
	IAPAPressGemDiscountPurchase,
	// Token: 0x04000E85 RID: 3717
	IAPAPressInstantCrateHalfPurchase,
	// Token: 0x04000E86 RID: 3718
	StartTitleMatch,
	// Token: 0x04000E87 RID: 3719
	UnlockUGMode,
	// Token: 0x04000E88 RID: 3720
	UGModeStartLeagueMatch,
	// Token: 0x04000E89 RID: 3721
	UGModeStay1d,
	// Token: 0x04000E8A RID: 3722
	UGModeStay3d,
	// Token: 0x04000E8B RID: 3723
	UGModeStay7d,
	// Token: 0x04000E8C RID: 3724
	UGModeStay14d,
	// Token: 0x04000E8D RID: 3725
	UGModeStay30d,
	// Token: 0x04000E8E RID: 3726
	UGModeStay60d,
	// Token: 0x04000E8F RID: 3727
	UGModeStay90d,
	// Token: 0x04000E90 RID: 3728
	UGModeStay120d,
	// Token: 0x04000E91 RID: 3729
	UGModeStay150d,
	// Token: 0x04000E92 RID: 3730
	GoldSpend10To20K
}
