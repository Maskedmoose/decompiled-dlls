﻿using System;

// Token: 0x02000033 RID: 51
[Serializable]
public class RestockData
{
	// Token: 0x04000311 RID: 785
	public string name;

	// Token: 0x04000312 RID: 786
	public bool isBigBox;

	// Token: 0x04000313 RID: 787
	public bool ignoreDoubleImage;

	// Token: 0x04000314 RID: 788
	public int index;

	// Token: 0x04000315 RID: 789
	public int amount;

	// Token: 0x04000316 RID: 790
	public int licenseShopLevelRequired;

	// Token: 0x04000317 RID: 791
	public float licensePrice;

	// Token: 0x04000318 RID: 792
	public EItemType itemType;

	// Token: 0x04000319 RID: 793
	public bool prologueShow;

	// Token: 0x0400031A RID: 794
	public bool isHideItemUntilUnlocked;
}
