﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200013B RID: 315
public class ParticleEffectsLibrary : MonoBehaviour
{
	// Token: 0x060008FC RID: 2300 RVA: 0x00041A68 File Offset: 0x0003FC68
	private void Awake()
	{
		ParticleEffectsLibrary.GlobalAccess = this;
		this.currentActivePEList = new List<Transform>();
		this.TotalEffects = this.ParticleEffectPrefabs.Length;
		this.CurrentParticleEffectNum = 1;
		if (this.ParticleEffectSpawnOffsets.Length != this.TotalEffects)
		{
			Debug.LogError("ParticleEffectsLibrary-ParticleEffectSpawnOffset: Not all arrays match length, double check counts.");
		}
		if (this.ParticleEffectPrefabs.Length != this.TotalEffects)
		{
			Debug.LogError("ParticleEffectsLibrary-ParticleEffectPrefabs: Not all arrays match length, double check counts.");
		}
		this.effectNameString = string.Concat(new string[]
		{
			this.ParticleEffectPrefabs[this.CurrentParticleEffectIndex].name,
			" (",
			this.CurrentParticleEffectNum.ToString(),
			" of ",
			this.TotalEffects.ToString(),
			")"
		});
	}

	// Token: 0x060008FD RID: 2301 RVA: 0x00041B29 File Offset: 0x0003FD29
	private void Start()
	{
	}

	// Token: 0x060008FE RID: 2302 RVA: 0x00041B2C File Offset: 0x0003FD2C
	public string GetCurrentPENameString()
	{
		return string.Concat(new string[]
		{
			this.ParticleEffectPrefabs[this.CurrentParticleEffectIndex].name,
			" (",
			this.CurrentParticleEffectNum.ToString(),
			" of ",
			this.TotalEffects.ToString(),
			")"
		});
	}

	// Token: 0x060008FF RID: 2303 RVA: 0x00041B90 File Offset: 0x0003FD90
	public void PreviousParticleEffect()
	{
		if (this.ParticleEffectLifetimes[this.CurrentParticleEffectIndex] == 0f && this.currentActivePEList.Count > 0)
		{
			for (int i = 0; i < this.currentActivePEList.Count; i++)
			{
				if (this.currentActivePEList[i] != null)
				{
					Object.Destroy(this.currentActivePEList[i].gameObject);
				}
			}
			this.currentActivePEList.Clear();
		}
		if (this.CurrentParticleEffectIndex > 0)
		{
			this.CurrentParticleEffectIndex--;
		}
		else
		{
			this.CurrentParticleEffectIndex = this.TotalEffects - 1;
		}
		this.CurrentParticleEffectNum = this.CurrentParticleEffectIndex + 1;
		this.effectNameString = string.Concat(new string[]
		{
			this.ParticleEffectPrefabs[this.CurrentParticleEffectIndex].name,
			" (",
			this.CurrentParticleEffectNum.ToString(),
			" of ",
			this.TotalEffects.ToString(),
			")"
		});
	}

	// Token: 0x06000900 RID: 2304 RVA: 0x00041C9C File Offset: 0x0003FE9C
	public void NextParticleEffect()
	{
		if (this.ParticleEffectLifetimes[this.CurrentParticleEffectIndex] == 0f && this.currentActivePEList.Count > 0)
		{
			for (int i = 0; i < this.currentActivePEList.Count; i++)
			{
				if (this.currentActivePEList[i] != null)
				{
					Object.Destroy(this.currentActivePEList[i].gameObject);
				}
			}
			this.currentActivePEList.Clear();
		}
		if (this.CurrentParticleEffectIndex < this.TotalEffects - 1)
		{
			this.CurrentParticleEffectIndex++;
		}
		else
		{
			this.CurrentParticleEffectIndex = 0;
		}
		this.CurrentParticleEffectNum = this.CurrentParticleEffectIndex + 1;
		this.effectNameString = string.Concat(new string[]
		{
			this.ParticleEffectPrefabs[this.CurrentParticleEffectIndex].name,
			" (",
			this.CurrentParticleEffectNum.ToString(),
			" of ",
			this.TotalEffects.ToString(),
			")"
		});
	}

	// Token: 0x06000901 RID: 2305 RVA: 0x00041DA8 File Offset: 0x0003FFA8
	public void SpawnParticleEffect(Vector3 positionInWorldToSpawn)
	{
		this.spawnPosition = positionInWorldToSpawn + this.ParticleEffectSpawnOffsets[this.CurrentParticleEffectIndex];
		GameObject gameObject = Object.Instantiate<GameObject>(this.ParticleEffectPrefabs[this.CurrentParticleEffectIndex], this.spawnPosition, this.ParticleEffectPrefabs[this.CurrentParticleEffectIndex].transform.rotation);
		Object @object = gameObject;
		string str = "PE_";
		GameObject gameObject2 = this.ParticleEffectPrefabs[this.CurrentParticleEffectIndex];
		@object.name = str + ((gameObject2 != null) ? gameObject2.ToString() : null);
		if (this.ParticleEffectLifetimes[this.CurrentParticleEffectIndex] == 0f)
		{
			this.currentActivePEList.Add(gameObject.transform);
		}
		this.currentActivePEList.Add(gameObject.transform);
		if (this.ParticleEffectLifetimes[this.CurrentParticleEffectIndex] != 0f)
		{
			Object.Destroy(gameObject, this.ParticleEffectLifetimes[this.CurrentParticleEffectIndex]);
		}
	}

	// Token: 0x04001115 RID: 4373
	public static ParticleEffectsLibrary GlobalAccess;

	// Token: 0x04001116 RID: 4374
	public int TotalEffects;

	// Token: 0x04001117 RID: 4375
	public int CurrentParticleEffectIndex;

	// Token: 0x04001118 RID: 4376
	public int CurrentParticleEffectNum;

	// Token: 0x04001119 RID: 4377
	public Vector3[] ParticleEffectSpawnOffsets;

	// Token: 0x0400111A RID: 4378
	public float[] ParticleEffectLifetimes;

	// Token: 0x0400111B RID: 4379
	public GameObject[] ParticleEffectPrefabs;

	// Token: 0x0400111C RID: 4380
	private string effectNameString = "";

	// Token: 0x0400111D RID: 4381
	private List<Transform> currentActivePEList;

	// Token: 0x0400111E RID: 4382
	private Vector3 spawnPosition = Vector3.zero;
}
