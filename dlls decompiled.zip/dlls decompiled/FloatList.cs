﻿using System;
using System.Collections.Generic;

// Token: 0x0200003F RID: 63
[Serializable]
public class FloatList
{
	// Token: 0x040003C5 RID: 965
	public List<float> floatDataList;
}
