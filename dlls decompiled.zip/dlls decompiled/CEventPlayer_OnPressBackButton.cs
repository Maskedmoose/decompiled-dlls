﻿using System;

// Token: 0x020000CD RID: 205
public class CEventPlayer_OnPressBackButton : CEvent
{
	// Token: 0x1700002A RID: 42
	// (get) Token: 0x06000748 RID: 1864 RVA: 0x0003830F File Offset: 0x0003650F
	// (set) Token: 0x06000749 RID: 1865 RVA: 0x00038317 File Offset: 0x00036517
	public bool m_IsAtMainMenu { get; private set; }

	// Token: 0x0600074A RID: 1866 RVA: 0x00038320 File Offset: 0x00036520
	public CEventPlayer_OnPressBackButton(bool isAtMainMenu)
	{
		this.m_IsAtMainMenu = isAtMainMenu;
	}
}
