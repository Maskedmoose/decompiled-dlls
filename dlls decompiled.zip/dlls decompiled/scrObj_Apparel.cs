﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CC
{
	// Token: 0x020001B2 RID: 434
	[CreateAssetMenu(fileName = "Apparel", menuName = "ScriptableObjects/Apparel")]
	public class scrObj_Apparel : ScriptableObject
	{
		// Token: 0x0400134E RID: 4942
		public List<scrObj_Apparel.Apparel> Items = new List<scrObj_Apparel.Apparel>();

		// Token: 0x0400134F RID: 4943
		public string MaskProperty;

		// Token: 0x04001350 RID: 4944
		public string Label;

		// Token: 0x02000267 RID: 615
		[Serializable]
		public struct Apparel
		{
			// Token: 0x0400164D RID: 5709
			public GameObject Mesh;

			// Token: 0x0400164E RID: 5710
			public string Name;

			// Token: 0x0400164F RID: 5711
			public string DisplayName;

			// Token: 0x04001650 RID: 5712
			public bool AddCopyPoseScript;

			// Token: 0x04001651 RID: 5713
			public Texture2D Mask;

			// Token: 0x04001652 RID: 5714
			public FootOffset FootOffset;

			// Token: 0x04001653 RID: 5715
			public List<CC_Apparel_Material_Collection> Materials;

			// Token: 0x04001654 RID: 5716
			public Sprite Icon;
		}
	}
}
