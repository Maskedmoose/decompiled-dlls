﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D2 RID: 466
	public class TurnTowardControllerVelocity : MonoBehaviour
	{
		// Token: 0x06000CFF RID: 3327 RVA: 0x00059D35 File Offset: 0x00057F35
		private void Start()
		{
			this.tr = base.transform;
			this.parentTransform = this.tr.parent;
			if (this.controller == null)
			{
				Debug.LogWarning("No controller script has been assigned to this 'TurnTowardControllerVelocity' component!", this);
				base.enabled = false;
			}
		}

		// Token: 0x06000D00 RID: 3328 RVA: 0x00059D74 File Offset: 0x00057F74
		private void LateUpdate()
		{
			Vector3 vector;
			if (this.ignoreControllerMomentum)
			{
				vector = this.controller.GetMovementVelocity();
			}
			else
			{
				vector = this.controller.GetVelocity();
			}
			vector = Vector3.ProjectOnPlane(vector, this.parentTransform.up);
			float num = 0.001f;
			if (vector.magnitude < num)
			{
				return;
			}
			vector.Normalize();
			float angle = VectorMath.GetAngle(this.tr.forward, vector, this.parentTransform.up);
			float num2 = Mathf.InverseLerp(0f, this.fallOffAngle, Mathf.Abs(angle));
			float num3 = Mathf.Sign(angle) * num2 * Time.deltaTime * this.turnSpeed;
			if (angle < 0f && num3 < angle)
			{
				num3 = angle;
			}
			else if (angle > 0f && num3 > angle)
			{
				num3 = angle;
			}
			this.currentYRotation += num3;
			if (this.currentYRotation > 360f)
			{
				this.currentYRotation -= 360f;
			}
			if (this.currentYRotation < -360f)
			{
				this.currentYRotation += 360f;
			}
			this.tr.localRotation = Quaternion.Euler(0f, this.currentYRotation, 0f);
		}

		// Token: 0x06000D01 RID: 3329 RVA: 0x00059EA7 File Offset: 0x000580A7
		private void OnDisable()
		{
		}

		// Token: 0x06000D02 RID: 3330 RVA: 0x00059EA9 File Offset: 0x000580A9
		private void OnEnable()
		{
			this.currentYRotation = base.transform.localEulerAngles.y;
		}

		// Token: 0x040013EC RID: 5100
		public Controller controller;

		// Token: 0x040013ED RID: 5101
		public float turnSpeed = 500f;

		// Token: 0x040013EE RID: 5102
		private Transform parentTransform;

		// Token: 0x040013EF RID: 5103
		private Transform tr;

		// Token: 0x040013F0 RID: 5104
		private float currentYRotation;

		// Token: 0x040013F1 RID: 5105
		private float fallOffAngle = 90f;

		// Token: 0x040013F2 RID: 5106
		public bool ignoreControllerMomentum;
	}
}
