﻿using System;

// Token: 0x020000EA RID: 234
public enum ESkill
{
	// Token: 0x04000B5E RID: 2910
	DoNothing = -2,
	// Token: 0x04000B5F RID: 2911
	Charging,
	// Token: 0x04000B60 RID: 2912
	None,
	// Token: 0x04000B61 RID: 2913
	FireClaw,
	// Token: 0x04000B62 RID: 2914
	BlazingClaw,
	// Token: 0x04000B63 RID: 2915
	InfernoClaw,
	// Token: 0x04000B64 RID: 2916
	HellfireClaw,
	// Token: 0x04000B65 RID: 2917
	FlamePillar,
	// Token: 0x04000B66 RID: 2918
	BlazingPillar,
	// Token: 0x04000B67 RID: 2919
	InfernoPillar,
	// Token: 0x04000B68 RID: 2920
	SunPillar,
	// Token: 0x04000B69 RID: 2921
	SpitFire,
	// Token: 0x04000B6A RID: 2922
	Fireball,
	// Token: 0x04000B6B RID: 2923
	MegaFlare,
	// Token: 0x04000B6C RID: 2924
	CometStrike,
	// Token: 0x04000B6D RID: 2925
	PiercingHit,
	// Token: 0x04000B6E RID: 2926
	PiercingStrike,
	// Token: 0x04000B6F RID: 2927
	PiercingCrash,
	// Token: 0x04000B70 RID: 2928
	OmegaPierce,
	// Token: 0x04000B71 RID: 2929
	BlitzAttack,
	// Token: 0x04000B72 RID: 2930
	BlitzStrike,
	// Token: 0x04000B73 RID: 2931
	BlitzSmash,
	// Token: 0x04000B74 RID: 2932
	BlitzCrash,
	// Token: 0x04000B75 RID: 2933
	FireWall,
	// Token: 0x04000B76 RID: 2934
	InfernoWall,
	// Token: 0x04000B77 RID: 2935
	BlazingWall,
	// Token: 0x04000B78 RID: 2936
	HellfireWall,
	// Token: 0x04000B79 RID: 2937
	PsychUp,
	// Token: 0x04000B7A RID: 2938
	CriticalWound,
	// Token: 0x04000B7B RID: 2939
	DesperadoHit,
	// Token: 0x04000B7C RID: 2940
	SolarFlare,
	// Token: 0x04000B7D RID: 2941
	Counter,
	// Token: 0x04000B7E RID: 2942
	FrenzyHit,
	// Token: 0x04000B7F RID: 2943
	Charge,
	// Token: 0x04000B80 RID: 2944
	SuperCharge,
	// Token: 0x04000B81 RID: 2945
	MegaCharge,
	// Token: 0x04000B82 RID: 2946
	GigaCharge,
	// Token: 0x04000B83 RID: 2947
	StoneWall,
	// Token: 0x04000B84 RID: 2948
	RockWall,
	// Token: 0x04000B85 RID: 2949
	GiantWall,
	// Token: 0x04000B86 RID: 2950
	GigaWall,
	// Token: 0x04000B87 RID: 2951
	Grow,
	// Token: 0x04000B88 RID: 2952
	SuperGrow,
	// Token: 0x04000B89 RID: 2953
	MegaGrow,
	// Token: 0x04000B8A RID: 2954
	GigaGrow,
	// Token: 0x04000B8B RID: 2955
	PebbleBlast,
	// Token: 0x04000B8C RID: 2956
	StoneBlast,
	// Token: 0x04000B8D RID: 2957
	RockSmash,
	// Token: 0x04000B8E RID: 2958
	BoulderCrush,
	// Token: 0x04000B8F RID: 2959
	Cover,
	// Token: 0x04000B90 RID: 2960
	Protection,
	// Token: 0x04000B91 RID: 2961
	Safeguard,
	// Token: 0x04000B92 RID: 2962
	PerfectGuard,
	// Token: 0x04000B93 RID: 2963
	HardenShell,
	// Token: 0x04000B94 RID: 2964
	FortifyShell,
	// Token: 0x04000B95 RID: 2965
	PowerUp,
	// Token: 0x04000B96 RID: 2966
	Sharpen,
	// Token: 0x04000B97 RID: 2967
	FuryStrike,
	// Token: 0x04000B98 RID: 2968
	SwipeAttack,
	// Token: 0x04000B99 RID: 2969
	Earthquake,
	// Token: 0x04000B9A RID: 2970
	AncientProtection,
	// Token: 0x04000B9B RID: 2971
	HealingMist,
	// Token: 0x04000B9C RID: 2972
	HealingShower,
	// Token: 0x04000B9D RID: 2973
	HealingRain,
	// Token: 0x04000B9E RID: 2974
	HealingWaterfall,
	// Token: 0x04000B9F RID: 2975
	EnergyPool,
	// Token: 0x04000BA0 RID: 2976
	EnergyFountain,
	// Token: 0x04000BA1 RID: 2977
	EnergyRain,
	// Token: 0x04000BA2 RID: 2978
	EnergyFlood,
	// Token: 0x04000BA3 RID: 2979
	DrainHit,
	// Token: 0x04000BA4 RID: 2980
	DrainStrike,
	// Token: 0x04000BA5 RID: 2981
	DrainSmash,
	// Token: 0x04000BA6 RID: 2982
	DrainCrush,
	// Token: 0x04000BA7 RID: 2983
	ColdShot,
	// Token: 0x04000BA8 RID: 2984
	IceBurst,
	// Token: 0x04000BA9 RID: 2985
	IcicleBlast,
	// Token: 0x04000BAA RID: 2986
	SubzeroBeam,
	// Token: 0x04000BAB RID: 2987
	RegenPool,
	// Token: 0x04000BAC RID: 2988
	RegenFountain,
	// Token: 0x04000BAD RID: 2989
	RegenRain,
	// Token: 0x04000BAE RID: 2990
	RegenFlood,
	// Token: 0x04000BAF RID: 2991
	Osmosis,
	// Token: 0x04000BB0 RID: 2992
	CleansingMist,
	// Token: 0x04000BB1 RID: 2993
	IcicleField,
	// Token: 0x04000BB2 RID: 2994
	MassAbsorb,
	// Token: 0x04000BB3 RID: 2995
	Consume,
	// Token: 0x04000BB4 RID: 2996
	Rejuvenate,
	// Token: 0x04000BB5 RID: 2997
	PoisonFang,
	// Token: 0x04000BB6 RID: 2998
	VenomFang,
	// Token: 0x04000BB7 RID: 2999
	ToxicFang,
	// Token: 0x04000BB8 RID: 3000
	AcidFang,
	// Token: 0x04000BB9 RID: 3001
	PoisonBlast,
	// Token: 0x04000BBA RID: 3002
	VenomBlast,
	// Token: 0x04000BBB RID: 3003
	ToxicBlast,
	// Token: 0x04000BBC RID: 3004
	AcidBlast,
	// Token: 0x04000BBD RID: 3005
	SandShot,
	// Token: 0x04000BBE RID: 3006
	SandBlast,
	// Token: 0x04000BBF RID: 3007
	SandStorm,
	// Token: 0x04000BC0 RID: 3008
	SandHurricane,
	// Token: 0x04000BC1 RID: 3009
	PowerDrip,
	// Token: 0x04000BC2 RID: 3010
	PowerLeak,
	// Token: 0x04000BC3 RID: 3011
	Discharge,
	// Token: 0x04000BC4 RID: 3012
	Meltdown,
	// Token: 0x04000BC5 RID: 3013
	AirShot,
	// Token: 0x04000BC6 RID: 3014
	AirCutter,
	// Token: 0x04000BC7 RID: 3015
	SonicBoom,
	// Token: 0x04000BC8 RID: 3016
	WindBlade,
	// Token: 0x04000BC9 RID: 3017
	Berserk,
	// Token: 0x04000BCA RID: 3018
	FocusFire,
	// Token: 0x04000BCB RID: 3019
	PoisonMist,
	// Token: 0x04000BCC RID: 3020
	PoisonStorm,
	// Token: 0x04000BCD RID: 3021
	BlindingSmog,
	// Token: 0x04000BCE RID: 3022
	StickyGoo,
	// Token: 0x04000BCF RID: 3023
	SpeedUp,
	// Token: 0x04000BD0 RID: 3024
	SpeedDown,
	// Token: 0x04000BD1 RID: 3025
	SleepShot,
	// Token: 0x04000BD2 RID: 3026
	SleepBlast,
	// Token: 0x04000BD3 RID: 3027
	SleepMist,
	// Token: 0x04000BD4 RID: 3028
	SleepStorm,
	// Token: 0x04000BD5 RID: 3029
	Tornado,
	// Token: 0x04000BD6 RID: 3030
	MassBerserk,
	// Token: 0x04000BD7 RID: 3031
	Tailwind,
	// Token: 0x04000BD8 RID: 3032
	BattleCry
}
