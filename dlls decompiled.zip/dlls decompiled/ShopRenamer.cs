﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000053 RID: 83
public class ShopRenamer : MonoBehaviour
{
	// Token: 0x060003D3 RID: 979 RVA: 0x00022714 File Offset: 0x00020914
	public void SetIsTutorial()
	{
		this.m_IsTutorial = true;
		this.m_ShopName.text = "";
		CPlayerData.PlayerName = "My Card Shop";
		GameUIScreen.SetGameUIVisible(false);
		InteractionPlayerController.AddToolTip(EGameAction.MoveForward, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.MoveLeft, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.MoveBackward, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.MoveRight, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.Jump, false, false);
		InteractionPlayerController.AddToolTip(EGameAction.Sprint, false, false);
	}

	// Token: 0x060003D4 RID: 980 RVA: 0x00022780 File Offset: 0x00020980
	private void OnTriggerEnter(Collider other)
	{
		if (this.m_IsInArea || !this.m_IsTutorial)
		{
			return;
		}
		this.m_IsInArea = true;
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		CSingleton<InteractionPlayerController>.Instance.ForceLookAt(this.m_FollowTarget, 3f);
		InteractionPlayerController.SetPlayerPos(this.m_FollowTarget.position);
		CSingleton<InteractionPlayerController>.Instance.EnterLockMoveMode();
		GameUIScreen.SetGameUIVisible(false);
		this.m_IntroScreen.SetActive(true);
		CSingleton<TutorialManager>.Instance.m_TutorialTargetIndicator.SetActive(false);
		InteractionPlayerController.RemoveToolTip(EGameAction.MoveForward);
		InteractionPlayerController.RemoveToolTip(EGameAction.MoveLeft);
		InteractionPlayerController.RemoveToolTip(EGameAction.MoveBackward);
		InteractionPlayerController.RemoveToolTip(EGameAction.MoveRight);
		InteractionPlayerController.RemoveToolTip(EGameAction.Jump);
		InteractionPlayerController.RemoveToolTip(EGameAction.Sprint);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension_IntroScreen);
	}

	// Token: 0x060003D5 RID: 981 RVA: 0x00022838 File Offset: 0x00020A38
	public void OnPressGoNextButton()
	{
		this.m_IntroScreen.SetActive(false);
		this.m_NameScreen.SetActive(true);
		this.m_SetName.text = CPlayerData.PlayerName;
		this.m_SetNameInputDisplay.text = CPlayerData.PlayerName;
		this.m_ShopName.text = CPlayerData.PlayerName;
		this.m_SetNameInputDisplay.gameObject.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_IntroScreen);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension_NameScreen);
	}

	// Token: 0x060003D6 RID: 982 RVA: 0x000228B4 File Offset: 0x00020AB4
	public void OnPressRenameButton()
	{
		GameUIScreen.SetGameUIVisible(false);
		this.m_SetName.text = CPlayerData.PlayerName;
		this.m_SetNameInputDisplay.text = CPlayerData.PlayerName;
		this.m_ShopName.text = CPlayerData.PlayerName;
		this.m_NameScreen.SetActive(true);
		this.m_ConfirmNameScreen.SetActive(false);
		this.m_SetNameInputDisplay.gameObject.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_ConfirmNameScreen);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension_NameScreen);
	}

	// Token: 0x060003D7 RID: 983 RVA: 0x00022936 File Offset: 0x00020B36
	public void OnPressSetNameButton()
	{
		if (string.IsNullOrWhiteSpace(CPlayerData.PlayerName))
		{
			return;
		}
		this.m_NameScreen.SetActive(false);
		this.m_ConfirmNameScreen.SetActive(true);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_NameScreen);
		ControllerScreenUIExtManager.OnOpenScreen(this.m_ControllerScreenUIExtension_ConfirmNameScreen);
	}

	// Token: 0x060003D8 RID: 984 RVA: 0x00022974 File Offset: 0x00020B74
	public void OnInputChanged(string text)
	{
		this.m_SetNameInputDisplay.text = text;
		this.m_ShopName.text = text;
		this.m_SetNameInputDisplay.gameObject.SetActive(true);
		this.m_SetName.gameObject.SetActive(false);
		CPlayerData.PlayerName = text;
	}

	// Token: 0x060003D9 RID: 985 RVA: 0x000229C1 File Offset: 0x00020BC1
	public void OnInputTextSelected(string text)
	{
		this.m_SetNameInputDisplay.gameObject.SetActive(true);
		this.m_SetNameInput.text = text;
		this.m_SetName.gameObject.SetActive(false);
	}

	// Token: 0x060003DA RID: 986 RVA: 0x000229F4 File Offset: 0x00020BF4
	public void OnInputTextUpdated(string text)
	{
		this.m_SetNameInput.text = text;
		this.m_SetNameInputDisplay.text = text;
		this.m_SetName.text = text;
		this.m_ShopName.text = text;
		this.m_SetNameInputDisplay.gameObject.SetActive(false);
		this.m_SetName.gameObject.SetActive(true);
		CPlayerData.PlayerName = text;
	}

	// Token: 0x060003DB RID: 987 RVA: 0x00022A5C File Offset: 0x00020C5C
	public void OnPressConfirmShopName()
	{
		this.m_IntroScreen.SetActive(false);
		this.m_NameScreen.SetActive(false);
		this.m_ConfirmNameScreen.SetActive(false);
		base.gameObject.SetActive(false);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
		CSingleton<InteractionPlayerController>.Instance.ExitLockMoveMode();
		GameUIScreen.SetGameUIVisible(true);
		ControllerScreenUIExtManager.OnCloseScreen(this.m_ControllerScreenUIExtension_ConfirmNameScreen);
		if (this.m_IsTutorial)
		{
			this.m_IsTutorial = false;
			CPlayerData.m_TutorialIndex = 1;
			CSingleton<TutorialManager>.Instance.EvaluateTaskVisibility();
			CSingleton<TutorialManager>.Instance.m_TutorialTargetIndicator.SetActive(false);
		}
	}

	// Token: 0x060003DC RID: 988 RVA: 0x00022AED File Offset: 0x00020CED
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x060003DD RID: 989 RVA: 0x00022B0E File Offset: 0x00020D0E
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x060003DE RID: 990 RVA: 0x00022B2F File Offset: 0x00020D2F
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		if (CPlayerData.m_TutorialIndex != 0)
		{
			this.m_ShopName.text = CPlayerData.PlayerName;
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x04000497 RID: 1175
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_IntroScreen;

	// Token: 0x04000498 RID: 1176
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_NameScreen;

	// Token: 0x04000499 RID: 1177
	public ControllerScreenUIExtension m_ControllerScreenUIExtension_ConfirmNameScreen;

	// Token: 0x0400049A RID: 1178
	public Transform m_FollowTarget;

	// Token: 0x0400049B RID: 1179
	public GameObject m_IntroScreen;

	// Token: 0x0400049C RID: 1180
	public GameObject m_NameScreen;

	// Token: 0x0400049D RID: 1181
	public GameObject m_ConfirmNameScreen;

	// Token: 0x0400049E RID: 1182
	public TMP_InputField m_SetNameInput;

	// Token: 0x0400049F RID: 1183
	public TextMeshProUGUI m_SetNameInputDisplay;

	// Token: 0x040004A0 RID: 1184
	public TextMeshProUGUI m_SetName;

	// Token: 0x040004A1 RID: 1185
	public TextMeshProUGUI m_ShopName;

	// Token: 0x040004A2 RID: 1186
	private bool m_IsInArea;

	// Token: 0x040004A3 RID: 1187
	private bool m_IsTutorial;
}
