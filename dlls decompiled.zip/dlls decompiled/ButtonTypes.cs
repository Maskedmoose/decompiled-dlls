﻿using System;

// Token: 0x0200013C RID: 316
public enum ButtonTypes
{
	// Token: 0x04001120 RID: 4384
	NotDefined,
	// Token: 0x04001121 RID: 4385
	Previous,
	// Token: 0x04001122 RID: 4386
	Next
}
