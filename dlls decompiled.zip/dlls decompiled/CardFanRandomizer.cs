﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000002 RID: 2
public class CardFanRandomizer : MonoBehaviour
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	private void OnEnable()
	{
		this.RandomizePlayCard();
	}

	// Token: 0x06000002 RID: 2 RVA: 0x00002058 File Offset: 0x00000258
	public void RandomizePlayCard()
	{
		for (int i = 0; i < this.m_CardFanGrpList.Count; i++)
		{
			this.m_CardFanGrpList[i].SetActive(false);
		}
		this.m_CardFanGrpList[Random.Range(0, this.m_CardFanGrpList.Count)].SetActive(true);
		Material material = this.m_PlayCardMatList[Random.Range(0, this.m_PlayCardMatList.Count)];
		Material material2 = this.m_PlayCardMatList[Random.Range(0, this.m_PlayCardMatList.Count)];
		for (int j = 0; j < this.m_MeshRendererList.Count; j++)
		{
			this.m_MeshRendererList[j].material = material;
		}
		this.m_MeshRendererList[0].material = material2;
	}

	// Token: 0x04000001 RID: 1
	public List<GameObject> m_CardFanGrpList;

	// Token: 0x04000002 RID: 2
	public List<Material> m_PlayCardMatList;

	// Token: 0x04000003 RID: 3
	public List<MeshRenderer> m_MeshRendererList;
}
