﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000051 RID: 81
public class ShelfManager : CSingleton<ShelfManager>
{
	// Token: 0x060003A1 RID: 929 RVA: 0x0001FE2C File Offset: 0x0001E02C
	public void SaveInteractableObjectData(bool ignoreFinishLoadingCheck = false)
	{
		if (!ignoreFinishLoadingCheck && !this.m_FinishLoadingObjectData)
		{
			Debug.Log("Dont SaveInteractableObjectData, havent finish load data");
			return;
		}
		CSingleton<CustomerManager>.Instance.SaveCustomerData();
		CSingleton<WorkerManager>.Instance.SaveWorkerData();
		this.m_InteractableObjectSaveDataList.Clear();
		for (int i = 0; i < this.m_InteractableObjectList.Count; i++)
		{
			if (this.m_InteractableObjectList[i] && this.m_InteractableObjectList[i].m_IsGenericObject)
			{
				InteractableObjectSaveData interactableObjectSaveData = new InteractableObjectSaveData();
				interactableObjectSaveData.pos.SetData(this.m_InteractableObjectList[i].transform.position);
				interactableObjectSaveData.rot.SetData(this.m_InteractableObjectList[i].transform.rotation);
				interactableObjectSaveData.objectType = this.m_InteractableObjectList[i].m_ObjectType;
				interactableObjectSaveData.isBoxed = this.m_InteractableObjectList[i].GetIsBoxedUp();
				if (interactableObjectSaveData.isBoxed)
				{
					interactableObjectSaveData.boxedPackagePos.SetData(this.m_InteractableObjectList[i].GetPackagingBoxShelf().transform.position);
					interactableObjectSaveData.boxedPackageRot.SetData(this.m_InteractableObjectList[i].GetPackagingBoxShelf().transform.rotation);
				}
				if (this.m_InteractableObjectList[i].GetIsMovingObject())
				{
					interactableObjectSaveData.isBoxed = true;
					interactableObjectSaveData.boxedPackagePos.SetData(this.m_InteractableObjectList[i].transform.position);
					interactableObjectSaveData.boxedPackageRot.SetData(this.m_InteractableObjectList[i].transform.rotation);
				}
				this.m_InteractableObjectSaveDataList.Add(interactableObjectSaveData);
			}
		}
		this.m_ShelfSaveDataList.Clear();
		for (int j = 0; j < this.m_ShelfList.Count; j++)
		{
			if (this.m_ShelfList[j])
			{
				ShelfSaveData shelfSaveData = new ShelfSaveData();
				List<ItemTypeAmount> list = new List<ItemTypeAmount>();
				for (int k = 0; k < this.m_ShelfList[j].GetItemCompartmentList().Count; k++)
				{
					list.Add(new ItemTypeAmount
					{
						itemType = this.m_ShelfList[j].GetItemCompartmentList()[k].GetItemType(),
						amount = this.m_ShelfList[j].GetItemCompartmentList()[k].GetItemCount()
					});
				}
				shelfSaveData.itemTypeAmountList = list;
				shelfSaveData.pos.SetData(this.m_ShelfList[j].transform.position);
				shelfSaveData.rot.SetData(this.m_ShelfList[j].transform.rotation);
				shelfSaveData.objectType = this.m_ShelfList[j].m_ObjectType;
				shelfSaveData.isBoxed = this.m_ShelfList[j].GetIsBoxedUp();
				if (shelfSaveData.isBoxed)
				{
					shelfSaveData.boxedPackagePos.SetData(this.m_ShelfList[j].GetPackagingBoxShelf().transform.position);
					shelfSaveData.boxedPackageRot.SetData(this.m_ShelfList[j].GetPackagingBoxShelf().transform.rotation);
				}
				if (this.m_ShelfList[j].GetIsMovingObject())
				{
					shelfSaveData.isBoxed = true;
					shelfSaveData.boxedPackagePos.SetData(this.m_ShelfList[j].transform.position);
					shelfSaveData.boxedPackageRot.SetData(this.m_ShelfList[j].transform.rotation);
				}
				this.m_ShelfSaveDataList.Add(shelfSaveData);
			}
		}
		this.m_WarehouseShelfSaveDataList.Clear();
		for (int l = 0; l < this.m_WarehouseShelfList.Count; l++)
		{
			if (this.m_WarehouseShelfList[l])
			{
				WarehouseShelfSaveData warehouseShelfSaveData = new WarehouseShelfSaveData();
				warehouseShelfSaveData.pos.SetData(this.m_WarehouseShelfList[l].transform.position);
				warehouseShelfSaveData.rot.SetData(this.m_WarehouseShelfList[l].transform.rotation);
				warehouseShelfSaveData.objectType = this.m_WarehouseShelfList[l].m_ObjectType;
				warehouseShelfSaveData.isBoxed = this.m_WarehouseShelfList[l].GetIsBoxedUp();
				if (warehouseShelfSaveData.isBoxed)
				{
					warehouseShelfSaveData.boxedPackagePos.SetData(this.m_WarehouseShelfList[l].GetPackagingBoxShelf().transform.position);
					warehouseShelfSaveData.boxedPackageRot.SetData(this.m_WarehouseShelfList[l].GetPackagingBoxShelf().transform.rotation);
				}
				if (this.m_WarehouseShelfList[l].GetIsMovingObject())
				{
					warehouseShelfSaveData.isBoxed = true;
					warehouseShelfSaveData.boxedPackagePos.SetData(this.m_WarehouseShelfList[l].transform.position);
					warehouseShelfSaveData.boxedPackageRot.SetData(this.m_WarehouseShelfList[l].transform.rotation);
				}
				warehouseShelfSaveData.compartmentItemType = new List<EItemType>();
				for (int m = 0; m < this.m_WarehouseShelfList[l].GetStorageCompartmentList().Count; m++)
				{
					warehouseShelfSaveData.compartmentItemType.Add(this.m_WarehouseShelfList[l].GetStorageCompartmentList()[m].GetShelfCompartment().GetItemType());
				}
				this.m_WarehouseShelfSaveDataList.Add(warehouseShelfSaveData);
			}
		}
		this.m_CardShelfSaveDataList.Clear();
		for (int n = 0; n < this.m_CardShelfList.Count; n++)
		{
			if (this.m_CardShelfList[n])
			{
				CardShelfSaveData cardShelfSaveData = new CardShelfSaveData();
				List<CardData> list2 = new List<CardData>();
				cardShelfSaveData.pos.SetData(this.m_CardShelfList[n].transform.position);
				cardShelfSaveData.rot.SetData(this.m_CardShelfList[n].transform.rotation);
				cardShelfSaveData.objectType = this.m_CardShelfList[n].m_ObjectType;
				cardShelfSaveData.isBoxed = this.m_CardShelfList[n].GetIsBoxedUp();
				if (cardShelfSaveData.isBoxed)
				{
					cardShelfSaveData.boxedPackagePos.SetData(this.m_CardShelfList[n].GetPackagingBoxShelf().transform.position);
					cardShelfSaveData.boxedPackageRot.SetData(this.m_CardShelfList[n].GetPackagingBoxShelf().transform.rotation);
				}
				if (this.m_CardShelfList[n].GetIsMovingObject())
				{
					cardShelfSaveData.isBoxed = true;
					cardShelfSaveData.boxedPackagePos.SetData(this.m_CardShelfList[n].transform.position);
					cardShelfSaveData.boxedPackageRot.SetData(this.m_CardShelfList[n].transform.rotation);
				}
				for (int num = 0; num < this.m_CardShelfList[n].GetCardCompartmentList().Count; num++)
				{
					if (this.m_CardShelfList[n].GetCardCompartmentList()[num].m_StoredCardList.Count > 0)
					{
						list2.Add(this.m_CardShelfList[n].GetCardCompartmentList()[num].m_StoredCardList[0].m_Card3dUI.m_CardUI.GetCardData());
					}
					else
					{
						list2.Add(null);
					}
				}
				cardShelfSaveData.cardDataList = list2;
				this.m_CardShelfSaveDataList.Add(cardShelfSaveData);
			}
		}
		this.m_PlayTableSaveDataList.Clear();
		for (int num2 = 0; num2 < this.m_PlayTableList.Count; num2++)
		{
			if (this.m_PlayTableList[num2])
			{
				PlayTableSaveData playTableSaveData = new PlayTableSaveData();
				playTableSaveData.pos.SetData(this.m_PlayTableList[num2].transform.position);
				playTableSaveData.rot.SetData(this.m_PlayTableList[num2].transform.rotation);
				playTableSaveData.objectType = this.m_PlayTableList[num2].m_ObjectType;
				playTableSaveData.isBoxed = this.m_PlayTableList[num2].GetIsBoxedUp();
				if (playTableSaveData.isBoxed)
				{
					playTableSaveData.boxedPackagePos.SetData(this.m_PlayTableList[num2].GetPackagingBoxShelf().transform.position);
					playTableSaveData.boxedPackageRot.SetData(this.m_PlayTableList[num2].GetPackagingBoxShelf().transform.rotation);
				}
				if (this.m_PlayTableList[num2].GetIsMovingObject())
				{
					playTableSaveData.isBoxed = true;
					playTableSaveData.boxedPackagePos.SetData(this.m_PlayTableList[num2].transform.position);
					playTableSaveData.boxedPackageRot.SetData(this.m_PlayTableList[num2].transform.rotation);
				}
				playTableSaveData.hasStartPlay = this.m_PlayTableList[num2].GetHasStartPlay();
				playTableSaveData.isSeatOccupied = this.m_PlayTableList[num2].GetIsSeatOccupied();
				playTableSaveData.isCustomerSmelly = this.m_PlayTableList[num2].GetIsCustomerSmelly();
				playTableSaveData.playTableFee = this.m_PlayTableList[num2].GetPlayTableFee();
				playTableSaveData.currentPlayerCount = this.m_PlayTableList[num2].GetCurrentPlayerCount();
				playTableSaveData.currentPlayTime = this.m_PlayTableList[num2].GetCurrentPlayTime();
				playTableSaveData.currentPlayTimeMax = this.m_PlayTableList[num2].GetCurrentPlayTimeMax();
				this.m_PlayTableSaveDataList.Add(playTableSaveData);
			}
		}
		this.m_AutoCleanserSaveDataList.Clear();
		for (int num3 = 0; num3 < this.m_AutoCleanserList.Count; num3++)
		{
			if (this.m_AutoCleanserList[num3])
			{
				AutoCleanserSaveData autoCleanserSaveData = new AutoCleanserSaveData();
				autoCleanserSaveData.isTurnedOn = this.m_AutoCleanserList[num3].IsTurnedOn();
				autoCleanserSaveData.isNeedRefill = this.m_AutoCleanserList[num3].IsNeedRefill();
				autoCleanserSaveData.itemAmount = this.m_AutoCleanserList[num3].GetStoredItemList().Count;
				List<float> list3 = new List<float>();
				for (int num4 = 0; num4 < this.m_AutoCleanserList[num3].GetStoredItemList().Count; num4++)
				{
					list3.Add(this.m_AutoCleanserList[num3].GetStoredItemList()[num4].GetContentFill());
				}
				autoCleanserSaveData.contentFillList = list3;
				autoCleanserSaveData.pos.SetData(this.m_AutoCleanserList[num3].transform.position);
				autoCleanserSaveData.rot.SetData(this.m_AutoCleanserList[num3].transform.rotation);
				autoCleanserSaveData.objectType = this.m_AutoCleanserList[num3].m_ObjectType;
				autoCleanserSaveData.isBoxed = this.m_AutoCleanserList[num3].GetIsBoxedUp();
				if (autoCleanserSaveData.isBoxed)
				{
					autoCleanserSaveData.boxedPackagePos.SetData(this.m_AutoCleanserList[num3].GetPackagingBoxShelf().transform.position);
					autoCleanserSaveData.boxedPackageRot.SetData(this.m_AutoCleanserList[num3].GetPackagingBoxShelf().transform.rotation);
				}
				if (this.m_AutoCleanserList[num3].GetIsMovingObject())
				{
					autoCleanserSaveData.isBoxed = true;
					autoCleanserSaveData.boxedPackagePos.SetData(this.m_AutoCleanserList[num3].transform.position);
					autoCleanserSaveData.boxedPackageRot.SetData(this.m_AutoCleanserList[num3].transform.rotation);
				}
				this.m_AutoCleanserSaveDataList.Add(autoCleanserSaveData);
			}
		}
		this.m_WorkbenchSaveDataList.Clear();
		for (int num5 = 0; num5 < this.m_WorkbenchList.Count; num5++)
		{
			if (this.m_WorkbenchList[num5])
			{
				WorkbenchSaveData workbenchSaveData = new WorkbenchSaveData();
				List<EItemType> list4 = new List<EItemType>();
				for (int num6 = 0; num6 < this.m_WorkbenchList[num5].m_StoredItemList.Count; num6++)
				{
					list4.Add(this.m_WorkbenchList[num5].m_StoredItemList[num6].GetItemType());
				}
				workbenchSaveData.itemTypeList = list4;
				workbenchSaveData.pos.SetData(this.m_WorkbenchList[num5].transform.position);
				workbenchSaveData.rot.SetData(this.m_WorkbenchList[num5].transform.rotation);
				workbenchSaveData.objectType = this.m_WorkbenchList[num5].m_ObjectType;
				workbenchSaveData.isBoxed = this.m_WorkbenchList[num5].GetIsBoxedUp();
				if (workbenchSaveData.isBoxed)
				{
					workbenchSaveData.boxedPackagePos.SetData(this.m_WorkbenchList[num5].GetPackagingBoxShelf().transform.position);
					workbenchSaveData.boxedPackageRot.SetData(this.m_WorkbenchList[num5].GetPackagingBoxShelf().transform.rotation);
				}
				if (this.m_WorkbenchList[num5].GetIsMovingObject())
				{
					workbenchSaveData.isBoxed = true;
					workbenchSaveData.boxedPackagePos.SetData(this.m_WorkbenchList[num5].transform.position);
					workbenchSaveData.boxedPackageRot.SetData(this.m_WorkbenchList[num5].transform.rotation);
				}
				this.m_WorkbenchSaveDataList.Add(workbenchSaveData);
			}
		}
		this.m_PackageBoxItemSaveDataList.Clear();
		for (int num7 = 0; num7 < RestockManager.GetItemPackagingBoxList().Count; num7++)
		{
			if (RestockManager.GetItemPackagingBoxList()[num7])
			{
				PackageBoxItemaveData packageBoxItemaveData = new PackageBoxItemaveData();
				packageBoxItemaveData.itemTypeAmount = new ItemTypeAmount
				{
					itemType = RestockManager.GetItemPackagingBoxList()[num7].m_ItemCompartment.GetItemType(),
					amount = RestockManager.GetItemPackagingBoxList()[num7].m_ItemCompartment.GetItemCount()
				};
				packageBoxItemaveData.isBigBox = RestockManager.GetItemPackagingBoxList()[num7].m_IsBigBox;
				packageBoxItemaveData.isStored = RestockManager.GetItemPackagingBoxList()[num7].m_IsStored;
				packageBoxItemaveData.storedWarehouseShelfIndex = RestockManager.GetItemPackagingBoxList()[num7].GeStoredWarehouseShelfIndex();
				packageBoxItemaveData.storageCompartmentIndex = RestockManager.GetItemPackagingBoxList()[num7].GetStorageCompartmentIndex();
				packageBoxItemaveData.pos.SetData(RestockManager.GetItemPackagingBoxList()[num7].transform.position);
				packageBoxItemaveData.rot.SetData(RestockManager.GetItemPackagingBoxList()[num7].transform.rotation);
				this.m_PackageBoxItemSaveDataList.Add(packageBoxItemaveData);
			}
		}
		CPlayerData.m_ShelfSaveDataList = this.m_ShelfSaveDataList;
		CPlayerData.m_WarehouseShelfSaveDataList = this.m_WarehouseShelfSaveDataList;
		CPlayerData.m_PackageBoxItemSaveDataList = this.m_PackageBoxItemSaveDataList;
		CPlayerData.m_InteractableObjectSaveDataList = this.m_InteractableObjectSaveDataList;
		CPlayerData.m_CardShelfSaveDataList = this.m_CardShelfSaveDataList;
		CPlayerData.m_PlayTableSaveDataList = this.m_PlayTableSaveDataList;
		CPlayerData.m_AutoCleanserSaveDataList = this.m_AutoCleanserSaveDataList;
		CPlayerData.m_WorkbenchSaveDataList = this.m_WorkbenchSaveDataList;
	}

	// Token: 0x060003A2 RID: 930 RVA: 0x00020DE3 File Offset: 0x0001EFE3
	private IEnumerator CheckLoadCorrect()
	{
		if (Time.timeScale != 0f)
		{
			yield return new WaitForSeconds(7f);
		}
		else
		{
			yield return new WaitForSecondsRealtime(30f);
		}
		if (!this.m_FinishLoadingObjectData)
		{
			Debug.Log("Shelf data not loaded properly");
			CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShelfDataNotLoadedCorrectly);
			GameInstance.m_HasLoadingError = true;
			Time.timeScale = 1f;
			CSingleton<CGameManager>.Instance.LoadMainLevelAsync("Title", -1);
			CSingleton<LoadingScreen>.Instance.gameObject.SetActive(false);
		}
		yield break;
	}

	// Token: 0x060003A3 RID: 931 RVA: 0x00020DF4 File Offset: 0x0001EFF4
	public void LoadInteractableObjectData()
	{
		base.StartCoroutine(this.CheckLoadCorrect());
		this.m_FinishLoadingObjectData = false;
		RestockManager.DestroyAllObject();
		ShelfManager.DestroyAllObject();
		this.m_ShelfSaveDataList = CPlayerData.m_ShelfSaveDataList;
		this.m_WarehouseShelfSaveDataList = CPlayerData.m_WarehouseShelfSaveDataList;
		this.m_PackageBoxItemSaveDataList = CPlayerData.m_PackageBoxItemSaveDataList;
		this.m_InteractableObjectSaveDataList = CPlayerData.m_InteractableObjectSaveDataList;
		this.m_CardShelfSaveDataList = CPlayerData.m_CardShelfSaveDataList;
		this.m_PlayTableSaveDataList = CPlayerData.m_PlayTableSaveDataList;
		this.m_AutoCleanserSaveDataList = CPlayerData.m_AutoCleanserSaveDataList;
		this.m_WorkbenchSaveDataList = CPlayerData.m_WorkbenchSaveDataList;
		this.m_SpawnedShelfList.Clear();
		for (int i = 0; i < this.m_ShelfSaveDataList.Count; i++)
		{
			Shelf component = ShelfManager.SpawnInteractableObject(this.m_ShelfSaveDataList[i].objectType).GetComponent<Shelf>();
			component.transform.position = this.m_ShelfSaveDataList[i].pos.Data;
			component.transform.rotation = this.m_ShelfSaveDataList[i].rot.Data;
			this.m_SpawnedShelfList.Add(component);
		}
		this.m_SpawnedWarehouseShelfList.Clear();
		for (int j = 0; j < this.m_WarehouseShelfSaveDataList.Count; j++)
		{
			WarehouseShelf component2 = ShelfManager.SpawnInteractableObject(this.m_WarehouseShelfSaveDataList[j].objectType).GetComponent<WarehouseShelf>();
			component2.transform.position = this.m_WarehouseShelfSaveDataList[j].pos.Data;
			component2.transform.rotation = this.m_WarehouseShelfSaveDataList[j].rot.Data;
			this.m_SpawnedWarehouseShelfList.Add(component2);
		}
		this.m_SpawnedCardShelfList.Clear();
		for (int k = 0; k < this.m_CardShelfSaveDataList.Count; k++)
		{
			CardShelf component3 = ShelfManager.SpawnInteractableObject(this.m_CardShelfSaveDataList[k].objectType).GetComponent<CardShelf>();
			component3.transform.position = this.m_CardShelfSaveDataList[k].pos.Data;
			component3.transform.rotation = this.m_CardShelfSaveDataList[k].rot.Data;
			this.m_SpawnedCardShelfList.Add(component3);
		}
		this.m_SpawnedPlayTableList.Clear();
		for (int l = 0; l < this.m_PlayTableSaveDataList.Count; l++)
		{
			InteractablePlayTable component4 = ShelfManager.SpawnInteractableObject(this.m_PlayTableSaveDataList[l].objectType).GetComponent<InteractablePlayTable>();
			component4.transform.position = this.m_PlayTableSaveDataList[l].pos.Data;
			component4.transform.rotation = this.m_PlayTableSaveDataList[l].rot.Data;
			this.m_SpawnedPlayTableList.Add(component4);
		}
		this.m_SpawnedAutoCleanserList.Clear();
		for (int m = 0; m < this.m_AutoCleanserSaveDataList.Count; m++)
		{
			InteractableAutoCleanser component5 = ShelfManager.SpawnInteractableObject(this.m_AutoCleanserSaveDataList[m].objectType).GetComponent<InteractableAutoCleanser>();
			component5.transform.position = this.m_AutoCleanserSaveDataList[m].pos.Data;
			component5.transform.rotation = this.m_AutoCleanserSaveDataList[m].rot.Data;
			this.m_SpawnedAutoCleanserList.Add(component5);
		}
		this.m_SpawnedWorkbenchList.Clear();
		for (int n = 0; n < this.m_WorkbenchSaveDataList.Count; n++)
		{
			InteractableWorkbench component6 = ShelfManager.SpawnInteractableObject(this.m_WorkbenchSaveDataList[n].objectType).GetComponent<InteractableWorkbench>();
			component6.transform.position = this.m_WorkbenchSaveDataList[n].pos.Data;
			component6.transform.rotation = this.m_WorkbenchSaveDataList[n].rot.Data;
			this.m_SpawnedWorkbenchList.Add(component6);
		}
		this.m_SpawnedInteractableObjectList.Clear();
		for (int num = 0; num < this.m_InteractableObjectSaveDataList.Count; num++)
		{
			InteractableObject interactableObject = ShelfManager.SpawnInteractableObject(this.m_InteractableObjectSaveDataList[num].objectType);
			interactableObject.transform.position = this.m_InteractableObjectSaveDataList[num].pos.Data;
			interactableObject.transform.rotation = this.m_InteractableObjectSaveDataList[num].rot.Data;
			this.m_SpawnedInteractableObjectList.Add(interactableObject);
		}
		this.m_SpawnedPackageBoxItemList.Clear();
		for (int num2 = 0; num2 < this.m_PackageBoxItemSaveDataList.Count; num2++)
		{
			EItemType itemType = this.m_PackageBoxItemSaveDataList[num2].itemTypeAmount.itemType;
			int amount = this.m_PackageBoxItemSaveDataList[num2].itemTypeAmount.amount;
			InteractablePackagingBox_Item interactablePackagingBox_Item = RestockManager.SpawnPackageBoxItem(itemType, amount, this.m_PackageBoxItemSaveDataList[num2].isBigBox);
			interactablePackagingBox_Item.transform.position = this.m_PackageBoxItemSaveDataList[num2].pos.Data;
			interactablePackagingBox_Item.transform.rotation = this.m_PackageBoxItemSaveDataList[num2].rot.Data;
			this.m_SpawnedPackageBoxItemList.Add(interactablePackagingBox_Item);
		}
		base.StartCoroutine(this.DelayLoad());
	}

	// Token: 0x060003A4 RID: 932 RVA: 0x0002135B File Offset: 0x0001F55B
	private IEnumerator DelayLoad()
	{
		yield return new WaitForSeconds(0.05f);
		int num = 0;
		while (num < this.m_SpawnedShelfList.Count && num < this.m_ShelfSaveDataList.Count)
		{
			this.m_SpawnedShelfList[num].LoadItemCompartment(this.m_ShelfSaveDataList[num].itemTypeAmountList);
			num++;
		}
		int num2 = 0;
		while (num2 < this.m_SpawnedCardShelfList.Count && num2 < this.m_CardShelfSaveDataList.Count)
		{
			this.m_SpawnedCardShelfList[num2].LoadCardCompartment(this.m_CardShelfSaveDataList[num2].cardDataList);
			num2++;
		}
		int num3 = 0;
		while (num3 < this.m_SpawnedPackageBoxItemList.Count && num3 < this.m_PackageBoxItemSaveDataList.Count)
		{
			if (this.m_PackageBoxItemSaveDataList[num3].isStored)
			{
				WarehouseShelf warehouseShelf = null;
				ShelfCompartment shelfCompartment = null;
				if (this.m_PackageBoxItemSaveDataList[num3].storedWarehouseShelfIndex < this.m_SpawnedWarehouseShelfList.Count)
				{
					warehouseShelf = this.m_SpawnedWarehouseShelfList[this.m_PackageBoxItemSaveDataList[num3].storedWarehouseShelfIndex];
				}
				if (warehouseShelf)
				{
					shelfCompartment = warehouseShelf.GetWarehouseCompartment(this.m_PackageBoxItemSaveDataList[num3].storageCompartmentIndex);
				}
				if (shelfCompartment)
				{
					this.m_SpawnedPackageBoxItemList[num3].SetPhysicsEnabled(false);
					this.m_SpawnedPackageBoxItemList[num3].DispenseItem(false, shelfCompartment);
				}
			}
			num3++;
		}
		yield return new WaitForSeconds(0.5f);
		int num4 = 0;
		while (num4 < this.m_SpawnedShelfList.Count && num4 < this.m_ShelfSaveDataList.Count)
		{
			if (this.m_ShelfSaveDataList[num4].isBoxed)
			{
				this.m_SpawnedShelfList[num4].BoxUpObject(false);
				this.m_SpawnedShelfList[num4].GetPackagingBoxShelf().transform.position = this.m_ShelfSaveDataList[num4].boxedPackagePos.Data;
				this.m_SpawnedShelfList[num4].GetPackagingBoxShelf().transform.rotation = this.m_ShelfSaveDataList[num4].boxedPackageRot.Data;
			}
			num4++;
		}
		int num5 = 0;
		while (num5 < this.m_SpawnedWarehouseShelfList.Count && num5 < this.m_WarehouseShelfSaveDataList.Count)
		{
			for (int i = 0; i < this.m_SpawnedWarehouseShelfList[num5].GetStorageCompartmentList().Count; i++)
			{
				if (this.m_WarehouseShelfSaveDataList[num5].compartmentItemType != null)
				{
					if (i >= this.m_WarehouseShelfSaveDataList[num5].compartmentItemType.Count)
					{
						break;
					}
					this.m_SpawnedWarehouseShelfList[num5].GetStorageCompartmentList()[i].GetShelfCompartment().SetCompartmentItemType(this.m_WarehouseShelfSaveDataList[num5].compartmentItemType[i]);
					this.m_SpawnedWarehouseShelfList[num5].GetStorageCompartmentList()[i].GetShelfCompartment().SetPriceTagItemAmountText();
					this.m_SpawnedWarehouseShelfList[num5].GetStorageCompartmentList()[i].GetShelfCompartment().SetPriceTagItemImage(this.m_WarehouseShelfSaveDataList[num5].compartmentItemType[i]);
				}
			}
			if (this.m_WarehouseShelfSaveDataList[num5].isBoxed)
			{
				this.m_SpawnedWarehouseShelfList[num5].BoxUpObject(false);
				this.m_SpawnedWarehouseShelfList[num5].GetPackagingBoxShelf().transform.position = this.m_WarehouseShelfSaveDataList[num5].boxedPackagePos.Data;
				this.m_SpawnedWarehouseShelfList[num5].GetPackagingBoxShelf().transform.rotation = this.m_WarehouseShelfSaveDataList[num5].boxedPackageRot.Data;
			}
			num5++;
		}
		int num6 = 0;
		while (num6 < this.m_SpawnedCardShelfList.Count && num6 < this.m_CardShelfSaveDataList.Count)
		{
			if (this.m_CardShelfSaveDataList[num6].isBoxed)
			{
				this.m_SpawnedCardShelfList[num6].BoxUpObject(false);
				this.m_SpawnedCardShelfList[num6].GetPackagingBoxShelf().transform.position = this.m_CardShelfSaveDataList[num6].boxedPackagePos.Data;
				this.m_SpawnedCardShelfList[num6].GetPackagingBoxShelf().transform.rotation = this.m_CardShelfSaveDataList[num6].boxedPackageRot.Data;
			}
			num6++;
		}
		int num7 = 0;
		while (num7 < this.m_SpawnedPlayTableList.Count && num7 < this.m_PlayTableSaveDataList.Count)
		{
			if (this.m_PlayTableSaveDataList[num7].isBoxed)
			{
				this.m_SpawnedPlayTableList[num7].BoxUpObject(false);
				this.m_SpawnedPlayTableList[num7].GetPackagingBoxShelf().transform.position = this.m_PlayTableSaveDataList[num7].boxedPackagePos.Data;
				this.m_SpawnedPlayTableList[num7].GetPackagingBoxShelf().transform.rotation = this.m_PlayTableSaveDataList[num7].boxedPackageRot.Data;
			}
			else
			{
				this.m_SpawnedPlayTableList[num7].LoadData(this.m_PlayTableSaveDataList[num7]);
			}
			num7++;
		}
		int num8 = 0;
		while (num8 < this.m_SpawnedAutoCleanserList.Count && num8 < this.m_AutoCleanserSaveDataList.Count)
		{
			if (this.m_AutoCleanserSaveDataList[num8].isBoxed)
			{
				this.m_SpawnedAutoCleanserList[num8].BoxUpObject(false);
				this.m_SpawnedAutoCleanserList[num8].GetPackagingBoxShelf().transform.position = this.m_AutoCleanserSaveDataList[num8].boxedPackagePos.Data;
				this.m_SpawnedAutoCleanserList[num8].GetPackagingBoxShelf().transform.rotation = this.m_AutoCleanserSaveDataList[num8].boxedPackageRot.Data;
			}
			else
			{
				this.m_SpawnedAutoCleanserList[num8].LoadData(this.m_AutoCleanserSaveDataList[num8]);
			}
			num8++;
		}
		int num9 = 0;
		while (num9 < this.m_SpawnedWorkbenchList.Count && num9 < this.m_WorkbenchSaveDataList.Count)
		{
			if (this.m_WorkbenchSaveDataList[num9].isBoxed)
			{
				this.m_SpawnedWorkbenchList[num9].BoxUpObject(false);
				this.m_SpawnedWorkbenchList[num9].GetPackagingBoxShelf().transform.position = this.m_WorkbenchSaveDataList[num9].boxedPackagePos.Data;
				this.m_SpawnedWorkbenchList[num9].GetPackagingBoxShelf().transform.rotation = this.m_WorkbenchSaveDataList[num9].boxedPackageRot.Data;
			}
			else
			{
				this.m_SpawnedWorkbenchList[num9].LoadData(this.m_WorkbenchSaveDataList[num9]);
			}
			num9++;
		}
		int num10 = 0;
		while (num10 < this.m_SpawnedInteractableObjectList.Count && num10 < this.m_InteractableObjectSaveDataList.Count)
		{
			if (this.m_InteractableObjectSaveDataList[num10].isBoxed)
			{
				this.m_SpawnedInteractableObjectList[num10].BoxUpObject(false);
				this.m_SpawnedInteractableObjectList[num10].GetPackagingBoxShelf().transform.position = this.m_InteractableObjectSaveDataList[num10].boxedPackagePos.Data;
				this.m_SpawnedInteractableObjectList[num10].GetPackagingBoxShelf().transform.rotation = this.m_InteractableObjectSaveDataList[num10].boxedPackageRot.Data;
			}
			num10++;
		}
		if (this.m_CashierCounterList.Count == 0)
		{
			Transform randomPackageSpawnPos = RestockManager.GetRandomPackageSpawnPos();
			ShelfManager.SpawnInteractableObjectInPackageBox(EObjectType.CashCounter, randomPackageSpawnPos.position, randomPackageSpawnPos.rotation);
		}
		this.m_FinishLoadingObjectData = true;
		CEventManager.QueueEvent(new CEventPlayer_GameDataFinishLoaded());
		CSingleton<LoadingScreen>.Instance.FinishLoading();
		GameInstance.m_FinishedSavefileLoading = true;
		yield break;
	}

	// Token: 0x060003A5 RID: 933 RVA: 0x0002136C File Offset: 0x0001F56C
	public static InteractableObject SpawnInteractableObject(EObjectType objType)
	{
		InteractableObject interactableObject = Object.Instantiate<InteractableObject>(InventoryBase.GetSpawnInteractableObjectPrefab(objType), Vector3.zero, Quaternion.identity, CSingleton<ShelfManager>.Instance.m_ShelfParentGrp);
		interactableObject.name = objType.ToString() + CSingleton<ShelfManager>.Instance.m_SpawnedObjectCount.ToString();
		CSingleton<ShelfManager>.Instance.m_SpawnedObjectCount = CSingleton<ShelfManager>.Instance.m_SpawnedObjectCount + 1;
		interactableObject.gameObject.SetActive(true);
		return interactableObject;
	}

	// Token: 0x060003A6 RID: 934 RVA: 0x000213E1 File Offset: 0x0001F5E1
	public static void SpawnInteractableObjectInPackageBox(EObjectType objType, Vector3 spawnPos, Quaternion spawnRot)
	{
		InteractableObject interactableObject = ShelfManager.SpawnInteractableObject(objType);
		interactableObject.Init();
		interactableObject.BoxUpObject(false);
		interactableObject.GetPackagingBoxShelf().transform.position = spawnPos;
		interactableObject.GetPackagingBoxShelf().transform.rotation = spawnRot;
	}

	// Token: 0x060003A7 RID: 935 RVA: 0x00021417 File Offset: 0x0001F617
	private IEnumerator DelayBoxUp(InteractableObject obj, Vector3 spawnPos, Quaternion spawnRot)
	{
		yield return new WaitForSeconds(0.02f);
		obj.BoxUpObject(false);
		obj.GetPackagingBoxShelf().transform.position = spawnPos;
		obj.GetPackagingBoxShelf().transform.rotation = spawnRot;
		yield break;
	}

	// Token: 0x060003A8 RID: 936 RVA: 0x00021434 File Offset: 0x0001F634
	private void Awake()
	{
		this.m_MoveObjectPreviewModelMat = this.m_MoveObjectPreviewRenderer.material;
		Material[] materials = new Material[]
		{
			this.m_MoveObjectPreviewModelMat,
			this.m_MoveObjectPreviewModelMat,
			this.m_MoveObjectPreviewModelMat,
			this.m_MoveObjectPreviewModelMat,
			this.m_MoveObjectPreviewModelMat
		};
		this.m_MoveObjectPreviewRenderer.materials = materials;
	}

	// Token: 0x060003A9 RID: 937 RVA: 0x00021494 File Offset: 0x0001F694
	private void Update()
	{
		for (int i = 0; i < this.m_ShelfList.Count; i++)
		{
			if (this.m_ShelfList[i])
			{
				float f = Vector3.Dot(CSingleton<InteractionPlayerController>.Instance.m_Cam.transform.forward, this.m_ShelfList[i].transform.forward);
				if ((this.m_ShelfList[i].transform.position - CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.transform.position).magnitude > 6f && Mathf.Abs(f) > 0.7f)
				{
					for (int j = 0; j < this.m_ShelfList[i].GetItemCompartmentList().Count; j++)
					{
						this.m_ShelfList[i].GetItemCompartmentList()[j].SetVisibilityHalfItemMesh(false);
					}
				}
				else
				{
					for (int k = 0; k < this.m_ShelfList[i].GetItemCompartmentList().Count; k++)
					{
						this.m_ShelfList[i].GetItemCompartmentList()[k].SetVisibilityHalfItemMesh(true);
					}
				}
			}
		}
	}

	// Token: 0x060003AA RID: 938 RVA: 0x000215D4 File Offset: 0x0001F7D4
	public static void ActivateMoveObjectPreviewMode(Transform targetParent, MeshFilter targetMesh, Transform moveStateValidArea)
	{
		CSingleton<ShelfManager>.Instance.m_MoveObjectTargetMesh = targetMesh;
		CSingleton<ShelfManager>.Instance.m_MoveObjectPreviewModel.transform.position = targetMesh.transform.position;
		CSingleton<ShelfManager>.Instance.m_MoveObjectPreviewModel.transform.rotation = targetMesh.transform.rotation;
		CSingleton<ShelfManager>.Instance.m_MoveObjectPreviewModel.transform.localScale = targetMesh.transform.lossyScale + Vector3.one * 0.001f;
		CSingleton<ShelfManager>.Instance.m_MoveObjectPreviewModel.transform.parent = targetParent;
		CSingleton<ShelfManager>.Instance.m_MoveObjectPreviewModel.mesh = targetMesh.mesh;
		CSingleton<ShelfManager>.Instance.m_MoveObjectPreviewModel.gameObject.SetActive(true);
		ShelfManager.SetAllDashedLineVisibility(true);
	}

	// Token: 0x060003AB RID: 939 RVA: 0x000216A4 File Offset: 0x0001F8A4
	public static void DisableMoveObjectPreviewMode()
	{
		CSingleton<ShelfManager>.Instance.m_MoveObjectTargetMesh = null;
		CSingleton<ShelfManager>.Instance.m_MoveObjectPreviewModel.gameObject.SetActive(false);
		CSingleton<ShelfManager>.Instance.m_MoveObjectPreviewModel.transform.parent = CSingleton<ShelfManager>.Instance.transform;
		ShelfManager.SetAllDashedLineVisibility(false);
	}

	// Token: 0x060003AC RID: 940 RVA: 0x000216F8 File Offset: 0x0001F8F8
	public static void SetMoveObjectPreviewModelValidState(bool isValid)
	{
		if (isValid)
		{
			CSingleton<ShelfManager>.Instance.m_MoveObjectPreviewModelMat.SetColor("_Color", CSingleton<ShelfManager>.Instance.m_PreviewMeshValidColor);
			return;
		}
		CSingleton<ShelfManager>.Instance.m_MoveObjectPreviewModelMat.SetColor("_Color", CSingleton<ShelfManager>.Instance.m_PreviewMeshInvalidColor);
	}

	// Token: 0x060003AD RID: 941 RVA: 0x00021745 File Offset: 0x0001F945
	public static void AddDashedLine(DashedLine dashline)
	{
		CSingleton<ShelfManager>.Instance.m_DashedLineList.Add(dashline);
	}

	// Token: 0x060003AE RID: 942 RVA: 0x00021758 File Offset: 0x0001F958
	public static void SetAllDashedLineVisibility(bool isVisible)
	{
		for (int i = CSingleton<ShelfManager>.Instance.m_DashedLineList.Count - 1; i >= 0; i--)
		{
			if (CSingleton<ShelfManager>.Instance.m_DashedLineList[i])
			{
				CSingleton<ShelfManager>.Instance.m_DashedLineList[i].gameObject.SetActive(isVisible);
			}
			else
			{
				CSingleton<ShelfManager>.Instance.m_DashedLineList.RemoveAt(i);
			}
		}
	}

	// Token: 0x060003AF RID: 943 RVA: 0x000217C5 File Offset: 0x0001F9C5
	public static void InitInteractableObject(InteractableObject obj)
	{
		CSingleton<ShelfManager>.Instance.m_InteractableObjectList.Add(obj);
	}

	// Token: 0x060003B0 RID: 944 RVA: 0x000217D7 File Offset: 0x0001F9D7
	public static List<InteractableObject> GetInteractableObjectList()
	{
		return CSingleton<ShelfManager>.Instance.m_InteractableObjectList;
	}

	// Token: 0x060003B1 RID: 945 RVA: 0x000217E3 File Offset: 0x0001F9E3
	public static void RemoveInteractableObject(InteractableObject obj)
	{
		CSingleton<ShelfManager>.Instance.m_InteractableObjectList.Remove(obj);
	}

	// Token: 0x060003B2 RID: 946 RVA: 0x000217F6 File Offset: 0x0001F9F6
	public static void InitShelf(Shelf shelf)
	{
		CSingleton<ShelfManager>.Instance.m_ShelfList.Add(shelf);
	}

	// Token: 0x060003B3 RID: 947 RVA: 0x00021808 File Offset: 0x0001FA08
	public static List<Shelf> GetShelfList()
	{
		return CSingleton<ShelfManager>.Instance.m_ShelfList;
	}

	// Token: 0x060003B4 RID: 948 RVA: 0x00021814 File Offset: 0x0001FA14
	public static void RemoveShelf(Shelf shelf)
	{
		CSingleton<ShelfManager>.Instance.m_ShelfList.Remove(shelf);
	}

	// Token: 0x060003B5 RID: 949 RVA: 0x00021828 File Offset: 0x0001FA28
	public static void InitWarehouseShelf(WarehouseShelf shelf)
	{
		CSingleton<ShelfManager>.Instance.m_WarehouseShelfList.Add(shelf);
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_WarehouseShelfList.Count; i++)
		{
			CSingleton<ShelfManager>.Instance.m_WarehouseShelfList[i].SetIndex(i);
		}
	}

	// Token: 0x060003B6 RID: 950 RVA: 0x00021878 File Offset: 0x0001FA78
	public static void RemoveWarehouseShelf(WarehouseShelf shelf)
	{
		CSingleton<ShelfManager>.Instance.m_WarehouseShelfList.Remove(shelf);
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_WarehouseShelfList.Count; i++)
		{
			CSingleton<ShelfManager>.Instance.m_WarehouseShelfList[i].SetIndex(i);
			for (int j = 0; j < CSingleton<ShelfManager>.Instance.m_WarehouseShelfList[i].GetStorageCompartmentList().Count; j++)
			{
				for (int k = 0; k < CSingleton<ShelfManager>.Instance.m_WarehouseShelfList[i].GetStorageCompartmentList()[j].GetShelfCompartment().GetInteractablePackagingBoxList().Count; k++)
				{
					CSingleton<ShelfManager>.Instance.m_WarehouseShelfList[i].GetStorageCompartmentList()[j].GetShelfCompartment().GetInteractablePackagingBoxList()[k].UpdateStoredWarehouseShelfIndex();
				}
			}
		}
	}

	// Token: 0x060003B7 RID: 951 RVA: 0x0002195C File Offset: 0x0001FB5C
	public static void InitCardShelf(CardShelf shelf)
	{
		CSingleton<ShelfManager>.Instance.m_CardShelfList.Add(shelf);
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_CardShelfList.Count; i++)
		{
			CSingleton<ShelfManager>.Instance.m_CardShelfList[i].SetIndex(i);
		}
	}

	// Token: 0x060003B8 RID: 952 RVA: 0x000219AC File Offset: 0x0001FBAC
	public static void RemoveCardShelf(CardShelf shelf)
	{
		CSingleton<ShelfManager>.Instance.m_CardShelfList.Remove(shelf);
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_CardShelfList.Count; i++)
		{
			CSingleton<ShelfManager>.Instance.m_CardShelfList[i].SetIndex(i);
		}
	}

	// Token: 0x060003B9 RID: 953 RVA: 0x000219FC File Offset: 0x0001FBFC
	public static void InitPlayTable(InteractablePlayTable shelf)
	{
		CSingleton<ShelfManager>.Instance.m_PlayTableList.Add(shelf);
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_PlayTableList.Count; i++)
		{
			CSingleton<ShelfManager>.Instance.m_PlayTableList[i].SetIndex(i);
		}
	}

	// Token: 0x060003BA RID: 954 RVA: 0x00021A4C File Offset: 0x0001FC4C
	public static void RemovePlayTable(InteractablePlayTable shelf)
	{
		CSingleton<ShelfManager>.Instance.m_PlayTableList.Remove(shelf);
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_PlayTableList.Count; i++)
		{
			CSingleton<ShelfManager>.Instance.m_PlayTableList[i].SetIndex(i);
		}
	}

	// Token: 0x060003BB RID: 955 RVA: 0x00021A9A File Offset: 0x0001FC9A
	public static void InitAutoCleanser(InteractableAutoCleanser autoCleanser)
	{
		CSingleton<ShelfManager>.Instance.m_AutoCleanserList.Add(autoCleanser);
	}

	// Token: 0x060003BC RID: 956 RVA: 0x00021AAC File Offset: 0x0001FCAC
	public static void InitWorkbench(InteractableWorkbench workbench)
	{
		CSingleton<ShelfManager>.Instance.m_WorkbenchList.Add(workbench);
	}

	// Token: 0x060003BD RID: 957 RVA: 0x00021ABE File Offset: 0x0001FCBE
	public static List<InteractableAutoCleanser> GetAutoCleanserList()
	{
		return CSingleton<ShelfManager>.Instance.m_AutoCleanserList;
	}

	// Token: 0x060003BE RID: 958 RVA: 0x00021ACA File Offset: 0x0001FCCA
	public static void RemoveAutoCleanser(InteractableAutoCleanser autoCleanser)
	{
		CSingleton<ShelfManager>.Instance.m_AutoCleanserList.Remove(autoCleanser);
	}

	// Token: 0x060003BF RID: 959 RVA: 0x00021ADD File Offset: 0x0001FCDD
	public static void InitCashierCounter(InteractableCashierCounter cashierCounter)
	{
		CSingleton<ShelfManager>.Instance.m_CashierCounterList.Add(cashierCounter);
	}

	// Token: 0x060003C0 RID: 960 RVA: 0x00021AEF File Offset: 0x0001FCEF
	public static void RemoveCashierCounter(InteractableCashierCounter cashierCounter)
	{
		CSingleton<ShelfManager>.Instance.m_CashierCounterList.Remove(cashierCounter);
	}

	// Token: 0x060003C1 RID: 961 RVA: 0x00021B04 File Offset: 0x0001FD04
	public static InteractableCashierCounter GetUnmannedCashierCounter()
	{
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_CashierCounterList.Count; i++)
		{
			if (!CSingleton<ShelfManager>.Instance.m_CashierCounterList[i].IsMannedByPlayer() && !CSingleton<ShelfManager>.Instance.m_CashierCounterList[i].IsMannedByNPC() && CSingleton<ShelfManager>.Instance.m_CashierCounterList[i].IsValidObject() && !CSingleton<ShelfManager>.Instance.m_CashierCounterList[i].GetCurrentWorker())
			{
				return CSingleton<ShelfManager>.Instance.m_CashierCounterList[i];
			}
		}
		return null;
	}

	// Token: 0x060003C2 RID: 962 RVA: 0x00021BA1 File Offset: 0x0001FDA1
	public static int GetCashierCounterCount()
	{
		return CSingleton<ShelfManager>.Instance.m_CashierCounterList.Count;
	}

	// Token: 0x060003C3 RID: 963 RVA: 0x00021BB4 File Offset: 0x0001FDB4
	public static InteractableCashierCounter GetCashierCounter()
	{
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_CashierCounterList.Count; i++)
		{
			if (CSingleton<ShelfManager>.Instance.m_CashierCounterList[i].IsMannedByPlayer() && CSingleton<ShelfManager>.Instance.m_CashierCounterList[i].IsValidObject() && CSingleton<ShelfManager>.Instance.m_CashierCounterList[i].GetCurrentQueingCustomerCount() <= 1)
			{
				return CSingleton<ShelfManager>.Instance.m_CashierCounterList[i];
			}
		}
		for (int j = 0; j < CSingleton<ShelfManager>.Instance.m_CashierCounterList.Count; j++)
		{
			if (CSingleton<ShelfManager>.Instance.m_CashierCounterList[j].IsMannedByNPC() && CSingleton<ShelfManager>.Instance.m_CashierCounterList[j].IsValidObject() && CSingleton<ShelfManager>.Instance.m_CashierCounterList[j].GetCurrentQueingCustomerCount() <= 1)
			{
				return CSingleton<ShelfManager>.Instance.m_CashierCounterList[j];
			}
		}
		int num = 100;
		int num2 = -1;
		for (int k = 0; k < CSingleton<ShelfManager>.Instance.m_CashierCounterList.Count; k++)
		{
			if (CSingleton<ShelfManager>.Instance.m_CashierCounterList[k].IsValidObject() && CSingleton<ShelfManager>.Instance.m_CashierCounterList[k].GetCurrentQueingCustomerCount() < num && (CSingleton<ShelfManager>.Instance.m_CashierCounterList[k].IsMannedByPlayer() || CSingleton<ShelfManager>.Instance.m_CashierCounterList[k].IsMannedByNPC()))
			{
				num = CSingleton<ShelfManager>.Instance.m_CashierCounterList[k].GetCurrentQueingCustomerCount();
				num2 = k;
			}
		}
		if (num2 != -1 && Random.Range(0, 100) < 100)
		{
			return CSingleton<ShelfManager>.Instance.m_CashierCounterList[num2];
		}
		List<int> list = new List<int>();
		for (int l = 0; l < CSingleton<ShelfManager>.Instance.m_CashierCounterList.Count; l++)
		{
			if (CSingleton<ShelfManager>.Instance.m_CashierCounterList[l].IsValidObject())
			{
				list.Add(l);
			}
		}
		if (list.Count > 0)
		{
			int index = list[Random.Range(0, list.Count)];
			return CSingleton<ShelfManager>.Instance.m_CashierCounterList[index];
		}
		return null;
	}

	// Token: 0x060003C4 RID: 964 RVA: 0x00021DE4 File Offset: 0x0001FFE4
	public static Shelf GetShelfToRestockItem(EItemType itemType, bool ignoreNoneType = false)
	{
		List<int> list = new List<int>();
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_ShelfList.Count; i++)
		{
			if (CSingleton<ShelfManager>.Instance.m_ShelfList[i].IsValidObject() && !CSingleton<ShelfManager>.Instance.m_ShelfList[i].m_ItemNotForSale && CSingleton<ShelfManager>.Instance.m_ShelfList[i].GetNonFullItemCompartment(itemType, ignoreNoneType))
			{
				list.Add(i);
			}
		}
		if (list.Count > 0)
		{
			int index = list[Random.Range(0, list.Count)];
			return CSingleton<ShelfManager>.Instance.m_ShelfList[index];
		}
		return null;
	}

	// Token: 0x060003C5 RID: 965 RVA: 0x00021E94 File Offset: 0x00020094
	public static List<Shelf> GetShelfListToRestockItem(EItemType itemType, bool ignoreNoneType = false)
	{
		List<Shelf> list = new List<Shelf>();
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_ShelfList.Count; i++)
		{
			if (CSingleton<ShelfManager>.Instance.m_ShelfList[i].IsValidObject() && !CSingleton<ShelfManager>.Instance.m_ShelfList[i].m_ItemNotForSale && CSingleton<ShelfManager>.Instance.m_ShelfList[i].GetNonFullItemCompartment(itemType, ignoreNoneType))
			{
				list.Add(CSingleton<ShelfManager>.Instance.m_ShelfList[i]);
			}
		}
		return list;
	}

	// Token: 0x060003C6 RID: 966 RVA: 0x00021F24 File Offset: 0x00020124
	public static List<WarehouseShelf> GetWarehouseShelfListToStoreItem(EItemType itemType, bool isBigBox, bool ignoreNoneType = false)
	{
		List<WarehouseShelf> list = new List<WarehouseShelf>();
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_WarehouseShelfList.Count; i++)
		{
			if (CSingleton<ShelfManager>.Instance.m_WarehouseShelfList[i].IsValidObject() && CSingleton<ShelfManager>.Instance.m_WarehouseShelfList[i].GetNonFullItemCompartment(itemType, isBigBox, ignoreNoneType))
			{
				list.Add(CSingleton<ShelfManager>.Instance.m_WarehouseShelfList[i]);
			}
		}
		return list;
	}

	// Token: 0x060003C7 RID: 967 RVA: 0x00021FA0 File Offset: 0x000201A0
	public static Shelf GetShelfToBuyItem(List<EItemType> targetBuyItemList, int randomizeFindAnyShelfChanceOffset = 0)
	{
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_ShelfList.Count; i++)
		{
			if (CSingleton<ShelfManager>.Instance.m_ShelfList[i].IsValidObject() && !CSingleton<ShelfManager>.Instance.m_ShelfList[i].m_ItemNotForSale)
			{
				if (CSingleton<ShelfManager>.Instance.m_ShelfList[i].HasItemOnShelf() && (targetBuyItemList == null || targetBuyItemList.Count == 0 || CSingleton<ShelfManager>.Instance.m_ShelfList[i].HasItemTypeOnShelf(targetBuyItemList)))
				{
					list.Add(i);
				}
				list2.Add(i);
			}
		}
		if (list.Count > 0 && Random.Range(0, 100) < 80 + randomizeFindAnyShelfChanceOffset)
		{
			int index = list[Random.Range(0, list.Count)];
			return CSingleton<ShelfManager>.Instance.m_ShelfList[index];
		}
		if (list2.Count > 0)
		{
			int index2 = list2[Random.Range(0, list2.Count)];
			return CSingleton<ShelfManager>.Instance.m_ShelfList[index2];
		}
		return null;
	}

	// Token: 0x060003C8 RID: 968 RVA: 0x000220B8 File Offset: 0x000202B8
	public static CardShelf GetCardShelfToBuyCard()
	{
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_CardShelfList.Count; i++)
		{
			if (CSingleton<ShelfManager>.Instance.m_CardShelfList[i].IsValidObject() && !CSingleton<ShelfManager>.Instance.m_CardShelfList[i].m_ItemNotForSale)
			{
				if (CSingleton<ShelfManager>.Instance.m_CardShelfList[i].HasCardOnShelf())
				{
					list.Add(i);
				}
				list2.Add(i);
			}
		}
		if (list.Count > 0 && Random.Range(0, 100) < 80)
		{
			int index = list[Random.Range(0, list.Count)];
			return CSingleton<ShelfManager>.Instance.m_CardShelfList[index];
		}
		if (list2.Count > 0)
		{
			int index2 = list2[Random.Range(0, list2.Count)];
			return CSingleton<ShelfManager>.Instance.m_CardShelfList[index2];
		}
		return null;
	}

	// Token: 0x060003C9 RID: 969 RVA: 0x000221A8 File Offset: 0x000203A8
	public static bool HasPlayTableWithPlayerWaiting()
	{
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_PlayTableList.Count; i++)
		{
			if (CSingleton<ShelfManager>.Instance.m_PlayTableList[i].IsValidObject() && CSingleton<ShelfManager>.Instance.m_PlayTableList[i].IsLookingForPlayer(true))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060003CA RID: 970 RVA: 0x00022204 File Offset: 0x00020404
	public static InteractablePlayTable GetPlayTableToPlay(bool findTableWithPlayerWaiting)
	{
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < CSingleton<ShelfManager>.Instance.m_PlayTableList.Count; i++)
		{
			if (CSingleton<ShelfManager>.Instance.m_PlayTableList[i].IsValidObject())
			{
				if (CSingleton<ShelfManager>.Instance.m_PlayTableList[i].IsLookingForPlayer(findTableWithPlayerWaiting))
				{
					list.Add(i);
					list2.Add(i);
				}
				else if (!findTableWithPlayerWaiting && CSingleton<ShelfManager>.Instance.m_PlayTableList[i].HasEmptySeatBooking() && CSingleton<ShelfManager>.Instance.m_PlayTableList[i].HasEmptyQueue())
				{
					list2.Add(i);
				}
			}
		}
		if (list.Count > 0 && Random.Range(0, 100) < 80)
		{
			int index = list[Random.Range(0, list.Count)];
			return CSingleton<ShelfManager>.Instance.m_PlayTableList[index];
		}
		if (list2.Count > 0)
		{
			int index2 = list2[Random.Range(0, list2.Count)];
			return CSingleton<ShelfManager>.Instance.m_PlayTableList[index2];
		}
		return null;
	}

	// Token: 0x060003CB RID: 971 RVA: 0x0002231C File Offset: 0x0002051C
	public static void DestroyAllObject()
	{
		CSingleton<ShelfManager>.Instance.m_SpawnedObjectCount = 0;
		for (int i = CSingleton<ShelfManager>.Instance.m_InteractableObjectList.Count - 1; i >= 0; i--)
		{
			CSingleton<ShelfManager>.Instance.m_InteractableObjectList[i].OnDestroyed();
		}
		for (int j = CSingleton<ShelfManager>.Instance.m_ShelfList.Count - 1; j >= 0; j--)
		{
			CSingleton<ShelfManager>.Instance.m_ShelfList[j].OnDestroyed();
		}
		for (int k = CSingleton<ShelfManager>.Instance.m_WarehouseShelfList.Count - 1; k >= 0; k--)
		{
			CSingleton<ShelfManager>.Instance.m_WarehouseShelfList[k].OnDestroyed();
		}
		for (int l = CSingleton<ShelfManager>.Instance.m_PlayTableList.Count - 1; l >= 0; l--)
		{
			CSingleton<ShelfManager>.Instance.m_PlayTableList[l].OnDestroyed();
		}
		for (int m = CSingleton<ShelfManager>.Instance.m_AutoCleanserList.Count - 1; m >= 0; m--)
		{
			CSingleton<ShelfManager>.Instance.m_AutoCleanserList[m].OnDestroyed();
		}
		for (int n = CSingleton<ShelfManager>.Instance.m_CardShelfList.Count - 1; n >= 0; n--)
		{
			CSingleton<ShelfManager>.Instance.m_CardShelfList[n].OnDestroyed();
		}
	}

	// Token: 0x060003CC RID: 972 RVA: 0x00022464 File Offset: 0x00020664
	public static bool HasCustomerInCashCounterQueue()
	{
		for (int i = CSingleton<ShelfManager>.Instance.m_CashierCounterList.Count - 1; i >= 0; i--)
		{
			if (CSingleton<ShelfManager>.Instance.m_CashierCounterList[i].GetCustomerInQueueCount() > 0)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060003CD RID: 973 RVA: 0x000224A8 File Offset: 0x000206A8
	public static void OnPressGoNextDay()
	{
		for (int i = CSingleton<ShelfManager>.Instance.m_PlayTableList.Count - 1; i >= 0; i--)
		{
			CSingleton<ShelfManager>.Instance.m_PlayTableList[i].OnPressGoNextDay();
		}
	}

	// Token: 0x060003CE RID: 974 RVA: 0x000224E6 File Offset: 0x000206E6
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x060003CF RID: 975 RVA: 0x00022507 File Offset: 0x00020707
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_OnMoneyCurrencyUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnMoneyCurrencyUpdated>(this.OnMoneyCurrencyUpdated));
		}
	}

	// Token: 0x060003D0 RID: 976 RVA: 0x00022528 File Offset: 0x00020728
	protected void OnMoneyCurrencyUpdated(CEventPlayer_OnMoneyCurrencyUpdated evt)
	{
		for (int i = 0; i < this.m_ShelfList.Count; i++)
		{
			for (int j = 0; j < this.m_ShelfList[i].GetItemCompartmentList().Count; j++)
			{
				this.m_ShelfList[i].GetItemCompartmentList()[j].RefreshPriceTagItemPriceText();
			}
		}
		for (int k = 0; k < this.m_CardShelfList.Count; k++)
		{
			for (int l = 0; l < this.m_CardShelfList[k].GetCardCompartmentList().Count; l++)
			{
				this.m_CardShelfList[k].GetCardCompartmentList()[l].RefreshPriceTagItemPriceText();
			}
		}
	}

	// Token: 0x04000471 RID: 1137
	public static ShelfManager m_Instance;

	// Token: 0x04000472 RID: 1138
	public Transform m_ShelfParentGrp;

	// Token: 0x04000473 RID: 1139
	public BoxCollider m_MoveObjectCustomerBlocker;

	// Token: 0x04000474 RID: 1140
	public MeshFilter m_MoveObjectPreviewModel;

	// Token: 0x04000475 RID: 1141
	public MeshRenderer m_MoveObjectPreviewRenderer;

	// Token: 0x04000476 RID: 1142
	private MeshFilter m_MoveObjectTargetMesh;

	// Token: 0x04000477 RID: 1143
	private Material m_MoveObjectPreviewModelMat;

	// Token: 0x04000478 RID: 1144
	public Color m_PreviewMeshValidColor;

	// Token: 0x04000479 RID: 1145
	public Color m_PreviewMeshInvalidColor;

	// Token: 0x0400047A RID: 1146
	private List<DashedLine> m_DashedLineList = new List<DashedLine>();

	// Token: 0x0400047B RID: 1147
	public List<InteractableObject> m_InteractableObjectList = new List<InteractableObject>();

	// Token: 0x0400047C RID: 1148
	public List<Shelf> m_ShelfList = new List<Shelf>();

	// Token: 0x0400047D RID: 1149
	public List<WarehouseShelf> m_WarehouseShelfList = new List<WarehouseShelf>();

	// Token: 0x0400047E RID: 1150
	public List<InteractableCashierCounter> m_CashierCounterList = new List<InteractableCashierCounter>();

	// Token: 0x0400047F RID: 1151
	public List<CardShelf> m_CardShelfList = new List<CardShelf>();

	// Token: 0x04000480 RID: 1152
	public List<InteractablePlayTable> m_PlayTableList = new List<InteractablePlayTable>();

	// Token: 0x04000481 RID: 1153
	public List<InteractableAutoCleanser> m_AutoCleanserList = new List<InteractableAutoCleanser>();

	// Token: 0x04000482 RID: 1154
	public List<InteractableWorkbench> m_WorkbenchList = new List<InteractableWorkbench>();

	// Token: 0x04000483 RID: 1155
	public List<ShelfSaveData> m_ShelfSaveDataList = new List<ShelfSaveData>();

	// Token: 0x04000484 RID: 1156
	public List<WarehouseShelfSaveData> m_WarehouseShelfSaveDataList = new List<WarehouseShelfSaveData>();

	// Token: 0x04000485 RID: 1157
	public List<PackageBoxItemaveData> m_PackageBoxItemSaveDataList = new List<PackageBoxItemaveData>();

	// Token: 0x04000486 RID: 1158
	public List<InteractableObjectSaveData> m_InteractableObjectSaveDataList = new List<InteractableObjectSaveData>();

	// Token: 0x04000487 RID: 1159
	public List<CardShelfSaveData> m_CardShelfSaveDataList = new List<CardShelfSaveData>();

	// Token: 0x04000488 RID: 1160
	public List<PlayTableSaveData> m_PlayTableSaveDataList = new List<PlayTableSaveData>();

	// Token: 0x04000489 RID: 1161
	public List<AutoCleanserSaveData> m_AutoCleanserSaveDataList = new List<AutoCleanserSaveData>();

	// Token: 0x0400048A RID: 1162
	public List<WorkbenchSaveData> m_WorkbenchSaveDataList = new List<WorkbenchSaveData>();

	// Token: 0x0400048B RID: 1163
	private List<Shelf> m_SpawnedShelfList = new List<Shelf>();

	// Token: 0x0400048C RID: 1164
	private List<WarehouseShelf> m_SpawnedWarehouseShelfList = new List<WarehouseShelf>();

	// Token: 0x0400048D RID: 1165
	private List<InteractablePackagingBox_Item> m_SpawnedPackageBoxItemList = new List<InteractablePackagingBox_Item>();

	// Token: 0x0400048E RID: 1166
	private List<InteractableObject> m_SpawnedInteractableObjectList = new List<InteractableObject>();

	// Token: 0x0400048F RID: 1167
	private List<CardShelf> m_SpawnedCardShelfList = new List<CardShelf>();

	// Token: 0x04000490 RID: 1168
	private List<InteractablePlayTable> m_SpawnedPlayTableList = new List<InteractablePlayTable>();

	// Token: 0x04000491 RID: 1169
	private List<InteractableAutoCleanser> m_SpawnedAutoCleanserList = new List<InteractableAutoCleanser>();

	// Token: 0x04000492 RID: 1170
	private List<InteractableWorkbench> m_SpawnedWorkbenchList = new List<InteractableWorkbench>();

	// Token: 0x04000493 RID: 1171
	private int m_SpawnedObjectCount;

	// Token: 0x04000494 RID: 1172
	public bool m_FinishLoadingObjectData;
}
