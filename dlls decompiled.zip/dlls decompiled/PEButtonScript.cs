﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Token: 0x0200013D RID: 317
public class PEButtonScript : MonoBehaviour, IEventSystemHandler, IPointerEnterHandler, IPointerExitHandler
{
	// Token: 0x06000903 RID: 2307 RVA: 0x00041EA6 File Offset: 0x000400A6
	private void Start()
	{
		this.myButton = base.gameObject.GetComponent<Button>();
	}

	// Token: 0x06000904 RID: 2308 RVA: 0x00041EB9 File Offset: 0x000400B9
	public void OnPointerEnter(PointerEventData eventData)
	{
		UICanvasManager.GlobalAccess.MouseOverButton = true;
		UICanvasManager.GlobalAccess.UpdateToolTip(this.ButtonType);
	}

	// Token: 0x06000905 RID: 2309 RVA: 0x00041ED6 File Offset: 0x000400D6
	public void OnPointerExit(PointerEventData eventData)
	{
		UICanvasManager.GlobalAccess.MouseOverButton = false;
		UICanvasManager.GlobalAccess.ClearToolTip();
	}

	// Token: 0x06000906 RID: 2310 RVA: 0x00041EED File Offset: 0x000400ED
	public void OnButtonClicked()
	{
		UICanvasManager.GlobalAccess.UIButtonClick(this.ButtonType);
	}

	// Token: 0x04001123 RID: 4387
	private Button myButton;

	// Token: 0x04001124 RID: 4388
	public ButtonTypes ButtonType;
}
