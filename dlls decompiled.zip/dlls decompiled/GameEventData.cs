﻿using System;
using I2.Loc;

// Token: 0x02000035 RID: 53
[Serializable]
public class GameEventData
{
	// Token: 0x060002A8 RID: 680 RVA: 0x000198B3 File Offset: 0x00017AB3
	public string GetName()
	{
		return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true);
	}

	// Token: 0x0400031E RID: 798
	public string name;

	// Token: 0x0400031F RID: 799
	public EGameEventFormat format;

	// Token: 0x04000320 RID: 800
	public int unlockPlayCountRequired;

	// Token: 0x04000321 RID: 801
	public int hostEventCost;

	// Token: 0x04000322 RID: 802
	public float baseFee;

	// Token: 0x04000323 RID: 803
	public float marketPriceMinPercent;

	// Token: 0x04000324 RID: 804
	public float marketPriceMaxPercent;

	// Token: 0x04000325 RID: 805
	public EPriceChangeType positivePriceChangeType;

	// Token: 0x04000326 RID: 806
	public EPriceChangeType negativePriceChangeType;
}
