﻿using System;

// Token: 0x020000F2 RID: 242
public enum ESortMethod
{
	// Token: 0x04000D5F RID: 3423
	None,
	// Token: 0x04000D60 RID: 3424
	HP_Ascending,
	// Token: 0x04000D61 RID: 3425
	HP_Descending,
	// Token: 0x04000D62 RID: 3426
	Atk_Ascending,
	// Token: 0x04000D63 RID: 3427
	Atk_Descending,
	// Token: 0x04000D64 RID: 3428
	Energy_Ascending,
	// Token: 0x04000D65 RID: 3429
	Energy_Descending,
	// Token: 0x04000D66 RID: 3430
	Level_Ascending,
	// Token: 0x04000D67 RID: 3431
	Level_Descending,
	// Token: 0x04000D68 RID: 3432
	Index_Ascending,
	// Token: 0x04000D69 RID: 3433
	Index_Descending,
	// Token: 0x04000D6A RID: 3434
	Stars_Ascending,
	// Token: 0x04000D6B RID: 3435
	Stars_Descending
}
