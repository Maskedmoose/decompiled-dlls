﻿using System;

// Token: 0x020000C8 RID: 200
public class CEventPlayer_WaitForKeyboardInput : CEvent
{
	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000739 RID: 1849 RVA: 0x0003826F File Offset: 0x0003646F
	// (set) Token: 0x0600073A RID: 1850 RVA: 0x00038277 File Offset: 0x00036477
	public string m_Text { get; private set; }

	// Token: 0x0600073B RID: 1851 RVA: 0x00038280 File Offset: 0x00036480
	public CEventPlayer_WaitForKeyboardInput(string Text)
	{
		this.m_Text = Text;
	}
}
