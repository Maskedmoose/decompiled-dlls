﻿using System;
using I2.Loc;
using UnityEngine;

// Token: 0x0200012E RID: 302
[Serializable]
public struct ProgressionArenaData
{
	// Token: 0x060008DD RID: 2269 RVA: 0x0004117A File Offset: 0x0003F37A
	public string GetArenaName()
	{
		return LocalizationManager.GetTranslation(this.m_ArenaTitle, true, 0, true, false, null, null, true);
	}

	// Token: 0x060008DE RID: 2270 RVA: 0x00041190 File Offset: 0x0003F390
	public string GetArenaNumberText(int index)
	{
		string result;
		if (index == -1)
		{
			result = LocalizationManager.GetTranslation("Beginner Arena", true, 0, true, false, null, null, true);
		}
		else
		{
			result = LocalizationManager.GetTranslation("Arena", true, 0, true, false, null, null, true) + " " + (index + 1).ToString();
		}
		return result;
	}

	// Token: 0x040010CC RID: 4300
	public int m_UnlockMMR;

	// Token: 0x040010CD RID: 4301
	public Sprite m_ArenaImage;

	// Token: 0x040010CE RID: 4302
	public string m_ArenaTitle;
}
