﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000139 RID: 313
public class IndicatorManager : CSingleton<IndicatorManager>
{
	// Token: 0x060008F5 RID: 2293 RVA: 0x00041634 File Offset: 0x0003F834
	public void Start()
	{
		if (IndicatorManager.m_Instance == null)
		{
			IndicatorManager.m_Instance = this;
		}
		else if (IndicatorManager.m_Instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		Object.DontDestroyOnLoad(this);
		for (int i = 0; i < this.m_ArrowIndicatorUIList.Count; i++)
		{
			this.m_ArrowIndicatorUIList[i].gameObject.SetActive(false);
			this.m_ParentList.Add(null);
		}
	}

	// Token: 0x060008F6 RID: 2294 RVA: 0x000416B0 File Offset: 0x0003F8B0
	private void Update()
	{
		for (int i = 0; i < this.m_ParentList.Count; i++)
		{
			if (this.m_ParentList[i] && !this.m_ParentList[i].activeInHierarchy)
			{
				this.m_ArrowIndicatorUIList[i].gameObject.SetActive(false);
				this.m_ArrowIndicatorUIList[i].transform.parent = base.transform;
				this.m_ParentList[i] = null;
			}
		}
	}

	// Token: 0x060008F7 RID: 2295 RVA: 0x0004173C File Offset: 0x0003F93C
	public static void HideAllIndicator()
	{
		for (int i = 0; i < CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList.Count; i++)
		{
			CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].gameObject.SetActive(false);
			CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].transform.parent = CSingleton<IndicatorManager>.Instance.transform;
			CSingleton<IndicatorManager>.Instance.m_ParentList[i] = null;
		}
	}

	// Token: 0x060008F8 RID: 2296 RVA: 0x000417B4 File Offset: 0x0003F9B4
	public static void ShowArrowIndicator(GameObject parent, float posYOffset = 0f, float scale = 1f)
	{
		for (int i = 0; i < CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList.Count; i++)
		{
			if (!CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].gameObject.activeSelf)
			{
				CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].SetPosY(posYOffset);
				CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].SetScale(scale);
				CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].transform.parent = parent.transform;
				CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].transform.localPosition = Vector3.zero;
				CSingleton<IndicatorManager>.Instance.m_ArrowIndicatorUIList[i].gameObject.SetActive(true);
				CSingleton<IndicatorManager>.Instance.m_ParentList[i] = parent;
				return;
			}
		}
	}

	// Token: 0x04001107 RID: 4359
	public static IndicatorManager m_Instance;

	// Token: 0x04001108 RID: 4360
	public List<ArrowIndicatorUI> m_ArrowIndicatorUIList;

	// Token: 0x04001109 RID: 4361
	private List<GameObject> m_ParentList = new List<GameObject>();
}
