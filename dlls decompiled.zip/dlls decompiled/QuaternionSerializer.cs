﻿using System;
using UnityEngine;

// Token: 0x020000A3 RID: 163
[Serializable]
public struct QuaternionSerializer
{
	// Token: 0x0600069D RID: 1693 RVA: 0x00036CBC File Offset: 0x00034EBC
	public void SetData(Quaternion q)
	{
		this.x = q.x;
		this.y = q.y;
		this.z = q.z;
		this.w = q.w;
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x0600069E RID: 1694 RVA: 0x00036CEE File Offset: 0x00034EEE
	public Quaternion Data
	{
		get
		{
			return new Quaternion(this.x, this.y, this.z, this.w);
		}
	}

	// Token: 0x040008D1 RID: 2257
	public float x;

	// Token: 0x040008D2 RID: 2258
	public float y;

	// Token: 0x040008D3 RID: 2259
	public float z;

	// Token: 0x040008D4 RID: 2260
	public float w;
}
