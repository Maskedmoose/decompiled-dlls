﻿using System;
using UnityEngine;

namespace CMF
{
	// Token: 0x020001D7 RID: 471
	public class AdvancedWalkerController : Controller
	{
		// Token: 0x06000D24 RID: 3364 RVA: 0x0005A940 File Offset: 0x00058B40
		private void Awake()
		{
			this.mover = base.GetComponent<Mover>();
			this.tr = base.transform;
			this.characterInput = base.GetComponent<CharacterInput>();
			this.ceilingDetector = base.GetComponent<CeilingDetector>();
			if (this.characterInput == null)
			{
				Debug.LogWarning("No character input script has been attached to this gameobject", base.gameObject);
			}
			this.Setup();
			this.movementSpeedModified = this.movementSpeed;
		}

		// Token: 0x06000D25 RID: 3365 RVA: 0x0005A9AD File Offset: 0x00058BAD
		protected virtual void Setup()
		{
		}

		// Token: 0x06000D26 RID: 3366 RVA: 0x0005A9AF File Offset: 0x00058BAF
		private void Update()
		{
			if (this.isStopMovement)
			{
				return;
			}
			this.HandleJumpKeyInput();
		}

		// Token: 0x06000D27 RID: 3367 RVA: 0x0005A9C0 File Offset: 0x00058BC0
		private void HandleJumpKeyInput()
		{
			bool flag = this.IsJumpKeyPressed();
			if (!this.jumpKeyIsPressed && flag)
			{
				this.jumpKeyWasPressed = true;
			}
			if (this.jumpKeyIsPressed && !flag)
			{
				this.jumpKeyWasLetGo = true;
				this.jumpInputIsLocked = false;
			}
			this.jumpKeyIsPressed = flag;
		}

		// Token: 0x06000D28 RID: 3368 RVA: 0x0005AA06 File Offset: 0x00058C06
		private void FixedUpdate()
		{
			this.ControllerUpdate();
		}

		// Token: 0x06000D29 RID: 3369 RVA: 0x0005AA10 File Offset: 0x00058C10
		private void ControllerUpdate()
		{
			this.mover.CheckForGround();
			this.currentControllerState = this.DetermineControllerState();
			this.HandleMomentum();
			this.HandleJumping();
			if (InputManager.GetKeyHoldAction(EGameAction.Sprint))
			{
				this.movementSpeedModified = this.movementSpeed * 1.5f;
			}
			else
			{
				this.movementSpeedModified = this.movementSpeed;
			}
			Vector3 vector = Vector3.zero;
			if (!this.isStopMovement && this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded)
			{
				vector = this.CalculateMovementVelocity();
			}
			Vector3 b = this.momentum;
			if (this.useLocalMomentum)
			{
				b = this.tr.localToWorldMatrix * this.momentum;
			}
			vector += b;
			this.mover.SetExtendSensorRange(this.IsGrounded());
			this.mover.SetVelocity(vector);
			this.savedVelocity = vector;
			this.savedMovementVelocity = this.CalculateMovementVelocity();
			this.jumpKeyWasLetGo = false;
			this.jumpKeyWasPressed = false;
			if (this.ceilingDetector != null)
			{
				this.ceilingDetector.ResetFlags();
			}
		}

		// Token: 0x06000D2A RID: 3370 RVA: 0x0005AB18 File Offset: 0x00058D18
		protected virtual Vector3 CalculateMovementDirection()
		{
			if (this.characterInput == null)
			{
				return Vector3.zero;
			}
			Vector3 vector = Vector3.zero;
			if (this.cameraTransform == null)
			{
				vector += this.tr.right * this.characterInput.GetHorizontalMovementInput();
				vector += this.tr.forward * this.characterInput.GetVerticalMovementInput();
			}
			else
			{
				vector += Vector3.ProjectOnPlane(this.cameraTransform.right, this.tr.up).normalized * this.characterInput.GetHorizontalMovementInput();
				vector += Vector3.ProjectOnPlane(this.cameraTransform.forward, this.tr.up).normalized * this.characterInput.GetVerticalMovementInput();
			}
			if (vector.magnitude > 1f)
			{
				vector.Normalize();
			}
			return vector;
		}

		// Token: 0x06000D2B RID: 3371 RVA: 0x0005AC1D File Offset: 0x00058E1D
		protected virtual Vector3 CalculateMovementVelocity()
		{
			return this.CalculateMovementDirection() * this.movementSpeedModified;
		}

		// Token: 0x06000D2C RID: 3372 RVA: 0x0005AC30 File Offset: 0x00058E30
		protected virtual bool IsJumpKeyPressed()
		{
			return !(this.characterInput == null) && this.characterInput.IsJumpKeyPressed();
		}

		// Token: 0x06000D2D RID: 3373 RVA: 0x0005AC50 File Offset: 0x00058E50
		private AdvancedWalkerController.ControllerState DetermineControllerState()
		{
			bool flag = this.IsRisingOrFalling() && VectorMath.GetDotProduct(this.GetMomentum(), this.tr.up) > 0f;
			bool flag2 = this.mover.IsGrounded() && this.IsGroundTooSteep();
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded)
			{
				if (flag)
				{
					this.OnGroundContactLost();
					return AdvancedWalkerController.ControllerState.Rising;
				}
				if (!this.mover.IsGrounded())
				{
					this.OnGroundContactLost();
					return AdvancedWalkerController.ControllerState.Falling;
				}
				if (flag2)
				{
					this.OnGroundContactLost();
					return AdvancedWalkerController.ControllerState.Sliding;
				}
				return AdvancedWalkerController.ControllerState.Grounded;
			}
			else if (this.currentControllerState == AdvancedWalkerController.ControllerState.Falling)
			{
				this.m_MagicAirJumpTimer += Time.deltaTime;
				if (flag)
				{
					return AdvancedWalkerController.ControllerState.Rising;
				}
				if (this.mover.IsGrounded() && !flag2)
				{
					this.OnGroundContactRegained();
					return AdvancedWalkerController.ControllerState.Grounded;
				}
				if (flag2)
				{
					return AdvancedWalkerController.ControllerState.Sliding;
				}
				return AdvancedWalkerController.ControllerState.Falling;
			}
			else if (this.currentControllerState == AdvancedWalkerController.ControllerState.Sliding)
			{
				if (flag)
				{
					this.OnGroundContactLost();
					return AdvancedWalkerController.ControllerState.Rising;
				}
				if (!this.mover.IsGrounded())
				{
					this.OnGroundContactLost();
					return AdvancedWalkerController.ControllerState.Falling;
				}
				if (this.mover.IsGrounded() && !flag2)
				{
					this.OnGroundContactRegained();
					return AdvancedWalkerController.ControllerState.Grounded;
				}
				return AdvancedWalkerController.ControllerState.Sliding;
			}
			else if (this.currentControllerState == AdvancedWalkerController.ControllerState.Rising)
			{
				if (!flag)
				{
					if (this.mover.IsGrounded() && !flag2)
					{
						this.OnGroundContactRegained();
						return AdvancedWalkerController.ControllerState.Grounded;
					}
					if (flag2)
					{
						return AdvancedWalkerController.ControllerState.Sliding;
					}
					if (!this.mover.IsGrounded())
					{
						return AdvancedWalkerController.ControllerState.Falling;
					}
				}
				if (this.ceilingDetector != null && this.ceilingDetector.HitCeiling())
				{
					this.OnCeilingContact();
					return AdvancedWalkerController.ControllerState.Falling;
				}
				return AdvancedWalkerController.ControllerState.Rising;
			}
			else
			{
				if (this.currentControllerState != AdvancedWalkerController.ControllerState.Jumping)
				{
					return AdvancedWalkerController.ControllerState.Falling;
				}
				if (Time.time - this.currentJumpStartTime > this.jumpDuration)
				{
					return AdvancedWalkerController.ControllerState.Rising;
				}
				if (this.jumpKeyWasLetGo)
				{
					return AdvancedWalkerController.ControllerState.Rising;
				}
				if (this.ceilingDetector != null && this.ceilingDetector.HitCeiling())
				{
					this.OnCeilingContact();
					return AdvancedWalkerController.ControllerState.Falling;
				}
				return AdvancedWalkerController.ControllerState.Jumping;
			}
		}

		// Token: 0x06000D2E RID: 3374 RVA: 0x0005AE00 File Offset: 0x00059000
		private void HandleJumping()
		{
			if ((this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded || this.m_MagicAirJumpTimer < this.m_MagicAirJumpTime) && (this.jumpKeyIsPressed || this.jumpKeyWasPressed) && !this.jumpInputIsLocked)
			{
				this.OnGroundContactLost();
				this.OnJumpStart();
				this.currentControllerState = AdvancedWalkerController.ControllerState.Jumping;
			}
		}

		// Token: 0x06000D2F RID: 3375 RVA: 0x0005AE50 File Offset: 0x00059050
		private void HandleMomentum()
		{
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.localToWorldMatrix * this.momentum;
			}
			Vector3 vector = Vector3.zero;
			Vector3 vector2 = Vector3.zero;
			if (this.momentum != Vector3.zero)
			{
				vector = VectorMath.ExtractDotVector(this.momentum, this.tr.up);
				vector2 = this.momentum - vector;
			}
			vector -= this.tr.up * this.gravity * Time.deltaTime;
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded && VectorMath.GetDotProduct(vector, this.tr.up) < 0f)
			{
				vector = Vector3.zero;
			}
			if (!this.IsGrounded())
			{
				Vector3 vector3 = this.CalculateMovementVelocity();
				if (vector2.magnitude > this.movementSpeedModified)
				{
					if (VectorMath.GetDotProduct(vector3, vector2.normalized) > 0f)
					{
						vector3 = VectorMath.RemoveDotVector(vector3, vector2.normalized);
					}
					float d = 0.25f;
					vector2 += vector3 * Time.deltaTime * this.airControlRate * d;
				}
				else
				{
					vector2 += vector3 * Time.deltaTime * this.airControlRate;
					vector2 = Vector3.ClampMagnitude(vector2, this.movementSpeedModified);
				}
			}
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Sliding)
			{
				Vector3 normalized = Vector3.ProjectOnPlane(this.mover.GetGroundNormal(), this.tr.up).normalized;
				Vector3 vector4 = this.CalculateMovementVelocity();
				vector4 = VectorMath.RemoveDotVector(vector4, normalized);
				vector2 += vector4 * Time.fixedDeltaTime;
			}
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded)
			{
				vector2 = VectorMath.IncrementVectorTowardTargetVector(vector2, this.groundFriction, Time.deltaTime, Vector3.zero);
			}
			else
			{
				vector2 = VectorMath.IncrementVectorTowardTargetVector(vector2, this.airFriction, Time.deltaTime, Vector3.zero);
			}
			this.momentum = vector2 + vector;
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Sliding)
			{
				this.momentum = Vector3.ProjectOnPlane(this.momentum, this.mover.GetGroundNormal());
				if (VectorMath.GetDotProduct(this.momentum, this.tr.up) > 0f)
				{
					this.momentum = VectorMath.RemoveDotVector(this.momentum, this.tr.up);
				}
				Vector3 normalized2 = Vector3.ProjectOnPlane(-this.tr.up, this.mover.GetGroundNormal()).normalized;
				this.momentum += normalized2 * this.slideGravity * Time.deltaTime;
			}
			if (this.currentControllerState == AdvancedWalkerController.ControllerState.Jumping)
			{
				this.momentum = VectorMath.RemoveDotVector(this.momentum, this.tr.up);
				this.momentum += this.tr.up * this.jumpSpeed;
			}
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * this.momentum;
			}
		}

		// Token: 0x06000D30 RID: 3376 RVA: 0x0005B17C File Offset: 0x0005937C
		private void OnJumpStart()
		{
			this.m_MagicAirJumpTimer = this.m_MagicAirJumpTime;
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.localToWorldMatrix * this.momentum;
			}
			this.momentum += this.tr.up * this.jumpSpeed;
			this.currentJumpStartTime = Time.time;
			this.jumpInputIsLocked = true;
			if (this.OnJump != null)
			{
				this.OnJump(this.momentum);
			}
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * this.momentum;
			}
		}

		// Token: 0x06000D31 RID: 3377 RVA: 0x0005B244 File Offset: 0x00059444
		private void OnGroundContactLost()
		{
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.localToWorldMatrix * this.momentum;
			}
			Vector3 vector = this.GetMovementVelocity();
			if (vector.sqrMagnitude >= 0f && this.momentum.sqrMagnitude > 0f)
			{
				Vector3 b = Vector3.Project(this.momentum, vector.normalized);
				float dotProduct = VectorMath.GetDotProduct(b.normalized, vector.normalized);
				if (b.sqrMagnitude >= vector.sqrMagnitude && dotProduct > 0f)
				{
					vector = Vector3.zero;
				}
				else if (dotProduct > 0f)
				{
					vector -= b;
				}
			}
			this.momentum += vector;
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * this.momentum;
			}
		}

		// Token: 0x06000D32 RID: 3378 RVA: 0x0005B340 File Offset: 0x00059540
		private void OnGroundContactRegained()
		{
			if (this.OnLand != null)
			{
				Vector3 v = this.momentum;
				if (this.useLocalMomentum)
				{
					v = this.tr.localToWorldMatrix * v;
				}
				this.OnLand(v);
				this.m_MagicAirJumpTimer = 0f;
			}
		}

		// Token: 0x06000D33 RID: 3379 RVA: 0x0005B398 File Offset: 0x00059598
		private void OnCeilingContact()
		{
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.localToWorldMatrix * this.momentum;
			}
			this.momentum = VectorMath.RemoveDotVector(this.momentum, this.tr.up);
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * this.momentum;
			}
		}

		// Token: 0x06000D34 RID: 3380 RVA: 0x0005B420 File Offset: 0x00059620
		private bool IsRisingOrFalling()
		{
			Vector3 vector = VectorMath.ExtractDotVector(this.GetMomentum(), this.tr.up);
			float num = 0.001f;
			return vector.magnitude > num;
		}

		// Token: 0x06000D35 RID: 3381 RVA: 0x0005B454 File Offset: 0x00059654
		private bool IsGroundTooSteep()
		{
			return !this.mover.IsGrounded() || Vector3.Angle(this.mover.GetGroundNormal(), this.tr.up) > this.slopeLimit;
		}

		// Token: 0x06000D36 RID: 3382 RVA: 0x0005B488 File Offset: 0x00059688
		public override Vector3 GetVelocity()
		{
			return this.savedVelocity;
		}

		// Token: 0x06000D37 RID: 3383 RVA: 0x0005B490 File Offset: 0x00059690
		public override Vector3 GetMovementVelocity()
		{
			return this.savedMovementVelocity;
		}

		// Token: 0x06000D38 RID: 3384 RVA: 0x0005B498 File Offset: 0x00059698
		public Vector3 GetMomentum()
		{
			Vector3 result = this.momentum;
			if (this.useLocalMomentum)
			{
				result = this.tr.localToWorldMatrix * this.momentum;
			}
			return result;
		}

		// Token: 0x06000D39 RID: 3385 RVA: 0x0005B4D6 File Offset: 0x000596D6
		public override bool IsGrounded()
		{
			return this.currentControllerState == AdvancedWalkerController.ControllerState.Grounded || this.currentControllerState == AdvancedWalkerController.ControllerState.Sliding;
		}

		// Token: 0x06000D3A RID: 3386 RVA: 0x0005B4EB File Offset: 0x000596EB
		public bool IsSliding()
		{
			return this.currentControllerState == AdvancedWalkerController.ControllerState.Sliding;
		}

		// Token: 0x06000D3B RID: 3387 RVA: 0x0005B4F8 File Offset: 0x000596F8
		public void AddMomentum(Vector3 _momentum)
		{
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.localToWorldMatrix * this.momentum;
			}
			this.momentum += _momentum;
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * this.momentum;
			}
		}

		// Token: 0x06000D3C RID: 3388 RVA: 0x0005B573 File Offset: 0x00059773
		public void SetMomentum(Vector3 _newMomentum)
		{
			if (this.useLocalMomentum)
			{
				this.momentum = this.tr.worldToLocalMatrix * _newMomentum;
				return;
			}
			this.momentum = _newMomentum;
		}

		// Token: 0x06000D3D RID: 3389 RVA: 0x0005B5A6 File Offset: 0x000597A6
		public void SetStopMovement(bool isStop)
		{
			this.isStopMovement = isStop;
		}

		// Token: 0x04001418 RID: 5144
		protected Transform tr;

		// Token: 0x04001419 RID: 5145
		protected Mover mover;

		// Token: 0x0400141A RID: 5146
		protected CharacterInput characterInput;

		// Token: 0x0400141B RID: 5147
		protected CeilingDetector ceilingDetector;

		// Token: 0x0400141C RID: 5148
		private bool jumpInputIsLocked;

		// Token: 0x0400141D RID: 5149
		private bool jumpKeyWasPressed;

		// Token: 0x0400141E RID: 5150
		private bool jumpKeyWasLetGo;

		// Token: 0x0400141F RID: 5151
		private bool jumpKeyIsPressed;

		// Token: 0x04001420 RID: 5152
		private bool isStopMovement;

		// Token: 0x04001421 RID: 5153
		public float m_MagicAirJumpTime = 1f;

		// Token: 0x04001422 RID: 5154
		public float m_MagicAirJumpTimer;

		// Token: 0x04001423 RID: 5155
		public float movementSpeed = 7f;

		// Token: 0x04001424 RID: 5156
		private float movementSpeedModified = 7f;

		// Token: 0x04001425 RID: 5157
		public float airControlRate = 2f;

		// Token: 0x04001426 RID: 5158
		public float jumpSpeed = 10f;

		// Token: 0x04001427 RID: 5159
		public float jumpDuration = 0.2f;

		// Token: 0x04001428 RID: 5160
		private float currentJumpStartTime;

		// Token: 0x04001429 RID: 5161
		public float airFriction = 0.5f;

		// Token: 0x0400142A RID: 5162
		public float groundFriction = 100f;

		// Token: 0x0400142B RID: 5163
		protected Vector3 momentum = Vector3.zero;

		// Token: 0x0400142C RID: 5164
		private Vector3 savedVelocity = Vector3.zero;

		// Token: 0x0400142D RID: 5165
		private Vector3 savedMovementVelocity = Vector3.zero;

		// Token: 0x0400142E RID: 5166
		public float gravity = 30f;

		// Token: 0x0400142F RID: 5167
		[Tooltip("How fast the character will slide down steep slopes.")]
		public float slideGravity = 5f;

		// Token: 0x04001430 RID: 5168
		public float slopeLimit = 80f;

		// Token: 0x04001431 RID: 5169
		[Tooltip("Whether to calculate and apply momentum relative to the controller's transform.")]
		public bool useLocalMomentum;

		// Token: 0x04001432 RID: 5170
		private AdvancedWalkerController.ControllerState currentControllerState = AdvancedWalkerController.ControllerState.Falling;

		// Token: 0x04001433 RID: 5171
		[Tooltip("Optional camera transform used for calculating movement direction. If assigned, character movement will take camera view into account.")]
		public Transform cameraTransform;

		// Token: 0x0200027D RID: 637
		public enum ControllerState
		{
			// Token: 0x04001691 RID: 5777
			Grounded,
			// Token: 0x04001692 RID: 5778
			Sliding,
			// Token: 0x04001693 RID: 5779
			Falling,
			// Token: 0x04001694 RID: 5780
			Rising,
			// Token: 0x04001695 RID: 5781
			Jumping
		}
	}
}
