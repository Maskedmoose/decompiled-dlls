﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200008A RID: 138
public class LockedRoomBlocker : MonoBehaviour
{
	// Token: 0x06000574 RID: 1396 RVA: 0x0002D5C5 File Offset: 0x0002B7C5
	private void Awake()
	{
		this.m_Wall.SetActive(!this.m_IsFrontRow);
		this.m_Building.SetActive(this.m_IsFrontRow);
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x0002D5EC File Offset: 0x0002B7EC
	public void HideBlocker()
	{
		this.m_Anim.Play();
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x0002D5FA File Offset: 0x0002B7FA
	private IEnumerator DelayHide()
	{
		yield return new WaitForSeconds(1f);
		base.gameObject.SetActive(false);
		yield break;
	}

	// Token: 0x04000718 RID: 1816
	public bool m_IsFrontRow;

	// Token: 0x04000719 RID: 1817
	public GameObject m_Wall;

	// Token: 0x0400071A RID: 1818
	public GameObject m_Building;

	// Token: 0x0400071B RID: 1819
	public Animation m_Anim;
}
