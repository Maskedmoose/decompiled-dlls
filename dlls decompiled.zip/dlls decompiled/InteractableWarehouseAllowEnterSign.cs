﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200002B RID: 43
public class InteractableWarehouseAllowEnterSign : InteractableObject
{
	// Token: 0x0600022B RID: 555 RVA: 0x00014FF0 File Offset: 0x000131F0
	public override void OnMouseButtonUp()
	{
		if (this.m_IsSwapping)
		{
			return;
		}
		CPlayerData.m_IsWarehouseDoorClosed = !CPlayerData.m_IsWarehouseDoorClosed;
		this.m_IsSwapping = true;
		this.m_Anim.Play();
		base.StartCoroutine(this.DelaySwapMesh());
		SoundManager.GenericPop(1f, 1f);
	}

	// Token: 0x0600022C RID: 556 RVA: 0x00015042 File Offset: 0x00013242
	private IEnumerator DelaySwapMesh()
	{
		yield return new WaitForSeconds(0.6f);
		SoundManager.PlayAudio("SFX_WhipSoft", 0.4f, 1.2f);
		this.EvaluateSignOpenCloseMesh();
		yield return new WaitForSeconds(0.7f);
		this.m_IsSwapping = false;
		yield break;
	}

	// Token: 0x0600022D RID: 557 RVA: 0x00015051 File Offset: 0x00013251
	private void EvaluateSignOpenCloseMesh()
	{
		this.m_OpenShopMesh.SetActive(CPlayerData.m_IsWarehouseDoorClosed);
		this.m_CloseShopMesh.SetActive(!CPlayerData.m_IsWarehouseDoorClosed);
		CSingleton<UnlockRoomManager>.Instance.EvaluateWarehouseRoomOpenClose();
	}

	// Token: 0x0600022E RID: 558 RVA: 0x00015080 File Offset: 0x00013280
	protected void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x0600022F RID: 559 RVA: 0x000150A1 File Offset: 0x000132A1
	protected void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
		}
	}

	// Token: 0x06000230 RID: 560 RVA: 0x000150C2 File Offset: 0x000132C2
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		this.EvaluateSignOpenCloseMesh();
	}

	// Token: 0x04000269 RID: 617
	public Animation m_Anim;

	// Token: 0x0400026A RID: 618
	public GameObject m_OpenShopMesh;

	// Token: 0x0400026B RID: 619
	public GameObject m_CloseShopMesh;

	// Token: 0x0400026C RID: 620
	private bool m_IsSwapping;

	// Token: 0x0400026D RID: 621
	private bool m_IsDayEnded;
}
