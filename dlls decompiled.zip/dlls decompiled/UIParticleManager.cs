﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000098 RID: 152
public class UIParticleManager : CSingleton<UIParticleManager>
{
	// Token: 0x060005EB RID: 1515 RVA: 0x000310C5 File Offset: 0x0002F2C5
	public void Awake()
	{
		this.m_Camera.SetActive(false);
	}

	// Token: 0x060005EC RID: 1516 RVA: 0x000310D4 File Offset: 0x0002F2D4
	public void Update()
	{
		if (this.m_HasActiveParticle)
		{
			if (this.m_IsLerp)
			{
				this.m_LerpTimer += Time.deltaTime * this.m_LerpSpeed;
				this.m_CurrentParticleTransform.position = Vector3.Lerp(this.m_StartPos, this.m_TargetPos, this.m_LerpTimer);
			}
			this.m_Timer += Time.deltaTime;
			if (this.m_Timer >= this.m_DeactivateTime)
			{
				this.m_CurrentParticleTransform.position = this.m_StartPos;
				this.m_IsLerp = true;
				this.m_HasActiveParticle = false;
				this.m_Camera.SetActive(false);
			}
		}
	}

	// Token: 0x060005ED RID: 1517 RVA: 0x0003117C File Offset: 0x0002F37C
	public static void SpawnParticle(EParticleType particleType)
	{
		CSingleton<UIParticleManager>.Instance.m_Camera.SetActive(true);
		CSingleton<UIParticleManager>.Instance.m_HasActiveParticle = true;
		CSingleton<UIParticleManager>.Instance.m_Timer = 0f;
		CSingleton<UIParticleManager>.Instance.m_DeactivateTime = CSingleton<UIParticleManager>.Instance.m_DeactivateTimeList[(int)particleType];
		CSingleton<UIParticleManager>.Instance.m_ParticleList[(int)particleType].gameObject.SetActive(true);
		CSingleton<UIParticleManager>.Instance.m_ParticleList[(int)particleType].Play();
	}

	// Token: 0x060005EE RID: 1518 RVA: 0x00031200 File Offset: 0x0002F400
	public static void SpawnParticleMove(EParticleType particleType, Vector3 movePos, float time)
	{
		CSingleton<UIParticleManager>.Instance.m_LerpTimer = 0f;
		if (CSingleton<UIParticleManager>.Instance.m_CurrentParticleTransform)
		{
			CSingleton<UIParticleManager>.Instance.m_CurrentParticleTransform.position = CSingleton<UIParticleManager>.Instance.m_StartPos;
		}
		UIParticleManager.SpawnParticle(particleType);
		CSingleton<UIParticleManager>.Instance.m_CurrentParticleTransform = CSingleton<UIParticleManager>.Instance.m_ParticleList[(int)particleType].transform;
		CSingleton<UIParticleManager>.Instance.m_StartPos = CSingleton<UIParticleManager>.Instance.m_CurrentParticleTransform.position;
		CSingleton<UIParticleManager>.Instance.m_TargetPos = CSingleton<UIParticleManager>.Instance.m_StartPos + movePos;
		if (time <= 0f)
		{
			time = 0.01f;
		}
		CSingleton<UIParticleManager>.Instance.m_LerpSpeed = 1f / time;
		CSingleton<UIParticleManager>.Instance.m_IsLerp = true;
	}

	// Token: 0x040007BE RID: 1982
	public GameObject m_Camera;

	// Token: 0x040007BF RID: 1983
	public List<ParticleSystem> m_ParticleList;

	// Token: 0x040007C0 RID: 1984
	public List<float> m_DeactivateTimeList;

	// Token: 0x040007C1 RID: 1985
	private bool m_HasActiveParticle;

	// Token: 0x040007C2 RID: 1986
	private float m_Timer;

	// Token: 0x040007C3 RID: 1987
	private float m_DeactivateTime = 3f;

	// Token: 0x040007C4 RID: 1988
	private bool m_IsLerp;

	// Token: 0x040007C5 RID: 1989
	private float m_LerpTimer;

	// Token: 0x040007C6 RID: 1990
	private float m_LerpSpeed = 1f;

	// Token: 0x040007C7 RID: 1991
	private Vector3 m_StartPos;

	// Token: 0x040007C8 RID: 1992
	private Vector3 m_TargetPos;

	// Token: 0x040007C9 RID: 1993
	private Transform m_CurrentParticleTransform;
}
