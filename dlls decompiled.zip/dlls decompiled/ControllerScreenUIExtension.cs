﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200010D RID: 269
public class ControllerScreenUIExtension : MonoBehaviour
{
	// Token: 0x060007DA RID: 2010 RVA: 0x0003A284 File Offset: 0x00038484
	public void OnOpenScreen()
	{
		if (this.m_CurrentControllerButton)
		{
			this.m_CurrentControllerButton.OnSelectionDeactivate();
		}
		if (this.m_StartControllerButton)
		{
			this.m_CurrentControllerButton = this.m_StartControllerButton;
			Vector2 controllerButtonIndex = this.GetControllerButtonIndex(this.m_CurrentControllerButton);
			this.m_CurrentCtrlBtnXIndex = Mathf.RoundToInt(controllerButtonIndex.x);
			this.m_CurrentCtrlBtnYIndex = Mathf.RoundToInt(controllerButtonIndex.y);
		}
		else
		{
			this.m_CurrentCtrlBtnXIndex = 0;
			this.m_CurrentCtrlBtnYIndex = 0;
			this.m_CurrentControllerButton = this.GetControllerButton(0, 0);
		}
		this.m_CurrentControllerButton.OnSelectionActive();
		if (this.GetCtrlBtnXChangeMethod(this.m_CurrentCtrlBtnYIndex) == ECtrlBtnXChangeMethod.RememberIndexX)
		{
			this.m_LastChangeMethodCtrlBtnXIndex = this.m_CurrentCtrlBtnXIndex;
		}
	}

	// Token: 0x060007DB RID: 2011 RVA: 0x0003A335 File Offset: 0x00038535
	public void OnCloseChildScreen()
	{
		if (this.m_CurrentControllerButton)
		{
			this.m_CurrentControllerButton.OnSelectionDeactivate();
			this.m_CurrentControllerButton.OnSelectionActive();
		}
	}

	// Token: 0x060007DC RID: 2012 RVA: 0x0003A35A File Offset: 0x0003855A
	private ControllerButton GetControllerButton(int indexX, int indexY)
	{
		return this.m_ControllerBtnColumnList[indexY].rowList[indexX];
	}

	// Token: 0x060007DD RID: 2013 RVA: 0x0003A374 File Offset: 0x00038574
	private Vector2 GetControllerButtonIndex(ControllerButton ctrlBtn)
	{
		Vector2 result = default(Vector2);
		int num = -1;
		int num2 = -1;
		for (int i = 0; i < this.m_ControllerBtnColumnList.Count; i++)
		{
			for (int j = 0; j < this.m_ControllerBtnColumnList[i].rowList.Count; j++)
			{
				if (this.m_ControllerBtnColumnList[i].rowList[j] == ctrlBtn)
				{
					num = j;
					num2 = i;
					break;
				}
			}
		}
		result.x = (float)num;
		result.y = (float)num2;
		return result;
	}

	// Token: 0x060007DE RID: 2014 RVA: 0x0003A404 File Offset: 0x00038604
	public void RunUpdate()
	{
		if (CSingleton<CGameManager>.Instance.m_IsPrologue || !CSingleton<InputManager>.Instance.m_IsControllerActive || CSingleton<CGameManager>.Instance.m_DisableController)
		{
			return;
		}
		if (InputManager.GetKeyDownAction(EGameAction.MenuConfirm))
		{
			if (this.m_CanRapidFireConfirmBtn)
			{
				this.m_IsHoldingConfirmBtn = true;
			}
			this.OnPressConfirm();
		}
		else if (InputManager.GetKeyUpAction(EGameAction.MenuConfirm))
		{
			if (this.m_CanRapidFireConfirmBtn)
			{
				this.m_IsHoldingConfirmBtn = false;
				this.m_JoystickRapidFireStartTimer = 0f;
				this.m_IsJoystickRapidFire = false;
			}
		}
		else if (InputManager.GetKeyDownAction(EGameAction.MenuBack))
		{
			this.OnPressCancel();
		}
		if (InputManager.GetLeftAnalogDown(0, true))
		{
			this.m_IsHoldingLeftJoystickRight = true;
			this.OnPressRight();
			return;
		}
		if (InputManager.GetLeftAnalogUp(0, true))
		{
			this.m_IsHoldingLeftJoystickRight = false;
			this.m_JoystickRapidFireStartTimer = 0f;
			this.m_IsJoystickRapidFire = false;
		}
		if (InputManager.GetLeftAnalogDown(0, false))
		{
			this.m_IsHoldingLeftJoystickLeft = true;
			this.OnPressLeft();
			return;
		}
		if (InputManager.GetLeftAnalogUp(0, false))
		{
			this.m_IsHoldingLeftJoystickLeft = false;
			this.m_JoystickRapidFireStartTimer = 0f;
			this.m_IsJoystickRapidFire = false;
		}
		if (InputManager.GetLeftAnalogDown(1, true))
		{
			this.m_IsHoldingLeftJoystickUp = true;
			this.OnPressUp();
			return;
		}
		if (InputManager.GetLeftAnalogUp(1, true))
		{
			this.m_IsHoldingLeftJoystickUp = false;
			this.m_JoystickRapidFireStartTimer = 0f;
			this.m_IsJoystickRapidFire = false;
		}
		if (InputManager.GetLeftAnalogDown(1, false))
		{
			this.m_IsHoldingLeftJoystickDown = true;
			this.OnPressDown();
			return;
		}
		if (InputManager.GetLeftAnalogUp(1, false))
		{
			this.m_IsHoldingLeftJoystickDown = false;
			this.m_JoystickRapidFireStartTimer = 0f;
			this.m_IsJoystickRapidFire = false;
		}
		if (!this.m_IsJoystickRapidFire)
		{
			if (this.m_IsHoldingLeftJoystickRight || this.m_IsHoldingLeftJoystickLeft || this.m_IsHoldingLeftJoystickUp || this.m_IsHoldingLeftJoystickDown || (this.m_CanRapidFireConfirmBtn && this.m_IsHoldingConfirmBtn))
			{
				this.m_JoystickRapidFireStartTimer += Time.unscaledDeltaTime;
				if (this.m_JoystickRapidFireStartTimer >= this.m_JoystickRapidFireStartTime)
				{
					this.m_JoystickRapidFireStartTimer = 0f;
					this.m_JoystickRapidFireTimer = 0f;
					this.m_IsJoystickRapidFire = true;
					return;
				}
			}
		}
		else if (this.m_IsJoystickRapidFire)
		{
			this.m_JoystickRapidFireTimer += Time.unscaledDeltaTime;
			if (this.m_JoystickRapidFireTimer >= this.m_JoystickRapidFireTime)
			{
				this.m_JoystickRapidFireTimer = 0f;
				if (this.m_IsHoldingLeftJoystickLeft)
				{
					this.OnPressLeft();
					return;
				}
				if (this.m_IsHoldingLeftJoystickRight)
				{
					this.OnPressRight();
					return;
				}
				if (this.m_IsHoldingLeftJoystickUp)
				{
					this.OnPressUp();
					return;
				}
				if (this.m_IsHoldingLeftJoystickDown)
				{
					this.OnPressDown();
					return;
				}
				if (this.m_IsHoldingConfirmBtn)
				{
					this.OnPressConfirm();
				}
			}
		}
	}

	// Token: 0x060007DF RID: 2015 RVA: 0x0003A674 File Offset: 0x00038874
	public void UpdateControllerBtnIndex_X(int addX)
	{
		this.m_CurrentCtrlBtnXIndex += addX;
		if (this.m_CurrentCtrlBtnXIndex < 0)
		{
			if (this.m_LoopWithinRowOnly)
			{
				for (int i = this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count - 1; i >= 0; i--)
				{
					if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[i].IsActive())
					{
						this.m_CurrentCtrlBtnXIndex = i;
						break;
					}
				}
			}
			else if (this.m_SettingScreenLoopSpecial)
			{
				this.EvaluateSpecialLoopCaseForSettingScreen();
			}
			else
			{
				this.UpdateControllerBtnIndex_Y(-1, true);
				for (int j = this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count - 1; j >= 0; j--)
				{
					if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[j].IsActive())
					{
						this.m_CurrentCtrlBtnXIndex = j;
						break;
					}
				}
			}
		}
		else if (this.m_CurrentCtrlBtnXIndex >= this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count)
		{
			if (this.m_LoopWithinRowOnly)
			{
				this.m_CurrentCtrlBtnXIndex = 0;
			}
			else if (this.m_SettingScreenLoopSpecial)
			{
				this.EvaluateSpecialLoopCaseForSettingScreen();
			}
			else
			{
				int currentCtrlBtnYIndex = this.m_CurrentCtrlBtnYIndex;
				this.UpdateControllerBtnIndex_Y(1, true);
				if (currentCtrlBtnYIndex != this.m_CurrentCtrlBtnYIndex)
				{
					this.m_CurrentCtrlBtnXIndex = 0;
				}
			}
		}
		else
		{
			bool flag = true;
			if (addX > 0)
			{
				for (int k = this.m_CurrentCtrlBtnXIndex; k < this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count; k++)
				{
					if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[k].IsActive())
					{
						flag = false;
						this.m_CurrentCtrlBtnXIndex = k;
						break;
					}
				}
			}
			else
			{
				for (int l = this.m_CurrentCtrlBtnXIndex; l >= 0; l--)
				{
					if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[l].IsActive())
					{
						flag = false;
						this.m_CurrentCtrlBtnXIndex = l;
						break;
					}
				}
			}
			if (flag)
			{
				if (addX > 0)
				{
					if (this.m_LoopWithinRowOnly)
					{
						this.m_CurrentCtrlBtnXIndex = 0;
					}
					else if (this.m_SettingScreenLoopSpecial)
					{
						this.EvaluateSpecialLoopCaseForSettingScreen();
					}
					else
					{
						this.UpdateControllerBtnIndex_Y(1, true);
						this.m_CurrentCtrlBtnXIndex = 0;
					}
				}
				else if (addX < 0)
				{
					if (this.m_LoopWithinRowOnly)
					{
						for (int m = this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count - 1; m >= 0; m--)
						{
							if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[m].IsActive())
							{
								this.m_CurrentCtrlBtnXIndex = m;
								break;
							}
						}
					}
					else if (this.m_SettingScreenLoopSpecial)
					{
						this.EvaluateSpecialLoopCaseForSettingScreen();
					}
					else
					{
						this.m_CurrentCtrlBtnXIndex = 1000;
						this.UpdateControllerBtnIndex_Y(-1, true);
					}
				}
			}
		}
		if (this.m_CurrentControllerButton)
		{
			this.m_CurrentControllerButton.OnSelectionDeactivate();
		}
		this.m_CurrentControllerButton = this.GetControllerButton(this.m_CurrentCtrlBtnXIndex, this.m_CurrentCtrlBtnYIndex);
		this.m_CurrentControllerButton.OnSelectionActive();
		if (this.m_SliderScreen && this.m_CurrentControllerButton.m_CanScrollerSlide)
		{
			this.m_SliderScreen.ScrollToUI(this.m_CurrentControllerButton.gameObject, false, this.m_SliderOffsetY);
		}
	}

	// Token: 0x060007E0 RID: 2016 RVA: 0x0003A9D0 File Offset: 0x00038BD0
	private void EvaluateSpecialLoopCaseForSettingScreen()
	{
		if (this.GetCtrlBtnXChangeMethod(this.m_CurrentCtrlBtnYIndex) == ECtrlBtnXChangeMethod.SettingScreenSkipSideButtonIndexY)
		{
			this.m_CurrentCtrlBtnXIndex = 0;
			this.m_CurrentCtrlBtnYIndex = CSingleton<SettingScreen>.Instance.m_SubSettingBtnHighlight.Count;
			bool flag = false;
			for (int i = this.m_CurrentCtrlBtnYIndex; i < this.m_ControllerBtnColumnList.Count; i++)
			{
				for (int j = 0; j < this.m_ControllerBtnColumnList[i].rowList.Count; j++)
				{
					if (this.m_ControllerBtnColumnList[i].rowList[j].IsActive())
					{
						flag = true;
						this.m_CurrentCtrlBtnXIndex = j;
						this.m_CurrentCtrlBtnYIndex = i;
						break;
					}
				}
				if (flag)
				{
					return;
				}
			}
			return;
		}
		this.m_CurrentCtrlBtnXIndex = 0;
		this.m_CurrentCtrlBtnYIndex = this.m_IndexYWhenLoopXEnd;
	}

	// Token: 0x060007E1 RID: 2017 RVA: 0x0003AA90 File Offset: 0x00038C90
	public void UpdateControllerBtnIndex_Y(int addY, bool ignoreUpdateControllerBtn = false)
	{
		ECtrlBtnXChangeMethod ctrlBtnXChangeMethod = this.GetCtrlBtnXChangeMethod(this.m_CurrentCtrlBtnYIndex);
		if (ctrlBtnXChangeMethod == ECtrlBtnXChangeMethod.RememberIndexX)
		{
			this.m_LastChangeMethodCtrlBtnXIndex = this.m_CurrentCtrlBtnXIndex;
		}
		this.m_CurrentCtrlBtnYIndex += addY;
		if (this.m_CurrentCtrlBtnYIndex < 0)
		{
			if (this.m_CanLoopY)
			{
				bool flag = false;
				for (int i = this.m_ControllerBtnColumnList.Count - 1; i >= 0; i--)
				{
					for (int j = this.m_ControllerBtnColumnList[i].rowList.Count - 1; j >= 0; j--)
					{
						if (this.m_ControllerBtnColumnList[i].rowList[j].IsActive())
						{
							flag = true;
							this.m_CurrentCtrlBtnYIndex = i;
							break;
						}
					}
					if (flag)
					{
						break;
					}
				}
			}
			else
			{
				this.m_CurrentCtrlBtnYIndex = 0;
			}
		}
		else if (this.m_CurrentCtrlBtnYIndex >= this.m_ControllerBtnColumnList.Count)
		{
			if (this.m_CanLoopY)
			{
				this.m_CurrentCtrlBtnYIndex = 0;
			}
			else
			{
				this.m_CurrentCtrlBtnYIndex = this.m_ControllerBtnColumnList.Count - 1;
			}
		}
		else
		{
			bool flag2 = true;
			if (addY > 0)
			{
				for (int k = this.m_CurrentCtrlBtnYIndex; k < this.m_ControllerBtnColumnList.Count; k++)
				{
					int l = this.m_ControllerBtnColumnList[k].rowList.Count - 1;
					while (l >= 0)
					{
						if (this.m_ControllerBtnColumnList[k].rowList[l].IsActive())
						{
							flag2 = false;
							this.m_CurrentCtrlBtnYIndex = k;
							if (this.m_CurrentCtrlBtnXIndex > l)
							{
								this.m_CurrentCtrlBtnXIndex = l;
								break;
							}
							break;
						}
						else
						{
							l--;
						}
					}
					if (!flag2)
					{
						break;
					}
				}
			}
			else
			{
				for (int m = this.m_CurrentCtrlBtnYIndex; m >= 0; m--)
				{
					int n = this.m_ControllerBtnColumnList[m].rowList.Count - 1;
					while (n >= 0)
					{
						if (this.m_ControllerBtnColumnList[m].rowList[n].IsActive())
						{
							flag2 = false;
							this.m_CurrentCtrlBtnYIndex = m;
							if (this.m_CurrentCtrlBtnXIndex > n)
							{
								this.m_CurrentCtrlBtnXIndex = n;
								break;
							}
							break;
						}
						else
						{
							n--;
						}
					}
					if (!flag2)
					{
						break;
					}
				}
			}
			if (flag2)
			{
				if (this.m_CanLoopY)
				{
					this.m_CurrentCtrlBtnYIndex = 0;
				}
				else
				{
					this.m_CurrentCtrlBtnYIndex--;
				}
			}
		}
		if (this.m_CurrentCtrlBtnXIndex >= this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count)
		{
			this.m_CurrentCtrlBtnXIndex = this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count - 1;
		}
		if (this.m_CurrentCtrlBtnXIndex > this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count - this.m_CurrentCtrlBtnXIndex)
		{
			for (int num = this.m_CurrentCtrlBtnXIndex; num < this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList.Count; num++)
			{
				if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[num].IsActive())
				{
					this.m_CurrentCtrlBtnXIndex = num;
					break;
				}
			}
		}
		else
		{
			for (int num2 = this.m_CurrentCtrlBtnXIndex; num2 >= 0; num2--)
			{
				if (this.m_ControllerBtnColumnList[this.m_CurrentCtrlBtnYIndex].rowList[num2].IsActive())
				{
					this.m_CurrentCtrlBtnXIndex = num2;
					break;
				}
			}
		}
		ctrlBtnXChangeMethod = this.GetCtrlBtnXChangeMethod(this.m_CurrentCtrlBtnYIndex);
		if (ctrlBtnXChangeMethod == ECtrlBtnXChangeMethod.RememberIndexX)
		{
			this.m_CurrentCtrlBtnXIndex = this.m_LastChangeMethodCtrlBtnXIndex;
		}
		else if (ctrlBtnXChangeMethod == ECtrlBtnXChangeMethod.AlwaysZeroifGoDown && addY > 0)
		{
			this.m_CurrentCtrlBtnXIndex = 0;
		}
		else if (ctrlBtnXChangeMethod == ECtrlBtnXChangeMethod.AlwaysGoIndexYOne)
		{
			this.m_CurrentCtrlBtnYIndex = 1;
		}
		if (ignoreUpdateControllerBtn)
		{
			return;
		}
		if (this.m_CurrentControllerButton)
		{
			this.m_CurrentControllerButton.OnSelectionDeactivate();
		}
		this.m_CurrentControllerButton = this.GetControllerButton(this.m_CurrentCtrlBtnXIndex, this.m_CurrentCtrlBtnYIndex);
		this.m_CurrentControllerButton.OnSelectionActive();
		if (this.m_SliderScreen && this.m_CurrentControllerButton.m_CanScrollerSlide)
		{
			this.m_SliderScreen.ScrollToUI(this.m_CurrentControllerButton.gameObject, false, this.m_SliderOffsetY);
		}
	}

	// Token: 0x060007E2 RID: 2018 RVA: 0x0003AE9D File Offset: 0x0003909D
	public void EvaluateCtrlBtnActiveChanged()
	{
		this.UpdateControllerBtnIndex_Y(-1, false);
	}

	// Token: 0x060007E3 RID: 2019 RVA: 0x0003AEA7 File Offset: 0x000390A7
	public void OnPressLeft()
	{
		if (CSingleton<ControllerScreenUIExtManager>.Instance.m_LockLJoystickHorizontal)
		{
			return;
		}
		SoundManager.GenericPop(0.5f, 1f);
		this.UpdateControllerBtnIndex_X(-1);
	}

	// Token: 0x060007E4 RID: 2020 RVA: 0x0003AECC File Offset: 0x000390CC
	public void OnPressRight()
	{
		if (CSingleton<ControllerScreenUIExtManager>.Instance.m_LockLJoystickHorizontal)
		{
			return;
		}
		SoundManager.GenericPop(0.5f, 1f);
		this.UpdateControllerBtnIndex_X(1);
	}

	// Token: 0x060007E5 RID: 2021 RVA: 0x0003AEF1 File Offset: 0x000390F1
	public void OnPressUp()
	{
		if (CSingleton<ControllerScreenUIExtManager>.Instance.m_LockLJoystickVertical)
		{
			return;
		}
		SoundManager.GenericPop(0.5f, 1f);
		this.UpdateControllerBtnIndex_Y(-1, false);
	}

	// Token: 0x060007E6 RID: 2022 RVA: 0x0003AF17 File Offset: 0x00039117
	public void OnPressDown()
	{
		if (CSingleton<ControllerScreenUIExtManager>.Instance.m_LockLJoystickVertical)
		{
			return;
		}
		SoundManager.GenericPop(0.5f, 1f);
		this.UpdateControllerBtnIndex_Y(1, false);
	}

	// Token: 0x060007E7 RID: 2023 RVA: 0x0003AF3D File Offset: 0x0003913D
	public void OnPressConfirm()
	{
		SoundManager.GenericConfirm(0.5f, 1f);
		this.m_CurrentControllerButton.OnPressConfirm();
	}

	// Token: 0x060007E8 RID: 2024 RVA: 0x0003AF59 File Offset: 0x00039159
	public void OnPressCancel()
	{
		if (!this.m_CloseScreenBtn)
		{
			return;
		}
		SoundManager.GenericCancel(0.5f, 1f);
		if (!this.m_CurrentControllerButton.OnPressCancel())
		{
			this.m_CloseScreenBtn.onClick.Invoke();
		}
	}

	// Token: 0x060007E9 RID: 2025 RVA: 0x0003AF95 File Offset: 0x00039195
	private ECtrlBtnXChangeMethod GetCtrlBtnXChangeMethod(int columnIndex)
	{
		if (columnIndex >= this.m_CtrlBtnXChangeMethodList.Count)
		{
			return ECtrlBtnXChangeMethod.Normal;
		}
		return this.m_CtrlBtnXChangeMethodList[columnIndex];
	}

	// Token: 0x04000F0D RID: 3853
	public List<ControllerBtnList> m_ControllerBtnColumnList;

	// Token: 0x04000F0E RID: 3854
	public List<ECtrlBtnXChangeMethod> m_CtrlBtnXChangeMethodList;

	// Token: 0x04000F0F RID: 3855
	public Button m_CloseScreenBtn;

	// Token: 0x04000F10 RID: 3856
	public ControllerButton m_StartControllerButton;

	// Token: 0x04000F11 RID: 3857
	public bool m_LoopWithinRowOnly;

	// Token: 0x04000F12 RID: 3858
	public bool m_CanLoopY = true;

	// Token: 0x04000F13 RID: 3859
	public bool m_CanRapidFireConfirmBtn;

	// Token: 0x04000F14 RID: 3860
	public bool m_SettingScreenLoopSpecial;

	// Token: 0x04000F15 RID: 3861
	public int m_IndexYWhenLoopXEnd;

	// Token: 0x04000F16 RID: 3862
	public GenericSliderScreen m_SliderScreen;

	// Token: 0x04000F17 RID: 3863
	public float m_SliderOffsetY;

	// Token: 0x04000F18 RID: 3864
	public ControllerButton m_CurrentControllerButton;

	// Token: 0x04000F19 RID: 3865
	public int m_CurrentCtrlBtnXIndex;

	// Token: 0x04000F1A RID: 3866
	public int m_CurrentCtrlBtnYIndex;

	// Token: 0x04000F1B RID: 3867
	public int m_LastChangeMethodCtrlBtnXIndex;

	// Token: 0x04000F1C RID: 3868
	private bool m_IsHoldingConfirmBtn;

	// Token: 0x04000F1D RID: 3869
	private bool m_IsHoldingLeftJoystickRight;

	// Token: 0x04000F1E RID: 3870
	private bool m_IsHoldingLeftJoystickLeft;

	// Token: 0x04000F1F RID: 3871
	private bool m_IsHoldingLeftJoystickUp;

	// Token: 0x04000F20 RID: 3872
	private bool m_IsHoldingLeftJoystickDown;

	// Token: 0x04000F21 RID: 3873
	private bool m_IsJoystickRapidFire;

	// Token: 0x04000F22 RID: 3874
	private float m_JoystickRapidFireStartTimer;

	// Token: 0x04000F23 RID: 3875
	private float m_JoystickRapidFireStartTime = 0.5f;

	// Token: 0x04000F24 RID: 3876
	private float m_JoystickRapidFireTimer;

	// Token: 0x04000F25 RID: 3877
	private float m_JoystickRapidFireTime = 0.08f;
}
