﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace CC
{
	// Token: 0x020001BF RID: 447
	public class Grid_Icon : MonoBehaviour
	{
		// Token: 0x06000CA4 RID: 3236 RVA: 0x00057F5A File Offset: 0x0005615A
		public void setIcon(Sprite icon)
		{
			if (icon != null)
			{
				this.Icon.SetActive(true);
				this.Icon.GetComponent<Image>().sprite = icon;
				return;
			}
			this.Icon.SetActive(false);
		}

		// Token: 0x06000CA5 RID: 3237 RVA: 0x00057F8F File Offset: 0x0005618F
		public void setSelected(bool selected)
		{
			base.gameObject.GetComponent<Image>().color = (selected ? this.ColorSelected : this.ColorUnselected);
			this.SelectedIcon.SetActive(selected);
		}

		// Token: 0x0400137A RID: 4986
		public string Name;

		// Token: 0x0400137B RID: 4987
		public int Slot;

		// Token: 0x0400137C RID: 4988
		public GameObject Icon;

		// Token: 0x0400137D RID: 4989
		public GameObject SelectedIcon;

		// Token: 0x0400137E RID: 4990
		public Color ColorSelected;

		// Token: 0x0400137F RID: 4991
		public Color ColorUnselected;
	}
}
