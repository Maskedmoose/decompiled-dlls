﻿using System;
using TMPro;
using UnityEngine.UI;

// Token: 0x02000076 RID: 118
public class RestockItemAddToCartScreen : UIScreenBase
{
	// Token: 0x060004C5 RID: 1221 RVA: 0x000293E4 File Offset: 0x000275E4
	public void UpdateData(RestockItemScreen restockItemScreen, int index)
	{
		this.m_Index = index;
		this.m_RestockItemScreen = restockItemScreen;
		this.m_RestockItemPanelUI = this.m_RestockItemScreen.GetRestockItemPanelUI(index);
		this.m_ItemImage.sprite = this.m_RestockItemPanelUI.m_ItemImage.sprite;
		this.m_ItemImage2.sprite = this.m_RestockItemPanelUI.m_ItemImage2.sprite;
		this.m_ItemImage2.enabled = this.m_RestockItemPanelUI.m_ItemImage2.enabled;
		this.m_ItemNameText.text = this.m_RestockItemPanelUI.m_ItemNameText.text;
		this.m_AmountText.text = this.m_RestockItemPanelUI.m_AmountText.text;
		this.m_UnitPriceText.text = this.m_RestockItemPanelUI.m_UnitPriceText.text;
		this.m_TotalPriceText.text = this.m_RestockItemPanelUI.m_TotalPriceText.text;
		this.m_PurchaseBoxCount = 1;
		this.EvaluateTotalCheckoutPrice();
	}

	// Token: 0x060004C6 RID: 1222 RVA: 0x000294DB File Offset: 0x000276DB
	public void OnPressAddCount()
	{
		this.m_PurchaseBoxCount++;
		this.EvaluateTotalCheckoutPrice();
	}

	// Token: 0x060004C7 RID: 1223 RVA: 0x000294F1 File Offset: 0x000276F1
	public void OnPressMinusCount()
	{
		this.m_PurchaseBoxCount--;
		if (this.m_PurchaseBoxCount <= 0)
		{
			this.m_PurchaseBoxCount = 0;
		}
		this.EvaluateTotalCheckoutPrice();
	}

	// Token: 0x060004C8 RID: 1224 RVA: 0x00029518 File Offset: 0x00027718
	private void EvaluateTotalCheckoutPrice()
	{
		this.m_PurchaseBoxCountText.text = this.m_PurchaseBoxCount.ToString();
		this.m_TotalCheckoutPrice = this.m_RestockItemPanelUI.GetTotalPrice() * (float)this.m_PurchaseBoxCount;
		this.m_TotalCheckoutPriceText.text = GameInstance.GetPriceString(this.m_TotalCheckoutPrice, false, true, false, "F2");
	}

	// Token: 0x060004C9 RID: 1225 RVA: 0x00029572 File Offset: 0x00027772
	public void OnPressAddToCartForCheckout()
	{
		if (this.m_PurchaseBoxCount > 0)
		{
			if (this.m_RestockItemScreen.HasEnoughCartSlot())
			{
				this.m_RestockItemScreen.AddToCartForCheckout(this.m_Index, this.m_PurchaseBoxCount);
				base.CloseScreen();
				return;
			}
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CartTooManyItem);
		}
	}

	// Token: 0x04000633 RID: 1587
	public Image m_ItemImage;

	// Token: 0x04000634 RID: 1588
	public Image m_ItemImage2;

	// Token: 0x04000635 RID: 1589
	public TextMeshProUGUI m_ItemNameText;

	// Token: 0x04000636 RID: 1590
	public TextMeshProUGUI m_AmountText;

	// Token: 0x04000637 RID: 1591
	public TextMeshProUGUI m_UnitPriceText;

	// Token: 0x04000638 RID: 1592
	public TextMeshProUGUI m_TotalPriceText;

	// Token: 0x04000639 RID: 1593
	public TextMeshProUGUI m_PurchaseBoxCountText;

	// Token: 0x0400063A RID: 1594
	public TextMeshProUGUI m_TotalCheckoutPriceText;

	// Token: 0x0400063B RID: 1595
	private RestockItemScreen m_RestockItemScreen;

	// Token: 0x0400063C RID: 1596
	private RestockItemPanelUI m_RestockItemPanelUI;

	// Token: 0x0400063D RID: 1597
	private int m_Index;

	// Token: 0x0400063E RID: 1598
	private int m_PurchaseBoxCount = 1;

	// Token: 0x0400063F RID: 1599
	private float m_TotalCheckoutPrice;
}
