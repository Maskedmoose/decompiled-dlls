﻿using System;

// Token: 0x0200005E RID: 94
public class ConfirmGoNextDayScreen : UIScreenBase
{
	// Token: 0x0600042B RID: 1067 RVA: 0x00024971 File Offset: 0x00022B71
	protected override void OnOpenScreen()
	{
		SoundManager.GenericMenuOpen(1f, 1f);
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(true);
		CSingleton<InteractionPlayerController>.Instance.EnterUIMode();
		base.OnOpenScreen();
	}

	// Token: 0x0600042C RID: 1068 RVA: 0x000249A2 File Offset: 0x00022BA2
	protected override void OnCloseScreen()
	{
		SoundManager.GenericMenuClose(1f, 1f);
		base.OnCloseScreen();
	}

	// Token: 0x0600042D RID: 1069 RVA: 0x000249B9 File Offset: 0x00022BB9
	public void OnPressConfirmBtn()
	{
		CEventManager.AddListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
		this.m_CanOpenScreen = false;
		CSingleton<InteractionPlayerController>.Instance.ShowGoNextDayScreen();
		SoundManager.GenericConfirm(1f, 1f);
		base.CloseScreen();
	}

	// Token: 0x0600042E RID: 1070 RVA: 0x000249F2 File Offset: 0x00022BF2
	public void OnPressCancelBtn()
	{
		SoundManager.GenericCancel(1f, 1f);
		base.CloseScreen();
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.SetStopMovement(false);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
	}

	// Token: 0x0600042F RID: 1071 RVA: 0x00024A23 File Offset: 0x00022C23
	protected void OnDayStarted(CEventPlayer_OnDayStarted evt)
	{
		CEventManager.RemoveListener<CEventPlayer_OnDayStarted>(new CEventManager.EventDelegate<CEventPlayer_OnDayStarted>(this.OnDayStarted));
		this.m_CanOpenScreen = true;
	}

	// Token: 0x06000430 RID: 1072 RVA: 0x00024A3D File Offset: 0x00022C3D
	public bool CanOpenScreen()
	{
		return this.m_CanOpenScreen;
	}

	// Token: 0x04000509 RID: 1289
	private bool m_CanOpenScreen = true;
}
