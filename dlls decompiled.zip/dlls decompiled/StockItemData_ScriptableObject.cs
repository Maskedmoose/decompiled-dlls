﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000134 RID: 308
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 4)]
public class StockItemData_ScriptableObject : ScriptableObject
{
	// Token: 0x040010E0 RID: 4320
	public List<EItemType> m_ShownAllItemType;

	// Token: 0x040010E1 RID: 4321
	public List<EItemType> m_ShownItemType;

	// Token: 0x040010E2 RID: 4322
	public List<EItemType> m_ShownAccessoryItemType;

	// Token: 0x040010E3 RID: 4323
	public List<EItemType> m_ShownFigurineItemType;

	// Token: 0x040010E4 RID: 4324
	public List<ECollectionPackType> m_ShownCollectionPackType;

	// Token: 0x040010E5 RID: 4325
	public List<ECardExpansionType> m_ShownCardExpansionType;

	// Token: 0x040010E6 RID: 4326
	public List<ItemData> m_ItemDataList;

	// Token: 0x040010E7 RID: 4327
	public List<ItemMeshData> m_ItemMeshDataList;

	// Token: 0x040010E8 RID: 4328
	public List<RestockData> m_RestockDataList;

	// Token: 0x040010E9 RID: 4329
	public List<GameEventData> m_GameEventDataList;

	// Token: 0x040010EA RID: 4330
	public List<CollectionPackImageSprite> m_CollectionPackImageSpriteList;

	// Token: 0x040010EB RID: 4331
	public float m_ShelfUnlockCostMultiplier;

	// Token: 0x040010EC RID: 4332
	public float m_ShelfUpgradeCostMultiplier;

	// Token: 0x040010ED RID: 4333
	public List<EQuestType> m_IdealQuestSequenceList;

	// Token: 0x040010EE RID: 4334
	public List<Sprite> m_AncientArtifactSpriteList;
}
