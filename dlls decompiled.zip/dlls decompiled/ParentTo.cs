﻿using System;
using UnityEngine;

// Token: 0x02000107 RID: 263
public class ParentTo : MonoBehaviour
{
	// Token: 0x060007B5 RID: 1973 RVA: 0x00039A64 File Offset: 0x00037C64
	private void Awake()
	{
		if (this.m_AutoParent)
		{
			this.StartParent();
		}
	}

	// Token: 0x060007B6 RID: 1974 RVA: 0x00039A74 File Offset: 0x00037C74
	public void StartParent()
	{
		base.transform.parent = this.m_Parent;
	}

	// Token: 0x04000EEF RID: 3823
	public bool m_AutoParent;

	// Token: 0x04000EF0 RID: 3824
	public Transform m_Parent;
}
