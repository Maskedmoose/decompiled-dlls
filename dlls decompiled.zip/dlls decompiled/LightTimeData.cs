﻿using System;

// Token: 0x02000039 RID: 57
[Serializable]
public class LightTimeData
{
	// Token: 0x0400034B RID: 843
	public bool m_IsLerpingSunIntensity;

	// Token: 0x0400034C RID: 844
	public bool m_IsBlendingSkybox;

	// Token: 0x0400034D RID: 845
	public bool m_IsStopBlendingSkybox;

	// Token: 0x0400034E RID: 846
	public bool m_HasDayEnded;

	// Token: 0x0400034F RID: 847
	public int m_TImeOfDayIndex;

	// Token: 0x04000350 RID: 848
	public int m_SkyboxIndex;

	// Token: 0x04000351 RID: 849
	public int m_TimeHour;

	// Token: 0x04000352 RID: 850
	public int m_TimeMin;

	// Token: 0x04000353 RID: 851
	public float m_TimeMinFloat;

	// Token: 0x04000354 RID: 852
	public float m_Timer;

	// Token: 0x04000355 RID: 853
	public float m_SunlightLerpTimer;

	// Token: 0x04000356 RID: 854
	public float m_SunlightRotationLerpTimer;

	// Token: 0x04000357 RID: 855
	public float m_GlobalBrightness;

	// Token: 0x04000358 RID: 856
	public float m_LerpStartBrightness;

	// Token: 0x04000359 RID: 857
	public float m_SkyboxBlendValue;

	// Token: 0x0400035A RID: 858
	public float m_SkyboxBlendSpeed;

	// Token: 0x0400035B RID: 859
	public float m_ShopLightOnTimer;

	// Token: 0x0400035C RID: 860
	public bool m_IsNightLightOn;

	// Token: 0x0400035D RID: 861
	public bool m_IsShopLightOn;

	// Token: 0x0400035E RID: 862
	public bool m_IsSunlightOn;
}
