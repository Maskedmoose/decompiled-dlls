﻿using System;

// Token: 0x020000B1 RID: 177
public class CEventPlayer_SetFame : CEvent
{
	// Token: 0x17000014 RID: 20
	// (get) Token: 0x06000700 RID: 1792 RVA: 0x0003801F File Offset: 0x0003621F
	// (set) Token: 0x06000701 RID: 1793 RVA: 0x00038027 File Offset: 0x00036227
	public int m_FameValue { get; private set; }

	// Token: 0x06000702 RID: 1794 RVA: 0x00038030 File Offset: 0x00036230
	public CEventPlayer_SetFame(int fameValue)
	{
		this.m_FameValue = fameValue;
	}
}
