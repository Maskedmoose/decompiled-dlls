﻿using System;

// Token: 0x020000E8 RID: 232
public enum EElementIndex
{
	// Token: 0x04000B47 RID: 2887
	None = -1,
	// Token: 0x04000B48 RID: 2888
	Fire,
	// Token: 0x04000B49 RID: 2889
	Earth,
	// Token: 0x04000B4A RID: 2890
	Water,
	// Token: 0x04000B4B RID: 2891
	Wind,
	// Token: 0x04000B4C RID: 2892
	Destiny,
	// Token: 0x04000B4D RID: 2893
	Champion,
	// Token: 0x04000B4E RID: 2894
	GhostWhite,
	// Token: 0x04000B4F RID: 2895
	GhostBlack,
	// Token: 0x04000B50 RID: 2896
	Megabot,
	// Token: 0x04000B51 RID: 2897
	FantasyRPG,
	// Token: 0x04000B52 RID: 2898
	CatJob,
	// Token: 0x04000B53 RID: 2899
	FoodieGO,
	// Token: 0x04000B54 RID: 2900
	FoodieGOBW,
	// Token: 0x04000B55 RID: 2901
	FoodieGOJP
}
