﻿using System;

// Token: 0x020000AD RID: 173
public class CEventPlayer_ReduceCoin : CEvent
{
	// Token: 0x1700000E RID: 14
	// (get) Token: 0x060006F0 RID: 1776 RVA: 0x00037F6F File Offset: 0x0003616F
	// (set) Token: 0x060006F1 RID: 1777 RVA: 0x00037F77 File Offset: 0x00036177
	public float m_CoinValue { get; private set; }

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x060006F2 RID: 1778 RVA: 0x00037F80 File Offset: 0x00036180
	// (set) Token: 0x060006F3 RID: 1779 RVA: 0x00037F88 File Offset: 0x00036188
	public bool m_NoLerp { get; private set; }

	// Token: 0x060006F4 RID: 1780 RVA: 0x00037F91 File Offset: 0x00036191
	public CEventPlayer_ReduceCoin(float coinValue, bool noLerp = false)
	{
		this.m_CoinValue = coinValue;
		this.m_NoLerp = noLerp;
	}
}
