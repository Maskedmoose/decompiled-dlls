﻿using System;
using System.Collections.Generic;

// Token: 0x020000A4 RID: 164
[Serializable]
public class CSettingData
{
	// Token: 0x0600069F RID: 1695 RVA: 0x00036D0D File Offset: 0x00034F0D
	public CSettingData()
	{
		if (CSettingData.instance == null)
		{
			CSettingData.instance = this;
		}
	}

	// Token: 0x060006A0 RID: 1696 RVA: 0x00036D22 File Offset: 0x00034F22
	public void PropagateLoadSettingData(CSettingData settingData)
	{
		if (settingData.m_KeybindBaseKeyList != null && settingData.m_KeybindBaseKeyList.Count > 0)
		{
			InputManager.m_KeybindBaseKeyList = settingData.m_KeybindBaseKeyList;
			InputManager.m_KeybindBaseJoystickCtrlList = settingData.m_KeybindBaseJoystickCtrlList;
		}
	}

	// Token: 0x060006A1 RID: 1697 RVA: 0x00036D50 File Offset: 0x00034F50
	public void SetLoadData<T>(ref T data, T loadData)
	{
		if (loadData != null)
		{
			T t = data;
			data = loadData;
		}
	}

	// Token: 0x060006A2 RID: 1698 RVA: 0x00036D7A File Offset: 0x00034F7A
	public void SaveSettingData()
	{
		InputManager.OnKeybindSettingSaved();
		this.SetLoadData<List<KeybindBaseKey>>(ref this.m_KeybindBaseKeyList, InputManager.m_KeybindBaseKeyList);
		this.SetLoadData<List<KeybindBaseGamepadControl>>(ref this.m_KeybindBaseJoystickCtrlList, InputManager.m_KeybindBaseJoystickCtrlList);
		CSaveLoad.SaveSetting();
	}

	// Token: 0x040008D5 RID: 2261
	public static CSettingData instance;

	// Token: 0x040008D6 RID: 2262
	private List<KeybindBaseKey> m_KeybindBaseKeyList;

	// Token: 0x040008D7 RID: 2263
	private List<KeybindBaseGamepadControl> m_KeybindBaseJoystickCtrlList;
}
