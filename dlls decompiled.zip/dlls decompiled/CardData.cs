﻿using System;

// Token: 0x0200002E RID: 46
[Serializable]
public class CardData
{
	// Token: 0x0600029D RID: 669 RVA: 0x000197A2 File Offset: 0x000179A2
	public ECardBorderType GetCardBorderType()
	{
		return CPlayerData.GetCardBorderType((int)this.borderType, this.expansionType);
	}

	// Token: 0x040002D3 RID: 723
	public ECardExpansionType expansionType;

	// Token: 0x040002D4 RID: 724
	public EMonsterType monsterType;

	// Token: 0x040002D5 RID: 725
	public ECardBorderType borderType;

	// Token: 0x040002D6 RID: 726
	public bool isFoil;

	// Token: 0x040002D7 RID: 727
	public bool isDestiny;

	// Token: 0x040002D8 RID: 728
	public bool isChampionCard;

	// Token: 0x040002D9 RID: 729
	public bool isNew;
}
