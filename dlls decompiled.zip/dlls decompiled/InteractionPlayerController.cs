﻿using System;
using System.Collections;
using System.Collections.Generic;
using CMF;
using UnityEngine;

// Token: 0x0200002D RID: 45
public class InteractionPlayerController : CSingleton<InteractionPlayerController>
{
	// Token: 0x06000245 RID: 581 RVA: 0x0001572D File Offset: 0x0001392D
	private void Awake()
	{
		this.EvaluateInvertedMouse();
	}

	// Token: 0x06000246 RID: 582 RVA: 0x00015735 File Offset: 0x00013935
	private void Start()
	{
		this.m_OpenCardBoxInnerMesh.gameObject.SetActive(false);
		this.m_DeodorantSprayVFX.Stop();
		this.m_SellShelfVFX.Stop();
		this.HideCursor();
	}

	// Token: 0x06000247 RID: 583 RVA: 0x00015764 File Offset: 0x00013964
	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.Backspace) || Input.GetKeyDown(KeyCode.LeftAlt) || Input.GetKeyDown(KeyCode.RightAlt))
		{
			CSingleton<ShelfManager>.Instance.SaveInteractableObjectData(false);
		}
		if (!this.m_IsInUIMode && !this.m_IsPhoneScreenMode)
		{
			if (InputManager.GetKeyDownAction(EGameAction.PauseGame) && !CSingleton<SettingScreen>.Instance.m_ScreenGrp.activeSelf && !SettingScreen.IsChangingKeybind())
			{
				PauseScreen.OpenScreen();
				return;
			}
			CSingleton<SettingScreen>.Instance.ManualUpdate();
		}
		if (this.m_IsHoldCardMode || this.m_IsViewCardAlbumMode)
		{
			this.m_HoldCardGrpRotation.transform.localRotation = Quaternion.Lerp(this.m_HoldCardGrpRotation.transform.localRotation, CSingleton<InteractionPlayerController>.Instance.m_HoldCardGrpTargetRotation, Time.deltaTime * 10f);
		}
		this.EvaluateCameraLerp();
		if (this.m_PlayerCollider.transform.position.y <= -0.5f || this.m_PlayerCollider.transform.position.y >= 5f)
		{
			this.m_PlayerCollider.transform.position = base.transform.position;
		}
		if (this.m_IsInUIMode)
		{
			return;
		}
		if (CSingleton<PauseScreen>.Instance.m_ScreenGrp.activeSelf || CSingleton<LoadingScreen>.Instance.m_ScreenGrp.activeSelf || (CPlayerData.m_TutorialIndex <= 0 && CPlayerData.m_ShopLevel < 1))
		{
			return;
		}
		if (this.m_IsPhoneScreenMode)
		{
			if ((InputManager.GetKeyUpAction(EGameAction.ClosePhone) || Input.GetKeyUp(KeyCode.Escape)) && !CSingleton<SettingScreen>.Instance.m_ScreenGrp.activeSelf)
			{
				PhoneManager.ExitPhoneMode();
				return;
			}
			CSingleton<SettingScreen>.Instance.ManualUpdate();
			return;
		}
		else
		{
			if (CSingleton<SettingScreen>.Instance.m_ScreenGrp.activeSelf)
			{
				return;
			}
			if ((InputManager.GetKeyDownAction(EGameAction.GoNextDay) || Input.GetKeyDown(KeyCode.KeypadEnter)) && LightManager.GetHasDayEnded())
			{
				if (ShelfManager.HasCustomerInCashCounterQueue() && this.m_ConfirmGoNextDayScreen.CanOpenScreen())
				{
					this.m_ConfirmGoNextDayScreen.OpenScreen();
					return;
				}
				this.ShowGoNextDayScreen();
			}
			if (!this.m_IsResetMousePress && InputManager.GetKeyDownAction(EGameAction.InteractLeft))
			{
				this.m_IsHoldingMouseDown = true;
			}
			if (InputManager.GetKeyUpAction(EGameAction.InteractLeft))
			{
				this.m_IsHoldingMouseDown = false;
			}
			if (!this.m_IsResetRightMousePress && InputManager.GetKeyDownAction(EGameAction.InteractRight))
			{
				this.m_IsHoldingRightMouseDown = true;
			}
			if (InputManager.GetKeyUpAction(EGameAction.InteractRight))
			{
				this.m_IsHoldingRightMouseDown = false;
			}
			if (this.m_IsHoldBoxMode)
			{
				this.RaycastHoldBoxState();
			}
			else if (this.m_IsHoldItemMode)
			{
				this.RaycastHoldItemState();
			}
			else if (this.m_IsHoldSprayMode)
			{
				this.RaycastHoldSprayState();
			}
			else if (this.m_IsWorkerInteractMode)
			{
				this.RaycastWorkerInteractMode();
			}
			else if (this.m_IsHoldCardMode)
			{
				this.RaycastHoldCardState();
			}
			else if (this.m_IsMovingObjectMode)
			{
				this.RaycastMovingObjectState();
			}
			else if (this.m_IsMovingBoxMode)
			{
				this.RaycastMovingBoxState();
			}
			else if (this.m_IsCashCounterMode)
			{
				this.RaycastCashCounterState();
			}
			else if (this.m_IsViewCardAlbumMode)
			{
				this.RaycastViewCardAlbumState();
			}
			else
			{
				this.RaycastNormalState();
				if (InputManager.GetKeyUpAction(EGameAction.OpenPhone))
				{
					PhoneManager.EnterPhoneMode();
				}
			}
			if (InputManager.GetKeyUpAction(EGameAction.InteractLeft))
			{
				this.m_IsResetMousePress = false;
			}
			if (InputManager.GetKeyUpAction(EGameAction.InteractRight))
			{
				this.m_IsResetRightMousePress = false;
			}
			if (this.m_IsResetMousePress && !InputManager.GetKeyHoldAction(EGameAction.InteractLeft))
			{
				this.m_IsResetMousePress = false;
			}
			if (this.m_IsResetRightMousePress && !InputManager.GetKeyHoldAction(EGameAction.InteractRight))
			{
				this.m_IsResetRightMousePress = false;
			}
			return;
		}
	}

	// Token: 0x06000248 RID: 584 RVA: 0x00015A96 File Offset: 0x00013C96
	public void ShowGoNextDayScreen()
	{
		if (LightManager.GetHasDayEnded())
		{
			if (this.m_IsCashCounterMode)
			{
				this.OnExitCashCounterMode();
			}
			ShelfManager.OnPressGoNextDay();
			EndOfDayReportScreen.OpenScreen();
		}
	}

	// Token: 0x06000249 RID: 585 RVA: 0x00015AB8 File Offset: 0x00013CB8
	public void ConfirmSellFurniture()
	{
		if (!this.m_CurrentHoldingBoxShelf)
		{
			return;
		}
		FurniturePurchaseData furniturePurchaseData = InventoryBase.GetFurniturePurchaseData(this.m_CurrentHoldingBoxShelf.GetBoxedObjectType());
		float price = furniturePurchaseData.price;
		furniturePurchaseData.GetName();
		CEventManager.QueueEvent(new CEventPlayer_AddCoin(price / 2f, false));
		this.m_CurrentHoldingBoxShelf.OnDestroyed();
		this.m_CurrentHoldingBoxShelf = null;
		this.OnExitHoldBoxMode();
		SoundManager.PlayAudio("SFX_CustomerBuy", 0.6f, 1f);
		this.m_SellShelfVFX.Play();
	}

	// Token: 0x0600024A RID: 586 RVA: 0x00015B3C File Offset: 0x00013D3C
	private void RaycastNormalState()
	{
		Ray ray = new Ray(this.m_Cam.transform.position, this.m_Cam.transform.forward);
		Debug.DrawRay(ray.origin, ray.direction * this.m_RayDistance);
		bool flag = false;
		int mask = LayerMask.GetMask(new string[]
		{
			"ShopModel",
			"Physics",
			"ItemCompartment",
			"Obstacles"
		});
		RaycastHit raycastHit;
		if (Physics.Raycast(ray, out raycastHit, this.m_RayDistance, mask))
		{
			Component transform = raycastHit.transform;
			WorkerCollider component = raycastHit.transform.GetComponent<WorkerCollider>();
			if (component)
			{
				if (this.m_HitWorkerCollider != component)
				{
					this.m_HitWorkerCollider = component;
					this.m_HitWorker = component.m_Worker;
					InteractionPlayerController.RemoveToolTip(EGameAction.InteractLeft);
					InteractionPlayerController.AddToolTip(EGameAction.InteractLeft, false, false);
					this.m_HitWorkerCollider.OnRaycasted();
				}
			}
			else
			{
				if (this.m_HitWorkerCollider)
				{
					InteractionPlayerController.RemoveToolTip(EGameAction.InteractLeft);
					this.m_HitWorkerCollider.OnRaycastEnded();
				}
				this.m_HitWorkerCollider = null;
				this.m_HitWorker = null;
			}
			InteractableStorageCompartment component2 = raycastHit.transform.GetComponent<InteractableStorageCompartment>();
			if (component2)
			{
				if (this.m_CurrentStorageCompartment != component2)
				{
					this.m_CurrentStorageCompartment = component2;
					if (this.m_CurrentStorageCompartment.GetShelfCompartment().GetItemCount() > 0)
					{
						InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
						InteractionPlayerController.AddToolTip(EGameAction.TakeBox, false, false);
					}
				}
			}
			else
			{
				if (this.m_CurrentStorageCompartment)
				{
					InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
				}
				this.m_CurrentStorageCompartment = null;
			}
			ShelfCompartment component3 = transform.transform.GetComponent<ShelfCompartment>();
			if (component3)
			{
				if (this.m_CurrentItemCompartment != component3)
				{
					this.m_CurrentItemCompartment = component3;
					if (this.m_CurrentItemCompartment.m_CanPutItem && this.m_CurrentItemCompartment.GetItemCount() > 0)
					{
						InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
						InteractionPlayerController.AddToolTip(EGameAction.TakeItem, true, false);
					}
				}
			}
			else if (this.m_CurrentItemCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
				this.m_CurrentItemCompartment = null;
			}
			InteractableCardCompartment component4 = raycastHit.transform.GetComponent<InteractableCardCompartment>();
			if (component4)
			{
				if (this.m_CurrentCardCompartment != component4)
				{
					this.m_CurrentCardCompartment = component4;
					InteractionPlayerController.RemoveToolTip(EGameAction.PutCard);
					InteractionPlayerController.RemoveToolTip(EGameAction.TakeCard);
					if (this.m_CurrentCardCompartment.m_StoredCardList.Count > 0)
					{
						InteractionPlayerController.AddToolTip(EGameAction.TakeCard, false, false);
					}
					else
					{
						InteractionPlayerController.AddToolTip(EGameAction.PutCard, false, false);
					}
				}
			}
			else if (this.m_CurrentCardCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.PutCard);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeCard);
				this.m_CurrentCardCompartment = null;
			}
			InteractablePlayTable component5 = raycastHit.transform.GetComponent<InteractablePlayTable>();
			if (component5)
			{
				if (this.m_CurrentPlayTable != component5)
				{
					this.m_CurrentPlayTable = component5;
					InteractionPlayerController.RemoveToolTip(EGameAction.ManageEvent);
					InteractionPlayerController.AddToolTip(EGameAction.ManageEvent, false, false);
				}
			}
			else if (this.m_CurrentPlayTable)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.ManageEvent);
				this.m_CurrentPlayTable = null;
			}
			InteractablePackagingBox_Item component6 = raycastHit.transform.GetComponent<InteractablePackagingBox_Item>();
			if (component6)
			{
				if (this.m_CurrentRaycastedPackageBoxItem != component6)
				{
					this.m_CurrentRaycastedPackageBoxItem = component6;
					InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
					InteractionPlayerController.AddToolTip(EGameAction.TakeBox, false, false);
					if (this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.GetItemCount() > 0)
					{
						InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
						InteractionPlayerController.AddToolTip(EGameAction.TakeItem, false, false);
					}
				}
			}
			else if (this.m_CurrentRaycastedPackageBoxItem)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
				this.m_CurrentRaycastedPackageBoxItem = null;
			}
			InteractableAutoCleanser component7 = raycastHit.transform.GetComponent<InteractableAutoCleanser>();
			if (component7)
			{
				if (this.m_CurrentAutoCleanser != component7)
				{
					if (this.m_CurrentAutoCleanser)
					{
						this.m_CurrentAutoCleanser.OnRaycastEnded();
					}
					this.m_CurrentAutoCleanser = component7;
					if (this.m_CurrentAutoCleanser.IsTurnedOn())
					{
						InteractionPlayerController.AddToolTip(EGameAction.TurnOff, false, false);
					}
					else
					{
						InteractionPlayerController.AddToolTip(EGameAction.TurnOn, false, false);
					}
				}
			}
			else if (this.m_CurrentAutoCleanser)
			{
				this.m_CurrentAutoCleanser.OnRaycastEnded();
				this.m_CurrentAutoCleanser = null;
				InteractionPlayerController.RemoveToolTip(EGameAction.TurnOff);
				InteractionPlayerController.RemoveToolTip(EGameAction.TurnOn);
			}
			InteractableWorkbench component8 = raycastHit.transform.GetComponent<InteractableWorkbench>();
			if (component8)
			{
				if (this.m_CurrentWorkbench != component8)
				{
					if (this.m_CurrentWorkbench)
					{
						this.m_CurrentWorkbench.OnRaycastEnded();
					}
					this.m_CurrentWorkbench = component8;
				}
			}
			else if (this.m_CurrentWorkbench)
			{
				this.m_CurrentWorkbench.OnRaycastEnded();
				this.m_CurrentWorkbench = null;
			}
		}
		else
		{
			if (this.m_CurrentItemCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
			}
			if (this.m_CurrentStorageCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
			}
			if (this.m_CurrentCardCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.PutCard);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeCard);
			}
			if (this.m_CurrentPlayTable)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.ManageEvent);
			}
			if (this.m_CurrentRaycastedPackageBoxItem)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
			}
			if (this.m_HitWorkerCollider)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.InteractLeft);
				this.m_HitWorkerCollider.OnRaycastEnded();
			}
			if (this.m_CurrentAutoCleanser)
			{
				this.m_CurrentAutoCleanser.OnRaycastEnded();
				InteractionPlayerController.RemoveToolTip(EGameAction.TurnOff);
				InteractionPlayerController.RemoveToolTip(EGameAction.TurnOn);
			}
			if (this.m_CurrentWorkbench)
			{
				this.m_CurrentWorkbench.OnRaycastEnded();
			}
			this.m_CurrentItemCompartment = null;
			this.m_CurrentStorageCompartment = null;
			this.m_CurrentCardCompartment = null;
			this.m_CurrentPlayTable = null;
			this.m_CurrentRaycastedPackageBoxItem = null;
			this.m_HitWorkerCollider = null;
			this.m_HitWorker = null;
			this.m_CurrentAutoCleanser = null;
			this.m_CurrentWorkbench = null;
		}
		int mask2 = LayerMask.GetMask(new string[]
		{
			"ShopModel",
			"Physics",
			"UI",
			"Obstacles"
		});
		if (Physics.Raycast(ray, out raycastHit, this.m_RayDistance, mask2))
		{
			Transform transform2 = raycastHit.transform;
			InteractableObject component9 = raycastHit.transform.GetComponent<InteractableObject>();
			if (component9)
			{
				if (this.m_CurrentRaycastObject != component9)
				{
					if (this.m_CurrentRaycastObject)
					{
						this.m_CurrentRaycastObject.OnRaycastEnded();
					}
					this.m_CurrentRaycastObject = component9;
					component9.OnRaycasted();
				}
			}
			else
			{
				flag = true;
			}
		}
		else
		{
			flag = true;
		}
		if (flag && this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.OnRaycastEnded();
			this.m_CurrentRaycastObject = null;
		}
		if (!this.m_IsResetMousePress && InputManager.GetKeyUpAction(EGameAction.InteractLeft))
		{
			if (this.m_CurrentStorageCompartment)
			{
				this.m_CurrentStorageCompartment.OnMouseButtonUp();
				return;
			}
			if (this.m_CurrentCardCompartment && this.m_CurrentCardCompartment.m_StoredCardList.Count <= 0)
			{
				this.m_CurrentPutOnDisplayCardCompartment = this.m_CurrentCardCompartment;
				this.SetIsPuttingCardOnDisplay(true);
				this.EnterViewCardAlbumMode();
				return;
			}
			if (this.m_CurrentPlayTable)
			{
				base.StartCoroutine(CSingleton<PhoneManager>.Instance.DelayOpenManageEventScreen());
				return;
			}
			if (this.m_HitWorkerCollider)
			{
				this.m_HitWorkerCollider.OnMousePress();
				return;
			}
			if (this.m_CurrentRaycastObject)
			{
				this.m_CurrentRaycastObject.OnMouseButtonUp();
				return;
			}
		}
		if (!this.m_IsResetRightMousePress && InputManager.GetKeyUpAction(EGameAction.InteractRight))
		{
			if (this.m_CurrentCardCompartment)
			{
				this.m_CurrentCardCompartment.OnRightMouseButtonUp();
				return;
			}
			if (this.m_CurrentRaycastObject)
			{
				this.m_CurrentRaycastObject.OnRightMouseButtonUp();
				return;
			}
		}
		if (this.m_IsHoldingRightMouseDown)
		{
			this.m_RightMouseDownTime += Time.deltaTime;
			if (this.m_RightMouseDownTime >= this.m_MouseHoldAutoFireRate)
			{
				this.m_RightMouseDownTime = 0f;
				this.EvaluateTakeItemFromShelf();
				return;
			}
		}
		else if (this.m_RightMouseDownTime > 0f)
		{
			this.m_RightMouseDownTime = 0f;
			this.EvaluateTakeItemFromShelf();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.OpenCardAlbum))
		{
			this.EnterViewCardAlbumMode();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.StartMoveObject) && this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.StartMoveObject();
			return;
		}
	}

	// Token: 0x0600024B RID: 587 RVA: 0x000162ED File Offset: 0x000144ED
	public void SetIsPuttingCardOnDisplay(bool isPuttingCardOnDisplay)
	{
		this.m_IsPuttingCardOnDisplay = isPuttingCardOnDisplay;
		if (!isPuttingCardOnDisplay)
		{
			this.m_CurrentPutOnDisplayCardCompartment = null;
		}
	}

	// Token: 0x0600024C RID: 588 RVA: 0x00016300 File Offset: 0x00014500
	public bool IsPuttingCardOnDisplay()
	{
		return this.m_IsPuttingCardOnDisplay;
	}

	// Token: 0x0600024D RID: 589 RVA: 0x00016308 File Offset: 0x00014508
	private void RaycastHoldBoxState()
	{
		Ray ray = new Ray(this.m_Cam.transform.position, this.m_Cam.transform.forward);
		int mask = LayerMask.GetMask(new string[]
		{
			"ShopModel",
			"ItemCompartment",
			"Obstacles"
		});
		RaycastHit raycastHit;
		if (Physics.Raycast(ray, out raycastHit, this.m_RayDistance, mask))
		{
			ShelfCompartment component = raycastHit.transform.transform.GetComponent<ShelfCompartment>();
			if (component)
			{
				if (this.m_CurrentItemCompartment != component)
				{
					this.m_CurrentItemCompartment = component;
					if (this.m_CurrentItemCompartment.m_CanPutBox)
					{
						InteractionPlayerController.RemoveToolTip(EGameAction.StoreBox);
						InteractionPlayerController.AddToolTip(EGameAction.StoreBox, false, false);
					}
					else
					{
						InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
						InteractionPlayerController.AddToolTip(EGameAction.PutItem, true, false);
						if (this.m_CurrentItemCompartment.m_CanPutItem && this.m_CurrentItemCompartment.GetItemCount() > 0)
						{
							InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
							InteractionPlayerController.AddToolTip(EGameAction.TakeItem, true, false);
						}
					}
				}
			}
			else if (this.m_CurrentItemCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.StoreBox);
				InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
				this.m_CurrentItemCompartment = null;
			}
			InteractableAutoCleanser component2 = raycastHit.transform.GetComponent<InteractableAutoCleanser>();
			if (component2)
			{
				if (this.m_CurrentAutoCleanser != component2)
				{
					if (this.m_CurrentAutoCleanser)
					{
						this.m_CurrentAutoCleanser.OnRaycastEnded();
					}
					this.m_CurrentAutoCleanser = component2;
					this.m_CurrentAutoCleanser.OnRaycasted();
					InteractionPlayerController.AddToolTip(EGameAction.Refill, false, false);
				}
			}
			else if (this.m_CurrentAutoCleanser)
			{
				this.m_CurrentAutoCleanser.OnRaycastEnded();
				this.m_CurrentAutoCleanser = null;
				InteractionPlayerController.RemoveToolTip(EGameAction.Refill);
			}
			InteractableWorkbench component3 = raycastHit.transform.GetComponent<InteractableWorkbench>();
			if (component3)
			{
				if (this.m_CurrentWorkbench != component3)
				{
					if (this.m_CurrentWorkbench)
					{
						this.m_CurrentWorkbench.OnRaycastEnded();
					}
					this.m_CurrentWorkbench = component3;
					this.m_CurrentWorkbench.OnRaycasted();
				}
			}
			else if (this.m_CurrentWorkbench)
			{
				this.m_CurrentWorkbench.OnRaycastEnded();
				this.m_CurrentWorkbench = null;
			}
			InteractableTrashBin component4 = raycastHit.transform.GetComponent<InteractableTrashBin>();
			if (component4)
			{
				this.m_CurrentTrashBin = component4;
				component4.OnRaycasted();
			}
			else if (this.m_CurrentTrashBin)
			{
				this.m_CurrentTrashBin.OnRaycastEnded();
				this.m_CurrentTrashBin = null;
			}
		}
		else
		{
			if (this.m_CurrentTrashBin)
			{
				this.m_CurrentTrashBin.OnRaycastEnded();
				this.m_CurrentTrashBin = null;
			}
			if (this.m_CurrentItemCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.StoreBox);
				InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
				this.m_CurrentItemCompartment = null;
			}
			if (this.m_CurrentAutoCleanser)
			{
				this.m_CurrentAutoCleanser.OnRaycastEnded();
				this.m_CurrentAutoCleanser = null;
				InteractionPlayerController.RemoveToolTip(EGameAction.Refill);
			}
			if (this.m_CurrentWorkbench)
			{
				this.m_CurrentWorkbench.OnRaycastEnded();
				this.m_CurrentWorkbench = null;
			}
		}
		if (InputManager.GetKeyUpAction(EGameAction.SellBoxedUpShelf) && this.m_CurrentHoldingBoxShelf)
		{
			if (this.m_CurrentHoldingBoxShelf.GetBoxedObjectType() == EObjectType.CashCounter && ShelfManager.GetCashierCounterCount() <= 1)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CantSellLastCashierCounter);
				return;
			}
			this.m_ConfirmSellShelfScreen.SetFurnitureData(InventoryBase.GetFurniturePurchaseData(this.m_CurrentHoldingBoxShelf.GetBoxedObjectType()));
			this.m_ConfirmSellShelfScreen.OpenScreen();
			return;
		}
		else
		{
			if (InputManager.GetKeyUpAction(EGameAction.Throw))
			{
				this.m_CurrentHoldingBox.ThrowBox(true);
				return;
			}
			if (InputManager.GetKeyUpAction(EGameAction.PlaceBox) && this.m_CurrentHoldingBox)
			{
				this.m_CurrentRaycastObject = this.m_CurrentHoldingBox;
				this.m_CurrentHoldingBox.DropBox(true);
				this.m_CurrentRaycastObject.StartMoveObject();
				return;
			}
			if (this.m_CurrentHoldingBox.IsBoxOpened())
			{
				if (InputManager.GetKeyUpAction(EGameAction.CloseBox))
				{
					this.m_CurrentHoldingBox.OnPressOpenBox();
					return;
				}
			}
			else if (InputManager.GetKeyUpAction(EGameAction.OpenBox))
			{
				this.m_CurrentHoldingBox.OnPressOpenBox();
				return;
			}
			if (this.m_IsHoldingMouseDown)
			{
				this.m_MouseDownTime += Time.deltaTime;
				if (this.m_MouseDownTime >= this.m_MouseHoldAutoFireRate)
				{
					this.m_MouseDownTime = 0f;
					if (this.m_CurrentAutoCleanser)
					{
						this.m_CurrentAutoCleanser.DispenseItemFromBox(this.m_CurrentHoldingItemBox, true);
						return;
					}
					if (this.m_CurrentWorkbench)
					{
						this.m_CurrentWorkbench.DispenseItemFromBox(this.m_CurrentHoldingItemBox, true);
						return;
					}
					this.m_CurrentHoldingBox.OnHoldStateLeftMousePress(true, InteractionPlayerController.GetCurrentItemCompartment());
					return;
				}
			}
			else if (this.m_MouseDownTime > 0f)
			{
				this.m_MouseDownTime = 0f;
				if (this.m_CurrentAutoCleanser)
				{
					this.m_CurrentAutoCleanser.DispenseItemFromBox(this.m_CurrentHoldingItemBox, true);
				}
				else if (this.m_CurrentWorkbench)
				{
					this.m_CurrentWorkbench.DispenseItemFromBox(this.m_CurrentHoldingItemBox, true);
				}
				else
				{
					this.m_CurrentHoldingBox.OnHoldStateLeftMousePress(true, InteractionPlayerController.GetCurrentItemCompartment());
				}
				if (this.m_CurrentTrashBin)
				{
					InteractablePackagingBox_Shelf component5 = this.m_CurrentHoldingBox.GetComponent<InteractablePackagingBox_Shelf>();
					if (this.m_CurrentHoldingItemBox)
					{
						if (this.m_CurrentHoldingItemBox.m_ItemCompartment.GetItemCount() > 0)
						{
							this.m_ConfirmTrashScreen.OpenScreen();
							return;
						}
						this.m_CurrentTrashBin.DiscardBox(this.m_CurrentHoldingBox, true);
						return;
					}
					else if (component5 && component5.GetBoxedObjectType() == EObjectType.CashCounter)
					{
						if (ShelfManager.GetCashierCounterCount() <= 1)
						{
							NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.NeedAtLeastOneCashierCounter);
							return;
						}
						this.m_CurrentTrashBin.DiscardBox(this.m_CurrentHoldingBox, true);
						return;
					}
					else
					{
						this.m_CurrentTrashBin.DiscardBox(this.m_CurrentHoldingBox, true);
					}
				}
				return;
			}
			if (this.m_IsHoldingRightMouseDown)
			{
				this.m_RightMouseDownTime += Time.deltaTime;
				if (this.m_RightMouseDownTime >= this.m_MouseHoldAutoFireRate)
				{
					this.m_RightMouseDownTime = 0f;
					this.m_CurrentHoldingBox.OnHoldStateRightMousePress(true, InteractionPlayerController.GetCurrentItemCompartment());
					return;
				}
			}
			else if (this.m_RightMouseDownTime > 0f)
			{
				this.m_RightMouseDownTime = 0f;
				this.m_CurrentHoldingBox.OnHoldStateRightMousePress(true, InteractionPlayerController.GetCurrentItemCompartment());
				return;
			}
			return;
		}
	}

	// Token: 0x0600024E RID: 590 RVA: 0x000168E3 File Offset: 0x00014AE3
	public void ConfirmDiscardBox()
	{
		if (this.m_CurrentTrashBin)
		{
			this.m_CurrentTrashBin.DiscardBox(this.m_CurrentHoldingBox, true);
		}
	}

	// Token: 0x0600024F RID: 591 RVA: 0x00016904 File Offset: 0x00014B04
	private void RaycastHoldSprayState()
	{
		if (this.m_IsHoldingMouseDown)
		{
			this.m_MouseDownTime += Time.deltaTime;
			this.m_MouseDownTimeTotal += Time.deltaTime;
			if (this.m_MouseDownTime >= this.m_MouseHoldAutoFireRate)
			{
				this.m_MouseDownTime = 0f;
				if (this.m_CurrentHoldSprayItem.GetContentFill() > 0f)
				{
					this.m_DeodorantSprayVFX.Play();
					if (this.m_MouseDownTimeTotal > 0.2f)
					{
						this.m_CurrentHoldSprayItem.DepleteContent(Time.fixedDeltaTime / 2.5f);
						CSingleton<GameUIScreen>.Instance.m_DeodorantBar.fillAmount = this.m_CurrentHoldSprayItem.GetContentFill();
						for (int i = 0; i < CSingleton<CustomerManager>.Instance.GetCustomerList().Count; i++)
						{
							CSingleton<CustomerManager>.Instance.GetCustomerList()[i].DeodorantSprayCheck(this.m_CurrentHoldSprayItem.transform.position, 2.5f, 1);
						}
					}
					SoundManager.SetEnableSound_SprayLoop(true);
				}
				else
				{
					this.m_DeodorantSprayVFX.Stop();
					SoundManager.SetEnableSound_SprayLoop(false);
				}
			}
		}
		else
		{
			this.m_MouseDownTime = 0f;
			this.m_MouseDownTimeTotal = 0f;
			this.m_DeodorantSprayVFX.Stop();
			SoundManager.SetEnableSound_SprayLoop(false);
		}
		if (InputManager.GetKeyUpAction(EGameAction.InitiateOpenPack))
		{
			this.m_IsResetRightMousePress = true;
			this.m_RightMouseDownTime = 0f;
			this.m_IsHoldingRightMouseDown = false;
			this.m_MouseDownTime = 0f;
			this.m_DeodorantSprayVFX.Stop();
			SoundManager.SetEnableSound_SprayLoop(false);
			this.m_IsHoldItemMode = true;
			this.m_IsHoldSprayMode = false;
			this.m_HoldItemList.Add(this.m_CurrentHoldSprayItem);
			CPlayerData.m_HoldItemTypeList.Add(this.m_CurrentHoldSprayItem.GetItemType());
			this.m_CurrentHoldSprayItem.SmoothLerpToTransform(this.m_HoldCardPackPosList[this.m_HoldItemList.Count], this.m_HoldCardPackPosList[this.m_HoldItemList.Count], true);
			this.m_CurrentHoldSprayItem = null;
			CSingleton<GameUIScreen>.Instance.m_DeodorantBarGrp.SetActive(false);
			this.SetCurrentGameState(EGameState.HoldingItemState);
		}
	}

	// Token: 0x06000250 RID: 592 RVA: 0x00016B0B File Offset: 0x00014D0B
	private void RaycastWorkerInteractMode()
	{
	}

	// Token: 0x06000251 RID: 593 RVA: 0x00016B10 File Offset: 0x00014D10
	private void RaycastHoldItemState()
	{
		if (this.m_IsOpeningCardBox)
		{
			return;
		}
		Ray ray = new Ray(this.m_Cam.transform.position, this.m_Cam.transform.forward);
		int mask = LayerMask.GetMask(new string[]
		{
			"ShopModel",
			"ItemCompartment",
			"Physics",
			"Obstacles"
		});
		RaycastHit raycastHit;
		if (Physics.Raycast(ray, out raycastHit, this.m_RayDistance, mask))
		{
			ShelfCompartment component = raycastHit.transform.transform.GetComponent<ShelfCompartment>();
			if (component)
			{
				if (this.m_CurrentItemCompartment != component)
				{
					this.m_CurrentItemCompartment = component;
					InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
					InteractionPlayerController.AddToolTip(EGameAction.PutItem, true, false);
					if (this.m_CurrentItemCompartment.m_CanPutItem && this.m_CurrentItemCompartment.GetItemCount() > 0)
					{
						InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
						InteractionPlayerController.AddToolTip(EGameAction.TakeItem, true, false);
					}
				}
			}
			else if (this.m_CurrentItemCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
				InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
				this.m_CurrentItemCompartment = null;
			}
			InteractablePackagingBox_Item component2 = raycastHit.transform.GetComponent<InteractablePackagingBox_Item>();
			if (component2)
			{
				if (this.m_CurrentRaycastedPackageBoxItem != component2)
				{
					if (this.m_CurrentRaycastedPackageBoxItem)
					{
						this.m_CurrentRaycastedPackageBoxItem.OnRaycastEnded();
					}
					this.m_CurrentRaycastedPackageBoxItem = component2;
					this.m_CurrentRaycastedPackageBoxItem.OnRaycasted();
					InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
					InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
					InteractionPlayerController.AddToolTip(EGameAction.PutItem, true, false);
					if (this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.GetItemCount() > 0)
					{
						InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
						InteractionPlayerController.AddToolTip(EGameAction.TakeItem, true, false);
					}
				}
			}
			else if (this.m_CurrentRaycastedPackageBoxItem)
			{
				this.m_CurrentRaycastedPackageBoxItem.OnRaycastEnded();
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
				InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
				this.m_CurrentRaycastedPackageBoxItem = null;
			}
			InteractableAutoCleanser component3 = raycastHit.transform.GetComponent<InteractableAutoCleanser>();
			if (component3)
			{
				if (this.m_CurrentAutoCleanser != component3)
				{
					if (this.m_CurrentAutoCleanser)
					{
						this.m_CurrentAutoCleanser.OnRaycastEnded();
					}
					this.m_CurrentAutoCleanser = component3;
					this.m_CurrentAutoCleanser.OnRaycasted();
					InteractionPlayerController.AddToolTip(EGameAction.Refill, false, false);
				}
			}
			else if (this.m_CurrentAutoCleanser)
			{
				this.m_CurrentAutoCleanser.OnRaycastEnded();
				this.m_CurrentAutoCleanser = null;
				InteractionPlayerController.RemoveToolTip(EGameAction.Refill);
			}
			InteractableWorkbench component4 = raycastHit.transform.GetComponent<InteractableWorkbench>();
			if (component4)
			{
				if (this.m_CurrentWorkbench != component4)
				{
					if (this.m_CurrentWorkbench)
					{
						this.m_CurrentWorkbench.OnRaycastEnded();
					}
					this.m_CurrentWorkbench = component4;
					this.m_CurrentWorkbench.OnRaycasted();
				}
			}
			else if (this.m_CurrentWorkbench)
			{
				this.m_CurrentWorkbench.OnRaycastEnded();
				this.m_CurrentWorkbench = null;
			}
			InteractableTrashBin component5 = raycastHit.transform.GetComponent<InteractableTrashBin>();
			if (component5)
			{
				this.m_CurrentTrashBin = component5;
				component5.OnRaycasted();
			}
			else if (this.m_CurrentTrashBin)
			{
				this.m_CurrentTrashBin.OnRaycastEnded();
				this.m_CurrentTrashBin = null;
			}
		}
		else
		{
			if (this.m_CurrentRaycastObject)
			{
				this.m_CurrentRaycastObject.OnRaycastEnded();
				this.m_CurrentRaycastObject = null;
			}
			if (this.m_CurrentTrashBin)
			{
				this.m_CurrentTrashBin.OnRaycastEnded();
				this.m_CurrentTrashBin = null;
			}
			if (this.m_CurrentItemCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
				InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
				this.m_CurrentItemCompartment = null;
			}
			if (this.m_CurrentRaycastedPackageBoxItem)
			{
				this.m_CurrentRaycastedPackageBoxItem.OnRaycastEnded();
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
				InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
				this.m_CurrentRaycastedPackageBoxItem = null;
			}
			if (this.m_CurrentAutoCleanser)
			{
				this.m_CurrentAutoCleanser.OnRaycastEnded();
				this.m_CurrentAutoCleanser = null;
				InteractionPlayerController.RemoveToolTip(EGameAction.Refill);
			}
			if (this.m_CurrentWorkbench)
			{
				this.m_CurrentWorkbench.OnRaycastEnded();
				this.m_CurrentWorkbench = null;
			}
		}
		if (!InputManager.GetKeyUpAction(EGameAction.InitiateOpenPack))
		{
			if (this.m_IsHoldingMouseDown)
			{
				this.m_MouseDownTime += Time.deltaTime;
				if (this.m_MouseDownTime >= this.m_MouseHoldAutoFireRate)
				{
					this.m_MouseDownTime = 0f;
					this.EvaluatePutItemOnShelf();
					return;
				}
			}
			else if (this.m_MouseDownTime > 0f)
			{
				this.m_MouseDownTime = 0f;
				this.EvaluatePutItemOnShelf();
				if (this.m_CurrentTrashBin)
				{
					Item item = this.m_HoldItemList[0];
					this.RemoveHoldItem(item);
					item.DisableItem();
					SoundManager.PlayAudio("SFX_Dispose", 0.5f, 1f);
					return;
				}
			}
			if (this.m_IsHoldingRightMouseDown)
			{
				this.m_RightMouseDownTime += Time.deltaTime;
				if (this.m_RightMouseDownTime >= this.m_MouseHoldAutoFireRate)
				{
					this.m_RightMouseDownTime = 0f;
					this.EvaluateTakeItemFromShelf();
					return;
				}
			}
			else if (this.m_RightMouseDownTime > 0f)
			{
				this.m_RightMouseDownTime = 0f;
				this.EvaluateTakeItemFromShelf();
				return;
			}
			return;
		}
		this.m_IsResetRightMousePress = true;
		this.m_RightMouseDownTime = 0f;
		this.m_IsHoldingRightMouseDown = false;
		this.m_MouseDownTime = 0f;
		Item item2 = this.m_HoldItemList[0];
		if (this.IsHoldingSpray())
		{
			this.m_CurrentHoldSprayItem = item2;
			this.RemoveHoldItem(item2);
			this.m_CurrentHoldSprayItem.SmoothLerpToTransform(this.m_HoldDeodorantPos, this.m_HoldDeodorantPos, true);
			this.m_IsHoldSprayMode = true;
			this.m_IsHoldItemMode = false;
			this.SetCurrentGameState(EGameState.HoldSprayState);
			CSingleton<GameUIScreen>.Instance.m_DeodorantBarGrp.SetActive(true);
			CSingleton<GameUIScreen>.Instance.m_DeodorantBar.fillAmount = this.m_CurrentHoldSprayItem.GetContentFill();
			return;
		}
		this.EvaluateOpenCardPack();
	}

	// Token: 0x06000252 RID: 594 RVA: 0x00017091 File Offset: 0x00015291
	public bool IsHoldingSpray()
	{
		return this.m_HoldItemList.Count > 0 && this.m_HoldItemList[0] && this.m_HoldItemList[0].GetItemType() == EItemType.Deodorant;
	}

	// Token: 0x06000253 RID: 595 RVA: 0x000170CC File Offset: 0x000152CC
	public bool CanOpenPack()
	{
		bool result = false;
		if (this.m_HoldItemList.Count > 0)
		{
			Item item = this.m_HoldItemList[0];
			result = (item.GetItemType() == EItemType.BasicCardPack || item.GetItemType() == EItemType.RareCardPack || item.GetItemType() == EItemType.EpicCardPack || item.GetItemType() == EItemType.LegendaryCardPack || item.GetItemType() == EItemType.DestinyBasicCardPack || item.GetItemType() == EItemType.DestinyRareCardPack || item.GetItemType() == EItemType.DestinyEpicCardPack || item.GetItemType() == EItemType.DestinyLegendaryCardPack || item.GetItemType() == EItemType.GhostPack || item.GetItemType() == EItemType.MegabotPack || item.GetItemType() == EItemType.FantasyRPGPack || item.GetItemType() == EItemType.CatJobPack);
		}
		return result;
	}

	// Token: 0x06000254 RID: 596 RVA: 0x00017170 File Offset: 0x00015370
	public bool CanOpenCardBox()
	{
		bool result = false;
		if (this.m_HoldItemList.Count > 0)
		{
			Item item = this.m_HoldItemList[0];
			result = (item.GetItemType() == EItemType.BasicCardBox || item.GetItemType() == EItemType.RareCardBox || item.GetItemType() == EItemType.EpicCardBox || item.GetItemType() == EItemType.LegendaryCardBox || item.GetItemType() == EItemType.DestinyBasicCardBox || item.GetItemType() == EItemType.DestinyRareCardBox || item.GetItemType() == EItemType.DestinyEpicCardBox || item.GetItemType() == EItemType.DestinyLegendaryCardBox);
		}
		return result;
	}

	// Token: 0x06000255 RID: 597 RVA: 0x000171EC File Offset: 0x000153EC
	public void EvaluateOpenCardPack()
	{
		if (this.CanOpenPack())
		{
			Item item = this.m_HoldItemList[0];
			this.RemoveHoldItem(item);
			CSingleton<CardOpeningSequence>.Instance.ReadyingCardPack(item);
			this.m_IsHoldingMouseDown = false;
			this.m_IsHoldingRightMouseDown = false;
			return;
		}
		if (this.CanOpenCardBox())
		{
			this.m_IsOpeningCardBox = true;
			Item item2 = this.m_HoldItemList[0];
			EItemType eitemType = this.CardBoxToCardPack(item2.GetItemType());
			if (eitemType == EItemType.None)
			{
				return;
			}
			ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(item2.GetItemType());
			this.m_OpenCardBoxMeshFilter.mesh = itemMeshData.mesh;
			this.m_OpenCardBoxMesh.material = itemMeshData.material;
			item2.gameObject.SetActive(false);
			this.m_HoldItemList.Clear();
			CPlayerData.m_HoldItemTypeList.Clear();
			InteractionPlayerController.RemoveToolTip(EGameAction.OpenCardBox);
			SoundManager.PlayAudio("SFX_OpenCardBox", 0.6f, 1f);
			this.m_OpenCardBoxInnerMesh.gameObject.SetActive(true);
			this.m_OpenCardBoxInnerMesh.Rewind();
			this.m_OpenCardBoxInnerMesh.Play();
			for (int i = 0; i < 8; i++)
			{
				ItemMeshData itemMeshData2 = InventoryBase.GetItemMeshData(eitemType);
				Item item3 = ItemSpawnManager.GetItem(this.m_OpenCardBoxSpawnCardPackPosList[i]);
				item3.SetMesh(itemMeshData2.mesh, itemMeshData2.material, eitemType, itemMeshData2.meshSecondary, itemMeshData2.materialSecondary);
				item3.transform.position = this.m_OpenCardBoxSpawnCardPackPosList[i].position;
				item3.transform.rotation = this.m_OpenCardBoxSpawnCardPackPosList[i].rotation;
				item3.transform.parent = this.m_OpenCardBoxSpawnCardPackPosList[i];
				item3.transform.localScale = this.m_OpenCardBoxSpawnCardPackPosList[i].localScale;
				item3.gameObject.SetActive(true);
				this.m_HoldItemList.Add(item3);
				CPlayerData.m_HoldItemTypeList.Add(item3.GetItemType());
				base.StartCoroutine(this.DelayLerpSpawnedCardPackToHand(i, 1.25f + 0.05f * (float)i, item3, this.m_HoldCardPackPosList[i], item2));
			}
		}
	}

	// Token: 0x06000256 RID: 598 RVA: 0x00017417 File Offset: 0x00015617
	private IEnumerator DelayLerpSpawnedCardPackToHand(int index, float waitTime, Item item, Transform targetTransform, Item cardBoxItem)
	{
		yield return new WaitForSeconds(waitTime);
		item.SmoothLerpToTransform(targetTransform, targetTransform, false);
		if (index == 7 && cardBoxItem)
		{
			cardBoxItem.DisableItem();
			this.m_OpenCardBoxInnerMesh.gameObject.SetActive(false);
			this.m_IsOpeningCardBox = false;
		}
		yield break;
	}

	// Token: 0x06000257 RID: 599 RVA: 0x0001744B File Offset: 0x0001564B
	private EItemType CardBoxToCardPack(EItemType cardBoxItemType)
	{
		if (cardBoxItemType == EItemType.BasicCardBox)
		{
			return EItemType.BasicCardPack;
		}
		if (cardBoxItemType == EItemType.RareCardBox)
		{
			return EItemType.RareCardPack;
		}
		if (cardBoxItemType == EItemType.EpicCardBox)
		{
			return EItemType.EpicCardPack;
		}
		if (cardBoxItemType == EItemType.LegendaryCardBox)
		{
			return EItemType.LegendaryCardPack;
		}
		if (cardBoxItemType == EItemType.DestinyBasicCardBox)
		{
			return EItemType.DestinyBasicCardPack;
		}
		if (cardBoxItemType == EItemType.DestinyRareCardBox)
		{
			return EItemType.DestinyRareCardPack;
		}
		if (cardBoxItemType == EItemType.DestinyEpicCardBox)
		{
			return EItemType.DestinyEpicCardPack;
		}
		if (cardBoxItemType == EItemType.DestinyLegendaryCardBox)
		{
			return EItemType.DestinyLegendaryCardPack;
		}
		return EItemType.None;
	}

	// Token: 0x06000258 RID: 600 RVA: 0x00017488 File Offset: 0x00015688
	private void EvaluateTakeItemFromShelf()
	{
		if (!this.m_CurrentAutoCleanser || this.m_CurrentAutoCleanser.GetItemCount() <= 0)
		{
			if (this.m_CurrentWorkbench && this.m_CurrentWorkbench.GetItemCount() > 0)
			{
				if (this.m_HoldItemList.Count > 0)
				{
					NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.HandFull);
					return;
				}
				Item item = this.m_CurrentWorkbench.TakeItemToHand(false);
				if (item)
				{
					item.SmoothLerpToTransform(this.m_HoldCardPackPosList[this.m_HoldItemList.Count], this.m_HoldCardPackPosList[this.m_HoldItemList.Count], false);
					this.m_HoldItemList.Add(item);
					CPlayerData.m_HoldItemTypeList.Add(item.GetItemType());
					this.SetCurrentGameState(EGameState.HoldingItemState);
					this.m_IsHoldItemMode = true;
					SoundManager.GenericPop(1f, 0.9f);
					return;
				}
			}
			else if (!this.m_CurrentStorageCompartment && this.m_CurrentRaycastedPackageBoxItem && this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.GetItemCount() > 0)
			{
				if (!this.m_CurrentRaycastedPackageBoxItem.IsBoxOpened())
				{
					this.m_CurrentRaycastedPackageBoxItem.OnPressOpenBox();
					InteractionPlayerController.RemoveToolTip(EGameAction.CloseBox);
					return;
				}
				int num = 8;
				if (this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.GetItemCount() <= 0)
				{
					NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxNoItem);
					return;
				}
				Item firstItem = this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.GetFirstItem();
				if (firstItem && firstItem.GetItemVolume() != 1f)
				{
					num = 1;
				}
				if (this.m_HoldItemList.Count >= num)
				{
					NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.HandFull);
					return;
				}
				if (this.m_HoldItemList.Count > 0)
				{
					float itemVolume = this.m_HoldItemList[0].GetItemVolume();
					if (firstItem && firstItem.GetItemVolume() != itemVolume)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.HandFull);
						return;
					}
				}
				Item item2 = this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.TakeItemToHand(false);
				if (item2)
				{
					item2.SmoothLerpToTransform(this.m_HoldCardPackPosList[this.m_HoldItemList.Count], this.m_HoldCardPackPosList[this.m_HoldItemList.Count], false);
					this.m_HoldItemList.Add(item2);
					CPlayerData.m_HoldItemTypeList.Add(item2.GetItemType());
					this.SetCurrentGameState(EGameState.HoldingItemState);
					this.m_IsHoldItemMode = true;
					SoundManager.GenericPop(1f, 0.9f);
					return;
				}
			}
			else if (!this.m_CurrentStorageCompartment && this.m_CurrentItemCompartment && this.m_CurrentItemCompartment.m_CanPutItem)
			{
				int num2 = 8;
				if (this.m_CurrentItemCompartment.GetItemCount() <= 0)
				{
					NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShelfNoItem);
					return;
				}
				Item lastItem = this.m_CurrentItemCompartment.GetLastItem();
				if (lastItem && lastItem.GetItemVolume() != 1f)
				{
					num2 = 1;
				}
				if (this.m_HoldItemList.Count < num2)
				{
					if (this.m_HoldItemList.Count > 0)
					{
						float itemVolume2 = this.m_HoldItemList[0].GetItemVolume();
						if (lastItem && lastItem.GetItemVolume() != itemVolume2)
						{
							NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.HandFull);
							return;
						}
					}
					Item item3 = this.m_CurrentItemCompartment.TakeItemToHand(true);
					if (item3)
					{
						item3.SmoothLerpToTransform(this.m_HoldCardPackPosList[this.m_HoldItemList.Count], this.m_HoldCardPackPosList[this.m_HoldItemList.Count], false);
						this.m_HoldItemList.Add(item3);
						CPlayerData.m_HoldItemTypeList.Add(item3.GetItemType());
						this.SetCurrentGameState(EGameState.HoldingItemState);
						this.m_IsHoldItemMode = true;
						SoundManager.GenericPop(1f, 0.9f);
						return;
					}
				}
				else
				{
					NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.HandFull);
				}
			}
		}
	}

	// Token: 0x06000259 RID: 601 RVA: 0x00017838 File Offset: 0x00015A38
	private void EvaluatePutItemOnShelf()
	{
		if (this.m_CurrentAutoCleanser && this.m_HoldItemList.Count > 0)
		{
			Item item = this.m_HoldItemList[0];
			if (item.GetItemType() != EItemType.Deodorant)
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AutoCleanserOnlyAllowCleanser);
				return;
			}
			if (this.m_CurrentAutoCleanser.HasEnoughSlot())
			{
				SoundManager.GenericPop(1f, 1f);
				this.m_CurrentAutoCleanser.AddItem(item, true);
				this.RemoveHoldItem(item);
				return;
			}
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AutoCleanserNoSlot);
			return;
		}
		else
		{
			if (!this.m_CurrentWorkbench || this.m_HoldItemList.Count <= 0)
			{
				if (!this.m_CurrentStorageCompartment && this.m_CurrentRaycastedPackageBoxItem)
				{
					if (!this.m_CurrentRaycastedPackageBoxItem.IsBoxOpened())
					{
						this.m_CurrentRaycastedPackageBoxItem.OnPressOpenBox();
						InteractionPlayerController.RemoveToolTip(EGameAction.CloseBox);
						return;
					}
					Item item2 = this.m_HoldItemList[0];
					if (!this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.m_CanPutItem)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CanOnlyStoreBoxOnThisShelf);
						return;
					}
					if (this.m_HoldItemList.Count <= 0)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.NoItemOnHand);
						return;
					}
					EItemType eitemType = this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.CheckItemType(item2.GetItemType());
					this.m_CurrentRaycastedPackageBoxItem.SetItemType(eitemType);
					if (!this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.HasEnoughSlot())
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxNoSlot);
						return;
					}
					if (eitemType != item2.GetItemType())
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.BoxWrongItemType);
						return;
					}
					Transform lastEmptySlotTransform = this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.GetLastEmptySlotTransform();
					Transform emptySlotParent = this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.GetEmptySlotParent();
					item2.LerpToTransform(lastEmptySlotTransform, emptySlotParent, false);
					this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.AddItem(item2, true);
					this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.SetPriceTagVisibility(false);
					this.RemoveHoldItem(item2);
					SoundManager.GenericPop(1f, 1f);
					if (this.m_HoldItemList.Count == 0)
					{
						this.m_IsResetMousePress = true;
						this.m_MouseDownTime = 0f;
						this.m_IsHoldingMouseDown = false;
						return;
					}
				}
				else if (!this.m_CurrentStorageCompartment && this.m_CurrentItemCompartment)
				{
					Item item3 = this.m_HoldItemList[0];
					if (!this.m_CurrentItemCompartment.m_CanPutItem)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CanOnlyStoreBoxOnThisShelf);
						return;
					}
					if (this.m_HoldItemList.Count <= 0)
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.NoItemOnHand);
						return;
					}
					EItemType eitemType2 = this.m_CurrentItemCompartment.CheckItemType(item3.GetItemType());
					if (!this.m_CurrentItemCompartment.HasEnoughSlot())
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShelfNoSlot);
						return;
					}
					if (eitemType2 != item3.GetItemType())
					{
						NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.ShelfWrongItemType);
						return;
					}
					Transform emptySlotTransform = this.m_CurrentItemCompartment.GetEmptySlotTransform();
					Transform emptySlotParent2 = this.m_CurrentItemCompartment.GetEmptySlotParent();
					item3.LerpToTransform(emptySlotTransform, emptySlotParent2, false);
					this.m_CurrentItemCompartment.AddItem(item3, false);
					this.RemoveHoldItem(item3);
					SoundManager.GenericPop(1f, 1f);
					TutorialManager.AddTaskValue(ETutorialTaskCondition.PutItemOnShelf, 1f);
				}
				return;
			}
			Item item4 = this.m_HoldItemList[0];
			if (!this.m_CurrentWorkbench.IsValidItemType(item4.GetItemType()))
			{
				NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.CanOnlyPutBulkBox);
				return;
			}
			if (this.m_CurrentWorkbench.HasEnoughSlot())
			{
				SoundManager.GenericPop(1f, 1f);
				this.m_CurrentWorkbench.AddItem(item4, true);
				this.RemoveHoldItem(item4);
				return;
			}
			NotEnoughResourceTextPopup.ShowText(ENotEnoughResourceText.AutoCleanserNoSlot);
			return;
		}
	}

	// Token: 0x0600025A RID: 602 RVA: 0x00017B80 File Offset: 0x00015D80
	private void RemoveHoldItem(Item currentItem)
	{
		this.m_HoldItemList.Remove(currentItem);
		CPlayerData.m_HoldItemTypeList.RemoveAt(0);
		if (this.m_HoldItemList.Count <= 0)
		{
			this.SetCurrentGameState(EGameState.DefaultState);
			this.m_IsHoldItemMode = false;
			this.m_IsResetMousePress = true;
			this.m_MouseDownTime = 0f;
			this.m_IsHoldingMouseDown = false;
			this.m_IsResetRightMousePress = true;
			this.m_RightMouseDownTime = 0f;
			this.m_IsHoldingRightMouseDown = false;
			return;
		}
		for (int i = 0; i < this.m_HoldItemList.Count; i++)
		{
			this.m_HoldItemList[i].SmoothLerpToTransform(this.m_HoldCardPackPosList[i], this.m_HoldCardPackPosList[i], true);
		}
	}

	// Token: 0x0600025B RID: 603 RVA: 0x00017C34 File Offset: 0x00015E34
	public void AddHoldItemToFront(Item currentItem)
	{
		this.m_HoldItemList.Insert(0, currentItem);
		CPlayerData.m_HoldItemTypeList.Insert(0, currentItem.GetItemType());
		this.SetCurrentGameState(EGameState.HoldingItemState);
		this.m_IsHoldItemMode = true;
		for (int i = 0; i < this.m_HoldItemList.Count; i++)
		{
			this.m_HoldItemList[i].SmoothLerpToTransform(this.m_HoldCardPackPosList[i], this.m_HoldCardPackPosList[i], true);
		}
	}

	// Token: 0x0600025C RID: 604 RVA: 0x00017CAD File Offset: 0x00015EAD
	public int GetHoldItemCount()
	{
		return this.m_HoldItemList.Count;
	}

	// Token: 0x0600025D RID: 605 RVA: 0x00017CBC File Offset: 0x00015EBC
	public static void SetAllHoldItemVisibility(bool isVisible)
	{
		for (int i = 0; i < CSingleton<InteractionPlayerController>.Instance.m_HoldItemList.Count; i++)
		{
			CSingleton<InteractionPlayerController>.Instance.m_HoldItemList[i].gameObject.SetActive(isVisible);
		}
	}

	// Token: 0x0600025E RID: 606 RVA: 0x00017D00 File Offset: 0x00015F00
	private void RaycastMovingObjectState()
	{
		if (InputManager.GetKeyUpAction(EGameAction.PlaceMoveObject) && this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.PlaceMovedObject();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.BoxUpShelf) && this.m_CurrentRaycastObject && this.m_CurrentRaycastObject.m_CanBoxUpObject && this.m_CurrentRaycastObject.m_CanPickupMoveObject)
		{
			this.m_CurrentRaycastObject.BoxUpObject(true);
			return;
		}
		if (this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.AddObjectRotation(Input.mouseScrollDelta.y * this.m_MoveObjectRotateSpeed, 0f);
		}
		if (InputManager.GetKeyUpAction(EGameAction.Rotate))
		{
			if (this.m_CurrentRaycastObject)
			{
				this.m_CurrentRaycastObject.AddObjectRotation(15f, 15f);
			}
		}
		else if (InputManager.GetKeyUpAction(EGameAction.RotateB) && this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.AddObjectRotation(-15f, 15f);
		}
		int mask = LayerMask.GetMask(new string[]
		{
			"ShopModel",
			"Ground",
			"Glass",
			"Obstacles"
		});
		RaycastHit raycastHit;
		if (Physics.Raycast(new Ray(this.m_Cam.transform.position, this.m_Cam.transform.forward), out raycastHit, this.m_RayDistance * 1.5f, mask))
		{
			Transform transform = raycastHit.transform;
			if (this.m_CurrentRaycastObject)
			{
				this.m_CurrentRaycastObject.SetTargetMovePosition(raycastHit.point);
				return;
			}
		}
		else if (this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.SetMovePositionToCamera(3f);
		}
	}

	// Token: 0x0600025F RID: 607 RVA: 0x00017EA0 File Offset: 0x000160A0
	private void RaycastMovingBoxState()
	{
		if (InputManager.GetKeyUpAction(EGameAction.PlaceMoveObject) && this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.PlaceMovedObject();
		}
		if (this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.AddObjectRotation(Input.mouseScrollDelta.y * this.m_MoveObjectRotateSpeed, 0f);
		}
		if (InputManager.GetKeyUpAction(EGameAction.Rotate))
		{
			if (this.m_CurrentRaycastObject)
			{
				this.m_CurrentRaycastObject.AddObjectRotation(15f, 15f);
			}
		}
		else if (InputManager.GetKeyUpAction(EGameAction.RotateB) && this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.AddObjectRotation(-15f, 15f);
		}
		int mask = LayerMask.GetMask(new string[]
		{
			"ShopModel",
			"Ground",
			"Glass",
			"Obstacles",
			"Physics"
		});
		RaycastHit raycastHit;
		if (Physics.Raycast(new Ray(this.m_Cam.transform.position, this.m_Cam.transform.forward), out raycastHit, this.m_RayDistance * 1f, mask))
		{
			Transform transform = raycastHit.transform;
			float d = Mathf.Lerp(this.m_BoxPhysicsDimension.x, this.m_BoxPhysicsDimension.y, raycastHit.normal.y);
			if (this.m_CurrentRaycastObject)
			{
				this.m_CurrentRaycastObject.SetTargetMovePosition(raycastHit.point + raycastHit.normal * d);
				return;
			}
		}
		else if (this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.SetMovePositionToCamera(1f);
		}
	}

	// Token: 0x06000260 RID: 608 RVA: 0x00018044 File Offset: 0x00016244
	private void RaycastCashCounterState()
	{
		bool flag = false;
		int mask = LayerMask.GetMask(new string[]
		{
			"Item",
			"UI"
		});
		RaycastHit raycastHit;
		if (Physics.Raycast(new Ray(this.m_Cam.transform.position, this.m_Cam.transform.forward), out raycastHit, this.m_RayDistance, mask))
		{
			Transform transform = raycastHit.transform;
			InteractableObject component = raycastHit.transform.GetComponent<InteractableObject>();
			if (component && component.m_CanScanByCounter)
			{
				if (this.m_CurrentRaycastObject != component)
				{
					if (this.m_CurrentRaycastObject)
					{
						this.m_CurrentRaycastObject.OnRaycastEnded();
					}
					this.m_CurrentRaycastObject = component;
					component.OnRaycasted();
				}
			}
			else
			{
				flag = true;
			}
		}
		else
		{
			flag = true;
		}
		if (flag && this.m_CurrentRaycastObject)
		{
			this.m_CurrentRaycastObject.OnRaycastEnded();
			this.m_CurrentRaycastObject = null;
		}
		if (InputManager.GetKeyDownAction(EGameAction.ScanCounter) || InputManager.GetKeyDownAction(EGameAction.AddChange))
		{
			this.m_IsHoldingMouseDown = true;
		}
		else if (InputManager.GetKeyUpAction(EGameAction.ScanCounter) || InputManager.GetKeyUpAction(EGameAction.AddChange))
		{
			this.m_IsHoldingMouseDown = false;
		}
		if (InputManager.GetKeyDownAction(EGameAction.RemoveChange))
		{
			this.m_IsHoldingRightMouseDown = true;
		}
		else if (InputManager.GetKeyUpAction(EGameAction.RemoveChange))
		{
			this.m_IsHoldingRightMouseDown = false;
		}
		if (this.m_IsHoldingMouseDown && !InputManager.GetKeyHoldAction(EGameAction.ScanCounter) && !InputManager.GetKeyHoldAction(EGameAction.AddChange))
		{
			this.m_IsHoldingMouseDown = false;
		}
		if (this.m_IsHoldingRightMouseDown && !InputManager.GetKeyHoldAction(EGameAction.RemoveChange))
		{
			this.m_IsHoldingRightMouseDown = false;
		}
		if (this.m_CurrentRaycastObject)
		{
			if (this.m_IsHoldingMouseDown)
			{
				this.m_MouseDownTime += Time.deltaTime;
				if (this.m_MouseDownTime >= this.m_MouseHoldAutoFireRate)
				{
					this.m_MouseDownTime = 0f;
					this.m_CurrentRaycastObject.OnMouseButtonUp();
				}
			}
			else if (this.m_MouseDownTime > 0f)
			{
				this.m_MouseDownTime = 0f;
				this.m_CurrentRaycastObject.OnMouseButtonUp();
			}
			if (this.m_IsHoldingRightMouseDown)
			{
				this.m_RightMouseDownTime += Time.deltaTime;
				if (this.m_RightMouseDownTime >= this.m_MouseHoldAutoFireRate)
				{
					this.m_RightMouseDownTime = 0f;
					this.m_CurrentRaycastObject.OnRightMouseButtonUp();
				}
			}
			else if (this.m_RightMouseDownTime > 0f)
			{
				this.m_RightMouseDownTime = 0f;
				this.m_CurrentRaycastObject.OnRightMouseButtonUp();
			}
		}
		if (InputManager.GetKeyUpAction(EGameAction.ExitCounter) && this.m_CurrentCashierCounter)
		{
			this.m_CurrentCashierCounter.OnPressEsc();
		}
		if (InputManager.GetKeyUpAction(EGameAction.DoneCounter) && this.m_CurrentCashierCounter)
		{
			this.m_CurrentCashierCounter.OnPressSpaceBar();
		}
	}

	// Token: 0x06000261 RID: 609 RVA: 0x000182CD File Offset: 0x000164CD
	public static void SetCurrentInteractableObject(InteractableObject obj)
	{
		CSingleton<InteractionPlayerController>.Instance.m_CurrentRaycastObject = obj;
	}

	// Token: 0x06000262 RID: 610 RVA: 0x000182DA File Offset: 0x000164DA
	public static void SetPlayerPos(Vector3 pos)
	{
		CSingleton<InteractionPlayerController>.Instance.m_WalkerCtrl.transform.position = pos;
	}

	// Token: 0x06000263 RID: 611 RVA: 0x000182F4 File Offset: 0x000164F4
	public static void CameraLerpToPosition(Vector3 pos, Quaternion rot)
	{
		CSingleton<InteractionPlayerController>.Instance.m_OriginalCameraPos = CSingleton<InteractionPlayerController>.Instance.m_CameraController.transform.position;
		CSingleton<InteractionPlayerController>.Instance.m_OriginalCameraRot = CSingleton<InteractionPlayerController>.Instance.m_CameraController.transform.rotation;
		CSingleton<InteractionPlayerController>.Instance.m_CameraController.transform.position = pos;
		CSingleton<InteractionPlayerController>.Instance.m_CameraController.transform.rotation = rot;
	}

	// Token: 0x06000264 RID: 612 RVA: 0x00018367 File Offset: 0x00016567
	public static void CameraLerpToOriginalPos()
	{
		CSingleton<InteractionPlayerController>.Instance.m_CameraController.transform.position = CSingleton<InteractionPlayerController>.Instance.m_OriginalCameraPos;
		CSingleton<InteractionPlayerController>.Instance.m_CameraController.transform.rotation = CSingleton<InteractionPlayerController>.Instance.m_OriginalCameraRot;
	}

	// Token: 0x06000265 RID: 613 RVA: 0x000183A8 File Offset: 0x000165A8
	private void EvaluateCameraLerp()
	{
		if (this.m_LookAtTarget != null)
		{
			if (this.m_LookAtDelayTimer >= this.m_LookAtDelayTime)
			{
				this.m_LookAtTransform.LookAt(this.m_LookAtTarget);
				this.ForceLookAt(this.m_LookAtTransform, this.m_LerpCameraRotSpeed);
			}
			else
			{
				this.m_LookAtDelayTimer += Time.deltaTime;
			}
		}
		if (this.m_IsLerpingCameraRot)
		{
			this.m_CameraController.transform.rotation = Quaternion.Lerp(this.m_CameraController.transform.rotation, this.m_LerpCameraTargetRot, Time.deltaTime * this.m_LerpCameraRotSpeed);
		}
	}

	// Token: 0x06000266 RID: 614 RVA: 0x00018447 File Offset: 0x00016647
	public void ShowCursor()
	{
		if (!CSingleton<InputManager>.Instance.m_IsControllerActive)
		{
			Cursor.visible = true;
		}
		CenterDot.SetVisibility(false);
		InputManager.SetCursorLockMode(CursorLockMode.Confined);
		this.m_CameraController.enabled = false;
	}

	// Token: 0x06000267 RID: 615 RVA: 0x00018473 File Offset: 0x00016673
	public void HideCursor()
	{
		Cursor.visible = false;
		CenterDot.SetVisibility(true);
		InputManager.SetCursorLockMode(CursorLockMode.Locked);
		this.m_CameraController.enabled = true;
	}

	// Token: 0x06000268 RID: 616 RVA: 0x00018493 File Offset: 0x00016693
	public void EnterUIMode()
	{
		this.ShowCursor();
		this.m_IsInUIMode = true;
		this.m_IsResetMousePress = true;
		this.m_MouseDownTime = 0f;
		this.m_IsHoldingMouseDown = false;
	}

	// Token: 0x06000269 RID: 617 RVA: 0x000184BB File Offset: 0x000166BB
	public void StartAimLookAt(Transform lookTarget, float lerpSpeed, float delay = 0f)
	{
		this.m_LookAtTarget = lookTarget;
		this.m_LerpCameraRotSpeed = lerpSpeed;
		this.m_LookAtDelayTimer = 0f;
		this.m_LookAtDelayTime = delay;
	}

	// Token: 0x0600026A RID: 618 RVA: 0x000184DD File Offset: 0x000166DD
	public void StopAimLookAt()
	{
		this.m_LookAtTarget = null;
	}

	// Token: 0x0600026B RID: 619 RVA: 0x000184E6 File Offset: 0x000166E6
	public void ForceLookAt(Transform forceView, float lerpSpeed)
	{
		this.m_IsLerpingCameraRot = true;
		this.m_LerpCameraTargetRot = forceView.rotation;
		this.m_LerpCameraRotSpeed = lerpSpeed;
	}

	// Token: 0x0600026C RID: 620 RVA: 0x00018504 File Offset: 0x00016704
	public void ExitUIMode()
	{
		if (this.m_IsLerpingCameraRot)
		{
			float num = this.m_CameraController.transform.localRotation.eulerAngles.x;
			float num2 = this.m_CameraController.transform.localRotation.eulerAngles.y;
			num = ((num > 180f) ? (num - 360f) : num);
			num2 = ((num2 > 180f) ? (num2 - 360f) : num2);
			this.m_CameraController.SetRotationAngles(num, num2);
		}
		this.HideCursor();
		this.m_IsLerpingCameraRot = false;
		base.StartCoroutine(this.DelaySetUIModeFalse());
		this.m_IsResetMousePress = true;
		this.m_MouseDownTime = 0f;
		this.m_IsHoldingMouseDown = false;
	}

	// Token: 0x0600026D RID: 621 RVA: 0x000185BB File Offset: 0x000167BB
	public void ResetMousePress()
	{
		this.m_IsResetMousePress = true;
		this.m_MouseDownTime = 0f;
		this.m_IsHoldingMouseDown = false;
	}

	// Token: 0x0600026E RID: 622 RVA: 0x000185D6 File Offset: 0x000167D6
	public void EnterLockMoveMode()
	{
		this.m_WalkerCtrl.SetStopMovement(true);
		this.m_CameraController.enabled = false;
		this.m_IsInUIMode = true;
	}

	// Token: 0x0600026F RID: 623 RVA: 0x000185F7 File Offset: 0x000167F7
	public void ExitLockMoveMode()
	{
		this.m_WalkerCtrl.SetStopMovement(false);
		this.m_CameraController.enabled = true;
		this.m_IsInUIMode = false;
	}

	// Token: 0x06000270 RID: 624 RVA: 0x00018618 File Offset: 0x00016818
	private IEnumerator DelaySetUIModeFalse()
	{
		yield return new WaitForSeconds(0.05f);
		this.m_IsInUIMode = false;
		yield break;
	}

	// Token: 0x06000271 RID: 625 RVA: 0x00018627 File Offset: 0x00016827
	public void OnEnterOpenPackState()
	{
		this.SetCurrentGameState(EGameState.OpeningPackState);
	}

	// Token: 0x06000272 RID: 626 RVA: 0x00018630 File Offset: 0x00016830
	public void OnExitOpenPackState()
	{
		if (this.m_HoldItemList.Count <= 0)
		{
			this.SetCurrentGameState(EGameState.DefaultState);
			this.m_IsResetMousePress = true;
			this.m_MouseDownTime = 0f;
			this.m_IsHoldingMouseDown = false;
			this.m_IsResetRightMousePress = true;
			this.m_RightMouseDownTime = 0f;
			this.m_IsHoldingRightMouseDown = false;
			return;
		}
		this.SetCurrentGameState(EGameState.HoldingItemState);
	}

	// Token: 0x06000273 RID: 627 RVA: 0x0001868C File Offset: 0x0001688C
	public void OnEnterHoldBoxMode(InteractablePackagingBox packageBox)
	{
		this.SetCurrentGameState(EGameState.HoldingBoxState);
		this.m_IsHoldBoxMode = true;
		this.m_CurrentHoldingBox = packageBox;
		this.m_CurrentHoldingItemBox = this.m_CurrentHoldingBox.GetComponent<InteractablePackagingBox_Item>();
		this.m_CurrentHoldingBoxShelf = this.m_CurrentHoldingBox.GetComponent<InteractablePackagingBox_Shelf>();
		this.m_CurrentRaycastObject = null;
	}

	// Token: 0x06000274 RID: 628 RVA: 0x000186CC File Offset: 0x000168CC
	public void OnExitHoldBoxMode()
	{
		this.m_IsHoldBoxMode = false;
		this.m_CurrentHoldingBox = null;
		this.m_CurrentHoldingItemBox = null;
		this.m_CurrentRaycastedPackageBoxItem = null;
		this.SetCurrentGameState(EGameState.DefaultState);
	}

	// Token: 0x06000275 RID: 629 RVA: 0x000186F1 File Offset: 0x000168F1
	public void OnEnterMoveObjectMode()
	{
		this.SetCurrentGameState(EGameState.MovingObjectState);
		this.m_IsMovingObjectMode = true;
	}

	// Token: 0x06000276 RID: 630 RVA: 0x00018701 File Offset: 0x00016901
	public void OnEnterMoveBoxMode(Vector3 boxPhysicsDimension)
	{
		this.SetCurrentGameState(EGameState.MovingBoxState);
		this.m_IsMovingBoxMode = true;
		this.m_BoxPhysicsDimension = boxPhysicsDimension;
	}

	// Token: 0x06000277 RID: 631 RVA: 0x00018719 File Offset: 0x00016919
	public void OnExitMoveObjectMode()
	{
		if (!this.m_IsMovingObjectMode && !this.m_IsMovingBoxMode)
		{
			return;
		}
		this.SetCurrentGameState(EGameState.DefaultState);
		this.m_IsMovingObjectMode = false;
		this.m_IsMovingBoxMode = false;
	}

	// Token: 0x06000278 RID: 632 RVA: 0x00018741 File Offset: 0x00016941
	public void OnEnterCashCounterMode(InteractableCashierCounter cashierCounter)
	{
		this.m_PlayerCollider.isTrigger = true;
		this.m_CurrentCashierCounter = cashierCounter;
		this.m_WalkerCtrl.SetStopMovement(true);
		this.SetCurrentGameState(EGameState.CashCounterState);
		this.m_IsCashCounterMode = true;
	}

	// Token: 0x06000279 RID: 633 RVA: 0x00018770 File Offset: 0x00016970
	public void OnExitCashCounterMode()
	{
		this.m_PlayerCollider.isTrigger = false;
		this.m_CurrentCashierCounter = null;
		this.m_WalkerCtrl.SetStopMovement(false);
		this.m_CurrentRaycastObject = null;
		this.SetCurrentGameState(EGameState.DefaultState);
		this.m_IsCashCounterMode = false;
		GameUIScreen.SetGameUIVisible(true);
	}

	// Token: 0x0600027A RID: 634 RVA: 0x000187AC File Offset: 0x000169AC
	public void OnEnterWorkbenchMode()
	{
		this.m_PlayerCollider.isTrigger = true;
		this.m_WalkerCtrl.SetStopMovement(true);
		GameUIScreen.SetGameUIVisible(false);
	}

	// Token: 0x0600027B RID: 635 RVA: 0x000187CC File Offset: 0x000169CC
	public void OnExitWorkbenchMode()
	{
		this.m_PlayerCollider.isTrigger = false;
		this.m_WalkerCtrl.SetStopMovement(false);
		this.m_CurrentRaycastObject = null;
		GameUIScreen.SetGameUIVisible(true);
		CSingleton<InteractionPlayerController>.Instance.ExitUIMode();
	}

	// Token: 0x0600027C RID: 636 RVA: 0x000187FD File Offset: 0x000169FD
	public void OnEnterPhoneScreenMode()
	{
		this.ShowCursor();
		this.m_WalkerCtrl.SetStopMovement(true);
		this.m_IsPhoneScreenMode = true;
		GameUIScreen.HideEnterGoNextDayIndicatorVisible();
		this.SetCurrentGameState(EGameState.PhoneState);
	}

	// Token: 0x0600027D RID: 637 RVA: 0x00018824 File Offset: 0x00016A24
	public void OnExitPhoneScreenMode()
	{
		this.HideCursor();
		this.m_WalkerCtrl.SetStopMovement(false);
		base.StartCoroutine(this.DelayExitPhoneScreenMode());
		GameUIScreen.ResetEnterGoNextDayIndicatorVisible();
		this.SetCurrentGameState(EGameState.DefaultState);
	}

	// Token: 0x0600027E RID: 638 RVA: 0x00018851 File Offset: 0x00016A51
	private IEnumerator DelayExitPhoneScreenMode()
	{
		yield return new WaitForSeconds(0.1f);
		this.m_CurrentRaycastObject = null;
		this.m_IsPhoneScreenMode = false;
		yield break;
	}

	// Token: 0x0600027F RID: 639 RVA: 0x00018860 File Offset: 0x00016A60
	public void EnterWorkerInteractMode()
	{
		this.SetCurrentGameState(EGameState.WorkerInteractState);
		this.m_IsWorkerInteractMode = true;
	}

	// Token: 0x06000280 RID: 640 RVA: 0x00018871 File Offset: 0x00016A71
	public void ExitWorkerInteractMode()
	{
		this.SetCurrentGameState(EGameState.DefaultState);
		this.m_IsWorkerInteractMode = false;
	}

	// Token: 0x06000281 RID: 641 RVA: 0x00018881 File Offset: 0x00016A81
	public void EnterHoldCardMode()
	{
		this.SetCurrentGameState(EGameState.HoldingCardState);
		this.m_IsHoldCardMode = true;
		if (this.m_IsPuttingCardOnDisplay)
		{
			if (this.m_CurrentPutOnDisplayCardCompartment)
			{
				this.m_CurrentPutOnDisplayCardCompartment.OnMouseButtonUp();
			}
			this.SetIsPuttingCardOnDisplay(false);
		}
	}

	// Token: 0x06000282 RID: 642 RVA: 0x000188B8 File Offset: 0x00016AB8
	public void ExitHoldCardMode()
	{
		this.SetCurrentGameState(EGameState.DefaultState);
		this.m_IsHoldCardMode = false;
	}

	// Token: 0x06000283 RID: 643 RVA: 0x000188C8 File Offset: 0x00016AC8
	private void RaycastHoldCardState()
	{
		Ray ray = new Ray(this.m_Cam.transform.position, this.m_Cam.transform.forward);
		int mask = LayerMask.GetMask(new string[]
		{
			"ItemCompartment"
		});
		RaycastHit raycastHit;
		if (Physics.Raycast(ray, out raycastHit, this.m_RayDistance, mask))
		{
			Transform transform = raycastHit.transform;
			InteractableCardCompartment component = raycastHit.transform.GetComponent<InteractableCardCompartment>();
			if (component)
			{
				if (this.m_CurrentCardCompartment != component)
				{
					this.m_CurrentCardCompartment = component;
					InteractionPlayerController.RemoveToolTip(EGameAction.PutCard);
					InteractionPlayerController.AddToolTip(EGameAction.PutCard, false, false);
					InteractionPlayerController.RemoveToolTip(EGameAction.TakeCard);
					InteractionPlayerController.AddToolTip(EGameAction.TakeCard, false, false);
				}
			}
			else
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.PutCard);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeCard);
				this.m_CurrentCardCompartment = null;
			}
		}
		else
		{
			InteractionPlayerController.RemoveToolTip(EGameAction.PutCard);
			InteractionPlayerController.RemoveToolTip(EGameAction.TakeCard);
			this.m_CurrentCardCompartment = null;
		}
		if (InputManager.GetKeyUpAction(EGameAction.PutCard) && this.m_CurrentCardCompartment)
		{
			this.m_CurrentCardCompartment.OnMouseButtonUp();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.TakeCard) && this.m_CurrentCardCompartment)
		{
			this.m_CurrentCardCompartment.OnRightMouseButtonUp();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.OpenCardAlbum))
		{
			this.EnterViewCardAlbumMode();
		}
	}

	// Token: 0x06000284 RID: 644 RVA: 0x000189EC File Offset: 0x00016BEC
	public void EnterViewCardAlbumMode()
	{
		if (this.m_IsViewCardAlbumMode || this.m_IsExitingViewCardAlbumMode)
		{
			return;
		}
		this.m_IsExitingViewCardAlbumMode = true;
		this.m_IsViewCardAlbumMode = true;
		this.m_WalkerCtrl.SetStopMovement(true);
		this.m_CameraController.EnterViewCardAlbumMode();
		this.m_CollectionBinderFlipAnimCtrl.StartShowCardAlbum(this.m_HoldCardAlbumPos);
		base.StartCoroutine(this.DelayExitViewCardAlbumMode());
		this.SetCurrentGameState(EGameState.ViewAlbumState);
		GameUIScreen.SetGameUIVisible(false);
		TutorialManager.SetGameUIVisible(false);
	}

	// Token: 0x06000285 RID: 645 RVA: 0x00018A60 File Offset: 0x00016C60
	public void ExitViewCardAlbumMode()
	{
		if (!this.m_IsViewCardAlbumMode || this.m_IsExitingViewCardAlbumMode)
		{
			return;
		}
		this.m_IsExitingViewCardAlbumMode = true;
		if (this.m_CurrentGameState != EGameState.HoldingCardState)
		{
			this.SetCurrentGameState(EGameState.DefaultState);
		}
		this.m_IsViewCardAlbumMode = false;
		this.m_WalkerCtrl.SetStopMovement(false);
		this.m_CameraController.ExitViewCardAlbumMode();
		this.m_CollectionBinderFlipAnimCtrl.HideCardAlbum();
		base.StartCoroutine(this.DelayExitViewCardAlbumMode());
		GameUIScreen.SetGameUIVisible(true);
		TutorialManager.SetGameUIVisible(true);
	}

	// Token: 0x06000286 RID: 646 RVA: 0x00018AD7 File Offset: 0x00016CD7
	private IEnumerator DelayExitViewCardAlbumMode()
	{
		yield return new WaitForSeconds(this.m_HideCardAlbumTime);
		this.m_IsExitingViewCardAlbumMode = false;
		yield break;
	}

	// Token: 0x06000287 RID: 647 RVA: 0x00018AE8 File Offset: 0x00016CE8
	private void RaycastViewCardAlbumState()
	{
		if (!this.m_CollectionBinderFlipAnimCtrl.m_IsHoldingCardCloseUp)
		{
			Ray ray = new Ray(this.m_Cam.transform.position, this.m_Cam.transform.forward);
			Debug.DrawRay(ray.origin, ray.direction * this.m_RayDistance);
			bool flag = false;
			int mask = LayerMask.GetMask(new string[]
			{
				"UI"
			});
			RaycastHit raycastHit;
			if (Physics.Raycast(ray, out raycastHit, this.m_RayDistance, mask))
			{
				Transform transform = raycastHit.transform;
				InteractableCard3d component = raycastHit.transform.GetComponent<InteractableCard3d>();
				if (component)
				{
					if (this.m_CurrentRaycastedCard3d != component)
					{
						if (this.m_CurrentRaycastedCard3d)
						{
							this.m_CurrentRaycastedCard3d.OnRaycastEnded();
						}
						this.m_CurrentRaycastedCard3d = component;
						component.OnRaycasted();
					}
				}
				else
				{
					flag = true;
				}
			}
			else
			{
				flag = true;
			}
			if (flag && this.m_CurrentRaycastedCard3d)
			{
				this.m_CurrentRaycastedCard3d.OnRaycastEnded();
				this.m_CurrentRaycastedCard3d = null;
			}
		}
		else
		{
			this.m_CurrentRaycastedCard3d = null;
		}
		if (InputManager.GetKeyUpAction(EGameAction.TakeAlbumCard))
		{
			this.m_CollectionBinderFlipAnimCtrl.OnMouseButtonUp();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.InteractRight))
		{
			this.m_CollectionBinderFlipAnimCtrl.OnRightMouseButtonUp();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.CloseCardAlbum))
		{
			this.ExitViewCardAlbumMode();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.FlipNextPage))
		{
			this.m_CollectionBinderFlipAnimCtrl.FlipNextPage();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.FlipPreviousPage))
		{
			this.m_CollectionBinderFlipAnimCtrl.FlipPreviousPage();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.FlipPreviousPage10))
		{
			this.m_CollectionBinderFlipAnimCtrl.FlipPrevious10Page();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.FlipNextPage10))
		{
			this.m_CollectionBinderFlipAnimCtrl.FlipNext10Page();
			return;
		}
		if (InputManager.GetKeyUpAction(EGameAction.SortAlbum))
		{
			this.m_CollectionBinderFlipAnimCtrl.OpenSortAlbumScreen();
		}
	}

	// Token: 0x06000288 RID: 648 RVA: 0x00018C9B File Offset: 0x00016E9B
	public static ShelfCompartment GetCurrentItemCompartment()
	{
		return CSingleton<InteractionPlayerController>.Instance.m_CurrentItemCompartment;
	}

	// Token: 0x06000289 RID: 649 RVA: 0x00018CA7 File Offset: 0x00016EA7
	public static bool HasEnoughSlotToHoldCard()
	{
		return CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Count < 8;
	}

	// Token: 0x0600028A RID: 650 RVA: 0x00018CBC File Offset: 0x00016EBC
	public static void AddHoldCard(InteractableCard3d card3d)
	{
		if (card3d)
		{
			card3d.m_Card3dUI.m_IgnoreCulling = true;
			card3d.m_Card3dUI.m_CardUI.ResetFarDistanceCull();
			card3d.m_Card3dUI.m_CardUIAnimGrp.gameObject.SetActive(true);
			card3d.m_Card3dUI.m_CardUI.SetFoilMaterialList(CSingleton<Card3dUISpawner>.Instance.m_FoilMaterialWorldView);
			card3d.m_Card3dUI.m_CardUI.SetFoilBlendedMaterialList(CSingleton<Card3dUISpawner>.Instance.m_FoilBlendedMaterialWorldView);
			card3d.LerpToTransform(CSingleton<InteractionPlayerController>.Instance.m_HoldCardPosList[CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Count], CSingleton<InteractionPlayerController>.Instance.m_HoldCardPosList[CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Count]);
			Quaternion holdCardGrpTargetRotation = Quaternion.Euler(0f, 0f, Mathf.Lerp(0f, 15f, (float)CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Count / 7f));
			CSingleton<InteractionPlayerController>.Instance.m_HoldCardGrpTargetRotation = holdCardGrpTargetRotation;
			CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Add(card3d);
			CPlayerData.m_HoldCardDataList.Add(card3d.m_Card3dUI.m_CardUI.GetCardData());
		}
	}

	// Token: 0x0600028B RID: 651 RVA: 0x00018DE8 File Offset: 0x00016FE8
	public static void RemoveCurrentCard()
	{
		CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList[0].m_Card3dUI.m_IgnoreCulling = false;
		CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList[0].m_Card3dUI.m_CardUI.SetFoilMaterialList(CSingleton<Card3dUISpawner>.Instance.m_FoilMaterialTangentView);
		CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList[0].m_Card3dUI.m_CardUI.SetFoilBlendedMaterialList(CSingleton<Card3dUISpawner>.Instance.m_FoilBlendedMaterialTangentView);
		CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.RemoveAt(0);
		CPlayerData.m_HoldCardDataList.RemoveAt(0);
		if (CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Count <= 0)
		{
			CSingleton<InteractionPlayerController>.Instance.ExitHoldCardMode();
			Quaternion holdCardGrpTargetRotation = Quaternion.Euler(0f, 0f, 0f);
			CSingleton<InteractionPlayerController>.Instance.m_HoldCardGrpTargetRotation = holdCardGrpTargetRotation;
			return;
		}
		for (int i = 0; i < CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Count; i++)
		{
			CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList[i].LerpToTransform(CSingleton<InteractionPlayerController>.Instance.m_HoldCardPosList[i], CSingleton<InteractionPlayerController>.Instance.m_HoldCardPosList[i]);
		}
		Quaternion holdCardGrpTargetRotation2 = Quaternion.Euler(0f, 0f, Mathf.Lerp(-2.143f, 15f, (float)CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Count / 8f));
		CSingleton<InteractionPlayerController>.Instance.m_HoldCardGrpTargetRotation = holdCardGrpTargetRotation2;
	}

	// Token: 0x0600028C RID: 652 RVA: 0x00018F4C File Offset: 0x0001714C
	public static void RemoveAllCard()
	{
		for (int i = 0; i < CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Count; i++)
		{
			CPlayerData.AddCard(CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList[i].m_Card3dUI.m_CardUI.GetCardData(), 1);
			CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList[i].OnDestroyed();
		}
		CSingleton<InteractionPlayerController>.Instance.ExitHoldCardMode();
		CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Clear();
		CPlayerData.m_HoldCardDataList.Clear();
		Quaternion holdCardGrpTargetRotation = Quaternion.Euler(0f, 0f, 0f);
		CSingleton<InteractionPlayerController>.Instance.m_HoldCardGrpTargetRotation = holdCardGrpTargetRotation;
	}

	// Token: 0x0600028D RID: 653 RVA: 0x00018FF0 File Offset: 0x000171F0
	public static InteractableCard3d GetCurrentHoldCard()
	{
		if (CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList.Count <= 0)
		{
			return null;
		}
		return CSingleton<InteractionPlayerController>.Instance.m_CurrentHoldingCard3dList[0];
	}

	// Token: 0x0600028E RID: 654 RVA: 0x00019016 File Offset: 0x00017216
	public static void ClearToolTip()
	{
		CSingleton<InteractionPlayerController>.Instance.m_InputTooltipListDisplay.ClearTooltip();
	}

	// Token: 0x0600028F RID: 655 RVA: 0x00019027 File Offset: 0x00017227
	public static void AddToolTip(EGameAction action, bool isHold = false, bool singleKeyOnly = false)
	{
		CSingleton<InteractionPlayerController>.Instance.m_InputTooltipListDisplay.ShowTooltip(action, isHold, singleKeyOnly);
	}

	// Token: 0x06000290 RID: 656 RVA: 0x0001903B File Offset: 0x0001723B
	public static void RemoveToolTip(EGameAction action)
	{
		CSingleton<InteractionPlayerController>.Instance.m_InputTooltipListDisplay.RemoveTooltip(action);
	}

	// Token: 0x06000291 RID: 657 RVA: 0x0001904D File Offset: 0x0001724D
	public static void TempHideToolTip()
	{
		CSingleton<InteractionPlayerController>.Instance.m_InputTooltipListDisplay.ClearTooltip();
	}

	// Token: 0x06000292 RID: 658 RVA: 0x0001905E File Offset: 0x0001725E
	public static void RestoreHiddenToolTip()
	{
		CSingleton<InteractionPlayerController>.Instance.SetCurrentGameState(CSingleton<InteractionPlayerController>.Instance.m_CurrentGameState);
	}

	// Token: 0x06000293 RID: 659 RVA: 0x00019074 File Offset: 0x00017274
	private void SetCurrentGameState(EGameState state)
	{
		this.m_CurrentGameState = state;
		this.m_InputTooltipListDisplay.SetCurrentGameState(state);
		if (state == EGameState.HoldingItemState)
		{
			if (this.m_CurrentItemCompartment && this.m_CurrentItemCompartment.m_CanPutItem)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
				InteractionPlayerController.AddToolTip(EGameAction.PutItem, true, false);
				InteractionPlayerController.AddToolTip(EGameAction.TakeItem, true, false);
			}
			if (this.m_CurrentRaycastedPackageBoxItem)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
				InteractionPlayerController.AddToolTip(EGameAction.PutItem, true, false);
				if (this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.GetItemCount() > 0)
				{
					InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
					InteractionPlayerController.AddToolTip(EGameAction.TakeItem, true, false);
					return;
				}
			}
		}
		else if (state == EGameState.HoldingCardState)
		{
			if (this.m_CurrentCardCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.PutCard);
				InteractionPlayerController.AddToolTip(EGameAction.PutCard, false, false);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeCard);
				InteractionPlayerController.AddToolTip(EGameAction.TakeCard, false, false);
				return;
			}
		}
		else if (state == EGameState.HoldingBoxState)
		{
			if (this.m_CurrentItemCompartment)
			{
				if (this.m_CurrentItemCompartment.m_CanPutBox)
				{
					InteractionPlayerController.RemoveToolTip(EGameAction.StoreBox);
					InteractionPlayerController.AddToolTip(EGameAction.StoreBox, false, false);
					return;
				}
				if (this.m_CurrentItemCompartment.m_CanPutItem)
				{
					InteractionPlayerController.RemoveToolTip(EGameAction.PutItem);
					InteractionPlayerController.AddToolTip(EGameAction.PutItem, true, false);
					InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
					InteractionPlayerController.AddToolTip(EGameAction.TakeItem, true, false);
					return;
				}
			}
		}
		else if (state == EGameState.DefaultState)
		{
			if (this.m_CurrentRaycastObject)
			{
				InteractionPlayerController.ClearToolTip();
				for (int i = 0; i < this.m_CurrentRaycastObject.m_GameActionInputDisplayList.Count; i++)
				{
					InteractionPlayerController.AddToolTip(this.m_CurrentRaycastObject.m_GameActionInputDisplayList[i], false, false);
				}
			}
			if (this.m_CurrentItemCompartment && this.m_CurrentItemCompartment.m_CanPutItem && this.m_CurrentItemCompartment.GetItemCount() > 0)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
				InteractionPlayerController.AddToolTip(EGameAction.TakeItem, true, false);
			}
			if (this.m_CurrentStorageCompartment && this.m_CurrentStorageCompartment.GetShelfCompartment().GetItemCount() > 0)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
				InteractionPlayerController.AddToolTip(EGameAction.TakeBox, false, false);
			}
			if (this.m_CurrentRaycastedPackageBoxItem)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeBox);
				InteractionPlayerController.AddToolTip(EGameAction.TakeBox, false, false);
				if (this.m_CurrentRaycastedPackageBoxItem.m_ItemCompartment.GetItemCount() > 0)
				{
					InteractionPlayerController.RemoveToolTip(EGameAction.TakeItem);
					InteractionPlayerController.AddToolTip(EGameAction.TakeItem, false, false);
				}
			}
			if (this.m_CurrentCardCompartment)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.PutCard);
				InteractionPlayerController.RemoveToolTip(EGameAction.TakeCard);
				if (this.m_CurrentCardCompartment.m_StoredCardList.Count > 0)
				{
					InteractionPlayerController.AddToolTip(EGameAction.TakeCard, false, false);
				}
				else
				{
					InteractionPlayerController.AddToolTip(EGameAction.PutCard, false, false);
				}
			}
			if (this.m_CurrentPlayTable)
			{
				InteractionPlayerController.RemoveToolTip(EGameAction.ManageEvent);
				InteractionPlayerController.AddToolTip(EGameAction.ManageEvent, false, false);
			}
		}
	}

	// Token: 0x06000294 RID: 660 RVA: 0x000192E7 File Offset: 0x000174E7
	public bool IsInUIMode()
	{
		return this.m_IsInUIMode || this.m_IsPhoneScreenMode || this.m_IsViewCardAlbumMode;
	}

	// Token: 0x06000295 RID: 661 RVA: 0x00019301 File Offset: 0x00017501
	public bool CanJump()
	{
		return this.m_CurrentGameState == EGameState.DefaultState || this.m_CurrentGameState == EGameState.HoldingBoxState || this.m_CurrentGameState == EGameState.HoldingCardState || this.m_CurrentGameState == EGameState.HoldingItemState || this.m_CurrentGameState == EGameState.HoldSprayState;
	}

	// Token: 0x06000296 RID: 662 RVA: 0x00019332 File Offset: 0x00017532
	private void EvaluateInvertedMouse()
	{
		if (!this.m_CameraMouseInput)
		{
			return;
		}
		this.m_CameraMouseInput.invertVerticalInput = CSingleton<CGameManager>.Instance.m_InvertedMouse;
	}

	// Token: 0x06000297 RID: 663 RVA: 0x00019358 File Offset: 0x00017558
	protected virtual void OnEnable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.AddListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.AddListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
			CEventManager.AddListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x06000298 RID: 664 RVA: 0x000193A8 File Offset: 0x000175A8
	protected virtual void OnDisable()
	{
		if (Application.isPlaying || Application.isMobilePlatform)
		{
			CEventManager.RemoveListener<CEventPlayer_GameDataFinishLoaded>(new CEventManager.EventDelegate<CEventPlayer_GameDataFinishLoaded>(this.OnGameDataFinishLoaded));
			CEventManager.RemoveListener<CEventPlayer_FinishHideLoadingScreen>(new CEventManager.EventDelegate<CEventPlayer_FinishHideLoadingScreen>(this.OnFinishHideLoadingScreen));
			CEventManager.RemoveListener<CEventPlayer_OnSettingUpdated>(new CEventManager.EventDelegate<CEventPlayer_OnSettingUpdated>(this.OnSettingUpdated));
		}
	}

	// Token: 0x06000299 RID: 665 RVA: 0x000193F8 File Offset: 0x000175F8
	protected void OnGameDataFinishLoaded(CEventPlayer_GameDataFinishLoaded evt)
	{
		CSingleton<InteractionPlayerController>.Instance.m_CameraController.SetRotationAngles(0f, -35f);
		CSingleton<InteractionPlayerController>.Instance.m_CameraController.enabled = false;
		if (CPlayerData.m_HoldItemTypeList.Count > 7)
		{
			for (int i = CPlayerData.m_HoldItemTypeList.Count - 1; i >= 8; i--)
			{
				CPlayerData.m_HoldItemTypeList.RemoveAt(i);
			}
		}
		if (CPlayerData.m_HoldCardDataList.Count > 7)
		{
			for (int j = CPlayerData.m_HoldCardDataList.Count - 1; j >= 8; j--)
			{
				CPlayerData.m_HoldCardDataList.RemoveAt(j);
			}
		}
		if (CPlayerData.m_HoldCardDataList.Count > 0)
		{
			List<InteractableCard3d> list = new List<InteractableCard3d>();
			for (int k = 0; k < CPlayerData.m_HoldCardDataList.Count; k++)
			{
				Card3dUIGroup cardUI = CSingleton<Card3dUISpawner>.Instance.GetCardUI();
				InteractableCard3d component = ShelfManager.SpawnInteractableObject(EObjectType.Card3d).GetComponent<InteractableCard3d>();
				cardUI.m_CardUI.SetCardUI(CPlayerData.m_HoldCardDataList[k]);
				cardUI.transform.position = CSingleton<InteractionPlayerController>.Instance.m_HoldCardPosList[k].position;
				cardUI.transform.rotation = CSingleton<InteractionPlayerController>.Instance.m_HoldCardPosList[k].rotation;
				component.transform.position = CSingleton<InteractionPlayerController>.Instance.m_HoldCardPosList[k].position;
				component.transform.rotation = CSingleton<InteractionPlayerController>.Instance.m_HoldCardPosList[k].rotation;
				component.SetCardUIFollow(cardUI);
				component.SetEnableCollision(false);
				list.Add(component);
			}
			CPlayerData.m_HoldCardDataList.Clear();
			for (int l = 0; l < list.Count; l++)
			{
				InteractionPlayerController.AddHoldCard(list[l]);
			}
			this.EnterHoldCardMode();
			return;
		}
		if (CPlayerData.m_HoldItemTypeList.Count > 0)
		{
			List<Item> list2 = new List<Item>();
			for (int m = 0; m < CPlayerData.m_HoldItemTypeList.Count; m++)
			{
				ItemMeshData itemMeshData = InventoryBase.GetItemMeshData(CPlayerData.m_HoldItemTypeList[m]);
				Item item = ItemSpawnManager.GetItem(this.m_HoldCardPackPosList[m]);
				item.SetMesh(itemMeshData.mesh, itemMeshData.material, CPlayerData.m_HoldItemTypeList[m], itemMeshData.meshSecondary, itemMeshData.materialSecondary);
				item.transform.position = this.m_HoldCardPackPosList[m].position;
				item.transform.rotation = this.m_HoldCardPackPosList[m].rotation;
				item.SmoothLerpToTransform(this.m_HoldCardPackPosList[m], this.m_HoldCardPackPosList[m], false);
				item.gameObject.SetActive(true);
				list2.Add(item);
			}
			for (int n = 0; n < list2.Count; n++)
			{
				this.m_HoldItemList.Add(list2[n]);
			}
			this.SetCurrentGameState(EGameState.HoldingItemState);
			this.m_IsHoldItemMode = true;
		}
	}

	// Token: 0x0600029A RID: 666 RVA: 0x000196F9 File Offset: 0x000178F9
	protected void OnFinishHideLoadingScreen(CEventPlayer_FinishHideLoadingScreen evt)
	{
		CSingleton<InteractionPlayerController>.Instance.m_CameraController.SetRotationAngles(0f, -35f);
		CSingleton<InteractionPlayerController>.Instance.m_CameraController.enabled = true;
	}

	// Token: 0x0600029B RID: 667 RVA: 0x00019724 File Offset: 0x00017924
	protected void OnSettingUpdated(CEventPlayer_OnSettingUpdated evt)
	{
		this.EvaluateInvertedMouse();
	}

	// Token: 0x0400027C RID: 636
	public static InteractionPlayerController m_Instance;

	// Token: 0x0400027D RID: 637
	public EGameState m_CurrentGameState;

	// Token: 0x0400027E RID: 638
	public Collider m_PlayerCollider;

	// Token: 0x0400027F RID: 639
	public Camera m_Cam;

	// Token: 0x04000280 RID: 640
	public float m_RayDistance = 5f;

	// Token: 0x04000281 RID: 641
	public float m_MouseHoldAutoFireRate = 0.15f;

	// Token: 0x04000282 RID: 642
	public float m_MoveObjectRotateSpeed = 5f;

	// Token: 0x04000283 RID: 643
	public Transform m_LookAtTransform;

	// Token: 0x04000284 RID: 644
	public Transform m_HoldItemPos;

	// Token: 0x04000285 RID: 645
	public Transform m_HoldBigItemPos;

	// Token: 0x04000286 RID: 646
	public Transform m_HoldCardPackPos;

	// Token: 0x04000287 RID: 647
	public Transform m_HoldCardAlbumPos;

	// Token: 0x04000288 RID: 648
	public Transform m_HoldCardPos;

	// Token: 0x04000289 RID: 649
	public Transform m_HoldCardGrpRotation;

	// Token: 0x0400028A RID: 650
	public List<Transform> m_HoldCardPosList;

	// Token: 0x0400028B RID: 651
	public Transform m_HoldCardCloseUpPos;

	// Token: 0x0400028C RID: 652
	public Transform m_OpenCardPackPos;

	// Token: 0x0400028D RID: 653
	public Transform m_HoldDeodorantPos;

	// Token: 0x0400028E RID: 654
	public ParticleSystem m_DeodorantSprayVFX;

	// Token: 0x0400028F RID: 655
	public ParticleSystem m_SellShelfVFX;

	// Token: 0x04000290 RID: 656
	public List<Transform> m_HoldCardPackPosList;

	// Token: 0x04000291 RID: 657
	public List<Transform> m_OpenCardBoxSpawnCardPackPosList;

	// Token: 0x04000292 RID: 658
	public Animation m_OpenCardBoxInnerMesh;

	// Token: 0x04000293 RID: 659
	public MeshFilter m_OpenCardBoxMeshFilter;

	// Token: 0x04000294 RID: 660
	public MeshRenderer m_OpenCardBoxMesh;

	// Token: 0x04000295 RID: 661
	public AdvancedWalkerController m_WalkerCtrl;

	// Token: 0x04000296 RID: 662
	public CameraController m_CameraController;

	// Token: 0x04000297 RID: 663
	public CameraMouseInput m_CameraMouseInput;

	// Token: 0x04000298 RID: 664
	public CameraFOVControl m_CameraFOVController;

	// Token: 0x04000299 RID: 665
	public ImageFadeInOut m_BlackBGWorldUIFade;

	// Token: 0x0400029A RID: 666
	public float m_HideCardAlbumTime = 0.6f;

	// Token: 0x0400029B RID: 667
	public CollectionBinderFlipAnimCtrl m_CollectionBinderFlipAnimCtrl;

	// Token: 0x0400029C RID: 668
	public InputTooltipListDisplay m_InputTooltipListDisplay;

	// Token: 0x0400029D RID: 669
	public ConfirmTrashScreen m_ConfirmTrashScreen;

	// Token: 0x0400029E RID: 670
	public ConfirmGoNextDayScreen m_ConfirmGoNextDayScreen;

	// Token: 0x0400029F RID: 671
	public ConfirmSellShelfScreen m_ConfirmSellShelfScreen;

	// Token: 0x040002A0 RID: 672
	private Vector3 m_OriginalCameraPos;

	// Token: 0x040002A1 RID: 673
	private Quaternion m_OriginalCameraRot = Quaternion.identity;

	// Token: 0x040002A2 RID: 674
	private Quaternion m_HoldCardGrpTargetRotation = Quaternion.identity;

	// Token: 0x040002A3 RID: 675
	private bool m_IsInUIMode;

	// Token: 0x040002A4 RID: 676
	private bool m_IsPhoneScreenMode;

	// Token: 0x040002A5 RID: 677
	private bool m_IsCashCounterMode;

	// Token: 0x040002A6 RID: 678
	private bool m_IsHoldBoxMode;

	// Token: 0x040002A7 RID: 679
	private bool m_IsHoldItemMode;

	// Token: 0x040002A8 RID: 680
	private bool m_IsHoldCardMode;

	// Token: 0x040002A9 RID: 681
	private bool m_IsHoldSprayMode;

	// Token: 0x040002AA RID: 682
	private bool m_IsWorkerInteractMode;

	// Token: 0x040002AB RID: 683
	private bool m_IsViewCardAlbumMode;

	// Token: 0x040002AC RID: 684
	private bool m_IsExitingViewCardAlbumMode;

	// Token: 0x040002AD RID: 685
	private bool m_IsMovingObjectMode;

	// Token: 0x040002AE RID: 686
	private bool m_IsMovingBoxMode;

	// Token: 0x040002AF RID: 687
	private Vector3 m_BoxPhysicsDimension;

	// Token: 0x040002B0 RID: 688
	private bool m_IsPuttingCardOnDisplay;

	// Token: 0x040002B1 RID: 689
	private bool m_IsHoldingMouseDown;

	// Token: 0x040002B2 RID: 690
	private bool m_IsHoldingRightMouseDown;

	// Token: 0x040002B3 RID: 691
	private bool m_IsResetMousePress;

	// Token: 0x040002B4 RID: 692
	private bool m_IsResetRightMousePress;

	// Token: 0x040002B5 RID: 693
	private bool m_IsLerpingCameraRot;

	// Token: 0x040002B6 RID: 694
	private bool m_IsOpeningCardBox;

	// Token: 0x040002B7 RID: 695
	private Quaternion m_LerpCameraTargetRot;

	// Token: 0x040002B8 RID: 696
	private Transform m_LookAtTarget;

	// Token: 0x040002B9 RID: 697
	private float m_LookAtDelayTimer;

	// Token: 0x040002BA RID: 698
	private float m_LookAtDelayTime;

	// Token: 0x040002BB RID: 699
	private float m_LerpCameraRotSpeed = 1f;

	// Token: 0x040002BC RID: 700
	public float m_MouseDownTime;

	// Token: 0x040002BD RID: 701
	private float m_RightMouseDownTime;

	// Token: 0x040002BE RID: 702
	private float m_MouseDownTimeTotal;

	// Token: 0x040002BF RID: 703
	private InteractableObject m_CurrentRaycastObject;

	// Token: 0x040002C0 RID: 704
	private InteractablePackagingBox m_CurrentHoldingBox;

	// Token: 0x040002C1 RID: 705
	private InteractablePackagingBox_Item m_CurrentHoldingItemBox;

	// Token: 0x040002C2 RID: 706
	private InteractablePackagingBox_Item m_CurrentRaycastedPackageBoxItem;

	// Token: 0x040002C3 RID: 707
	private InteractablePackagingBox_Shelf m_CurrentHoldingBoxShelf;

	// Token: 0x040002C4 RID: 708
	private ShelfCompartment m_CurrentItemCompartment;

	// Token: 0x040002C5 RID: 709
	private WorkerCollider m_HitWorkerCollider;

	// Token: 0x040002C6 RID: 710
	private Worker m_HitWorker;

	// Token: 0x040002C7 RID: 711
	private InteractableStorageCompartment m_CurrentStorageCompartment;

	// Token: 0x040002C8 RID: 712
	private InteractableCardCompartment m_CurrentCardCompartment;

	// Token: 0x040002C9 RID: 713
	private InteractableCardCompartment m_CurrentPutOnDisplayCardCompartment;

	// Token: 0x040002CA RID: 714
	private InteractablePlayTable m_CurrentPlayTable;

	// Token: 0x040002CB RID: 715
	private InteractableTrashBin m_CurrentTrashBin;

	// Token: 0x040002CC RID: 716
	private InteractableCashierCounter m_CurrentCashierCounter;

	// Token: 0x040002CD RID: 717
	private InteractableAutoCleanser m_CurrentAutoCleanser;

	// Token: 0x040002CE RID: 718
	private InteractableWorkbench m_CurrentWorkbench;

	// Token: 0x040002CF RID: 719
	private InteractableCard3d m_CurrentRaycastedCard3d;

	// Token: 0x040002D0 RID: 720
	private List<InteractableCard3d> m_CurrentHoldingCard3dList = new List<InteractableCard3d>();

	// Token: 0x040002D1 RID: 721
	private List<Item> m_HoldItemList = new List<Item>();

	// Token: 0x040002D2 RID: 722
	private Item m_CurrentHoldSprayItem;
}
