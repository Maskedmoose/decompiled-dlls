﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace CC
{
	// Token: 0x020001AB RID: 427
	public class BlendshapeManager : MonoBehaviour
	{
		// Token: 0x06000C54 RID: 3156 RVA: 0x00055F7C File Offset: 0x0005417C
		public void parseBlendshapes()
		{
			this.mesh = base.gameObject.GetComponent<SkinnedMeshRenderer>();
			if (this.mesh.sharedMesh != null)
			{
				for (int i = 0; i < this.mesh.sharedMesh.blendShapeCount; i++)
				{
					this.blendshapeNames.Add(this.mesh.sharedMesh.GetBlendShapeName(i));
				}
			}
		}

		// Token: 0x06000C55 RID: 3157 RVA: 0x00055FE4 File Offset: 0x000541E4
		public void setBlendshape(string name, float value)
		{
			int num = this.blendshapeNames.FindIndex((string t) => t == name);
			if (num != -1)
			{
				this.mesh.SetBlendShapeWeight(num, value * 100f);
			}
		}

		// Token: 0x04001329 RID: 4905
		private List<string> blendshapeNames = new List<string>();

		// Token: 0x0400132A RID: 4906
		private SkinnedMeshRenderer mesh;
	}
}
