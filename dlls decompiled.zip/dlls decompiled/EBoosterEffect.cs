﻿using System;

// Token: 0x020000E0 RID: 224
public enum EBoosterEffect
{
	// Token: 0x04000A94 RID: 2708
	None,
	// Token: 0x04000A95 RID: 2709
	IncreasePrice,
	// Token: 0x04000A96 RID: 2710
	IncreaseTapPower,
	// Token: 0x04000A97 RID: 2711
	IncreaseCustomerSpendLimit,
	// Token: 0x04000A98 RID: 2712
	IncreaseCustomerBuyLimit,
	// Token: 0x04000A99 RID: 2713
	PackStorageLimit,
	// Token: 0x04000A9A RID: 2714
	SellCardLimit
}
