﻿using System;
using System.Collections.Generic;

namespace CC
{
	// Token: 0x020001B0 RID: 432
	[Serializable]
	public class CC_SaveData
	{
		// Token: 0x04001341 RID: 4929
		public List<CC_CharacterData> SavedCharacters = new List<CC_CharacterData>();
	}
}
