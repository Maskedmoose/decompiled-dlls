﻿using System;
using UnityEngine;

// Token: 0x02000096 RID: 150
public class LegendCardGlowTexturePanner : MonoBehaviour
{
	// Token: 0x060005E7 RID: 1511 RVA: 0x00030F1D File Offset: 0x0002F11D
	private void Start()
	{
	}

	// Token: 0x060005E8 RID: 1512 RVA: 0x00030F20 File Offset: 0x0002F120
	private void Update()
	{
		this.m_X1 += Time.deltaTime * this.m_SpeedX1;
		this.m_X2 += Time.deltaTime * this.m_SpeedX2;
		this.m_Y1 += Time.deltaTime * this.m_SpeedY1;
		this.m_Y2 += Time.deltaTime * this.m_SpeedY2;
		this.m_Offset1.x = this.m_X1;
		this.m_Offset2.x = this.m_X2;
		this.m_Offset1.y = this.m_Y1;
		this.m_Offset2.y = this.m_Y2;
		this.m_Material1.SetFloat("_OffsetX", this.m_X1);
		this.m_Material2.SetFloat("_OffsetX", this.m_X2);
		this.m_Material1.SetTextureOffset("_Texture", this.m_Offset1);
		this.m_Material2.SetTextureOffset("_Texture", this.m_Offset2);
	}

	// Token: 0x060005E9 RID: 1513 RVA: 0x00031030 File Offset: 0x0002F230
	private void OnApplicationQuit()
	{
		this.m_Material1.SetTextureOffset("_Texture", Vector2.zero);
		this.m_Material2.SetTextureOffset("_Texture", Vector2.zero);
		this.m_Material1.SetFloat("_OffsetX", 0f);
		this.m_Material2.SetFloat("_OffsetX", 0f);
	}

	// Token: 0x040007AF RID: 1967
	public Material m_Material1;

	// Token: 0x040007B0 RID: 1968
	public Material m_Material2;

	// Token: 0x040007B1 RID: 1969
	public float m_SpeedX1 = 1f;

	// Token: 0x040007B2 RID: 1970
	public float m_SpeedX2 = 1f;

	// Token: 0x040007B3 RID: 1971
	public float m_SpeedY1 = 1f;

	// Token: 0x040007B4 RID: 1972
	public float m_SpeedY2 = 1f;

	// Token: 0x040007B5 RID: 1973
	private float m_X1;

	// Token: 0x040007B6 RID: 1974
	private float m_X2;

	// Token: 0x040007B7 RID: 1975
	private float m_Y1;

	// Token: 0x040007B8 RID: 1976
	private float m_Y2;

	// Token: 0x040007B9 RID: 1977
	private Vector2 m_Offset1;

	// Token: 0x040007BA RID: 1978
	private Vector2 m_Offset2;
}
