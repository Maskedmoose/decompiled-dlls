﻿using System;

// Token: 0x020000F4 RID: 244
public enum ERarity
{
	// Token: 0x04000D77 RID: 3447
	None = -1,
	// Token: 0x04000D78 RID: 3448
	Common,
	// Token: 0x04000D79 RID: 3449
	Rare,
	// Token: 0x04000D7A RID: 3450
	Epic,
	// Token: 0x04000D7B RID: 3451
	Legendary,
	// Token: 0x04000D7C RID: 3452
	SuperLegend
}
