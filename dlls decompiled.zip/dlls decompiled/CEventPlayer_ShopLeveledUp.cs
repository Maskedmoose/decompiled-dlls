﻿using System;

// Token: 0x020000B4 RID: 180
public class CEventPlayer_ShopLeveledUp : CEvent
{
	// Token: 0x17000018 RID: 24
	// (get) Token: 0x0600070B RID: 1803 RVA: 0x00038097 File Offset: 0x00036297
	// (set) Token: 0x0600070C RID: 1804 RVA: 0x0003809F File Offset: 0x0003629F
	public int m_ShopLevel { get; private set; }

	// Token: 0x0600070D RID: 1805 RVA: 0x000380A8 File Offset: 0x000362A8
	public CEventPlayer_ShopLeveledUp(int shopLevel)
	{
		this.m_ShopLevel = shopLevel;
	}
}
