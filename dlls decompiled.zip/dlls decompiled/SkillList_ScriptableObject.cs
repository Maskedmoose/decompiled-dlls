﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000133 RID: 307
[CreateAssetMenu(fileName = "Data", menuName = "Inventory/List", order = 7)]
public class SkillList_ScriptableObject : ScriptableObject
{
	// Token: 0x040010DF RID: 4319
	public List<Color> m_ElementColorList;
}
