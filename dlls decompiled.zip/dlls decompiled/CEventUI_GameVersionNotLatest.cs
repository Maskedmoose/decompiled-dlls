﻿using System;

// Token: 0x020000CB RID: 203
public class CEventUI_GameVersionNotLatest : CEvent
{
	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000740 RID: 1856 RVA: 0x000382B7 File Offset: 0x000364B7
	// (set) Token: 0x06000741 RID: 1857 RVA: 0x000382BF File Offset: 0x000364BF
	public float m_CurrentVersion { get; private set; }

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000742 RID: 1858 RVA: 0x000382C8 File Offset: 0x000364C8
	// (set) Token: 0x06000743 RID: 1859 RVA: 0x000382D0 File Offset: 0x000364D0
	public float m_LatestVersion { get; private set; }

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x06000744 RID: 1860 RVA: 0x000382D9 File Offset: 0x000364D9
	// (set) Token: 0x06000745 RID: 1861 RVA: 0x000382E1 File Offset: 0x000364E1
	public string m_LatestVersionString { get; private set; }

	// Token: 0x06000746 RID: 1862 RVA: 0x000382EA File Offset: 0x000364EA
	public CEventUI_GameVersionNotLatest(float CurrentVersion, float LatestVersion, string LatestVersionString)
	{
		this.m_CurrentVersion = CurrentVersion;
		this.m_LatestVersion = LatestVersion;
		this.m_LatestVersionString = LatestVersionString;
	}
}
