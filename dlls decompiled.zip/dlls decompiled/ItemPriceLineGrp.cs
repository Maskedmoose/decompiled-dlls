﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200006E RID: 110
public class ItemPriceLineGrp : MonoBehaviour
{
	// Token: 0x060004A2 RID: 1186 RVA: 0x00028646 File Offset: 0x00026846
	public void SetActive(bool isActive)
	{
		this.m_IsActive = isActive;
		base.gameObject.SetActive(isActive);
	}

	// Token: 0x060004A3 RID: 1187 RVA: 0x0002865B File Offset: 0x0002685B
	public void SetColor(Color color)
	{
		this.m_Line.color = color;
	}

	// Token: 0x060004A4 RID: 1188 RVA: 0x00028669 File Offset: 0x00026869
	public void SetScaleLerp(float lerp)
	{
		this.m_Lerp = lerp;
		this.m_Scale = Vector3.one;
		this.m_Scale.z = this.m_Lerp;
		this.m_LineScaleTransform.localScale = this.m_Scale;
	}

	// Token: 0x060004A5 RID: 1189 RVA: 0x000286A0 File Offset: 0x000268A0
	public void AddScaleLerp(float lerp)
	{
		this.m_Lerp += lerp;
		if (this.m_Lerp > 1f)
		{
			this.m_Lerp = 1f;
		}
		this.m_Scale = Vector3.one;
		this.m_Scale.z = this.m_Lerp;
		this.m_LineScaleTransform.localScale = this.m_Scale;
	}

	// Token: 0x040005DE RID: 1502
	public Image m_Line;

	// Token: 0x040005DF RID: 1503
	public Transform m_LineScaleTransform;

	// Token: 0x040005E0 RID: 1504
	public bool m_IsActive;

	// Token: 0x040005E1 RID: 1505
	public float m_Lerp;

	// Token: 0x040005E2 RID: 1506
	private Vector3 m_Scale;
}
