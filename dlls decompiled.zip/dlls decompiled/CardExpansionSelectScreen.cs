﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000058 RID: 88
public class CardExpansionSelectScreen : CSingleton<CardExpansionSelectScreen>
{
	// Token: 0x060003F8 RID: 1016 RVA: 0x00023590 File Offset: 0x00021790
	public static void OpenScreen(ECardExpansionType initCardExpansion)
	{
		CSingleton<CardExpansionSelectScreen>.Instance.m_CurrentIndex = (int)initCardExpansion;
		for (int i = 0; i < CSingleton<CardExpansionSelectScreen>.Instance.m_BtnHighlightList.Count; i++)
		{
			CSingleton<CardExpansionSelectScreen>.Instance.m_BtnHighlightList[i].SetActive(false);
		}
		CSingleton<CardExpansionSelectScreen>.Instance.m_BtnHighlightList[CSingleton<CardExpansionSelectScreen>.Instance.m_CurrentIndex].SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		CSingleton<CardExpansionSelectScreen>.Instance.m_ScreenGrp.SetActive(true);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<CardExpansionSelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x060003F9 RID: 1017 RVA: 0x00023625 File Offset: 0x00021825
	private void CloseScreen()
	{
		this.m_ScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<CardExpansionSelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x060003FA RID: 1018 RVA: 0x00023642 File Offset: 0x00021842
	public void OnPressButton(int index)
	{
		this.m_CurrentIndex = index;
		CEventManager.QueueEvent(new CEventPlayer_OnCardExpansionSelectScreenUpdated(index));
		this.CloseScreen();
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x060003FB RID: 1019 RVA: 0x0002366B File Offset: 0x0002186B
	public void OnPressBackButton()
	{
		CEventManager.QueueEvent(new CEventPlayer_OnCardExpansionSelectScreenUpdated(this.m_CurrentIndex));
		this.CloseScreen();
		SoundManager.GenericMenuClose(1f, 1f);
	}

	// Token: 0x040004C9 RID: 1225
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040004CA RID: 1226
	public GameObject m_ScreenGrp;

	// Token: 0x040004CB RID: 1227
	public List<GameObject> m_BtnHighlightList;

	// Token: 0x040004CC RID: 1228
	private int m_CurrentIndex;
}
