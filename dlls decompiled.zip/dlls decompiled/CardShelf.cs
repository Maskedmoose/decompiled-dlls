﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200000B RID: 11
public class CardShelf : InteractableObject
{
	// Token: 0x06000042 RID: 66 RVA: 0x00005071 File Offset: 0x00003271
	protected override void Awake()
	{
		base.Awake();
		ShelfManager.InitCardShelf(this);
	}

	// Token: 0x06000043 RID: 67 RVA: 0x00005080 File Offset: 0x00003280
	public override void Init()
	{
		if (this.m_HasInit)
		{
			return;
		}
		base.Init();
		for (int i = 0; i < this.m_CardShelfCompartmentGrpList.Count; i++)
		{
			for (int j = 0; j < this.m_CardShelfCompartmentGrpList[i].childCount; j++)
			{
				this.m_CardCompartmentList.Add(this.m_CardShelfCompartmentGrpList[i].GetChild(j).GetComponent<InteractableCardCompartment>());
			}
		}
		this.m_Shelf_WorldUIGrp = PriceTagUISpawner.SpawnShelfWorldUIGrp(base.transform);
		for (int k = 0; k < this.m_CardCompartmentList.Count; k++)
		{
			this.m_CardCompartmentList[k].m_ItemNotForSale = this.m_ItemNotForSale;
			this.m_CardCompartmentList[k].InitCardShelf(this);
			if (!this.m_ItemNotForSale)
			{
				for (int l = 0; l < this.m_CardCompartmentList[k].m_InteractablePriceTagList.Count; l++)
				{
					UI_PriceTag ui_PriceTag = PriceTagUISpawner.SpawnPriceTagCardWorldUIGrp(this.m_Shelf_WorldUIGrp, this.m_CardCompartmentList[k].m_InteractablePriceTagList[l].transform);
					this.m_UIPriceTagList.Add(ui_PriceTag);
					this.m_CardCompartmentList[k].m_InteractablePriceTagList[l].SetPriceTagUI(ui_PriceTag);
					this.m_CardCompartmentList[k].m_InteractablePriceTagList[l].SetVisibility(false);
				}
			}
		}
	}

	// Token: 0x06000044 RID: 68 RVA: 0x000051E8 File Offset: 0x000033E8
	protected override void LateUpdate()
	{
		base.LateUpdate();
		if (this.m_IsMovingObject && this.m_Shelf_WorldUIGrp)
		{
			this.m_Shelf_WorldUIGrp.transform.position = base.transform.position;
			this.m_Shelf_WorldUIGrp.transform.rotation = base.transform.rotation;
		}
	}

	// Token: 0x06000045 RID: 69 RVA: 0x00005248 File Offset: 0x00003448
	public void LoadCardCompartment(List<CardData> cardDataList)
	{
		if (cardDataList == null)
		{
			return;
		}
		int num = 0;
		while (num < this.m_CardCompartmentList.Count && num < cardDataList.Count)
		{
			if (cardDataList[num] != null && cardDataList[num].monsterType != EMonsterType.None)
			{
				Card3dUIGroup cardUI = CSingleton<Card3dUISpawner>.Instance.GetCardUI();
				InteractableCard3d component = ShelfManager.SpawnInteractableObject(EObjectType.Card3d).GetComponent<InteractableCard3d>();
				cardUI.m_IgnoreCulling = true;
				cardUI.m_CardUI.SetFoilCullListVisibility(true);
				cardUI.m_CardUI.ResetFarDistanceCull();
				cardUI.m_CardUI.SetCardUI(cardDataList[num]);
				cardUI.transform.position = component.transform.position;
				cardUI.transform.rotation = component.transform.rotation;
				component.SetCardUIFollow(cardUI);
				component.SetEnableCollision(false);
				this.m_CardCompartmentList[num].SetCardOnShelf(component);
				cardUI.m_IgnoreCulling = false;
			}
			num++;
		}
	}

	// Token: 0x06000046 RID: 70 RVA: 0x00005339 File Offset: 0x00003539
	protected override void OnPlacedMovedObject()
	{
		base.OnPlacedMovedObject();
		if (this.m_ObjectType == EObjectType.CardShelf)
		{
			TutorialManager.AddTaskValue(ETutorialTaskCondition.BuyCardShelf, 1f);
		}
	}

	// Token: 0x06000047 RID: 71 RVA: 0x00005358 File Offset: 0x00003558
	protected override void OnStartMoveObject()
	{
		base.OnStartMoveObject();
		for (int i = 0; i < this.m_CardCompartmentList.Count; i++)
		{
			if (this.m_CardCompartmentList[i].m_StoredCardList.Count > 0)
			{
				this.m_CardCompartmentList[i].SetCardVisibility(true);
			}
		}
	}

	// Token: 0x06000048 RID: 72 RVA: 0x000053AC File Offset: 0x000035AC
	public override void BoxUpObject(bool holdBox)
	{
		base.BoxUpObject(holdBox);
		for (int i = 0; i < this.m_CardCompartmentList.Count; i++)
		{
			if (this.m_CardCompartmentList[i].m_StoredCardList.Count > 0)
			{
				this.m_CardCompartmentList[i].SetCardVisibility(false);
			}
		}
	}

	// Token: 0x06000049 RID: 73 RVA: 0x00005404 File Offset: 0x00003604
	public override void OnDestroyed()
	{
		ShelfManager.RemoveCardShelf(this);
		for (int i = 0; i < this.m_CardCompartmentList.Count; i++)
		{
			if (this.m_CardCompartmentList[i])
			{
				this.m_CardCompartmentList[i].DisableAllCard();
			}
		}
		base.OnDestroyed();
	}

	// Token: 0x0600004A RID: 74 RVA: 0x00005458 File Offset: 0x00003658
	public InteractableCardCompartment GetCustomerTargetCardCompartment()
	{
		List<int> list = new List<int>();
		for (int i = 0; i < this.m_CardCompartmentList.Count; i++)
		{
			if (this.m_CardCompartmentList[i].m_StoredCardList.Count > 0)
			{
				list.Add(i);
			}
		}
		if (list.Count > 0)
		{
			int index = list[Random.Range(0, list.Count)];
			return this.m_CardCompartmentList[index];
		}
		return this.m_CardCompartmentList[Random.Range(0, this.m_CardCompartmentList.Count)];
	}

	// Token: 0x0600004B RID: 75 RVA: 0x000054E6 File Offset: 0x000036E6
	public InteractableCardCompartment GetCardCompartment(int index)
	{
		return this.m_CardCompartmentList[index];
	}

	// Token: 0x0600004C RID: 76 RVA: 0x000054F4 File Offset: 0x000036F4
	public List<InteractableCardCompartment> GetCardCompartmentList()
	{
		return this.m_CardCompartmentList;
	}

	// Token: 0x0600004D RID: 77 RVA: 0x000054FC File Offset: 0x000036FC
	public void SetIndex(int index)
	{
		this.m_Index = index;
	}

	// Token: 0x0600004E RID: 78 RVA: 0x00005505 File Offset: 0x00003705
	public int GetIndex()
	{
		return this.m_Index;
	}

	// Token: 0x0600004F RID: 79 RVA: 0x00005510 File Offset: 0x00003710
	public bool HasCardOnShelf()
	{
		for (int i = 0; i < this.m_CardCompartmentList.Count; i++)
		{
			if (this.m_CardCompartmentList[i].m_StoredCardList.Count > 0)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x04000067 RID: 103
	public bool m_ItemNotForSale;

	// Token: 0x04000068 RID: 104
	public List<Transform> m_CardShelfCompartmentGrpList;

	// Token: 0x04000069 RID: 105
	private List<InteractableCardCompartment> m_CardCompartmentList = new List<InteractableCardCompartment>();

	// Token: 0x0400006A RID: 106
	private List<UI_PriceTag> m_UIPriceTagList = new List<UI_PriceTag>();

	// Token: 0x0400006B RID: 107
	private int m_Index;
}
