﻿using System;
using UnityEngine;

// Token: 0x02000116 RID: 278
[Serializable]
public class KeybindBaseKey
{
	// Token: 0x04000F78 RID: 3960
	public EGameBaseKey baseKey;

	// Token: 0x04000F79 RID: 3961
	public KeyCode bindKey;
}
