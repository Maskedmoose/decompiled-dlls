﻿using System;
using I2.Loc;

// Token: 0x02000135 RID: 309
[Serializable]
public class PriceChangeTypeText
{
	// Token: 0x060008EA RID: 2282 RVA: 0x0004129C File Offset: 0x0003F49C
	public string GetName(bool isIncrease)
	{
		if (isIncrease)
		{
			string translation = LocalizationManager.GetTranslation("increase", true, 0, true, false, null, null, true);
			return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true).Replace("XXX", translation);
		}
		string translation2 = LocalizationManager.GetTranslation("decrease", true, 0, true, false, null, null, true);
		return LocalizationManager.GetTranslation(this.name, true, 0, true, false, null, null, true).Replace("XXX", translation2);
	}

	// Token: 0x040010EF RID: 4335
	public string name;

	// Token: 0x040010F0 RID: 4336
	public EPriceChangeType priceChangeType;
}
