﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000059 RID: 89
public class CardRaritySelectScreen : CSingleton<CardRaritySelectScreen>
{
	// Token: 0x060003FD RID: 1021 RVA: 0x0002369C File Offset: 0x0002189C
	public static void OpenScreen(ERarity initCardRarity)
	{
		CSingleton<CardRaritySelectScreen>.Instance.m_CurrentIndex = (int)(initCardRarity + 1);
		for (int i = 0; i < CSingleton<CardRaritySelectScreen>.Instance.m_BtnHighlightList.Count; i++)
		{
			CSingleton<CardRaritySelectScreen>.Instance.m_BtnHighlightList[i].SetActive(false);
		}
		CSingleton<CardRaritySelectScreen>.Instance.m_BtnHighlightList[CSingleton<CardRaritySelectScreen>.Instance.m_CurrentIndex].SetActive(true);
		SoundManager.GenericMenuOpen(1f, 1f);
		CSingleton<CardRaritySelectScreen>.Instance.m_ScreenGrp.SetActive(true);
		ControllerScreenUIExtManager.OnOpenScreen(CSingleton<CardRaritySelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x060003FE RID: 1022 RVA: 0x00023733 File Offset: 0x00021933
	private void CloseScreen()
	{
		this.m_ScreenGrp.SetActive(false);
		ControllerScreenUIExtManager.OnCloseScreen(CSingleton<CardRaritySelectScreen>.Instance.m_ControllerScreenUIExtension);
	}

	// Token: 0x060003FF RID: 1023 RVA: 0x00023750 File Offset: 0x00021950
	public void OnPressButton(int index)
	{
		this.m_CurrentIndex = index + 1;
		CEventManager.QueueEvent(new CEventPlayer_OnCardRaritySelectScreenUpdated(index));
		this.CloseScreen();
		SoundManager.GenericConfirm(1f, 1f);
	}

	// Token: 0x06000400 RID: 1024 RVA: 0x0002377B File Offset: 0x0002197B
	public void OnPressBackButton()
	{
		CEventManager.QueueEvent(new CEventPlayer_OnCardRaritySelectScreenUpdated(this.m_CurrentIndex - 1));
		this.CloseScreen();
		SoundManager.GenericMenuClose(1f, 1f);
	}

	// Token: 0x040004CD RID: 1229
	public ControllerScreenUIExtension m_ControllerScreenUIExtension;

	// Token: 0x040004CE RID: 1230
	public GameObject m_ScreenGrp;

	// Token: 0x040004CF RID: 1231
	public List<GameObject> m_BtnHighlightList;

	// Token: 0x040004D0 RID: 1232
	private int m_CurrentIndex;
}
