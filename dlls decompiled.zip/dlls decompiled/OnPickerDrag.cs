﻿using System;
using UnityEngine;
using UnityEngine.Events;

namespace CC
{
	// Token: 0x020001C1 RID: 449
	[Serializable]
	public class OnPickerDrag : UnityEvent<Vector2>
	{
	}
}
