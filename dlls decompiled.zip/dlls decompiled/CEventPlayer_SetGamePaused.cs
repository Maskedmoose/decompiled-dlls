﻿using System;

// Token: 0x020000AA RID: 170
public class CEventPlayer_SetGamePaused : CEvent
{
	// Token: 0x1700000A RID: 10
	// (get) Token: 0x060006E5 RID: 1765 RVA: 0x00037EF7 File Offset: 0x000360F7
	// (set) Token: 0x060006E6 RID: 1766 RVA: 0x00037EFF File Offset: 0x000360FF
	public bool m_IsPaused { get; private set; }

	// Token: 0x060006E7 RID: 1767 RVA: 0x00037F08 File Offset: 0x00036108
	public CEventPlayer_SetGamePaused(bool isPaused)
	{
		this.m_IsPaused = isPaused;
	}
}
