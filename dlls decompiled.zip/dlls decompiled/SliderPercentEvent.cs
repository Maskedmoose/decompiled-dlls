﻿using System;
using UnityEngine.Events;

// Token: 0x02000125 RID: 293
[Serializable]
public class SliderPercentEvent : UnityEvent<float>
{
}
