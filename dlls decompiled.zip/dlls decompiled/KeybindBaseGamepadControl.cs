﻿using System;

// Token: 0x02000117 RID: 279
[Serializable]
public class KeybindBaseGamepadControl
{
	// Token: 0x04000F7A RID: 3962
	public EGameBaseKey baseKey;

	// Token: 0x04000F7B RID: 3963
	public EGamepadControlBtn ctrlBtn;
}
