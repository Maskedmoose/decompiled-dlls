﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace CMF
{
	// Token: 0x020001E8 RID: 488
	public class DemoMenu : MonoBehaviour
	{
		// Token: 0x06000DA4 RID: 3492 RVA: 0x0005D6C4 File Offset: 0x0005B8C4
		private void Start()
		{
			this.disableShadows = base.GetComponent<DisableShadows>();
			this.fpsCounter = base.GetComponent<FPSCounter>();
			this.SetMenuEnabled(false);
			this.disableShadows.SetShadows(PlayerData.enableShadows);
			this.shadowToggle.isOn = PlayerData.enableShadows;
			for (int i = 0; i < this.controllers.Count; i++)
			{
				this.controllers[i].SetActive(false);
			}
			this.controllers[PlayerData.controllerIndex].SetActive(true);
			if (PlayerData.controllerIndex >= 4)
			{
				this.regularArea.SetActive(false);
			}
			else
			{
				this.topDownArea.SetActive(false);
			}
			ColorBlock colors = this.buttons[PlayerData.controllerIndex].colors;
			colors.normalColor = this.activeButtonColor;
			colors.highlightedColor = this.activeButtonColor;
			colors.pressedColor = this.activeButtonColor;
			this.buttons[PlayerData.controllerIndex].colors = colors;
		}

		// Token: 0x06000DA5 RID: 3493 RVA: 0x0005D7C4 File Offset: 0x0005B9C4
		private void Update()
		{
			if (Input.GetKeyDown(this.menuKey))
			{
				this.SetMenuEnabled(!this.demoMenuObject.activeSelf);
			}
			if (Input.GetKeyDown(KeyCode.Escape))
			{
				this.SetMenuEnabled(!this.demoMenuObject.activeSelf);
			}
			if (Input.GetMouseButtonDown(0) && !this.demoMenuObject.activeSelf)
			{
				Cursor.lockState = CursorLockMode.Locked;
			}
		}

		// Token: 0x06000DA6 RID: 3494 RVA: 0x0005D82C File Offset: 0x0005BA2C
		public void RestartScene()
		{
			SceneManager.LoadScene(SceneManager.GetActiveScene().name);
		}

		// Token: 0x06000DA7 RID: 3495 RVA: 0x0005D84B File Offset: 0x0005BA4B
		public void QuitGame()
		{
			Application.Quit();
		}

		// Token: 0x06000DA8 RID: 3496 RVA: 0x0005D852 File Offset: 0x0005BA52
		public void OnControllerPresetChosen(int _presetIndex)
		{
			PlayerData.controllerIndex = _presetIndex;
			this.RestartScene();
		}

		// Token: 0x06000DA9 RID: 3497 RVA: 0x0005D860 File Offset: 0x0005BA60
		public void SetMenuEnabled(bool _isEnabled)
		{
			this.demoMenuObject.SetActive(_isEnabled);
			if (_isEnabled)
			{
				Cursor.lockState = CursorLockMode.None;
				return;
			}
			Cursor.lockState = CursorLockMode.Locked;
		}

		// Token: 0x06000DAA RID: 3498 RVA: 0x0005D87E File Offset: 0x0005BA7E
		public void SetShadowsEnabled(bool _isEnabled)
		{
			this.disableShadows.SetShadows(_isEnabled);
			PlayerData.enableShadows = _isEnabled;
		}

		// Token: 0x06000DAB RID: 3499 RVA: 0x0005D892 File Offset: 0x0005BA92
		public void SetFrameRateEnabled(bool _isEnabled)
		{
			this.fpsCounter.enabled = _isEnabled;
		}

		// Token: 0x04001498 RID: 5272
		public KeyCode menuKey = KeyCode.C;

		// Token: 0x04001499 RID: 5273
		private DisableShadows disableShadows;

		// Token: 0x0400149A RID: 5274
		private FPSCounter fpsCounter;

		// Token: 0x0400149B RID: 5275
		public GameObject demoMenuObject;

		// Token: 0x0400149C RID: 5276
		public List<GameObject> controllers = new List<GameObject>();

		// Token: 0x0400149D RID: 5277
		public List<Button> buttons = new List<Button>();

		// Token: 0x0400149E RID: 5278
		public Toggle shadowToggle;

		// Token: 0x0400149F RID: 5279
		public GameObject regularArea;

		// Token: 0x040014A0 RID: 5280
		public GameObject topDownArea;

		// Token: 0x040014A1 RID: 5281
		public Color activeButtonColor = Color.cyan;
	}
}
